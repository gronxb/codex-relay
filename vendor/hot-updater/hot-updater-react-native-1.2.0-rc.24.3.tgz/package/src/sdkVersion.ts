export const HOT_UPDATER_SDK_VERSION = "1.2.0-rc.24.3";
