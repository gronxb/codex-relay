import { AnyHotUpdaterPlugin, ConfiguredDatabase, StorageAdapter } from "@hot-updater/plugin-core";
//#region src/index.d.ts
type ConsoleAuthProvider = "google" | "github";
type ConsolePrincipal = Readonly<{
  email: string;
  name?: string | null;
  image?: string | null;
}>;
type ConsoleAccess = {
  status: "unauthenticated";
} | {
  status: "forbidden";
  principal: ConsolePrincipal;
} | {
  status: "authorized";
  principal: ConsolePrincipal;
};
type ConsoleAuthAdapter = Readonly<{
  handle(request: Request): Promise<Response>;
  getAccess(request: Request): Promise<ConsoleAccess>;
  getProviders(request: Request): Promise<readonly ConsoleAuthProvider[]>;
}>;
type HotUpdaterConsoleConfig = Readonly<{
  /**
   * The database your server runs on, such as `dynamoDB(...)`, or
   * `standaloneRepository(...)`, which reaches a self-hosted server through
   * its admin API.
   */
  database: ConfiguredDatabase;
  /** The storage your server lists; the console reads bundle files with it. */
  storage: StorageAdapter;
  /**
   * The plugins your server runs, such as the `plugins` a managed provider
   * package exports or `[insights(), apiKeys()]`. The console runs them over
   * `database` as the server does, and shows only the built-in features of
   * the plugins listed. With `standaloneRepository`, they run on the server,
   * and the console shows the features its admin API serves.
   */
  plugins?: readonly AnyHotUpdaterPlugin[];
  console?: {
    /** The Git repository whose commits the console links bundles to. */
    gitUrl?: string;
    /**
     * The signed-in emails that may approve iPhones and iPads for ad hoc
     * builds, each of which the next build registers with your Apple account
     * and spends one of its yearly device slots on. Left out or empty, nobody
     * approves in this Console: approve from a terminal with
     * `npx hot-updater native-build devices add`. The emails come from the
     * Console's sign-in, so a custom auth adapter must supply verified ones.
     */
    deviceApprovers?: readonly string[];
  };
}>;
type HotUpdaterConsoleConfigSource = HotUpdaterConsoleConfig | ((request: Request) => HotUpdaterConsoleConfig | Promise<HotUpdaterConsoleConfig>);
declare const defineConsoleConfig: <const TConfig extends HotUpdaterConsoleConfigSource>(config: TConfig) => TConfig;
//#endregion
export { ConsoleAccess, ConsoleAuthAdapter, ConsoleAuthProvider, ConsolePrincipal, HotUpdaterConsoleConfig, HotUpdaterConsoleConfigSource, defineConsoleConfig };