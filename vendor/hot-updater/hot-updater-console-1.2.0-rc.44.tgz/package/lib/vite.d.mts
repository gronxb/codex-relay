import { PluginOption } from "vite";
//#region src/vite.d.ts
interface HotUpdaterConsolePluginOptions {
  /** The console's auth module, `console.auth.ts` by default. */
  readonly auth?: string;
  /** The module whose default export is `defineConsoleConfig(...)`, `console.config.ts` by default. */
  readonly config?: string;
}
declare const hotUpdaterConsole: (options?: HotUpdaterConsolePluginOptions) => PluginOption[];
//#endregion
export { HotUpdaterConsolePluginOptions, hotUpdaterConsole };