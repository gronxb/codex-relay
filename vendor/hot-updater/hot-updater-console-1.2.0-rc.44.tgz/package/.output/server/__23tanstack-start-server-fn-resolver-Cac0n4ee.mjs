//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-Cac0n4ee.js
var manifest = {
	"0ccfae64b399b03d820328fa98a38e2caa0b622d3da5a7ca633c5a0e8101e3f6": {
		functionName: "getRemoteConfigRpc_createServerFn_handler",
		importer: () => import("./_ssr/remote-config-rpc-DDdUxgLV.mjs")
	},
	"0d1dacdd1e5ee6b100e5c142fb9af03602b6f2c6fe6af79312b36c223d7f8f97": {
		functionName: "getUpdateFailuresRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-failures-rpc-HwnD8fbl.mjs")
	},
	"1371bff16085636e2c44b60a573ae434b556c63045c40a0a93a93ab69ec47999": {
		functionName: "previewRemoteConfigRpc_createServerFn_handler",
		importer: () => import("./_ssr/remote-config-rpc-DDdUxgLV.mjs")
	},
	"16e3be74610cddd54e5e894419dca16817a7b63c09a4eed15042cdac9c39e1e0": {
		functionName: "getAdoptionReleaseRpc_createServerFn_handler",
		importer: () => import("./_ssr/release-adoption-rpc-nk4ZlZ6I.mjs")
	},
	"17a54fe7c5ad6ca53457914b1d02b3d6887811aa6b5fa6598a1ee107796ce8f0": {
		functionName: "getNativeBuilds_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"1bd85c2a50e24785cb6abb023a247a9f048f37ddfa85cbb1c57e579563bad013": {
		functionName: "getBundle_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"1fc98b1499df6f62eeb3e84712ff4bd12e428d2ddd08880d541463d24ccd0233": {
		functionName: "getNativeBuildFold_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"206547cb1526f961070a989818ca7b9e34f6b2b0e4ab851698c3807fe9fb5e0c": {
		functionName: "getReleases_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"28ea8c9bdbeb67f80c776990bb5bcb5c990f5129520631f241faf074d90fea02": {
		functionName: "getSchemaMigrationRpc_createServerFn_handler",
		importer: () => import("./_ssr/schema-migration-rpc-DhU6zebM.mjs")
	},
	"2b9b8d1f49f79a511589617d8d4bfc6094a3acf5264f33651b9569ba66d3f321": {
		functionName: "createChannel_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"2c7f3cdb9bd3cab2c026a48abdc84c362db0362924a08679052a325640aec56b": {
		functionName: "listApiKeysRpc_createServerFn_handler",
		importer: () => import("./_ssr/api-keys-rpc-B71HN7wb.mjs")
	},
	"2e3fab89483b2e4fea0c2f996071b2dbb15b8bc072e7dae78c75a9a9d854d5b9": {
		functionName: "getNativeBuildPatches_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"3377db68b9d1d971971595469029c0466da0777a177b294d655cd0c039737f1a": {
		functionName: "listRemoteConfigVersionsRpc_createServerFn_handler",
		importer: () => import("./_ssr/remote-config-rpc-DDdUxgLV.mjs")
	},
	"3a62744a539db57f5a29f39cec7fb03fd2817703b40d98e6da69e2f5e7ae6f3d": {
		functionName: "getIosDevices_createServerFn_handler",
		importer: () => import("./_ssr/ios-devices-rpc-Bj59mqiF.mjs")
	},
	"3c04bc6624be6dfdd80cf96819f9c6d0455e59a7bb4c0374b6afb0162ffd15b0": {
		functionName: "listInsightsInstallationEventsRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-rpc-C7McmRcP.mjs")
	},
	"4182bf9ccbb675700638f30bc6122517ccd90b16a339a6823a0f5f6c808d70a6": {
		functionName: "publishRemoteConfigRpc_createServerFn_handler",
		importer: () => import("./_ssr/remote-config-rpc-DDdUxgLV.mjs")
	},
	"4370f1bf70b91f1168d85379d3008449a1bedb915e9878ca4ef89d5f3a80fa7f": {
		functionName: "getBundleChildren_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"4b173c2b2f5ea074a1f10862282308f11f5a043c044d64b6f63e6a29d571ec64": {
		functionName: "createIosDeviceProfileLink_createServerFn_handler",
		importer: () => import("./_ssr/ios-devices-rpc-Bj59mqiF.mjs")
	},
	"4c92dfeae76a6fc898d6f38941eeedaec1f3d118f51a6f31ebf0bb1cea3fcea4": {
		functionName: "renameIosDevice_createServerFn_handler",
		importer: () => import("./_ssr/ios-devices-rpc-Bj59mqiF.mjs")
	},
	"4ca367070b00f58179a572f0bb8196a4ccdd3881e9b1dbfe33deee0cb6e1f549": {
		functionName: "getBundleChildCounts_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"51a34c05479a893c7d320bd4cd1604427289d667698c48b9f30a01aabf8a5e68": {
		functionName: "getConfig_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"52756dde414919a906bfe83d1ab6d29910c63bcafdb47653d6f1df562d958920": {
		functionName: "deleteChannel_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"6726f1ed9eda1f0cb4c1f1ad1023faee435ddcfd0b7c55ef08ca7f2f7f577370": {
		functionName: "getInsightsInstallationRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-rpc-C7McmRcP.mjs")
	},
	"67cea9f69773d83e69e68e20b81116a2bee9ee4ab3e378698ff74149f1d59ad0": {
		functionName: "getNativeBuildInstallEligibility_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"68a2d94ee016be64936401f5eba60ab08a47ff373e1cf9de48e4413336e6034b": {
		functionName: "createApiKeyRpc_createServerFn_handler",
		importer: () => import("./_ssr/api-keys-rpc-B71HN7wb.mjs")
	},
	"7138a71df2ede8dd2c3db732d8d0ae10c56b85a8177dcdacf4e747b8087177c6": {
		functionName: "getIosDevice_createServerFn_handler",
		importer: () => import("./_ssr/ios-devices-rpc-Bj59mqiF.mjs")
	},
	"735c501f6d5ea81a445ff2b6b2ea6a1b589e3c6f63a465a881822c80ae71e7d1": {
		functionName: "findInsightsInstallationsRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-rpc-C7McmRcP.mjs")
	},
	"7908c24ccc2674ce07a553a645b8f4790889975a80f424a05d71a9fb8ab49787": {
		functionName: "approveIosDevice_createServerFn_handler",
		importer: () => import("./_ssr/ios-devices-rpc-Bj59mqiF.mjs")
	},
	"79ada05964de8f2123bfcd62b10097d59bf8fd689ef5c7161031e5871d8396c5": {
		functionName: "getChannels_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"7ea0186f19f9f2bc2ca4b26e3c59636891cf046957f84287b6783f8d88bd8cb7": {
		functionName: "updateRelease_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"82ec3500e57f9e81dac6d3f3a7bd9e34915da3121429beec87b7ad153dc6eafe": {
		functionName: "getConsoleFeaturesRpc_createServerFn_handler",
		importer: () => import("./_ssr/console-features-rpc-BBDAeg2d.mjs")
	},
	"868ce85f0b63ad138a1f82a573d1d6b12f80c7ca44aefec3dadf01b5fa7db86c": {
		functionName: "getReleaseNativeBuild_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"8a98cd9c178e4a54185d62c25a95f09d3d59850c43d3f5baa1563e1614ad942e": {
		functionName: "getAppUsageReportRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-usage-rpc-rhVHNr_s.mjs")
	},
	"8e37ec67413ceba554adb2d4b15e53682595a089d4b431ba7965d4347fb500fc": {
		functionName: "removeIosDevice_createServerFn_handler",
		importer: () => import("./_ssr/ios-devices-rpc-Bj59mqiF.mjs")
	},
	"936ef8582ff49d97077d1d80e8403d0b4106831c955591c5c471a88f96007fe9": {
		functionName: "getNativeBuildDownloadUrl_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"956539a300d79a7efa191c1cc2d529d62fc4bfd940442548fdbc1404e0d53078": {
		functionName: "promoteRelease_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"98c10bdc514eb4d3fe65af546be44452b492a81092cfe45625778a4c9f731727": {
		functionName: "rollbackRemoteConfigRpc_createServerFn_handler",
		importer: () => import("./_ssr/remote-config-rpc-DDdUxgLV.mjs")
	},
	"a11cb4014e6b23528f76382c43684798b0e84a6936aaba02c918e8f4e216e282": {
		functionName: "getNativeBuildIpaDevices_createServerFn_handler",
		importer: () => import("./_ssr/ios-devices-rpc-Bj59mqiF.mjs")
	},
	"a1cb80b19ca72a64fb631ca28ebb9b6941db245983de082d5dd3203ec2eef795": {
		functionName: "revokeApiKeyRpc_createServerFn_handler",
		importer: () => import("./_ssr/api-keys-rpc-B71HN7wb.mjs")
	},
	"a6c8cfa907e2f75bf69aa90044bd52a3ee684d1a0462d23781161a1a3531aa33": {
		functionName: "markNativeBuild_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"a6f23116eeaf76166d405e28a95213123025613c6603030894e519015bf48032": {
		functionName: "getRelease_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"af71e3c55a659ce46093e33b9d70e729359610eec7d576502e8f0e26c785b317": {
		functionName: "getRemoteConfigVersionRpc_createServerFn_handler",
		importer: () => import("./_ssr/remote-config-rpc-DDdUxgLV.mjs")
	},
	"b30a0e32e3e84050037368e4405bfc34507fda8891a64faefe1a7acd019e9f3c": {
		functionName: "getReleaseFold_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"b4388826a9b515fb4d2113270aa8ded1c50ba13d7f07ac2b268c41396e87d0a3": {
		functionName: "listFailureReportsRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-failures-rpc-HwnD8fbl.mjs")
	},
	"b46c95dba95a6a3e8fa5c9d100e3622fa5ae7af4f38e10fb1ed2fa48289a3a8f": {
		functionName: "preflightRelease_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"b4bf4c461903edcdc44eea52468c737b5b600a586f542138ff022dcbbe86c45c": {
		functionName: "getBundleActivityRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-recovery-rpc-DFiuGbxf.mjs")
	},
	"bfcca2365dfef4d071bdcddf97538a2637482c77bb747969dbdcd6769ca98416": {
		functionName: "getBundleEventsRpc_createServerFn_handler",
		importer: () => import("./_ssr/release-adoption-rpc-nk4ZlZ6I.mjs")
	},
	"c101ad0315790cf226f182906274176b64a93b9bf5b410cacec5067208c70a04": {
		functionName: "getNativeBuildDetail_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"c504696e68ba764b48c48aa8a40275938640941e473cf9cfdd7b2322d99f9d13": {
		functionName: "getConsoleAccessRpc_createServerFn_handler",
		importer: () => import("./_ssr/auth-rpc-C4TrAmWn.mjs")
	},
	"c6f18db42ac40385dbff247095197ee9f3fd3a97dc914efd368ce0ded1f098c6": {
		functionName: "getInsightsRetentionRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-rpc-C7McmRcP.mjs")
	},
	"c6ff40bd8faad0b2d7aba3e94179c18e02a918a76bff25849d771ff31f688208": {
		functionName: "createNativeBuildDownloadLink_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"d11a48f7251928b7819e2376aed4902fa66277bf6d30312d87ca53468332f256": {
		functionName: "listAdoptionReleasesRpc_createServerFn_handler",
		importer: () => import("./_ssr/release-adoption-rpc-nk4ZlZ6I.mjs")
	},
	"d4c50f40701055145f24873dc90f3c55a5494457a6a03a743339b2ac4545eb19": {
		functionName: "listInsightsEventsRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-rpc-C7McmRcP.mjs")
	},
	"d5b58722ce514e3b63a377f736b4823c2011782495442ae4870ed547e392c70b": {
		functionName: "deleteRelease_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"e8c24b7247936f045a145ffd5c177fd0e3df3b52769d67dfbd8d1de491d66396": {
		functionName: "getReleaseCatalogDiagnostics_createServerFn_handler",
		importer: () => import("./_ssr/api-rpc-C1CJ-QWs.mjs")
	},
	"fa8c48f0489d97c62b9b68fd0caf0a61b15bad25a42b3866ec36264b4b30bb74": {
		functionName: "getConsoleAuthProvidersRpc_createServerFn_handler",
		importer: () => import("./_ssr/auth-rpc-C4TrAmWn.mjs")
	},
	"ff00311d412c8cdfa8ad5b0ba1eb6aa7471d0cc12170e6cc645deb91603d42dd": {
		functionName: "getReportingInstallationsRpc_createServerFn_handler",
		importer: () => import("./_ssr/insights-rpc-C7McmRcP.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
