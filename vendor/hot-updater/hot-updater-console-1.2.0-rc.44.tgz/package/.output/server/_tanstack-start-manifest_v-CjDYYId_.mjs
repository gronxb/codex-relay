//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CjDYYId_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/__root.tsx",
		children: [
			"/",
			"/api-keys",
			"/insights",
			"/installations",
			"/native-builds",
			"/remote-config",
			"/insights_/distribution",
			"/native-builds_/$buildId",
			"/native-builds_/devices",
			"/_hot-updater/devices/device-response",
			"/_hot-updater/devices/device.mobileconfig",
			"/_hot-updater/devices/receipt",
			"/_hot-updater/devices/request",
			"/api/auth/$",
			"/_hot-updater/native-builds/$buildId/manifest.plist",
			"/api/bundles/$bundleId/download",
			"/api/native-builds/$buildId/download"
		],
		preloads: [
			"/assets/index-BHt1lVdq.js",
			"/assets/sidebar-BmzmPGuv.js",
			"/assets/useCompositeListItem-BEDqZ9Ni.js",
			"/assets/link-CRMwpc7-.js",
			"/assets/remote-config-DfUXmtPZ.js",
			"/assets/alert-dialog-DGPqJBCk.js",
			"/assets/select-iSWTEY9t.js",
			"/assets/useAnchoredPopupScrollLock-Cvx6CdPD.js",
			"/assets/check-C3VCvMOV.js",
			"/assets/chevron-down-BkoJHAll.js",
			"/assets/tabs-Byfy8Qls.js",
			"/assets/CompositeItem-UhIlCBg4.js",
			"/assets/switch-ByNYRVTN.js",
			"/assets/useMutation-D7IuoOLE.js",
			"/assets/console-features-api-CtbGqKyr.js",
			"/assets/relativeTime-RUNbaMyO.js",
			"/assets/arrow-right-DjRwIoF1.js",
			"/assets/clipboard-D0JWZ1KF.js",
			"/assets/git-branch-BGatQV8Q.js",
			"/assets/history-Ci4dhphE.js",
			"/assets/loader-circle-8lunBReu.js",
			"/assets/plus-DztQIXYL.js",
			"/assets/dist-BEmib-ZM.js",
			"/assets/rotate-ccw-tITIe0Bd.js",
			"/assets/search-BfEqtE64.js",
			"/assets/smartphone-Dy13ukaU.js",
			"/assets/trash-2-DI0biNI-.js",
			"/assets/badge-zMibJGR5.js",
			"/assets/undo-2-CxhBbgJw.js",
			"/assets/PlatformIcon-D4KPXCHL.js",
			"/assets/card-BAs80yql.js",
			"/assets/dialog-BvZDZzdQ.js",
			"/assets/empty-C5GqArX9.js",
			"/assets/field-DInLQ5oV.js",
			"/assets/input-group-CIjTdxCW.js",
			"/assets/api-B-1SpJeB.js",
			"/assets/arrow-up-right-C_1ALUCD.js",
			"/assets/routes-C047Z4F3.js",
			"/assets/insights-api-C4Dmm34n.js",
			"/assets/key-round-BkeLvA1m.js",
			"/assets/insights-search-CfbhmuFL.js",
			"/assets/constants-C5gi7fdZ.js",
			"/assets/native-builds_._buildId-2cLz1YM1.js",
			"/assets/-native-builds-search-BFcW2mlI.js",
			"/assets/copy-BjVLMKbo.js",
			"/assets/native-builds-zwqucwx2.js",
			"/assets/rotate-cw-BFQcpUTO.js",
			"/assets/NotFoundPage-BEpesHEm.js",
			"/assets/IosInstall-DvV3pRKv.js",
			"/assets/installations-DlTdbNgY.js",
			"/assets/insights-CSHfYaU4.js",
			"/assets/insights_.distribution-CzuSRyqb.js",
			"/assets/native-builds-DhwYkLmx.js",
			"/assets/native-builds_.devices-Bet7RN0x.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BHt1lVdq.js"
		} }]
	},
	"/": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BHP1sMv1.js",
			"/assets/ChannelPicker-Ck8vBdjI.js",
			"/assets/valueToPercent-Db73Kirz.js",
			"/assets/TargetDisplay-DG_I3qln.js",
			"/assets/HashValueDisplay-DvwvQchI.js",
			"/assets/chevron-right-RAuPv9r1.js",
			"/assets/circle-off-DvYMC5yF.js",
			"/assets/download-CgpaZb23.js",
			"/assets/list-DQ9YBIDW.js",
			"/assets/BundleIdDisplay-C0X-k49t.js",
			"/assets/ChannelBadge-BgVCJfJs.js",
			"/assets/RelativeTime-5ZP9WlQ6.js",
			"/assets/table-DbZPkzdz.js",
			"/assets/RowReason-CXMCJ-Jc.js",
			"/assets/RolloutPercentageBadge-DCtG7c1o.js"
		]
	},
	"/api-keys": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/api-keys.tsx",
		children: void 0,
		preloads: [
			"/assets/api-keys-CAVLgicI.js",
			"/assets/ConsoleFeatureUnavailable-B3VCINom.js",
			"/assets/api-keys-ztwXoKcj.js",
			"/assets/table-DbZPkzdz.js"
		]
	},
	"/insights": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/insights.tsx",
		children: void 0,
		preloads: [
			"/assets/insights-V3D8tYPQ.js",
			"/assets/ConsoleFeatureUnavailable-B3VCINom.js",
			"/assets/insights-nnyldFdS.js",
			"/assets/ChannelPicker-Ck8vBdjI.js",
			"/assets/insights-usage-rpc-Dw5_pmRH.js",
			"/assets/valueToPercent-Db73Kirz.js",
			"/assets/EventDetails-BGglj3Ap.js",
			"/assets/download-CgpaZb23.js",
			"/assets/HashValueDisplay-DvwvQchI.js",
			"/assets/InsightsPageHeader-ypKKV3rL.js",
			"/assets/list-DQ9YBIDW.js",
			"/assets/chevron-right-RAuPv9r1.js",
			"/assets/circle-off-DvYMC5yF.js",
			"/assets/BundleIdDisplay-C0X-k49t.js",
			"/assets/table-DbZPkzdz.js"
		]
	},
	"/installations": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/installations.tsx",
		children: void 0,
		preloads: [
			"/assets/installations-BHWbfpbI.js",
			"/assets/EventDetails-BGglj3Ap.js",
			"/assets/download-CgpaZb23.js",
			"/assets/HashValueDisplay-DvwvQchI.js",
			"/assets/InsightsPageHeader-ypKKV3rL.js",
			"/assets/list-DQ9YBIDW.js",
			"/assets/arrow-left-68S4uy4I.js",
			"/assets/table-DbZPkzdz.js",
			"/assets/installations-CcPrSZwW.js",
			"/assets/ConsoleFeatureUnavailable-B3VCINom.js"
		]
	},
	"/native-builds": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/native-builds.tsx",
		children: void 0,
		preloads: [
			"/assets/native-builds-DDTZlyLe.js",
			"/assets/ChannelPicker-Ck8vBdjI.js",
			"/assets/TargetDisplay-DG_I3qln.js",
			"/assets/HashValueDisplay-DvwvQchI.js",
			"/assets/ChannelBadge-BgVCJfJs.js",
			"/assets/RelativeTime-5ZP9WlQ6.js",
			"/assets/chevron-right-RAuPv9r1.js",
			"/assets/table-DbZPkzdz.js",
			"/assets/RowReason-CXMCJ-Jc.js",
			"/assets/NativeBuildsNav-ChBahvFN.js",
			"/assets/SandboxBadge-PM92jCk6.js"
		]
	},
	"/remote-config": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/remote-config.tsx",
		children: void 0,
		preloads: [
			"/assets/remote-config-BIIj0Faf.js",
			"/assets/ConsoleFeatureUnavailable-B3VCINom.js",
			"/assets/remote-config-C7grLPjp.js"
		]
	},
	"/insights_/distribution": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/insights_.distribution.tsx",
		children: void 0,
		preloads: [
			"/assets/insights_.distribution-7l1cAZVo.js",
			"/assets/insights-usage-rpc-Dw5_pmRH.js",
			"/assets/valueToPercent-Db73Kirz.js",
			"/assets/arrow-left-68S4uy4I.js",
			"/assets/BundleIdDisplay-C0X-k49t.js",
			"/assets/InsightsPageHeader-ypKKV3rL.js",
			"/assets/list-DQ9YBIDW.js",
			"/assets/insights_.distribution-oIFSv2TC.js",
			"/assets/ConsoleFeatureUnavailable-B3VCINom.js"
		]
	},
	"/native-builds_/$buildId": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/native-builds_.$buildId.tsx",
		children: void 0,
		preloads: [
			"/assets/native-builds_._buildId-C4ZAkDN_.js",
			"/assets/TargetDisplay-DG_I3qln.js",
			"/assets/HashValueDisplay-DvwvQchI.js",
			"/assets/chevron-right-RAuPv9r1.js",
			"/assets/download-CgpaZb23.js",
			"/assets/QrCode-BFSCkbPj.js",
			"/assets/BundleIdDisplay-C0X-k49t.js",
			"/assets/ChannelBadge-BgVCJfJs.js",
			"/assets/RolloutPercentageBadge-DCtG7c1o.js",
			"/assets/NativeBuildsNav-ChBahvFN.js",
			"/assets/SandboxBadge-PM92jCk6.js",
			"/assets/table-DbZPkzdz.js"
		]
	},
	"/native-builds_/devices": {
		filePath: "/Volumes/SSD_2TB/.t3/worktrees/hot-updater/t3-f56386c9-13c97d7af1009d4a/packages/console/src/routes/native-builds_.devices.tsx",
		children: void 0,
		preloads: [
			"/assets/native-builds_.devices-C0ebsrcu.js",
			"/assets/TargetDisplay-DG_I3qln.js",
			"/assets/HashValueDisplay-DvwvQchI.js",
			"/assets/QrCode-BFSCkbPj.js",
			"/assets/RelativeTime-5ZP9WlQ6.js",
			"/assets/chevron-right-RAuPv9r1.js",
			"/assets/table-DbZPkzdz.js",
			"/assets/NativeBuildsNav-ChBahvFN.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
