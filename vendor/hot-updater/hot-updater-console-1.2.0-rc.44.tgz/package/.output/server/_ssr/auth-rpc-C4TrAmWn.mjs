import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
import { i as getRequest } from "./server-CUH0Oy00.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-rpc-C4TrAmWn.js
var getConsoleAccessRpc_createServerFn_handler = createServerRpc({
	id: "c504696e68ba764b48c48aa8a40275938640941e473cf9cfdd7b2322d99f9d13",
	name: "getConsoleAccessRpc",
	filename: "src/lib/auth-rpc.ts"
}, (opts) => getConsoleAccessRpc.__executeServer(opts));
var getConsoleAccessRpc = createServerFn({ method: "GET" }).handler(getConsoleAccessRpc_createServerFn_handler, async () => {
	const { getConsoleAccess } = await import("./auth.server-BtwE9LLM.mjs");
	return getConsoleAccess(getRequest());
});
var getConsoleAuthProvidersRpc_createServerFn_handler = createServerRpc({
	id: "fa8c48f0489d97c62b9b68fd0caf0a61b15bad25a42b3866ec36264b4b30bb74",
	name: "getConsoleAuthProvidersRpc",
	filename: "src/lib/auth-rpc.ts"
}, (opts) => getConsoleAuthProvidersRpc.__executeServer(opts));
var getConsoleAuthProvidersRpc = createServerFn({ method: "GET" }).handler(getConsoleAuthProvidersRpc_createServerFn_handler, async () => {
	const { getConsoleAuthProviders } = await import("./auth.server-BtwE9LLM.mjs");
	return getConsoleAuthProviders(getRequest());
});
//#endregion
export { getConsoleAccessRpc_createServerFn_handler, getConsoleAuthProvidersRpc_createServerFn_handler };
