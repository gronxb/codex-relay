import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { at as ArrowLeft, h as RotateCw, nt as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { C as Skeleton, O as buttonVariants, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as CardHeader, i as CardFooter, n as CardContent, o as CardTitle, t as Card } from "./card-CsUxqR3-.mjs";
import { a as Badge, i as AlertTitle, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { a as FieldLabel, t as Field } from "./field-BVbdqLG6.mjs";
import { i as useQuery } from "../_libs/tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as EmptyHeader, o as EmptyTitle, r as EmptyDescription, t as Empty } from "./empty-qtSrrSOA.mjs";
import { a as validateInsightsSearch, t as InfoTooltip } from "./insights-search-BZ00lACC.mjs";
import { l as useInsightsRetention, r as keepsTwelveMonths } from "./insights-api-DGzoZoEY.mjs";
import { t as PlatformIcon } from "./PlatformIcon-C22qEcwo.mjs";
import { a as SelectTrigger, i as SelectItem, n as SelectContent, o as SelectValue, r as SelectGroup, t as Select$1 } from "./select-DYhN8vLu.mjs";
import { t as BundleIdDisplay } from "./BundleIdDisplay-LgsZ_E0k.mjs";
import { n as getAppUsageReportRpc, t as Progress$1 } from "./insights-usage-rpc-CUpYkwHr.mjs";
import { n as InsightsErrorAlert, o as UsagePeriodSelector, r as InsightsPageHeader, t as BuiltinBundleBadge } from "./InsightsPageHeader-DdY_p5TY.mjs";
import { t as Route } from "./insights_.distribution-C-cLCobe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights_.distribution-CswHCPCC.js
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 20;
var dates = new Intl.DateTimeFormat("en", {
	month: "short",
	day: "numeric",
	timeZone: "UTC"
});
/** How a distribution row's bundle reads aloud. */
var bundleName = (row) => row.releaseId ?? (row.builtinBundleId ? `Built-in bundle ${row.builtinBundleId}` : "Unknown bundle");
/** The bundle an app version's native build shipped, by its ID. */
function BuiltinBundle({ bundleId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-11 min-w-0 flex-wrap items-center gap-2 md:min-h-9",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuiltinBundleBadge, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
			bundleId,
			className: "text-muted-foreground"
		})]
	});
}
function DistributionPage() {
	const search = Route.useSearch();
	const retention = useInsightsRetention();
	const navigate = Route.useNavigate();
	const input = {
		platform: search.platform ?? "all",
		channel: search.channel ?? "production",
		appVersion: search.appVersion,
		window: search.window ?? "24h"
	};
	const query = useQuery({
		queryKey: [
			"insights",
			"app-usage",
			input
		],
		queryFn: () => getAppUsageReportRpc({ data: input }),
		staleTime: 3e4
	});
	const report = query.error ? void 0 : query.data;
	const distributionPeriod = report ? `since ${dates.format(report.distributionSinceMs)}, 00:00 UTC` : "in this period";
	const rows = (report?.bundleDistribution ?? []).filter((row) => !search.version || row.appVersion === search.version);
	const total = rows.reduce((sum, row) => sum + row.installations, 0);
	const pageCount = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
	const page = Math.min(search.page ?? 1, pageCount);
	const versions = [...new Set([...report?.versions.map((row) => row.name) ?? [], ...search.version ? [search.version] : []])];
	const overviewSearch = validateInsightsSearch(search);
	const changeSearch = (next) => void navigate({ search: {
		...search,
		page: void 0,
		...next
	} });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsPageHeader, {
			view: "distribution",
			overviewSearch
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 min-w-0 flex-1 overflow-y-auto bg-muted/5 px-4 py-6 sm:p-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-6xl flex-col gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/insights",
						search: overviewSearch,
						className: buttonVariants({
							variant: "ghost",
							className: "h-11 w-fit sm:h-9"
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
							"aria-hidden": "true",
							"data-icon": "inline-start"
						}), "Back to overview"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold tracking-tight",
							children: "Distribution"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsagePeriodSelector, {
								twelveMonths: keepsTwelveMonths(retention),
								window: input.window,
								onWindowChange: (window) => changeSearch({ window })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
								"aria-label": "Refresh distribution",
								variant: "ghost",
								size: "icon",
								className: "size-11 sm:size-9",
								disabled: query.isFetching,
								onClick: () => void query.refetch(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { "aria-hidden": "true" })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
							className: "w-full sm:w-64",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
								htmlFor: "distribution-version",
								children: "App version"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select$1, {
								items: Object.fromEntries([["all", "All versions"], ...versions.map((version) => [`version:${version}`, version])]),
								value: search.version ? `version:${search.version}` : "all",
								onValueChange: (value) => {
									if (value !== null) changeSearch({ version: value === "all" ? void 0 : value.slice(8) });
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									id: "distribution-version",
									className: "min-h-11 w-full sm:min-h-9",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "all",
									children: "All versions"
								}), versions.map((version) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: `version:${version}`,
									children: version
								}, version))] }) })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-9 flex-wrap items-center gap-2",
							"aria-label": "Distribution scope",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "gap-1.5",
									children: [input.platform !== "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
										platform: input.platform,
										className: "size-3.5"
									}) : null, input.platform === "all" ? "All platforms" : input.platform === "ios" ? "iOS" : "Android"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: input.channel
								}),
								input.appVersion ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									children: ["Reports from ", input.appVersion]
								}) : null
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						"aria-label": "Bundles by app version",
						role: "region",
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
								className: "flex flex-col gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Bundles by app version" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoTooltip, {
										label: "How bundle distribution is counted",
										children: [
											"Each installation counts once, by its latest report",
											" ",
											distributionPeriod,
											". Shares are within each app version. Built-in bundle: the bundle the native build shipped, by its ID. Unknown bundle: no deployment and no built-in bundle ID."
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-baseline gap-x-3 gap-y-1",
									children: [query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-9 w-16" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-3xl font-semibold tabular-nums",
										children: report ? `${report.truncated ? "≥" : ""}${total.toLocaleString()}` : "—"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted-foreground",
										children: "Reporting installations"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "flex min-w-0 flex-col gap-4",
								children: [report?.truncated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Partial history" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, { children: [
									"Counts and shares reflect reports since",
									" ",
									new Date(report.sinceMs).toLocaleString("en", { timeZone: "UTC" }),
									" ",
									"UTC. Choose a shorter period for a more complete view."
								] })] }) : null, query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
									"aria-label": "Loading bundle distribution",
									className: "h-64"
								}) : query.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-start gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
										error: query.error,
										fallbackTitle: "Distribution unavailable"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
										variant: "outline",
										onClick: () => void query.refetch(),
										children: "Retry distribution"
									})]
								}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "No bundles reported" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: "Choose another version or period, or change the filters in the overview." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
									variant: "outline",
									onClick: () => changeSearch({ version: void 0 }),
									children: "Show all versions"
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										"aria-hidden": "true",
										className: "hidden grid-cols-[8rem_minmax(0,1fr)_7rem_7rem] gap-4 border-b px-3 pb-3 text-xs text-muted-foreground md:grid",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "App version" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Bundle ID" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-right",
												children: "Active installations"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-right",
												children: "Version share"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										"aria-label": "Bundle distribution",
										className: "divide-y",
										children: rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE).map((row) => {
											const versionTotal = report?.versions.find((version) => version.name === row.appVersion)?.installations ?? 0;
											const share = versionTotal > 0 ? row.installations / versionTotal * 100 : 0;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "grid min-w-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-x-4 gap-y-3 px-1 py-4 md:grid-cols-[8rem_minmax(0,1fr)_7rem_7rem] md:px-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex min-w-0 flex-col gap-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "truncate text-sm font-medium",
															title: row.appVersion,
															children: row.appVersion
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "flex items-center gap-1.5 text-xs text-muted-foreground",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
																platform: row.platform,
																className: "size-3.5"
															}), row.platform === "ios" ? "iOS" : "Android"]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "col-span-2 row-start-2 min-w-0 md:col-span-1 md:row-auto",
														children: [row.releaseId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
															to: "/",
															search: { releaseId: row.releaseId },
															"aria-label": `Review bundle ${row.releaseId} for app version ${row.appVersion}`,
															className: "flex min-h-11 min-w-0 items-center gap-2 text-xs underline-offset-4 hover:underline md:min-h-9",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "break-all font-mono",
																children: row.releaseId
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
																"aria-hidden": "true",
																className: "size-3.5 shrink-0"
															})]
														}) : row.builtinBundleId ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-sm text-muted-foreground",
															children: "Unknown bundle"
														}), row.builtinBundleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuiltinBundle, { bundleId: row.builtinBundleId }) : null]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "col-start-2 row-start-1 text-right md:col-auto md:row-auto",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-sm font-medium tabular-nums",
																children: row.installations.toLocaleString()
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "ml-1 text-xs text-muted-foreground md:sr-only",
																children: "active"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																className: "mt-1 text-xs tabular-nums text-muted-foreground md:hidden",
																children: [share.toFixed(1), "% of version"]
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "hidden flex-col gap-2 md:flex",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-right text-sm tabular-nums",
															children: [share.toFixed(1), "%"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress$1, {
															"aria-label": `${bundleName(row)} share in ${row.appVersion} on ${row.platform}`,
															value: share
														})]
													})
												]
											}, JSON.stringify([
												row.appVersion,
												row.platform,
												row.releaseId,
												row.builtinBundleId
											]));
										})
									})]
								})]
							}),
							report && rows.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardFooter, {
								className: "flex flex-wrap items-center justify-between gap-3 border-t pt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs tabular-nums text-muted-foreground",
									children: [
										(page - 1) * PAGE_SIZE + 1,
										"–",
										Math.min(page * PAGE_SIZE, rows.length),
										" of ",
										rows.length
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
									"aria-label": "Distribution pages",
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
										variant: "outline",
										className: "h-11 sm:h-9",
										disabled: page <= 1,
										onClick: () => changeSearch({ page: page - 1 }),
										children: "Previous"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
										variant: "outline",
										className: "h-11 sm:h-9",
										disabled: page >= pageCount,
										onClick: () => changeSearch({ page: page + 1 }),
										children: "Next"
									})]
								})]
							}) : null
						]
					})
				]
			})
		})]
	});
}
//#endregion
export { DistributionPage as component };
