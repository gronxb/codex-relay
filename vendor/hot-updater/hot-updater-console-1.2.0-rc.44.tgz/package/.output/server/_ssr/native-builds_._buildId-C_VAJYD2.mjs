import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as validateNativeBuildDetailSearch } from "./-native-builds-search-Bwt8tQzp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-builds_._buildId-C_VAJYD2.js
var $$splitComponentImporter = () => import("./native-builds_._buildId-CgMdfezh.mjs");
var Route = createFileRoute("/native-builds_/$buildId")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	validateSearch: validateNativeBuildDetailSearch
});
//#endregion
export { Route as t };
