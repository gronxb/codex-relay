import { r as recoveryWindows, t as insightsPeriodEnd } from "./insights-recovery-Cdg3Msrj.mjs";
import { t as readAppUsageInput } from "./insights-usage-BVm7CDw9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insightsUsage-lPKyRC2o.js
var DAY_MS = 864e5;
var WEEK_MS = 7 * DAY_MS;
/**
* What a period reads, ending with the current hour. The 12-month period is
* 52 weeks of whole UTC days, the last one today, so it reads the daily
* counts: the hourly ones are kept 90 days.
*/
var usageRange = (window, now) => {
	const end = insightsPeriodEnd(now);
	if (window === "12m") {
		const lastDay = Math.ceil(end / DAY_MS) * DAY_MS;
		return {
			start: Math.max(0, lastDay - 52 * WEEK_MS),
			end,
			intervalMs: WEEK_MS
		};
	}
	const { durationMs, intervalMs } = recoveryWindows[window];
	return {
		start: Math.max(0, end - durationMs),
		end,
		intervalMs
	};
};
async function getAppUsageReport(model, input, now = Date.now()) {
	readAppUsageInput(input);
	const { start, end, intervalMs } = usageRange(input.window, now);
	const report = await model.getAppUsage({
		channel: input.channel,
		platform: input.platform,
		...input.appVersion === void 0 ? {} : { appVersion: input.appVersion },
		timeRange: {
			start,
			end
		},
		intervalMs
	});
	return {
		bundleDistribution: report.bundleDistribution,
		activeInstallations: report.activeInstallations,
		sinceMs: report.coverage.sinceMs === null ? start : Math.max(start, report.coverage.sinceMs),
		distributionSinceMs: start - start % DAY_MS,
		beforeReceivedAtMs: end,
		intervalMs,
		truncated: report.coverage.kind === "partial",
		appVersions: report.appVersions,
		versions: report.versions,
		platforms: report.platforms,
		points: report.points
	};
}
//#endregion
export { getAppUsageReport };
