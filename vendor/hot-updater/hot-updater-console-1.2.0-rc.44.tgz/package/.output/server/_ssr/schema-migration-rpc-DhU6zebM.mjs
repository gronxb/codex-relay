import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schema-migration-rpc-DhU6zebM.js
/** Compares dotted numeric versions, such as "1" and "1.2.0"; NaN when either is not one. */
var compareVersions = (left, right) => {
	const parse = (version) => version.split(".").map(Number);
	const [a, b] = [parse(left), parse(right)];
	if ([...a, ...b].some(Number.isNaN)) return NaN;
	for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
		const difference = (a[index] ?? 0) - (b[index] ?? 0);
		if (difference !== 0) return difference;
	}
	return 0;
};
/** The brand Hot Updater's own plugin factories set, read as the server reads it. */
var OFFICIAL = Symbol.for("@hot-updater/server/official-plugin");
/**
* Whether a migration moves a setting forward: a missing one, or an older
* version of core's or of one of Hot Updater's own plugins. Another plugin's
* changed tables need its own migration.
*/
var migrates = ({ key, expected, found }, official) => found === null || (key === "schema.core" || official.has(key)) && compareVersions(found, expected) < 0;
/**
* The fence's refusal in `error`, recognized by name: plugin-core may be
* another copy than the console's. Null for any other error.
*/
var schemaMigrationOf = (error, plugins = []) => {
	if (!(error instanceof Error) || error.name !== "HotUpdaterSchemaMigrationRequiredError") return null;
	const official = new Set(plugins.flatMap((plugin) => typeof plugin === "object" && plugin !== null && Reflect.get(plugin, OFFICIAL) === true ? [`schema.${String(Reflect.get(plugin, "id"))}`] : []));
	const { settings = [], plugins: refused = [], currentVersion } = error;
	return {
		message: error.message,
		settings: settings.map(({ key, expected, found }) => ({
			key,
			expected,
			found
		})),
		plugins: [...refused],
		migratable: currentVersion === void 0 && settings.length > 0 && settings.every((setting) => migrates(setting, official))
	};
};
/**
* Whether the schema fence refuses the console's database, and what it
* found: one read through core, which the console makes only after a page's
* read failed. Null when the read passes or fails for another reason, which
* the page reports itself.
*/
var getSchemaMigrationRpc_createServerFn_handler = createServerRpc({
	id: "28ea8c9bdbeb67f80c776990bb5bcb5c990f5129520631f241faf074d90fea02",
	name: "getSchemaMigrationRpc",
	filename: "src/lib/schema-migration-rpc.ts"
}, (opts) => getSchemaMigrationRpc.__executeServer(opts));
var getSchemaMigrationRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(getSchemaMigrationRpc_createServerFn_handler, async () => {
	const { prepareConfig } = await import("./config.server-CvAlgb8E.mjs");
	const { config, core } = await prepareConfig();
	try {
		await core.listChannels();
		return null;
	} catch (error) {
		return schemaMigrationOf(error, config.plugins);
	}
});
//#endregion
export { getSchemaMigrationRpc_createServerFn_handler };
