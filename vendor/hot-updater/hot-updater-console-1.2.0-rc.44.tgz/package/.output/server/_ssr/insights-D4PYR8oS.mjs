import { i as __toESM } from "../_runtime.mjs";
import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { Et as require_react, Tt as require_jsx_runtime, d as ScrollAreaThumb, f as ScrollAreaScrollbar, m as ScrollAreaRoot, p as ScrollAreaViewport, u as ScrollAreaCorner } from "../_libs/@base-ui/react+[...].mjs";
import { J as ChevronRight, O as List, V as Copy, W as CircleOff, _ as RefreshCw, g as RotateCcw, h as RotateCw, i as TriangleAlert, nt as ArrowUpRight, r as Undo2, rt as ArrowRight, t as X } from "../_libs/lucide-react.mjs";
import { A as createSsrRpc, C as Skeleton, O as buttonVariants, a as SheetContent, c as SheetTitle, i as Sheet, k as cn, l as SheetTrigger, o as SheetDescription, r as Separator$1, s as SheetHeader, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as CardHeader, i as CardFooter, n as CardContent, o as CardTitle, r as CardDescription, t as Card } from "./card-CsUxqR3-.mjs";
import { a as Badge, i as AlertTitle, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { a as AlertDialogDescription, i as AlertDialogContent, l as AlertDialogTitle, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog$1 } from "./alert-dialog-ByY_ghMv.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-4qgdiham.mjs";
import { a as useQueries, i as useQuery, s as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as EmptyHeader, n as EmptyContent, o as EmptyTitle, r as EmptyDescription, t as Empty } from "./empty-qtSrrSOA.mjs";
import { s as isUUIDv7 } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
import { r as recoveryWindows, t as insightsPeriodEnd } from "./insights-recovery-Cdg3Msrj.mjs";
import { a as failureReasonLabel, i as failureRate, o as failureStageLabel, r as failureDetailParts, s as formatRate, t as checkFailureRate } from "./insights-failures-DGO2_3Vx.mjs";
import { t as groupFailureReports } from "./insights-errors-DwUaDs0Z.mjs";
import { n as usageMetrics } from "./insights-usage-BVm7CDw9.mjs";
import { a as readAdoptionReleasesInput, i as readAdoptionReleaseInput, n as crashRateOf, o as readBundleEventsInput, r as defaultAdoptionReleases, s as recommendsRollback, t as CRASH_RATE_THRESHOLD } from "./release-adoption-gfhE5tz5.mjs";
import { r as comparedBundleIds, t as InfoTooltip } from "./insights-search-BZ00lACC.mjs";
import { i as useFailureReportsQuery, l as useInsightsRetention, r as keepsTwelveMonths, t as DEFAULT_INSIGHTS_RETENTION, u as useUpdateFailuresQuery } from "./insights-api-DGzoZoEY.mjs";
import { _ as usePreflightReleaseMutation, w as useUpdateReleaseMutation } from "./api-BISxaFip.mjs";
import { n as DEFAULT_CHANNEL } from "./constants-BjsJZqaU.mjs";
import { t as Route } from "./insights-Cq1Qojom.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs$1 } from "./tabs-Bw-XniPE.mjs";
import { t as PlatformIcon } from "./PlatformIcon-C22qEcwo.mjs";
import { a as SelectTrigger, i as SelectItem, n as SelectContent, o as SelectValue, r as SelectGroup, t as Select$1 } from "./select-DYhN8vLu.mjs";
import { t as BundleIdDisplay } from "./BundleIdDisplay-LgsZ_E0k.mjs";
import { a as ComboboxEmpty, c as ComboboxItem, d as ComboboxTrigger, f as FilterChip, i as ComboboxContent, l as ComboboxLabel, n as Combobox$1, o as ComboboxGroup, r as ComboboxCollection, s as ComboboxInput, t as ChannelPicker, u as ComboboxList } from "./ChannelPicker-DNX6PX8b.mjs";
import { n as getAppUsageReportRpc, t as Progress$1 } from "./insights-usage-rpc-CUpYkwHr.mjs";
import { i as InsightsPeriodSelector, n as InsightsErrorAlert, o as UsagePeriodSelector, r as InsightsPageHeader } from "./InsightsPageHeader-DdY_p5TY.mjs";
import { i as HttpResponseBody, n as EventTimestamp, o as useInsightsTimeFormat, t as EventBundleTransition } from "./EventDetails-DNlQeQSr.mjs";
import { a as CartesianGrid, i as Line, l as ResponsiveContainer, n as YAxis, o as ReferenceLine, r as XAxis, s as Tooltip, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-D4PYR8oS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var THEMES = {
	light: "",
	dark: ".dark"
};
var INITIAL_DIMENSION = {
	width: 320,
	height: 200
};
var ChartContext = import_react.createContext(null);
function useChart() {
	const context = import_react.useContext(ChartContext);
	if (!context) throw new Error("useChart must be used within a <ChartContainer />");
	return context;
}
function ChartContainer({ id, className, children, config, initialDimension = INITIAL_DIMENSION, ...props }) {
	const uniqueId = import_react.useId();
	const chartId = `chart-${id ?? uniqueId.replace(/:/g, "")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContext.Provider, {
		value: { config },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			"data-slot": "chart",
			"data-chart": chartId,
			className: cn("flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-hidden [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector]:outline-hidden [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-surface]:outline-hidden", className),
			...props,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartStyle, {
				id: chartId,
				config
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				initialDimension,
				children
			})]
		})
	});
}
var ChartStyle = ({ id, config }) => {
	const colorConfig = Object.entries(config).filter(([, config]) => config.theme ?? config.color);
	if (!colorConfig.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { dangerouslySetInnerHTML: { __html: Object.entries(THEMES).map(([theme, prefix]) => `
${prefix} [data-chart=${id}] {
${colorConfig.map(([key, itemConfig]) => {
		const color = itemConfig.theme?.[theme] ?? itemConfig.color;
		return color ? `  --color-${key}: ${color};` : null;
	}).join("\n")}
}
`).join("\n") } });
};
var ChartTooltip = Tooltip;
function ChartTooltipContent({ active, payload, className, indicator = "dot", hideLabel = false, hideIndicator = false, label, labelFormatter, labelClassName, formatter, color, nameKey, labelKey }) {
	const { config } = useChart();
	const tooltipLabel = import_react.useMemo(() => {
		if (hideLabel || !payload?.length) return null;
		const [item] = payload;
		const itemConfig = getPayloadConfigFromPayload(config, item, `${labelKey ?? item?.dataKey ?? item?.name ?? "value"}`);
		const value = !labelKey && typeof label === "string" ? config[label]?.label ?? label : itemConfig?.label;
		if (labelFormatter) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("font-medium", labelClassName),
			children: labelFormatter(value, payload)
		});
		if (!value) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("font-medium", labelClassName),
			children: value
		});
	}, [
		label,
		labelFormatter,
		payload,
		hideLabel,
		labelClassName,
		config,
		labelKey
	]);
	if (!active || !payload?.length) return null;
	const nestLabel = payload.length === 1 && indicator !== "dot";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid min-w-32 items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs/relaxed shadow-xl", className),
		children: [!nestLabel ? tooltipLabel : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-1.5",
			children: payload.filter((item) => item.type !== "none").map((item, index) => {
				const itemConfig = getPayloadConfigFromPayload(config, item, `${nameKey ?? item.name ?? item.dataKey ?? "value"}`);
				const indicatorColor = color ?? item.payload?.fill ?? item.color;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground", indicator === "dot" && "items-center"),
					children: formatter && item?.value !== void 0 && item.name ? formatter(item.value, item.name, item, index, item.payload) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [itemConfig?.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(itemConfig.icon, {}) : !hideIndicator && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("shrink-0 rounded-[2px] border-(--color-border) bg-(--color-bg)", {
							"h-2.5 w-2.5": indicator === "dot",
							"w-1": indicator === "line",
							"w-0 border-[1.5px] border-dashed bg-transparent": indicator === "dashed",
							"my-0.5": nestLabel && indicator === "dashed"
						}),
						style: {
							"--color-bg": indicatorColor,
							"--color-border": indicatorColor
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex flex-1 justify-between gap-2 leading-none", nestLabel ? "items-end" : "items-center"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [nestLabel ? tooltipLabel : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: itemConfig?.label ?? item.name
							})]
						}), item.value != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono font-medium text-foreground tabular-nums",
							children: typeof item.value === "number" ? item.value.toLocaleString() : String(item.value)
						})]
					})] })
				}, index);
			})
		})]
	});
}
function getPayloadConfigFromPayload(config, payload, key) {
	if (typeof payload !== "object" || payload === null) return;
	const payloadPayload = "payload" in payload && typeof payload.payload === "object" && payload.payload !== null ? payload.payload : void 0;
	let configLabelKey = key;
	if (key in payload && typeof payload[key] === "string") configLabelKey = payload[key];
	else if (payloadPayload && key in payloadPayload && typeof payloadPayload[key] === "string") configLabelKey = payloadPayload[key];
	return configLabelKey in config ? config[configLabelKey] : config[key];
}
function ScrollArea$1({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScrollAreaRoot, {
		"data-slot": "scroll-area",
		className: cn("relative", className),
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaViewport, {
				"data-slot": "scroll-area-viewport",
				className: "size-full rounded-[inherit] transition-[color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaCorner, {})
		]
	});
}
function ScrollBar({ className, orientation = "vertical", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
		"data-slot": "scroll-area-scrollbar",
		"data-orientation": orientation,
		orientation,
		className: cn("flex touch-none p-px transition-colors select-none data-horizontal:h-2.5 data-horizontal:flex-col data-horizontal:border-t data-horizontal:border-t-transparent data-vertical:h-full data-vertical:w-2.5 data-vertical:border-l data-vertical:border-l-transparent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, {
			"data-slot": "scroll-area-thumb",
			className: "relative flex-1 rounded-full bg-border"
		})
	});
}
/**
* A unique count the server estimates from a HyperLogLog sketch, typically
* within about 3% of the true count. It shows as approximate, as analytics
* consoles mark estimates, and says so to screen readers. Zero is exact: no
* report reached the sketch.
*/
function EstimatedCount({ value }) {
	if (value === 0) return "0";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		title: "Estimated",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				className: "mr-1 text-muted-foreground",
				children: "≈"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Estimated "
			}),
			value.toLocaleString()
		]
	});
}
var platformLabel = (platform) => platform === "all" ? "All platforms" : platform === "ios" ? "iOS" : "Android";
/** What a report reads, as the filters set it: its channel, platform, and any narrower filter. */
function InsightsScope({ channel, platform, narrower = [] }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex min-w-0 flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-muted-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "max-w-full truncate font-medium text-foreground",
				children: channel
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				children: "·"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1",
				children: [platform === "all" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
					platform,
					className: "size-3"
				}), platformLabel(platform)]
			}),
			narrower.map((filter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				children: "·"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "max-w-full truncate",
				children: filter
			})] }, filter))
		]
	});
}
function ReportingDevicesSummary({ window, count, isPending, partial }) {
	const metric = usageMetrics[window];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-label": `${metric.label} over ${metric.period}`,
		role: "region",
		className: "flex items-center gap-3",
		children: [isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			"aria-label": "Loading active users",
			className: "h-9 w-12"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-4xl font-semibold tracking-tight tabular-nums",
			children: count === void 0 ? "—" : partial ? `≥${count.toLocaleString()}` : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EstimatedCount, { value: count })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1 text-sm text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: metric.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoTooltip, {
				label: `How ${metric.label} is counted`,
				children: [
					"Installations that reported in the last ",
					metric.period,
					", estimated within about 3%. The chart shows them per ",
					metric.interval,
					".",
					partial ? " Some history is missing, so this is a minimum." : ""
				]
			})]
		})]
	});
}
var dates$1 = new Intl.DateTimeFormat("en", {
	month: "short",
	day: "numeric",
	timeZone: "UTC"
});
var times$1 = new Intl.DateTimeFormat("en", {
	month: "short",
	day: "numeric",
	hour: "numeric",
	timeZone: "UTC"
});
function AppUsage({ query, search, window, onWindowChange, retention = DEFAULT_INSIGHTS_RETENTION }) {
	const report = query.error ? void 0 : query.data;
	const formatTime = (ms) => (window === "30d" || window === "12m" ? dates$1 : times$1).format(ms);
	const distributionPeriod = report ? `since ${dates$1.format(report.distributionSinceMs)}, 00:00 UTC` : "in the selected period";
	const distributionTotals = report ? {
		versions: report.versions.reduce((sum, row) => sum + row.installations, 0),
		platforms: report.platforms.reduce((sum, row) => sum + row.installations, 0)
	} : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-w-0 gap-6 xl:grid-cols-[minmax(0,2fr)_minmax(16rem,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			"aria-label": "App usage",
			role: "region",
			className: "min-w-0 shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "flex-row flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-col gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "App usage" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsScope, {
						channel: search.channel ?? "production",
						platform: search.platform ?? "all",
						narrower: search.appVersion ? [`App version ${search.appVersion}`] : []
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsagePeriodSelector, {
					window,
					onWindowChange,
					twelveMonths: keepsTwelveMonths(retention)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportingDevicesSummary, {
					window,
					count: report?.activeInstallations,
					isPending: query.isPending,
					partial: report?.truncated ?? false
				}), query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
					"aria-label": "Loading app usage",
					className: "h-48"
				}) : query.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
						error: query.error,
						fallbackTitle: "App usage unavailable"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
						variant: "outline",
						onClick: () => void query.refetch(),
						children: "Retry app usage"
					})]
				}) : report?.activeInstallations === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					className: "h-48",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "No activity reported" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: "Try another period, platform, channel, or app version." })] })
				}) : report ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-right text-xs text-muted-foreground",
					children: "Reporting installations · UTC"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
					"aria-label": "Active users per interval",
					className: "h-48 w-full aspect-auto",
					config: { installations: {
						label: "Active users",
						color: "var(--chart-2)"
					} },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						accessibilityLayer: true,
						data: report.points,
						margin: {
							right: 8,
							top: 8
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { vertical: false }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "startMs",
								tick: { fill: "var(--muted-foreground)" },
								tickFormatter: formatTime,
								axisLine: false,
								tickLine: false,
								minTickGap: 45
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: { fill: "var(--muted-foreground)" },
								allowDecimals: false,
								axisLine: false,
								tickLine: false,
								width: "auto"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, { labelFormatter: (_, payload) => `${times$1.format(payload[0]?.payload.startMs)} · UTC` }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								dataKey: "installations",
								type: "linear",
								stroke: "var(--color-installations)",
								strokeWidth: 2,
								dot: { r: 2 },
								activeDot: { r: 4 },
								isAnimationActive: false
							})
						]
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer py-2",
						children: "View usage data"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						"aria-label": "App usage by interval",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Interval · UTC" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "text-right",
							children: "Active users"
						})] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: report.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: times$1.format(point.startMs) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right tabular-nums",
							children: point.installations === null ? "Unknown" : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EstimatedCount, { value: point.installations })
						})] }, point.startMs)) })]
					})]
				})] }) : null]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			"aria-label": "Usage distribution",
			role: "region",
			className: "flex min-w-0 flex-col shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "flex-row items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "flex min-h-9 items-center",
						children: "Distribution"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoTooltip, {
						label: "How distribution is counted",
						children: [
							"Each installation counts once, by its latest report",
							" ",
							distributionPeriod,
							".",
							report?.truncated ? " Some history is missing." : ""
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "flex-1",
					children: query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
						"aria-label": "Loading distribution",
						className: "h-48"
					}) : query.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
						error: query.error,
						fallbackTitle: "Distribution unavailable"
					}) : !report?.activeInstallations ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
						className: "h-40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "No reporting installations" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: "Try a different filter or period." })] })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-6",
						children: ["versions", "platforms"].map((dimension) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-label": dimension === "versions" ? "App version distribution" : "Platform distribution",
							className: "flex flex-col gap-4",
							children: [
								dimension === "platforms" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator$1, {}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "flex items-center gap-2 text-sm font-medium text-muted-foreground",
									children: [dimension === "versions" ? "App versions" : "Platforms", dimension === "versions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: report.versions.length
									}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea$1, {
									className: "min-w-0 [&_[data-slot=scroll-area-viewport]]:max-h-40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
										className: "flex flex-col gap-4 pr-4",
										children: report[dimension].map((row) => {
											const name = dimension === "platforms" ? row.name === "ios" ? "iOS" : "Android" : row.name;
											const share = row.installations / (distributionTotals?.[dimension] ?? 1) * 100;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group relative flex min-h-11 flex-col gap-2 rounded-sm focus-within:ring-2 focus-within:ring-ring sm:min-h-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex min-w-0 items-baseline justify-between gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
														className: "flex min-w-0 items-center gap-2 text-sm",
														title: name,
														children: [dimension === "platforms" && (row.name === "ios" || row.name === "android") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
															platform: row.name,
															className: "size-4 shrink-0"
														}) : null, dimension === "versions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
															to: "/insights/distribution",
															search: {
																...search,
																version: row.name
															},
															"aria-label": `View bundles for app version ${row.name}`,
															className: "flex min-w-0 items-center gap-1 after:absolute after:inset-0 group-hover:underline",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "truncate",
																children: name
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
																"aria-hidden": "true",
																className: "size-3 shrink-0 text-muted-foreground"
															})]
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "truncate",
															children: name
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
														className: "flex shrink-0 gap-3 text-sm tabular-nums",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.installations.toLocaleString() }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "min-w-10 text-right text-muted-foreground",
															children: [share.toFixed(1), "%"]
														})]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress$1, {
													"aria-label": `${name} share`,
													"aria-valuetext": `${row.installations} installations, ${share.toFixed(1)}%`,
													value: share
												})]
											}, row.name);
										})
									})
								})
							]
						}, dimension))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFooter, {
					className: "border-t pt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/insights/distribution",
						search,
						className: buttonVariants({
							variant: "outline",
							className: "h-11 w-full sm:h-9"
						}),
						children: ["View distribution", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
							"aria-hidden": "true",
							"data-icon": "inline-end"
						})]
					})
				})
			]
		})]
	});
}
var messageOf = (event) => event.failure?.errorMessage || "No error message reported";
function FailureDetail({ group }) {
	const [selectedId, setSelectedId] = (0, import_react.useState)(group.reports[0].id);
	const event = group.reports.find(({ id }) => id === selectedId) ?? group.reports[0];
	const failure = event.failure;
	const formatter = useInsightsTimeFormat();
	const context = [
		["App", `${event.platform === "ios" ? "iOS" : "Android"} ${event.appVersion}`],
		["Channel", event.channel],
		["SDK", event.sdkVersion ?? "Not reported"],
		["Stage", failureStageLabel(failure.stage)],
		["Resource", failure.resource],
		["HTTP status", failure.httpStatus?.toString()],
		["Origin code", failure.originCode],
		["Transport", failure.transport]
	].filter(([, value]) => value !== void 0);
	const copy = async () => {
		try {
			await navigator.clipboard.writeText(JSON.stringify(event, null, 2));
			toast.success("Error report copied");
		} catch {
			toast.error("Could not copy the report");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
		className: "data-[side=right]:w-full data-[side=right]:sm:max-w-2xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
			className: "border-b pr-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Error details" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, { children: [
				group.reports.length.toLocaleString(),
				" loaded reports ·",
				" ",
				group.installations.toLocaleString(),
				" installations"
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col gap-6 overflow-y-auto p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": "Original error",
					className: "flex min-w-0 flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								failureStageLabel(failure.stage),
								" ·",
								" ",
								failureReasonLabel(failure.reason)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: cn("text-sm leading-relaxed whitespace-pre-wrap wrap-anywhere", failure.errorMessage ? "font-mono" : "text-muted-foreground"),
							children: messageOf(event)
						}),
						!failure.errorMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "This client did not send the original error. Upgrade the app’s Insights plugin and server to collect details for future failures."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							className: "w-fit max-md:h-11",
							variant: "outline",
							onClick: () => void copy(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
								"aria-hidden": "true",
								"data-icon": "inline-start"
							}), " Copy report"]
						})
					]
				}),
				event.httpResponse ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": "Server response",
					className: "flex min-w-0 flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-sm font-medium",
							children: ["Server response · HTTP ", event.httpResponse.status]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Most recent response available when this report was created."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs wrap-anywhere",
							children: ["GET ", event.httpResponse.path]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [
								"Response received",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTimestamp, {
									value: event.httpResponse.receivedAtMs,
									formatter
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HttpResponseBody, { response: event.httpResponse })
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": "Stack trace",
					className: "flex min-w-0 flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Stack trace"
					}), failure.errorStack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "rounded-md border bg-muted/30 p-4 font-mono text-xs leading-relaxed whitespace-pre-wrap wrap-anywhere",
						children: failure.errorStack
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No stack trace was sent with this report."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": "Report context",
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Report context"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTimestamp, {
								value: event.receivedAtMs,
								formatter
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "grid grid-cols-2 gap-x-6 gap-y-4",
							children: context.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm wrap-anywhere",
									children: value
								})]
							}, label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventBundleTransition, { event }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							variant: "outline",
							className: "w-fit max-md:h-11",
							render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/installations",
								search: {
									query: event.installId,
									installId: event.installId
								}
							}),
							children: [
								"Installation history",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
									"aria-hidden": "true",
									"data-icon": "inline-end"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-muted-foreground wrap-anywhere",
							children: event.installId
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": "Occurrences",
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Occurrences in loaded reports"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Select a report to inspect its stack and context. Times use your browser’s zone."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-1",
							children: group.reports.map((report) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
								variant: report.id === event.id ? "secondary" : "ghost",
								"aria-pressed": report.id === event.id,
								className: "h-auto min-h-11 justify-between gap-4 whitespace-normal",
								onClick: () => setSelectedId(report.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-left tabular-nums",
									children: formatter.format(report.receivedAtMs)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0",
									children: report.appVersion
								})]
							}, report.id))
						})
					]
				})
			]
		})]
	});
}
function FailureReportsList({ pages, error, isPending, isFetching, hasNextPage, onLoadMore, onRefresh }) {
	const groups = groupFailureReports(pages.flatMap((page) => page.data));
	const reportCount = groups.reduce((sum, group) => sum + group.reports.length, 0);
	const scanned = pages.reduce((sum, page) => sum + page.scanned, 0);
	const formatter = useInsightsTimeFormat();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-label": "Errors to investigate",
		className: "flex min-w-0 flex-col gap-3",
		"aria-busy": isFetching,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: "Errors to investigate"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Original messages, most reported first. Select an error for its stack and affected app."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
				variant: "ghost",
				size: "icon-lg",
				"aria-label": "Refresh error reports",
				className: "max-md:size-11",
				disabled: isFetching,
				onClick: onRefresh,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "aria-hidden": "true" })
			})]
		}), isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			className: "h-40",
			"aria-label": "Loading error reports"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
				error,
				fallbackTitle: "Error reports unavailable"
			}) : null,
			groups.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				"aria-label": "Error messages",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Error" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "text-right",
						children: "Reports"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "hidden text-right sm:table-cell",
						children: "Installations"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "hidden lg:table-cell",
						children: "Last seen"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: groups.map((group) => {
					const latest = group.reports[0];
					const failure = latest.failure;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "max-w-md whitespace-normal",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
								render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
									variant: "link",
									className: "h-auto min-h-11 w-full justify-start whitespace-normal px-0 text-left"
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex min-w-0 flex-col gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("line-clamp-2 text-xs leading-relaxed wrap-anywhere", latest.failure?.errorMessage ? "font-mono" : "text-muted-foreground"),
										children: messageOf(latest)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-normal text-muted-foreground",
										children: [failureStageLabel(failure.stage), ...failureDetailParts(failure)].join(" · ")
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailureDetail, { group })] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right font-medium tabular-nums",
							children: group.reports.length.toLocaleString()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "hidden text-right tabular-nums sm:table-cell",
							children: group.installations.toLocaleString()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "hidden text-xs text-muted-foreground tabular-nums lg:table-cell",
							children: formatter.format(latest.receivedAtMs)
						})
					] }, group.key);
				}) })]
			}) : !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: hasNextPage ? "No failures in the events loaded so far" : "No error reports in this range" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: hasNextPage ? "Load older events to continue investigating this period." : "Reports appear here when a client sends an update failure. Raw history may be shorter than aggregate history." })] }) }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					role: "status",
					children: [
						reportCount.toLocaleString(),
						" failure reports from",
						" ",
						scanned.toLocaleString(),
						" events reviewed.",
						hasNextPage ? " More events remain; these counts are not period totals." : error ? " Scan interrupted." : " End of available range.",
						pages[0] ? ` Raw history since ${formatter.format(pages[0].sinceMs)}.` : ""
					]
				}), hasNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
					variant: "outline",
					disabled: isFetching,
					onClick: onLoadMore,
					children: isFetching ? "Loading…" : "Load older events"
				}) : null]
			})
		] })]
	});
}
function FailureReports({ input }) {
	const query = useFailureReportsQuery(input, true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailureReportsList, {
		pages: query.data?.pages ?? [],
		error: query.error,
		isPending: query.isPending,
		isFetching: query.isFetching,
		hasNextPage: query.hasNextPage,
		onLoadMore: () => void query.fetchNextPage(),
		onRefresh: () => void query.refetch()
	});
}
var listAdoptionReleasesRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readAdoptionReleasesInput).handler(createSsrRpc("d11a48f7251928b7819e2376aed4902fa66277bf6d30312d87ca53468332f256"));
var getAdoptionReleaseRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readAdoptionReleaseInput).handler(createSsrRpc("16e3be74610cddd54e5e894419dca16817a7b63c09a4eed15042cdac9c39e1e0"));
var getBundleEventsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readBundleEventsInput).handler(createSsrRpc("bfcca2365dfef4d071bdcddf97538a2637482c77bb747969dbdcd6769ca98416"));
var HOUR$1 = 36e5;
var DAY$1 = 24 * HOUR$1;
var times = new Intl.DateTimeFormat("en", {
	month: "short",
	day: "numeric",
	hour: "2-digit",
	minute: "2-digit",
	hourCycle: "h23",
	timeZone: "UTC"
});
var dates = new Intl.DateTimeFormat("en", {
	month: "short",
	day: "numeric",
	timeZone: "UTC"
});
var clock = new Intl.DateTimeFormat("en", {
	hour: "2-digit",
	minute: "2-digit",
	hourCycle: "h23",
	timeZone: "UTC"
});
/** One hue per compared bundle, in the validated order of `--series-*`. */
var SERIES = [
	"--series-1",
	"--series-2",
	"--series-3",
	"--series-4"
];
var formatDeployedAt = (ms) => `${times.format(ms)} UTC`;
/**
* A color for each bundle that stays with it: a bundle keeps its hue while
* others are added or removed, and a new one takes the first free hue.
*/
function useSeriesColors(releaseIds) {
	const [slots] = (0, import_react.useState)(() => /* @__PURE__ */ new Map());
	for (const releaseId of slots.keys()) if (!releaseIds.includes(releaseId)) slots.delete(releaseId);
	for (const releaseId of releaseIds) {
		if (slots.has(releaseId)) continue;
		const used = new Set(slots.values());
		let slot = 0;
		while (used.has(slot)) slot += 1;
		slots.set(releaseId, slot);
	}
	return (releaseId) => `var(${SERIES[(slots.get(releaseId) ?? 0) % SERIES.length]})`;
}
/** An interval as the tooltip names it, in UTC. */
var spanOf = (startMs, endMs) => dates.format(startMs) === dates.format(endMs) ? `${times.format(startMs)}–${clock.format(endMs)} UTC` : `${times.format(startMs)} – ${times.format(endMs)} UTC`;
/**
* One row per interval of the period, at the interval's end, with each
* bundle's count as `b<index>` and its dashed count, when it has one, as
* `d<index>`: none before the interval it was deployed in, and none while
* its counts load.
*/
var curveOf = (period, lines) => Array.from({ length: Math.round(period.durationMs / period.intervalMs) }, (_, interval) => {
	const startMs = period.startMs + interval * period.intervalMs;
	const endMs = startMs + period.intervalMs;
	const countOf = (release, points) => points === void 0 || endMs <= release.deployedAtMs ? null : points.find((point) => point.startMs === startMs)?.events ?? 0;
	return Object.fromEntries([
		["startMs", startMs],
		["endMs", endMs],
		...lines.flatMap((line, index) => [[`b${index}`, countOf(line.release, line.points)], ..."dashed" in line ? [[`d${index}`, countOf(line.release, line.dashed)]] : []])
	]);
});
/**
* Ticks on whole UTC times between the first count and the period's end, so
* a date names its midnight: every 4 hours of a day, each midnight of a week,
* every fifth midnight of a month.
*/
var ticksOf = (period) => {
	const step = period.intervalMs === HOUR$1 ? 4 * HOUR$1 : period.intervalMs === 6 * HOUR$1 ? DAY$1 : 5 * DAY$1;
	const ticks = [];
	for (let at = Math.ceil((period.startMs + period.intervalMs) / step) * step; at < period.endMs; at += step) ticks.push(at);
	return ticks;
};
/**
* Each bundle's counts per interval of the period on one timeline, with its
* deployment marked: a solid line, and a dashed one in its hue when the
* bundle has a second count. A count sits at the end of its interval, so a
* line starts after its deployment, with the interval it was deployed in.
*/
function ComparedBundlesChart({ period, lines, colorOf, active, label, names }) {
	const measuredAtMs = Math.max(0, ...lines.map((line) => line.measuredAtMs ?? 0));
	const curve = curveOf(period, lines);
	const ticks = ticksOf(period);
	const tick = (value) => period.intervalMs === HOUR$1 ? times.format(value) : dates.format(value);
	const labelOf = (release, name) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-1.5 whitespace-nowrap",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
			bundleId: release.releaseId,
			className: "whitespace-nowrap"
		}), name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: name
		}) : null]
	});
	const config = Object.fromEntries(lines.flatMap((line, index) => [[`b${index}`, {
		label: labelOf(line.release, names?.solid),
		color: colorOf(line.release.releaseId)
	}], ..."dashed" in line ? [[`d${index}`, {
		label: labelOf(line.release, names?.dashed),
		color: colorOf(line.release.releaseId)
	}]] : []]));
	const isolated = (key, color, hollow) => ({ cx, cy, index: at }) => {
		return curve[at]?.[key] == null || cx == null || cy == null || curve[at - 1]?.[key] != null || curve[at + 1]?.[key] != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {}, `${key}-${at}`) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx,
			cy,
			r: 4,
			fill: hollow ? "var(--background)" : color,
			stroke: color,
			strokeWidth: hollow ? 2 : 0
		}, `${key}-${at}`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
		"aria-label": label,
		className: "h-64 w-full aspect-auto",
		config,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
			accessibilityLayer: true,
			data: curve,
			margin: {
				left: -12,
				right: 12,
				top: 8
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { vertical: false }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "endMs",
					type: "number",
					domain: ["dataMin", "dataMax"],
					ticks,
					tickFormatter: tick,
					axisLine: false,
					tickLine: false,
					minTickGap: 32
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					allowDecimals: false,
					axisLine: false,
					tickLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, { labelFormatter: (_, payload) => {
					const point = payload[0]?.payload;
					return point ? `${spanOf(point.startMs, point.endMs)}${point.endMs > measuredAtMs ? " · In progress" : ""}` : "";
				} }) }),
				lines.map(({ release }) => release.deployedAtMs >= period.startMs ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceLine, {
					x: release.deployedAtMs,
					stroke: colorOf(release.releaseId),
					strokeOpacity: .5,
					ifOverflow: "extendDomain"
				}, `deployed-${release.releaseId}`) : null),
				lines.flatMap((line, index) => [..."dashed" in line ? ["d"] : [], "b"].map((kind) => {
					const { releaseId } = line.release;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						dataKey: `${kind}${index}`,
						type: "linear",
						stroke: `var(--color-${kind}${index})`,
						strokeDasharray: kind === "d" ? "6 4" : void 0,
						strokeWidth: active === releaseId ? 3 : 2,
						strokeOpacity: active === null || active === releaseId ? 1 : .25,
						dot: isolated(`${kind}${index}`, colorOf(releaseId), kind === "d"),
						activeDot: { r: 4 },
						connectNulls: false,
						isAnimationActive: false
					}, `${kind}-${releaseId}`);
				}))
			]
		})
	});
}
/** Whether a bundle deployment matches what was typed: its IDs or target app version. */
var matches = (release, typed) => typed === "" || release.releaseId.includes(typed) || release.bundleId.toLowerCase().includes(typed) || (release.targetAppVersion ?? "").toLowerCase().includes(typed);
/** A bundle deployment as a picker names it: ID, platform, deployment, target, and state. */
function ReleaseOption({ release }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex min-w-0 flex-col gap-0.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex min-w-0 items-center gap-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
					platform: release.platform,
					className: "size-3 shrink-0"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: platformLabel(release.platform)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
					bundleId: release.releaseId,
					className: "min-w-0"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted-foreground",
			children: [
				"Deployed ",
				formatDeployedAt(release.deployedAtMs),
				release.targetAppVersion ? ` · ${release.targetAppVersion}` : "",
				release.enabled ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" · ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: "Disabled"
				})] }),
				release.enabled && !release.live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" · ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 align-middle",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleOff, {
						"aria-hidden": "true",
						className: "size-3"
					}), "Unreachable"]
				})] }) : null
			]
		})]
	});
}
/**
* Picks one of a channel's bundle deployments: live ones first, searchable
* by ID or target app version. A full release ID the list leaves out is
* looked up in the scope, with the read Release health uses for it.
*/
function ReleaseCombobox({ scope, candidates, excluded = [], onPick, disabled = false, label, placeholder, trigger }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const typed = query.trim().toLowerCase();
	const offered = candidates.filter((release) => !excluded.includes(release.releaseId) && matches(release, typed));
	const lookupId = offered.length === 0 && isUUIDv7(typed) && !candidates.some((release) => release.releaseId === typed) ? typed : void 0;
	const lookup = useQuery({
		queryKey: [
			"insights",
			"adoption-release",
			scope,
			lookupId,
			false
		],
		queryFn: () => getAdoptionReleaseRpc({ data: {
			...scope,
			releaseId: lookupId
		} }),
		enabled: lookupId !== void 0,
		staleTime: Number.POSITIVE_INFINITY
	});
	const found = lookupId !== void 0 && lookup.data?.release && !excluded.includes(lookup.data.release.releaseId) ? [lookup.data.release] : [];
	const groups = [
		{
			value: "Live",
			items: offered.filter((release) => release.live)
		},
		{
			value: "Not live",
			items: offered.filter((release) => !release.live)
		},
		{
			value: "Found",
			items: found
		}
	].filter((group) => group.items.length > 0);
	const input = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
		"aria-label": label,
		className: trigger ? void 0 : "h-11 w-full sm:h-9 sm:w-96 [&_input]:h-full [&_input]:text-base max-md:[&_[data-slot=input-group-button]]:size-11 max-md:[&_input]:min-h-11 sm:[&_input]:text-xs",
		disabled,
		placeholder,
		showTrigger: !trigger,
		maxLength: 1024
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox$1, {
		items: groups,
		filter: null,
		value: null,
		inputValue: query,
		onInputValueChange: setQuery,
		itemToStringLabel: (release) => release.releaseId,
		onValueChange: (release) => {
			if (release === null) return;
			setQuery("");
			onPick(release);
		},
		disabled,
		children: [trigger ?? input, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, {
			className: trigger ? "w-96" : void 0,
			children: [
				trigger ? input : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, { children: lookupId === void 0 ? "No matching bundles." : lookup.isPending ? "Looking up the release…" : lookup.isError ? "Couldn't look up the release." : `No bundle with this ID in ${scope.channel} · ${platformLabel(scope.platform)}.` }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList, { children: (group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxGroup, {
					items: group.items,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxLabel, { children: group.value }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxCollection, { children: (release) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxItem, {
						className: "min-h-11 pr-8 sm:min-h-8",
						value: release,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseOption, { release })
					}, release.releaseId) })]
				}, group.value) })
			]
		})]
	});
}
var DEFAULT_FILTERS = {
	channel: DEFAULT_CHANNEL,
	platform: "all",
	appVersion: void 0,
	releaseId: void 0
};
var SELECT_CHIP = "shrink-0 gap-1.5 px-3 text-sm data-[active=true]:border-primary/60 data-[active=true]:bg-primary/10 data-[size=default]:h-11 sm:text-xs sm:data-[size=default]:h-8";
/** A filter with a button that returns it to its default when it is narrowed. */
function Clearable({ name, active, onClear, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex shrink-0 items-center",
		children: [children, active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			"aria-label": `Clear ${name}`,
			className: "size-11 sm:size-8",
			size: "icon",
			variant: "ghost",
			onClick: onClear,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "aria-hidden": "true" })
		}) : null]
	});
}
/**
* The Insights filters, above every report. Each applies as it changes, so
* what they show is what the reports read; one narrower than its default is
* filled and can be cleared on its own, and Reset filters clears them all.
*/
function InsightsControls({ filters, appVersions, releases, onFiltersChange }) {
	const versions = [...new Set([...appVersions, ...filters.appVersion ? [filters.appVersion] : []])];
	const narrowed = {
		channel: filters.channel !== DEFAULT_FILTERS.channel,
		platform: filters.platform !== DEFAULT_FILTERS.platform,
		appVersion: filters.appVersion !== void 0,
		releaseId: filters.releaseId !== void 0
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-label": "Insights filters",
		className: "flex shrink-0 items-center gap-2 overflow-x-auto border-b bg-background px-3 py-2 sm:flex-wrap sm:overflow-visible sm:px-4",
		role: "group",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelPicker, {
				active: narrowed.channel,
				value: filters.channel,
				onValueChange: (channel) => {
					if (channel !== void 0) onFiltersChange({ channel });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clearable, {
				name: "platform",
				active: narrowed.platform,
				onClear: () => onFiltersChange({ platform: DEFAULT_FILTERS.platform }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select$1, {
					items: {
						all: "All platforms",
						ios: "iOS",
						android: "Android"
					},
					value: filters.platform,
					onValueChange: (value) => {
						if ((value === "all" || value === "ios" || value === "android") && value !== filters.platform) onFiltersChange({ platform: value });
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger, {
						"aria-label": "Platform",
						className: SELECT_CHIP,
						"data-active": narrowed.platform,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Platform"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectValue, { children: [filters.platform === "all" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
							platform: filters.platform,
							className: "size-3.5"
						}), platformLabel(filters.platform)] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All platforms"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: "ios",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
								platform: "ios",
								className: "size-3.5"
							}), "iOS"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: "android",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
								platform: "android",
								className: "size-3.5"
							}), "Android"]
						})
					] }) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clearable, {
				name: "app version",
				active: narrowed.appVersion,
				onClear: () => onFiltersChange({ appVersion: void 0 }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select$1, {
					items: Object.fromEntries([["all", "All versions"], ...versions.map((version) => [`version:${version}`, version])]),
					value: filters.appVersion ? `version:${filters.appVersion}` : "all",
					onValueChange: (value) => {
						if (value === null) return;
						const appVersion = value === "all" ? void 0 : value.slice(8);
						if (appVersion !== filters.appVersion) onFiltersChange({ appVersion });
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger, {
						"aria-label": "App version",
						className: SELECT_CHIP,
						"data-active": narrowed.appVersion,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "App version"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "all",
						children: "All versions"
					}), versions.map((version) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: `version:${version}`,
						children: version
					}, version))] }) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clearable, {
				name: "release",
				active: narrowed.releaseId,
				onClear: () => onFiltersChange({ releaseId: void 0 }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseCombobox, {
					scope: {
						channel: filters.channel,
						platform: filters.platform
					},
					candidates: releases,
					excluded: filters.releaseId ? [filters.releaseId] : [],
					label: "Search releases",
					placeholder: "Search by ID or app version…",
					onPick: (release) => onFiltersChange({ releaseId: release.releaseId }),
					trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxTrigger, {
						"aria-label": `Release: ${filters.releaseId ?? "All"}`,
						"data-active": narrowed.releaseId,
						render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Release"
						}), filters.releaseId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-w-36 truncate font-mono",
							translate: "no",
							children: filters.releaseId
						}) : "All"]
					})
				})
			}),
			Object.values(narrowed).some(Boolean) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
				className: "h-11 shrink-0 sm:h-8",
				variant: "ghost",
				onClick: () => onFiltersChange(DEFAULT_FILTERS),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
					"aria-hidden": "true",
					"data-icon": "inline-start"
				}), "Reset filters"]
			}) : null
		]
	});
}
var percent$1 = (rate) => `${(rate * 100).toFixed(1)}%`;
/**
* Rolls a crashing bundle back the way its editor does: disabling its
* release sends installations running it back to the previous enabled
* release on their next update check.
*/
function RollbackButton({ release, rate, crashes, attempts, onRolledBack }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const queryClient = useQueryClient();
	const preflight = usePreflightReleaseMutation();
	const update = useUpdateReleaseMutation();
	const busy = preflight.isPending || update.isPending;
	const id = release.releaseId;
	const rollBack = async () => {
		const input = {
			expectedRevision: release.revision,
			patch: { enabled: false },
			releaseId: release.releaseId
		};
		setError("");
		try {
			await preflight.mutateAsync(input);
			await update.mutateAsync(input);
			onRolledBack?.();
			await queryClient.invalidateQueries({ queryKey: ["insights", "adoption-releases"] });
			toast.success(`${id} rolled back`, { description: "Installations running it return to the previous enabled bundle on their next update check." });
			setOpen(false);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "The bundle could not be rolled back.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog$1, {
		open,
		onOpenChange: (next) => {
			if (busy) return;
			setOpen(next);
			if (!next) setError("");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
			variant: "destructive",
			size: "sm",
			onClick: () => setOpen(true),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {
				"aria-hidden": "true",
				"data-icon": "inline-start"
			}), "Roll back"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Roll back this bundle?" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, { bundleId: id }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					"It crashed for ",
					percent$1(rate),
					" of the installations that tried it (",
					crashes.toLocaleString(),
					" of ",
					attempts.toLocaleString(),
					"). Rolling back disables it, so installations running it return to the previous enabled bundle on their next update check. You can enable it again in its bundle details."
				] })
			] }),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-sm text-destructive",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
				disabled: busy,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
				variant: "destructive",
				disabled: busy,
				onClick: () => void rollBack(),
				children: busy ? "Rolling back…" : "Roll back"
			})] })
		] })]
	});
}
var HOUR = 36e5;
var DAY = 24 * HOUR;
var percent = (rate) => `${(rate * 100).toFixed(1)}%`;
var lengthOf = (durationMs) => durationMs > DAY ? `${durationMs / DAY} days` : `${durationMs / HOUR} hours`;
var cadenceOf = (intervalMs) => intervalMs === HOUR ? "Hourly" : intervalMs === DAY ? "Daily" : `Every ${intervalMs / HOUR} hours`;
/** A bundle's crash numbers over the period, once both counts are read. */
var crashesOf = ({ release, launched, recovered }) => launched === void 0 || recovered === void 0 ? void 0 : {
	crashes: recovered.total,
	...crashRateOf(launched.total, recovered.total),
	recommended: recommendsRollback(release, launched.total, recovered.total)
};
/** A line sample for the legend: solid or dashed, in the text color. */
function LineSample({ dashed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		"aria-hidden": "true",
		className: "h-3 w-6 shrink-0",
		viewBox: "0 0 24 12",
		preserveAspectRatio: "none",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "0",
			y1: "6",
			x2: "24",
			y2: "6",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: dashed ? "6 4" : void 0
		})
	});
}
/**
* Release health: how the live bundles fare after their deployment, on
* one timeline, per interval. Adoption shows installations downloading each
* bundle (dashed) and launching it (solid), so the gap is the restarts still
* to come; Crashes shows them crashing back from it, and offers a rollback
* when a bundle crashes for too many of them.
*/
function InsightsOverview({ input, chart, onChartChange, health, onReleasesChange, onWindowChange, onShowAllPlatforms }) {
	const [active, setActive] = (0, import_react.useState)(null);
	const { period, candidates, releases } = health;
	const ids = (releases ?? []).map(({ release }) => release.releaseId);
	const colorOf = useSeriesColors(ids);
	const full = ids.length >= 4;
	const wider = period.durationMs < 7 * DAY ? "7d" : period.durationMs < 30 * DAY ? "30d" : null;
	const reset = health.isDefault ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
		variant: "ghost",
		size: "sm",
		onClick: () => onReleasesChange(void 0),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
			"aria-hidden": "true",
			"data-icon": "inline-start"
		}), "Show live bundles"]
	});
	const seriesOf = (bundle) => chart === "adoption" ? bundle.launched : bundle.recovered;
	const loaded = (releases ?? []).filter((bundle) => seriesOf(bundle) !== void 0 && (chart !== "adoption" || bundle.downloaded !== void 0));
	const failed = (releases ?? []).find(({ error }) => error !== null)?.error ?? null;
	const flagged = (releases ?? []).flatMap((bundle) => {
		const crashes = crashesOf(bundle);
		return crashes?.recommended ? [{
			...bundle,
			...crashes
		}] : [];
	});
	const remove = (releaseId) => {
		const rest = ids.filter((id) => id !== releaseId);
		onReleasesChange(rest.length === 0 ? void 0 : rest);
	};
	const heading = chart === "adoption" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1 text-sm font-medium",
			children: ["Installations downloading and launching each bundle", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTooltip, {
				label: "About adoption",
				children: "Dashed: installations that downloaded the bundle. Solid: installations that launched it. After a forced update the two lines meet."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				cadenceOf(period.intervalMs),
				" · last ",
				lengthOf(period.durationMs),
				" ",
				"· UTC"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				"aria-label": "Line styles",
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineSample, { dashed: true }), "Downloaded"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineSample, {}), "Launched"]
				})]
			})]
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1 text-sm font-medium",
			children: ["Crashes after each deployment", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoTooltip, {
				label: "About crashes",
				children: [
					"Installations that crashed on a bundle and rolled back. Crash rate = crashed ÷ (launched + crashed). A rollback is suggested at",
					" ",
					percent(CRASH_RATE_THRESHOLD),
					" once ",
					20,
					" ",
					"installations tried it."
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				cadenceOf(period.intervalMs),
				" · last ",
				lengthOf(period.durationMs),
				" · UTC"
			]
		})]
	});
	const body = (() => {
		if (releases === void 0) return health.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
			error: health.error,
			fallbackTitle: "Release health unavailable"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			"aria-label": "Loading release health",
			className: "h-64"
		});
		if (releases.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, {
			className: "min-h-64",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyTitle, { children: [
				"No bundles deployed to ",
				input.channel,
				" ·",
				" ",
				platformLabel(input.platform)
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: "Deploy one, or choose another channel or platform in the filters." })] }), reset || input.platform !== "all" && onShowAllPlatforms ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyContent, {
				className: "flex-row flex-wrap justify-center",
				children: [input.platform !== "all" && onShowAllPlatforms ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
					variant: "outline",
					size: "sm",
					onClick: onShowAllPlatforms,
					children: "Show all platforms"
				}) : null, reset]
			}) : null]
		});
		if (loaded.length === 0) return failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
			error: failed,
			fallbackTitle: "Release health unavailable"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			"aria-label": "Loading release health",
			className: "h-64"
		});
		if (loaded.every((bundle) => seriesOf(bundle).total === 0 && (chart !== "adoption" || bundle.downloaded.total === 0))) return chart === "adoption" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, {
			className: "min-h-48",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyTitle, { children: [
				"No installation downloaded or launched these bundles in the last",
				" ",
				lengthOf(period.durationMs)
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: wider ? "Choose a longer period, or refresh after apps download them." : "Refresh after apps download them." })] }), wider ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
				variant: "outline",
				size: "sm",
				onClick: () => onWindowChange(wider),
				children: ["Show ", lengthOf(wider === "7d" ? 7 * DAY : 30 * DAY)]
			}) }) : null]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			className: "min-h-48",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyTitle, { children: ["No crashes in the last ", lengthOf(period.durationMs)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: "No launch of these bundles crashed and recovered." })] })
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparedBundlesChart, {
			period,
			lines: releases.map((bundle) => ({
				release: bundle.release,
				points: seriesOf(bundle)?.points,
				...chart === "adoption" ? { dashed: bundle.downloaded?.points } : {},
				measuredAtMs: seriesOf(bundle)?.measuredAtMs
			})),
			colorOf,
			active,
			names: chart === "adoption" ? {
				solid: "Launched",
				dashed: "Downloaded"
			} : { solid: "Crashed" },
			label: chart === "adoption" ? "Installations downloading (dashed) and launching (solid) each bundle per interval" : "Crashes of each bundle per interval"
		});
	})();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"aria-label": "Release health",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "min-w-0 overflow-hidden shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
					className: "flex flex-col gap-4 p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 flex-col gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Release health" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsScope, {
								channel: input.channel,
								platform: input.platform,
								narrower: input.releaseId ? [`Release ${input.releaseId}`] : []
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsPeriodSelector, {
								window: input.window,
								onWindowChange
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
								"aria-label": "Refresh release health",
								variant: "ghost",
								size: "icon-lg",
								className: "max-md:size-11",
								disabled: health.isFetching,
								onClick: health.refresh,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {
									"aria-hidden": "true",
									className: cn(health.isFetching && "motion-safe:animate-spin")
								})
							})]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					"aria-busy": health.isFetching,
					className: "flex flex-col gap-5 px-6 pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs$1, {
						value: chart,
						onValueChange: (value) => onChartChange(value),
						className: "gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
									"aria-label": "Release health chart",
									className: "min-h-11 sm:min-h-9",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "adoption",
										className: "px-3",
										children: "Adoption"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "crashes",
										className: "px-3",
										children: ["Crashes", flagged.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
											"aria-hidden": "true",
											className: "text-destructive"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: ", rollback recommended"
										})] }) : null]
									})]
								}), reset]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
								value: "adoption",
								className: "flex flex-col gap-4",
								children: [heading, chart === "adoption" ? body : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
								value: "crashes",
								className: "flex flex-col gap-4",
								children: [
									flagged.map((bundle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
										variant: "destructive",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { "aria-hidden": "true" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertTitle, { children: [
												"Roll back",
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
													bundleId: bundle.release.releaseId,
													className: "text-sm"
												})
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, {
												className: "flex flex-col items-start gap-3",
												children: [
													"It crashed for ",
													percent(bundle.rate),
													" of the installations that tried it (",
													bundle.crashes.toLocaleString(),
													" of",
													" ",
													bundle.attempts.toLocaleString(),
													"), above",
													" ",
													percent(CRASH_RATE_THRESHOLD),
													".",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RollbackButton, {
														release: bundle.release,
														rate: bundle.rate,
														crashes: bundle.crashes,
														attempts: bundle.attempts,
														onRolledBack: health.isDefault ? () => onReleasesChange(ids) : void 0
													})
												]
											})
										]
									}, bundle.release.releaseId)),
									heading,
									chart === "crashes" ? body : null
								]
							})
						]
					}), releases !== void 0 && releases.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						failed && loaded.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
							error: failed,
							fallbackTitle: "Some bundles could not be read"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							"aria-label": "Compared bundles",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Bundle" }),
								chart === "adoption" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right",
									children: "Downloaded"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right",
									children: "Launched"
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right",
									children: "Crashed"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right",
									children: "Crash rate"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Remove"
									})
								})
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: releases.map((bundle) => {
								const { release } = bundle;
								const crashes = crashesOf(bundle);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
									"data-state": active === release.releaseId ? "selected" : void 0,
									onMouseEnter: () => setActive(release.releaseId),
									onMouseLeave: () => setActive(null),
									onFocus: () => setActive(release.releaseId),
									onBlur: () => setActive(null),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "w-full max-w-0 whitespace-normal",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex min-w-0 items-center gap-2 sm:gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
													"aria-hidden": "true",
													className: "h-3 w-4 shrink-0 sm:w-6",
													viewBox: "0 0 24 12",
													preserveAspectRatio: "none",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
														x1: "0",
														y1: "6",
														x2: "24",
														y2: "6",
														stroke: colorOf(release.releaseId),
														strokeWidth: "3"
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex min-w-0 flex-col",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex min-w-0 items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
															bundleId: release.releaseId,
															className: "min-w-0"
														}), release.enabled ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
															variant: "outline",
															children: "Disabled"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-xs break-words text-muted-foreground",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
																platform: release.platform,
																className: "mr-1 inline size-3 align-[-1px]"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "sr-only",
																children: [platformLabel(release.platform), " "]
															}),
															"Deployed",
															" ",
															formatDeployedAt(release.deployedAtMs),
															release.targetAppVersion ? ` · ${release.targetAppVersion}` : "",
															release.enabled && !release.live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" · ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "inline-flex items-center gap-1 align-middle",
																title: "No device gets this bundle with the current delivery settings.",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleOff, {
																	"aria-hidden": "true",
																	className: "size-3"
																}), "Unreachable"]
															})] }) : null
														]
													})]
												})]
											})
										}),
										chart === "adoption" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-right whitespace-nowrap tabular-nums",
											children: bundle.downloaded?.total.toLocaleString() ?? "—"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-right font-medium whitespace-nowrap tabular-nums",
											children: bundle.launched?.total.toLocaleString() ?? "—"
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-right whitespace-nowrap tabular-nums",
											children: crashes === void 0 ? "—" : crashes.crashes === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "0"
											}) : crashes.crashes.toLocaleString()
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-right whitespace-nowrap tabular-nums",
											children: crashes === void 0 || crashes.attempts === 0 ? "—" : crashes.recommended ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 font-medium text-destructive",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
														"aria-hidden": "true",
														className: "size-3.5"
													}),
													percent(crashes.rate),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "sr-only",
														children: ", rollback recommended"
													})
												]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: cn(crashes.attempts < 20 && "text-muted-foreground"),
												title: crashes.attempts < 20 ? `Only ${crashes.attempts} installations tried it` : void 0,
												children: percent(crashes.rate)
											})
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
											"aria-label": `Remove ${release.releaseId}`,
											className: "max-md:size-11",
											variant: "ghost",
											size: "icon-xs",
											onClick: () => remove(release.releaseId),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "aria-hidden": "true" })
										}) })
									]
								}, release.releaseId);
							}) })]
						}),
						(candidates ?? []).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseCombobox, {
							scope: {
								channel: input.channel,
								platform: input.platform
							},
							candidates: candidates ?? [],
							excluded: ids,
							disabled: full,
							label: "Add a bundle",
							placeholder: full ? `Up to 4 bundles` : "Add a bundle by ID or app version…",
							onPick: (release) => onReleasesChange([...ids, release.releaseId])
						}) : null
					] }) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFooter, {
					className: "flex items-center justify-end border-t px-6 py-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						className: buttonVariants({
							className: "max-md:h-11",
							variant: "outline",
							size: "sm"
						}),
						to: "/installations",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { "aria-hidden": "true" }), "Event history"]
					})
				})
			]
		})
	});
}
var share = (events, total) => total === 0 ? "—" : `${(events / total * 100).toFixed(1)}%`;
/**
* One kind of failure: its rate as the headline, then how many failures and
* installations it holds.
*/
function FailureSummary({ id, title, info, rate, of, failures, installations, previous, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-labelledby": id,
		className: "flex min-w-0 flex-col gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				id,
				className: "flex min-h-11 items-center gap-1 text-sm font-medium sm:min-h-7",
				children: [title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTooltip, {
					label: `About ${title.toLowerCase()}`,
					children: info
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-3xl font-semibold tracking-tight tabular-nums",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rate, { value: rate })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: of
			}),
			previous ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateChange, {
				value: rate,
				previous: previous.rate,
				complete: previous.complete
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground tabular-nums",
				children: [
					failures.toLocaleString(),
					" ",
					failures === 1 ? "failure" : "failures",
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EstimatedCount, { value: installations }),
					" ",
					installations === 1 ? "installation" : "installations"
				]
			}),
			children
		]
	});
}
function Rate({ value }) {
	const formatted = formatRate(value);
	return value === null ? formatted : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [formatted.slice(0, -1), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "ml-0.5 text-sm font-normal text-muted-foreground",
		children: "%"
	})] });
}
function RateChange({ value, previous, complete }) {
	if (!complete || value === null || previous === null) return null;
	const difference = (value - previous) * 100;
	const rounded = Number(difference.toFixed(2));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("mt-1 block text-xs font-normal", rounded > 0 ? "text-warning" : "text-muted-foreground"),
		children: [
			rounded === 0 ? "Unchanged" : `${rounded > 0 ? "↑ +" : "↓ "}${rounded.toFixed(2)} pp`,
			" ",
			"vs previous period"
		]
	});
}
/** One stage and reason, and what else its clients knew, most first. */
function FailureRow({ failure, total }) {
	const label = `${failureStageLabel(failure.stage)} · ${failureReasonLabel(failure.reason)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
		className: "[&>td]:px-2 [&>td]:py-3 [&>td]:align-top sm:[&>td]:px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-normal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "group/failure",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
						"aria-label": label,
						className: "flex min-h-11 w-fit max-w-full cursor-pointer list-none items-center gap-3 rounded-md outline-none focus-visible:ring-2 focus-visible:ring-ring [&::-webkit-details-marker]:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
							"aria-hidden": "true",
							className: "size-4 shrink-0 text-muted-foreground group-open/failure:rotate-90"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex min-w-0 flex-col gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: failureStageLabel(failure.stage)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium wrap-anywhere",
								children: failureReasonLabel(failure.reason)
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						"aria-label": `${label} details`,
						className: "mt-3 flex flex-col gap-3 rounded-md border bg-muted/20 p-3 text-sm",
						children: failure.details.map((detail) => {
							const parts = failureDetailParts(detail);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "wrap-anywhere",
									children: parts.length === 0 ? "No details reported" : parts.join(" · ")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 font-medium tabular-nums",
									children: detail.events.toLocaleString()
								})]
							}, JSON.stringify(detail));
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "inline-flex min-h-11 items-center text-sm font-medium",
					children: failure.events.toLocaleString()
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "inline-flex min-h-11 items-center text-sm",
					children: share(failure.events, total)
				})
			})
		]
	});
}
function FailuresReport({ report, errors }) {
	const breakdown = report.breakdown ?? [];
	const total = breakdown.reduce((sum, { events }) => sum + events, 0);
	const unreasoned = breakdown.filter(({ reason }) => reason === "unknown").reduce((sum, { events }) => sum + events, 0);
	const patchAttempts = report.patchDownloads + report.patchFallbacks;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("grid gap-6", report.checks && "sm:grid-cols-2"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailureSummary, {
					id: "download-install-failures",
					title: "Downloads & installs",
					info: "Failed downloads and installs ÷ those plus successful downloads.",
					rate: failureRate(report),
					of: "of update attempts failed",
					failures: report.failedUpdates,
					installations: report.failedInstallations,
					previous: report.previous && {
						rate: report.previous.attemptRate,
						complete: report.previous.complete
					},
					children: patchAttempts > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground tabular-nums",
						children: [
							report.patchFallbacks.toLocaleString(),
							" of",
							" ",
							patchAttempts.toLocaleString(),
							" patch downloads fell back to the full archive"
						]
					}) : null
				}), report.checks ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailureSummary, {
					id: "update-check-failures",
					title: "Update checks",
					info: "Installations whose update check failed ÷ active installations. A check that fails offline isn't reported.",
					rate: checkFailureRate(report.checks),
					of: "of active installations had a check fail",
					failures: report.checks.failures,
					installations: report.checks.failedInstallations,
					previous: report.previous && {
						rate: report.previous.checkRate,
						complete: report.previous.complete
					}
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator$1, {}),
			errors ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [errors, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator$1, {})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "failures-by-stage",
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						id: "failures-by-stage",
						children: "Failures by stage and reason"
					}),
					unreasoned * 2 > total ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Most report no reason: an SDK that doesn't classify failures reports every failed check, offline ones included."
					}) : null,
					breakdown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No update failures in this period."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						"aria-label": "Failures by stage and reason",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "[&>th]:px-2 sm:[&>th]:px-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Stage / reason" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-16 text-right sm:w-24",
									children: "Reports"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-16 text-right sm:w-24",
									children: "Share"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: breakdown.map((failure) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailureRow, {
							failure,
							total
						}, `${failure.stage} ${failure.reason}`)) })]
					})
				]
			})
		]
	});
}
/**
* Update failures for Release health's scope and period: counts, rates, and
* the stage and reason breakdown with what else the clients knew.
*/
function UpdateFailures({ errors, scope, query, onRefresh }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"aria-label": "Update failures",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "min-w-0 overflow-hidden shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "flex flex-col gap-1.5 p-4 sm:p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 flex-col gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Update failures" }), scope]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
							"aria-label": "Refresh update failures",
							variant: "ghost",
							size: "icon-lg",
							className: "max-md:size-11",
							disabled: query.isFetching,
							onClick: onRefresh,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { "aria-hidden": "true" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Track failure rates, inspect original errors, and open individual reports in the selected Release health scope and period." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "px-4 pb-4 sm:px-6 sm:pb-6",
					children: query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
						"aria-label": "Loading update failures",
						className: "h-64"
					}) : query.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
						error: query.error,
						fallbackTitle: "Update failures unavailable"
					}) : query.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailuresReport, {
						report: query.data,
						errors
					}) : null
				}),
				query.data?.coverage.kind === "partial" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFooter, {
					className: "border-t px-6 py-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "Partial"
					})
				}) : null
			]
		})
	});
}
/** What each Release health chart reads per bundle. */
var READS = {
	adoption: ["DOWNLOADED", "LAUNCHED"],
	crashes: ["LAUNCHED", "RECOVERED"]
};
/**
* Release health's reads, each keyed by what it depends on: the newest
* deployments by channel and platform, kept five minutes; a bundle the
* newest leave out, kept; and one count series per bundle and report type,
* so adding a bundle or opening the other chart reads only what is new.
*/
function useReleaseHealth({ platform, channel, window, releaseIds, focusReleaseId, chart }) {
	const { durationMs, intervalMs } = recoveryWindows[window];
	const endMs = insightsPeriodEnd(Date.now());
	const scope = {
		platform,
		channel
	};
	const candidatesQuery = useQuery({
		queryKey: [
			"insights",
			"adoption-releases",
			scope
		],
		queryFn: () => listAdoptionReleasesRpc({ data: scope }),
		staleTime: 5 * 6e4
	});
	const candidates = candidatesQuery.data;
	const focusQuery = useQuery({
		queryKey: [
			"insights",
			"adoption-release",
			scope,
			focusReleaseId,
			true
		],
		queryFn: () => getAdoptionReleaseRpc({ data: {
			...scope,
			releaseId: focusReleaseId,
			withPrevious: true
		} }),
		enabled: releaseIds === void 0 && focusReleaseId !== void 0,
		staleTime: Number.POSITIVE_INFINITY
	});
	const known = /* @__PURE__ */ new Map();
	for (const release of [
		...focusQuery.data?.release ? [focusQuery.data.release] : [],
		...focusQuery.data?.previous ? [focusQuery.data.previous] : [],
		...candidates ?? []
	]) known.set(release.releaseId, release);
	const live = (list) => defaultAdoptionReleases(list, platform);
	const chosen = releaseIds !== void 0 ? releaseIds.slice(0, 4) : candidates === void 0 ? void 0 : focusReleaseId === void 0 ? live(candidates) : focusQuery.data === void 0 ? void 0 : focusQuery.data.release === null ? live(candidates) : [focusQuery.data.release.releaseId, focusQuery.data.previous?.releaseId].filter((id) => id !== void 0);
	const labelQueries = useQueries({ queries: (chosen ?? []).filter((releaseId) => !known.has(releaseId) && releaseId !== focusReleaseId).map((releaseId) => ({
		queryKey: [
			"insights",
			"adoption-release",
			scope,
			releaseId,
			false
		],
		queryFn: () => getAdoptionReleaseRpc({ data: {
			...scope,
			releaseId
		} }),
		staleTime: Number.POSITIVE_INFINITY
	})) });
	for (const query of labelQueries) if (query.data?.release) known.set(query.data.release.releaseId, query.data.release);
	const releases = chosen === void 0 || labelQueries.some((query) => query.isPending) ? void 0 : chosen.flatMap((releaseId) => {
		const release = known.get(releaseId);
		return release === void 0 ? [] : [release];
	});
	const reads = (releases ?? []).flatMap((release) => READS[chart].map((type) => ({
		release,
		type
	})));
	const seriesQueries = useQueries({ queries: reads.map(({ release, type }) => {
		const data = {
			platform: release.platform,
			channel,
			window,
			endMs,
			bundleId: release.bundleId,
			type
		};
		return {
			queryKey: [
				"insights",
				"bundle-events",
				data
			],
			queryFn: () => getBundleEventsRpc({ data }),
			staleTime: 3e4,
			placeholderData: (previous) => previous?.bundleId === release.bundleId && previous.type === type ? previous : void 0
		};
	}) });
	const seriesOf = (bundleId, type) => {
		const index = reads.findIndex((read) => read.release.bundleId === bundleId && read.type === type);
		return index === -1 ? void 0 : seriesQueries[index];
	};
	return {
		period: {
			startMs: endMs - durationMs,
			endMs,
			durationMs,
			intervalMs
		},
		candidates,
		releases: releases?.map((release) => {
			const downloaded = seriesOf(release.bundleId, "DOWNLOADED");
			const launched = seriesOf(release.bundleId, "LAUNCHED");
			const recovered = seriesOf(release.bundleId, "RECOVERED");
			return {
				release,
				downloaded: downloaded?.data,
				launched: launched?.data,
				recovered: recovered?.data,
				error: downloaded?.error ?? launched?.error ?? recovered?.error ?? null
			};
		}),
		isDefault: releaseIds === void 0,
		error: candidatesQuery.error ?? focusQuery.error ?? null,
		isFetching: candidatesQuery.isFetching || focusQuery.isFetching || seriesQueries.some((query) => query.isFetching),
		refresh: () => {
			candidatesQuery.refetch();
			for (const query of seriesQueries) query.refetch();
		}
	};
}
function InsightsPage() {
	const queryClient = useQueryClient();
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	const retention = useInsightsRetention();
	const usageWindow = search.window ?? "24h";
	const bundleWindow = search.bundleWindow ?? "24h";
	const channel = search.channel ?? "production";
	const platform = search.platform ?? "all";
	const scope = {
		platform,
		channel,
		appVersion: search.appVersion
	};
	const setUsageWindow = (window) => void navigate({ search: {
		...search,
		window
	} });
	const input = {
		...scope,
		window: usageWindow
	};
	const bundleInput = {
		platform,
		channel,
		window: bundleWindow,
		...search.releaseId === void 0 ? {} : { releaseId: search.releaseId }
	};
	const query = useQuery({
		queryKey: [
			"insights",
			"app-usage",
			input
		],
		queryFn: () => getAppUsageReportRpc({ data: input }),
		staleTime: 3e4
	});
	const chart = search.healthChart ?? "adoption";
	const health = useReleaseHealth({
		platform,
		channel,
		window: bundleWindow,
		releaseIds: comparedBundleIds(search.bundles),
		focusReleaseId: search.releaseId,
		chart
	});
	const failuresQuery = useUpdateFailuresQuery(bundleInput);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsPageHeader, {
				view: "overview",
				overviewSearch: search
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsControls, {
				filters: {
					channel,
					platform,
					appVersion: search.appVersion,
					releaseId: search.releaseId
				},
				appVersions: query.data?.appVersions ?? [],
				releases: health.candidates ?? [],
				onFiltersChange: (change) => {
					const next = {
						...search,
						...change
					};
					navigate({ search: {
						...next,
						channel: next.channel === "production" ? void 0 : next.channel,
						platform: next.platform === "all" ? void 0 : next.platform,
						..."channel" in change || "platform" in change ? {
							releaseId: change.releaseId,
							bundles: void 0
						} : {},
						..."releaseId" in change ? { bundles: void 0 } : {}
					} });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 min-w-0 flex-1 overflow-y-auto bg-muted/5 px-4 py-6 sm:p-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-6xl flex-col gap-6",
					children: [
						query.data?.truncated && !query.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Partial history" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, { children: [
							"Only reports since",
							" ",
							new Date(query.data.sinceMs).toLocaleString("en", { timeZone: "UTC" }),
							" ",
							"UTC are available. The active-user count is a lower bound. Choose a shorter period for a more complete view."
						] })] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppUsage, {
							query,
							search: {
								...scope,
								window: usageWindow,
								bundleWindow
							},
							window: usageWindow,
							onWindowChange: setUsageWindow,
							retention
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsOverview, {
							input: bundleInput,
							chart,
							onChartChange: (healthChart) => void navigate({ search: {
								...search,
								healthChart
							} }),
							health,
							onReleasesChange: (ids) => void navigate({ search: {
								...search,
								bundles: ids?.join(",")
							} }),
							onShowAllPlatforms: () => void navigate({ search: {
								...search,
								platform: void 0,
								releaseId: void 0,
								bundles: void 0
							} }),
							onWindowChange: (window) => void navigate({ search: {
								...search,
								bundleWindow: window
							} })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdateFailures, {
							scope: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsScope, {
								channel,
								platform,
								narrower: search.releaseId ? [`Release ${search.releaseId}`] : []
							}),
							query: failuresQuery,
							errors: failuresQuery.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailureReports, { input: {
								...bundleInput,
								beforeReceivedAtMs: failuresQuery.data.endMs
							} }, JSON.stringify(bundleInput)) : null,
							onRefresh: () => {
								failuresQuery.refetch();
								queryClient.invalidateQueries({ queryKey: ["insights", "failure-reports"] });
							}
						})
					]
				})
			})
		]
	});
}
//#endregion
export { InsightsPage as component };
