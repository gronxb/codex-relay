import { i as rowToBundle } from "./databaseRows-BZMFl5QV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/getBundleChildren-CnOf4Frp.js
/** The most children the lineage panel lists; the count comes from the base bundle's counter. */
var BUNDLE_CHILDREN_LIMIT = 100;
/**
* The bundles with a patch from this base, newest first: one read of the
* patches index, then each child bundle.
*/
async function getBundleChildren(core, baseBundleId) {
	const patches = await core.listPatchesFromBase(baseBundleId, {
		order: "desc",
		limit: 100
	});
	return (await Promise.all([...new Set(patches.map(({ bundle_id }) => bundle_id))].map((id) => core.getBundle(id)))).flatMap((detail) => detail === null ? [] : [rowToBundle(detail.bundle, detail.patches)]);
}
/** How many bundles patch from each base: each base bundle's reference counter, in one batch read. */
async function getBundleChildCounts(core, baseBundleIds) {
	const ids = [...new Set(baseBundleIds.filter(Boolean))];
	return ids.length === 0 ? {} : core.countBundleChildren(ids);
}
//#endregion
export { BUNDLE_CHILDREN_LIMIT, getBundleChildCounts, getBundleChildren };
