import { i as getRequest } from "./server-CUH0Oy00.mjs";
import { requireConsoleAccess, t as resolveConsoleConfig } from "./auth.server-BtwE9LLM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/config.server-CvAlgb8E.js
var configPromise = null;
var core = null;
var runtime = null;
var loadCachedConfig = async (request) => {
	if (!configPromise) configPromise = resolveConsoleConfig(request).catch((error) => {
		configPromise = null;
		throw error;
	});
	return configPromise;
};
/**
* The console's config, core, and features, without the access check: for
* routes that take no session, such as a channel link's QR code. Everything
* else goes through {@link prepareConfig}.
*/
var loadConsole = async (request = getRequest()) => {
	const config = await loadCachedConfig(request);
	core ??= config.core;
	if (!runtime) {
		const { createConsoleRuntime } = await import("./runtime.server-BUbb281Z.mjs");
		runtime = createConsoleRuntime(config);
	}
	return {
		config,
		core,
		runtime,
		storage: config.storage
	};
};
var prepareConfig = async (request = getRequest()) => {
	try {
		await requireConsoleAccess(request);
		return await loadConsole(request);
	} catch (error) {
		if (!(error instanceof Response && (error.status === 401 || error.status === 403))) console.error("Error during configuration initialization:", error);
		throw error;
	}
};
//#endregion
export { loadConsole, prepareConfig };
