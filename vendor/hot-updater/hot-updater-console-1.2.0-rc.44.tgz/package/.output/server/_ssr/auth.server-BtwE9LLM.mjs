import { n as DatabaseBundleNotFoundError, r as DatabaseRowReferencedError } from "./databaseJsonValue-DuUoft8j.mjs";
import { a as getAssetBaseStorageUri, c as getManifestFileHash, i as RELEASE_CATALOG_FALLBACK_POLICY, l as getManifestStorageUri, o as getBundlePatch } from "./dist-CiOq3ygH.mjs";
import { i as rowToBundle, n as bundleToRow, r as releaseRowToRelease, t as bundleToPatchRows } from "./databaseRows-BZMFl5QV.mjs";
import { a as decodeChannelKey, c as parseReleaseCatalogScopeKey, i as createReleaseCatalogScopeKey, o as encodeChannelKey, r as canonicalizeAppVersion, s as isUUIDv7, t as NIL_UUID } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
import { t as ReleaseManagementError } from "./releaseManagement-CqIc-SDE.mjs";
import { n as createUUIDv7After, t as createUUIDv7 } from "./uuidv7-C0jNe2Om.mjs";
import { i as normalizeRange } from "./version-CQ98ZBpL-zW2fpHOZ.mjs";
import { n as projectCompiledCatalog, r as projectCompiledRollbackCatalog, t as compileReleaseCatalog } from "./releaseCatalogCompiler-CJ2Shida.mjs";
import { t as isRemoteDatabase } from "./databaseConfig-B56IJxlu.mjs";
import { n as defineTable, t as defineAggregate } from "./schema-CaIuQCXb.mjs";
import { r as rangesIntersect } from "../_libs/verkit.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.server-BtwE9LLM.js
var SHA256_FILE_HASH_RE = /^[0-9a-f]{64}$/;
var isContentAddressedAssetFileHash = (value) => {
	return typeof value === "string" && SHA256_FILE_HASH_RE.test(value);
};
var getContentAddressedAssetStoragePath = ({ assetPath, fileHash }) => {
	const extension = assetPath.endsWith(".br") ? ".br" : assetPath.includes(".") ? `.${assetPath.split(".").pop()}` : "";
	return `sha256/${fileHash.slice(0, 2)}/${fileHash}${extension}`;
};
var normalizeStorageKeyParts = (values) => {
	if (values.some((value) => value.includes("\\"))) throw new Error("Storage keys must use '/' as the hierarchy separator.");
	const segments = values.flatMap((value) => value.split("/").filter(Boolean));
	if (segments.some((segment) => segment === "." || segment === "..")) throw new Error("Storage key segments must not be '.' or '..'.");
	return segments;
};
var createStorageKeyBuilder = (basePath) => {
	const baseSegments = normalizeStorageKeyParts([basePath ?? ""]);
	return (...args) => [...baseSegments, ...normalizeStorageKeyParts(args)].join("/");
};
var PROTOCOL_PATTERN = /^[a-z][a-z\d+.-]*$/;
var INVALID_BUCKET_CHARACTER_PATTERN = /[\s/?#%@:\\]/;
var assertProtocol = (protocol) => {
	if (!PROTOCOL_PATTERN.test(protocol)) throw new Error(`Invalid storage URI protocol: ${protocol}`);
};
var assertBucket = (bucket) => {
	if (bucket.length === 0 || INVALID_BUCKET_CHARACTER_PATTERN.test(bucket)) throw new Error(`Invalid storage URI bucket: ${bucket}`);
};
var getKeySegments = (key) => {
	if (key.length === 0) throw new Error("Invalid storage URI key: key must not be empty");
	const segments = key.split("/");
	if (segments.some((segment) => segment.length === 0 || segment === "." || segment === ".." || segment.includes("\\"))) throw new Error("Invalid storage URI key: segments must not be empty, '.', '..' or contain '\\'");
	return segments;
};
/**
* Creates a hierarchical storage identifier in the form
* `protocol://bucket/slash-separated-encoded-key`.
*/
var createStorageUri = ({ protocol, bucket, key }) => {
	assertProtocol(protocol);
	assertBucket(bucket);
	return `${protocol}://${bucket}/${getKeySegments(key).map(encodeURIComponent).join("/")}`;
};
/**
* Parses a hierarchical storage identifier and decodes each key segment.
*
* Search parameters and fragments are not part of a storage identifier.
*/
function parseStorageUri(storageUri, expectedProtocol) {
	assertProtocol(expectedProtocol);
	if (storageUri.includes("?") || storageUri.includes("#")) throw new Error(`Invalid storage URI format: ${storageUri}`);
	const match = /^([a-z][a-z\d+.-]*):\/\/([^/]+)\/(.*)$/.exec(storageUri);
	if (!match) throw new Error(`Invalid storage URI format: ${storageUri}`);
	const [, protocol, bucket, encodedKey] = match;
	if (protocol !== expectedProtocol) throw new Error(`Invalid storage URI protocol. Expected ${expectedProtocol}, got ${protocol}`);
	assertBucket(bucket);
	let segments;
	try {
		segments = getKeySegments(encodedKey).map((segment) => {
			const decoded = decodeURIComponent(segment);
			if (decoded.includes("/") || decoded.includes("\\")) throw new Error("encoded hierarchy separator");
			if (encodeURIComponent(decoded) !== segment) throw new Error("non-canonical segment");
			return decoded;
		});
	} catch {
		throw new Error(`Invalid storage URI format: ${storageUri}`);
	}
	return {
		protocol,
		bucket,
		key: segments.join("/")
	};
}
var isBrotliManifestAssetPath = (assetPath) => /(^|\/)index\.[^/]+\.bundle$/.test(assetPath.replace(/\\/g, "/"));
var getManifestAssetDownloadPath = (assetPath) => isBrotliManifestAssetPath(assetPath) ? `${assetPath}.br` : assetPath;
var createStorageUriWithRelativePath = ({ baseStorageUri, relativePath }) => {
	const parsed = parseStorageUri(baseStorageUri, new URL(baseStorageUri).protocol.replace(":", ""));
	const childKey = createStorageKeyBuilder(void 0)(relativePath);
	if (!childKey) throw new Error("Relative storage key must not be empty.");
	return createStorageUri({
		protocol: parsed.protocol,
		bucket: parsed.bucket,
		key: createStorageKeyBuilder(parsed.key)(childKey)
	});
};
var replaceStorageUriKeySuffix = ({ storageUri, keySuffix, replacement }) => {
	const parsed = parseStorageUri(storageUri, new URL(storageUri).protocol.replace(":", ""));
	const normalizedSuffix = createStorageKeyBuilder(void 0)(keySuffix);
	const normalizedReplacement = createStorageKeyBuilder(void 0)(replacement);
	if (!normalizedSuffix || !normalizedReplacement) throw new Error("Storage URI key suffix and replacement must not be empty.");
	const keySegments = parsed.key.split("/");
	const suffixSegments = normalizedSuffix.split("/");
	const suffixOffset = keySegments.length - suffixSegments.length;
	if (suffixOffset < 0 || suffixSegments.some((segment, index) => keySegments[suffixOffset + index] !== segment)) throw new Error("Storage URI key does not end with the expected suffix.");
	const prefix = keySegments.slice(0, suffixOffset).join("/");
	return createStorageUri({
		protocol: parsed.protocol,
		bucket: parsed.bucket,
		key: createStorageKeyBuilder(prefix)(normalizedReplacement)
	});
};
var resolveManifestAssetStorageFileHash = ({ downloadFileHash, fileHash }) => isContentAddressedAssetFileHash(downloadFileHash) ? downloadFileHash : fileHash;
var getManifestAssetStoragePath = ({ assetPath, downloadFileHash, fileHash }) => getContentAddressedAssetStoragePath({
	assetPath,
	fileHash: resolveManifestAssetStorageFileHash({
		downloadFileHash,
		fileHash
	})
});
var resolveManifestAssetStorageUri = ({ assetBaseStorageUri, assetPath, downloadFileHash, fileHash }) => createStorageUriWithRelativePath({
	baseStorageUri: assetBaseStorageUri,
	relativePath: getManifestAssetStoragePath({
		assetPath,
		downloadFileHash,
		fileHash
	})
});
var BUNDLE_STORAGE_PREFIX = "bundles";
var createBundleStorageKey = (bundleId, ...relativePaths) => [
	BUNDLE_STORAGE_PREFIX,
	bundleId,
	...relativePaths
].filter(Boolean).join("/");
var getBundleArchiveStorageUri = ({ manifestStorageUri, bundleId }) => replaceStorageUriKeySuffix({
	storageUri: manifestStorageUri,
	keySuffix: createBundleStorageKey(bundleId, "manifest.json"),
	replacement: createBundleStorageKey(bundleId, "bundle.tar.br")
});
function assertStorageOperations(adapter, operations) {
	for (const operation of operations) if (typeof adapter[operation] !== "function") throw new Error(`Storage adapter "${adapter.name}" does not implement ${operation}.`);
}
var ReleaseCatalogMutationError = class extends Error {
	code;
	name = "ReleaseCatalogMutationError";
	constructor(code, message) {
		super(message);
		this.code = code;
	}
};
var DatabaseConstraintError = class extends Error {
	reason;
	model;
	name = "DatabaseConstraintError";
	constructor(reason, model) {
		super(`${model}: ${reason}`);
		this.reason = reason;
		this.model = model;
	}
};
/** The retry budget ran out; ingestion answers 503 with Retry-After. */
var DatabaseConflictError = class extends Error {
	name = "DatabaseConflictError";
};
/** The write may or may not have committed; it is reported, never rerun. */
var DatabaseAmbiguousCommitError = class extends Error {
	name = "DatabaseAmbiguousCommitError";
};
var DatabaseTransactionError = class extends Error {
	name = "DatabaseTransactionError";
};
/** A read that does not fit its model, such as an unknown index, a missing `where` field, or an out-of-range limit. */
var DatabaseQueryError = class extends Error {
	name = "DatabaseQueryError";
};
/** A malformed cursor, or one from a read with another model, index, filter, order, or range. */
var DatabaseCursorError = class extends Error {
	name = "DatabaseCursorError";
};
var REGISTER_COUNT = 1024;
var MAX_RANK = 55;
var OFFSET = 33;
var decode = (summary) => {
	if (!summary) return new Uint8Array(REGISTER_COUNT);
	if (summary.length !== REGISTER_COUNT) throw new Error("Invalid distinct sketch");
	const registers = new Uint8Array(REGISTER_COUNT);
	for (let index = 0; index < REGISTER_COUNT; index += 1) {
		const value = summary.charCodeAt(index) - OFFSET;
		if (!Number.isInteger(value) || value < 0 || value > MAX_RANK) throw new Error("Invalid distinct sketch");
		registers[index] = value;
	}
	return registers;
};
var encode$1 = (registers) => Array.from(registers, (value) => String.fromCharCode(value + OFFSET)).join("");
/**
* The union of sketches, register by register: how a plugin combines a
* `distinct` column across the aggregate rows it reads.
*/
var mergeDistinct = (summaries) => {
	const merged = new Uint8Array(REGISTER_COUNT);
	for (const summary of summaries) {
		const registers = decode(summary);
		for (let index = 0; index < REGISTER_COUNT; index += 1) merged[index] = Math.max(merged[index], registers[index]);
	}
	return encode$1(merged);
};
/** A misconfigured `createHotUpdater` call, reported at startup. */
var HotUpdaterConfigError = class extends Error {
	name = "HotUpdaterConfigError";
};
/**
* The scope and range a base-candidate key names, null for any other
* string: what an implementation of `findBaseBundleIds` reads the key with.
*/
var parseBaseCandidateKey = (key) => {
	try {
		const parsed = JSON.parse(key);
		if (!Array.isArray(parsed) || typeof parsed[0] !== "string") return null;
		const [scopeKey, text] = parsed;
		const { strategy } = parseReleaseCatalogScopeKey(scopeKey);
		if (strategy === "FINGERPRINT") return parsed.length === 1 ? {
			scopeKey,
			range: null
		} : null;
		const range = parsed.length === 2 && typeof text === "string" ? normalizeRange(text) : null;
		return range === null ? null : {
			scopeKey,
			range
		};
	} catch {
		return null;
	}
};
var DatabaseSchemaError = class extends Error {
	name = "DatabaseSchemaError";
};
/**
* The column `name` of `table`, or a `DatabaseSchemaError`: how an adapter
* that is neither SQL nor key-value, such as the MongoDB adapter, reads a
* column's type.
*/
var findPhysicalColumn = (table, name) => {
	const column = table.columns.find((candidate) => candidate.name === name);
	if (column === void 0) throw new DatabaseSchemaError(`${table.name} has no column ${name}.`);
	return column;
};
/**
* The index `name` of `table`, or a `DatabaseSchemaError`: how an adapter
* that is neither SQL nor key-value, such as the MongoDB adapter, resolves a
* query's `index`.
*/
var findPhysicalIndex = (table, name) => {
	const index = table.indexes.find((candidate) => candidate.name === name);
	if (index === void 0) throw new DatabaseSchemaError(`${table.name} has no index ${name}.`);
	return index;
};
/**
* The columns that order an index read and close its cursors: the sort
* columns, then the key columns that neither `eq` nor `sort` fixes.
*/
var indexOrderColumns = (table, index) => [...index.sort, ...table.key.filter((column) => !index.sort.includes(column) && !index.eq.includes(column))];
/**
* The primary key of a row, in key-column order: what `get` takes for it.
* An adapter that is neither SQL nor key-value, such as the MongoDB adapter,
* addresses rows by it.
*/
var rowKey = (table, row) => table.key.map((column) => {
	const value = row[column];
	if (typeof value !== "string" && typeof value !== "number" && typeof value !== "boolean") throw new DatabaseSchemaError(`${table.name}.${column} is a key column and must be a string, number, or boolean.`);
	return value;
});
var DatabaseValueError = class extends Error {
	name = "DatabaseValueError";
};
/**
* Compares strings in UTF-8 byte order, which is Unicode code point order:
* the order the engine sorts string keys in. A plugin that merges rows from
* several reads, as Insights does, keeps that order with it.
*/
var compareUtf8 = (left, right) => {
	let leftIndex = 0;
	let rightIndex = 0;
	while (leftIndex < left.length && rightIndex < right.length) {
		const leftPoint = left.codePointAt(leftIndex);
		const rightPoint = right.codePointAt(rightIndex);
		if (leftPoint !== rightPoint) return leftPoint < rightPoint ? -1 : 1;
		leftIndex += leftPoint > 65535 ? 2 : 1;
		rightIndex += rightPoint > 65535 ? 2 : 1;
	}
	const leftDone = leftIndex >= left.length;
	return leftDone === rightIndex >= right.length ? 0 : leftDone ? -1 : 1;
};
/** Orders strings by UTF-8 bytes, numbers numerically, and false before true. */
var compareKeyValues = (left, right) => {
	if (typeof left === "string" && typeof right === "string") return compareUtf8(left, right);
	if (typeof left === "number" && typeof right === "number") return left < right ? -1 : left > right ? 1 : 0;
	if (typeof left === "boolean" && typeof right === "boolean") return Number(left) - Number(right);
	throw new DatabaseValueError(`Cannot compare ${typeof left} with ${typeof right}.`);
};
/** Compares tuples element by element; a shorter equal prefix sorts first. */
var compareTuples = (left, right) => {
	for (let index = 0; index < Math.min(left.length, right.length); index += 1) {
		const result = compareKeyValues(left[index], right[index]);
		if (result !== 0) return result;
	}
	return left.length - right.length;
};
/** JSON text with object keys sorted, so a value compares equal after a store reorders map keys. */
var canonicalJson = (value) => JSON.stringify(value ?? null, (_, inner) => inner !== null && typeof inner === "object" && !Array.isArray(inner) ? Object.fromEntries(Object.entries(inner).sort(([left], [right]) => compareUtf8(left, right))) : inner);
var isKeyValue = (value) => typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value);
/** Every `eq` tuple a row is indexed under; none when an index field is null. */
var indexEntries = (table, index, row) => {
	if (index.sort.some((column) => !isKeyValue(row[column]))) return [];
	let entries = [[]];
	for (const column of index.eq) {
		const value = row[column];
		const values = findPhysicalColumn(table, column).multi ? Array.isArray(value) ? value.filter(isKeyValue) : [] : isKeyValue(value) ? [value] : [];
		if (values.length === 0) return [];
		entries = entries.flatMap((entry) => [...new Set(values)].map((item) => [...entry, item]));
	}
	return entries;
};
/** The row's position in an index read, following `indexOrderColumns`. */
var indexOrderTuple = (table, index, row) => indexOrderColumns(table, index).map((column) => {
	const value = row[column];
	if (!isKeyValue(value)) throw new DatabaseValueError(`${table.name}.${column} is not orderable for index ${index.name}.`);
	return value;
});
var satisfiesBound = (tuple, bound, side) => {
	if (bound === void 0) return true;
	const result = compareTuples(tuple.slice(0, bound.values.length), bound.values);
	if (result === 0) return bound.inclusive;
	return side === "lower" ? result > 0 : result < 0;
};
/** Whether a stored row belongs to the result range of a query. */
var matchesQuery = (table, index, request, row) => indexEntries(table, index, row).some((entry) => compareTuples(entry, request.eq) === 0) && satisfiesBound(indexOrderTuple(table, index, row), request.lower, "lower") && satisfiesBound(indexOrderTuple(table, index, row), request.upper, "upper");
var keyId = (key) => JSON.stringify(key);
var numberOf = (value) => typeof value === "number" ? value : 0;
var violatesUnique = (table, rows, id, row) => table.indexes.some((index) => {
	if (!index.unique) return false;
	const entries = indexEntries(table, index, row);
	return entries.length > 0 && [...rows].some(([otherId, other]) => otherId !== id && indexEntries(table, index, other).some((entry) => entries.some((candidate) => compareTuples(entry, candidate) === 0)));
});
var putRow = (table, rows, id, row) => {
	if (violatesUnique(table, rows, id, row)) return false;
	rows.set(id, row);
	return true;
};
/** Applies one op to a draft; false means its guard or a constraint failed. */
var applyOp = (rows, op) => {
	const id = keyId(op.type === "insert" ? rowKey(op.table, op.row) : op.key);
	const current = rows.get(id);
	const version = numberOf(current?.["_v"]);
	switch (op.type) {
		case "insert": return current === void 0 && putRow(op.table, rows, id, structuredClone(op.row));
		case "patch": return current !== void 0 && version === op.guard.v && putRow(op.table, rows, id, {
			...current,
			...structuredClone(op.set),
			["_v"]: version + 1
		});
		case "delete": return current !== void 0 && version === op.guard.v && rows.delete(id);
		case "increment": {
			const base = current ?? op.init;
			if (base === void 0 || op.guard !== void 0 && (current === void 0 || version !== op.guard.v)) return false;
			const next = structuredClone(base);
			for (const [column, delta] of Object.entries(op.by)) next[column] = numberOf(base[column]) + delta;
			next["_v"] = numberOf(base["_v"]) + 1;
			return putRow(op.table, rows, id, next);
		}
		case "check": return current !== void 0 && version === op.guard.v;
	}
};
/**
* The reference adapter: every read is a consistent snapshot and every write
* applies to a copy that replaces the state only when all ops succeed.
*/
var createMemoryAdapter = (options = {}) => {
	const prefix = options.tablePrefix ?? "";
	let state = /* @__PURE__ */ new Map();
	const rowsOf = (table) => state.get(prefix + table.name) ?? /* @__PURE__ */ new Map();
	return {
		id: "memory",
		fits: () => true,
		async get(table, keys) {
			const rows = rowsOf(table);
			return keys.map((key) => {
				const row = rows.get(keyId(key));
				return row === void 0 ? null : structuredClone(row);
			});
		},
		async query(table, request) {
			const index = findPhysicalIndex(table, request.index);
			const direction = request.order === "asc" ? 1 : -1;
			return [...rowsOf(table).values()].filter((row) => matchesQuery(table, index, request, row)).sort((left, right) => direction * compareTuples(indexOrderTuple(table, index, left), indexOrderTuple(table, index, right))).slice(0, request.limit).map((row) => structuredClone(row));
		},
		async write(ops) {
			const draft = new Map(state);
			const copied = /* @__PURE__ */ new Set();
			for (const [position, op] of ops.entries()) {
				const name = prefix + op.table.name;
				if (!copied.has(name)) {
					draft.set(name, new Map(draft.get(name)));
					copied.add(name);
				}
				if (!applyOp(draft.get(name), op)) return {
					ok: false,
					failedOp: position
				};
			}
			state = draft;
			return { ok: true };
		},
		async prune(table, before, limit) {
			const column = table.retention?.column ?? "";
			/** Oldest first; the key breaks a tie. */
			const order = (row) => [row[column], ...rowKey(table, row)];
			const doomed = [...rowsOf(table)].filter(([, row]) => {
				const time = row[column];
				return typeof time === "number" && time <= before;
			}).sort(([, left], [, right]) => compareTuples(order(left), order(right))).slice(0, limit);
			const rows = new Map(rowsOf(table));
			for (const [id] of doomed) rows.delete(id);
			state = new Map(state).set(prefix + table.name, rows);
			return doomed.length;
		},
		migrations: { async apply(tables) {
			const next = new Map(state);
			for (const table of tables) {
				const name = prefix + table.name;
				next.set(name, next.get(name) ?? /* @__PURE__ */ new Map());
			}
			state = next;
		} },
		async dispose() {
			state = /* @__PURE__ */ new Map();
		}
	};
};
/** What `verifyAdapter` throws when an adapter call breaks the adapter contract. */
var DatabaseAdapterContractError = class extends Error {
	name = "DatabaseAdapterContractError";
};
var EMPTY = {
	gets: 0,
	keys: 0,
	queries: 0,
	rows: 0
};
var createReadMeter = () => {
	const tables = /* @__PURE__ */ new Map();
	const add = (table, count) => {
		const current = tables.get(table) ?? EMPTY;
		tables.set(table, {
			gets: current.gets + (count.gets ?? 0),
			keys: current.keys + (count.keys ?? 0),
			queries: current.queries + (count.queries ?? 0),
			rows: current.rows + (count.rows ?? 0)
		});
	};
	return {
		add,
		meter: {
			total: () => [...tables.values()].reduce((sum, count) => ({
				gets: sum.gets + count.gets,
				keys: sum.keys + count.keys,
				queries: sum.queries + count.queries,
				rows: sum.rows + count.rows
			}), EMPTY),
			byTable: (table) => tables.get(table) ?? EMPTY,
			reset: () => tables.clear()
		}
	};
};
var fail$2 = (message) => {
	throw new DatabaseAdapterContractError(message);
};
var sameKey = (left, right) => left.length === right.length && compareTuples(left, right) === 0;
var verifyRequest = (table, request) => {
	const index = findPhysicalIndex(table, request.index);
	if (!Number.isSafeInteger(request.limit) || request.limit < 1 || request.limit > 500) fail$2(`query limit must be 1–500.`);
	if (request.eq.length !== index.eq.length || !request.eq.every(isKeyValue)) fail$2(`query on ${table.name}.${index.name} must bind every eq column.`);
	return index;
};
var verifyRows = (table, request, rows) => {
	const index = findPhysicalIndex(table, request.index);
	if (rows.length > request.limit) fail$2(`${table.name}.${index.name} returned more than ${request.limit} rows.`);
	let previous;
	for (const row of rows) {
		if (!matchesQuery(table, index, request, row)) fail$2(`${table.name}.${index.name} returned a row outside the request.`);
		const tuple = indexOrderTuple(table, index, row);
		if (previous !== void 0) {
			const order = compareTuples(previous, tuple);
			if (request.order === "asc" ? order >= 0 : order <= 0) fail$2(`${table.name}.${index.name} returned rows out of order.`);
		}
		previous = tuple;
	}
	return previous;
};
var verifyWrite = (adapter, ops) => {
	if (ops.length === 0) fail$2("write needs at least one op.");
	const seen = /* @__PURE__ */ new Set();
	for (const op of ops) {
		const key = op.type === "insert" ? rowKey(op.table, op.row) : op.key;
		const id = JSON.stringify([op.table.name, key]);
		if (seen.has(id)) fail$2(`write touches ${op.table.name} ${id} twice.`);
		seen.add(id);
		if (op.type === "insert" && typeof op.row["_v"] !== "number") fail$2(`insert into ${op.table.name} must set _v.`);
		if (op.type === "patch" && Object.keys(op.set).some((column) => column === "_v" || op.table.key.includes(column))) fail$2(`patch of ${op.table.name} may not set key columns or _v.`);
	}
	if (!adapter.fits(ops)) fail$2("write does not fit in one atomic write.");
};
/** Wraps an adapter to check the contract at its boundary and count reads. */
var verifyAdapter = (adapter, options = {}) => {
	const { add, meter } = createReadMeter();
	return {
		...adapter,
		id: adapter.id,
		reads: meter,
		fits: (ops) => adapter.fits(ops),
		async get(table, keys) {
			const rows = await adapter.get(table, keys);
			add(table.name, {
				gets: 1,
				keys: keys.length
			});
			if (rows.length !== keys.length) fail$2(`${table.name} get returned ${rows.length} rows for ${keys.length} keys.`);
			rows.forEach((row, position) => {
				if (row !== null && !sameKey(rowKey(table, row), keys[position])) fail$2(`${table.name} get returned a row for another key.`);
			});
			return rows;
		},
		async query(table, request) {
			const index = verifyRequest(table, request);
			const rows = await adapter.query(table, request);
			add(table.name, {
				queries: 1,
				rows: rows.length
			});
			const last = verifyRows(table, request, rows);
			if (options.probeShortPages && last !== void 0 && rows.length < request.limit) {
				const bound = {
					values: last,
					inclusive: false
				};
				if ((await adapter.query(table, {
					...request,
					limit: 1,
					...request.order === "asc" ? { lower: bound } : { upper: bound }
				})).length > 0) fail$2(`${table.name}.${index.name} returned a short page before the range ended.`);
			}
			return rows;
		},
		...adapter.prune && { async prune(table, before, limit) {
			if (table.retention === void 0) fail$2(`${table.name} has no retention to prune by.`);
			if (!Number.isSafeInteger(limit) || limit < 1) fail$2("prune limit must be a positive integer.");
			const deleted = await adapter.prune(table, before, limit);
			if (!Number.isSafeInteger(deleted) || deleted < 0 || deleted > limit) fail$2(`${table.name} prune reported ${deleted} rows for ${limit}.`);
			return deleted;
		} },
		async write(ops) {
			verifyWrite(adapter, ops);
			const result = await adapter.write(ops);
			if (!result.ok && "failedOp" in result) {
				if (!Number.isSafeInteger(result.failedOp) || result.failedOp < 0 || result.failedOp >= ops.length) fail$2(`write reported failedOp ${result.failedOp} for ${ops.length} ops.`);
			}
			return result;
		}
	};
};
/**
* The settings rows migrations write, last, and the fence reads; retention
* passes keep their lease here too. Tooling that creates the tables creates
* this one with them: an ORM's schema generator, a provider's setup, and an
* access policy that names the tables a server reads.
*/
var SETTINGS_TABLE = {
	name: "private_hot_updater_settings",
	columns: [
		{
			name: "key",
			type: "string",
			nullable: false,
			maxLength: 255
		},
		{
			name: "value",
			type: "string",
			nullable: false,
			maxLength: 255
		},
		{
			name: "_v",
			type: "integer",
			nullable: false,
			default: 0
		}
	],
	key: ["key"],
	indexes: []
};
/** The engine's storage-layout generation; it changes only with a migration. */
var ENGINE_SCHEMA_KEY = "schema.engine";
var CORE_SCHEMA_KEY = "schema.core";
var stored = ({ key, expected, found }) => `"${key}" is ${found === null ? "missing" : `"${found}"`}; expected "${expected}"`;
/**
* How to migrate a database the fence refused: doctor names the command for
* it, init again for a deployment init manages, or the database's own
* tooling in the server's project.
*/
var MIGRATE_SCHEMA_FIX = "Run `npx hot-updater doctor` in the project whose hot-updater.config.ts names this database: it names the command that migrates it. In a server project, `hot-updater db migrate` migrates the database its server file names.";
var settingMessage = (adapterName, { key, expected, found }) => `Hot Updater schema setting "${key}" for ${adapterName} is ${found === null ? "missing" : `"${found}"`}; expected "${expected}". ${MIGRATE_SCHEMA_FIX}`;
/** The plugin a `schema.<id>` setting belongs to; undefined for core's and the engine's. */
var pluginOf = ({ key }) => key.startsWith("schema.") && key !== "schema.engine" && key !== CORE_SCHEMA_KEY ? key.slice(7) : void 0;
var listed = (items) => items.length < 2 ? items.join("") : `${items.slice(0, -1).join(", ")} and ${items.at(-1)}`;
var settingsMessage = (adapterName, settings) => `Hot Updater schema settings for ${adapterName} are not migrated: ${settings.map(stored).join(", and ")}. ${MIGRATE_SCHEMA_FIX}`;
var pluginsMessage = (adapterName, plugins, settings, fix) => `The tables of ${plugins.length === 1 ? "plugin" : "plugins"} ${listed(plugins.map((id) => `"${id}"`))} are not migrated on ${adapterName}: schema ${settings.length === 1 ? "setting" : "settings"} ${settings.map(stored).join(", and ")}. ${fix}`;
/** The database needs `hot-updater db migrate`, or a new database; the handler answers 503. */
var HotUpdaterSchemaMigrationRequiredError = class extends Error {
	adapterName;
	currentVersion;
	setting;
	/** Every setting the fence found missing or different; `setting` is the first. */
	settings;
	/**
	* The ids of the plugins whose `schema.<id>` setting is among them: the
	* plugins whose tables a migration has yet to create or change.
	*/
	plugins;
	constructor(adapterName, currentVersion, setting, options) {
		const settings = options?.settings ?? (setting === void 0 ? [] : [setting]);
		const plugins = settings.flatMap((mismatch) => pluginOf(mismatch) ?? []);
		super(setting === void 0 ? currentVersion === void 0 ? `Hot Updater database schema is not initialized for ${adapterName}. ${MIGRATE_SCHEMA_FIX}` : `Hot Updater v1 cannot migrate schema ${currentVersion} in place. Create a new empty database and run \`hot-updater db migrate\`.` : plugins.length > 0 && plugins.length === settings.length ? pluginsMessage(adapterName, plugins, settings, options?.fix ?? MIGRATE_SCHEMA_FIX) : settings.length > 1 && !(setting.key === "schema.engine" && setting.found === null) ? settingsMessage(adapterName, settings) : settingMessage(adapterName, setting), options?.cause === void 0 ? void 0 : { cause: options.cause });
		this.adapterName = adapterName;
		this.currentVersion = currentVersion;
		this.setting = setting;
		this.name = "HotUpdaterSchemaMigrationRequiredError";
		this.settings = settings;
		this.plugins = plugins;
	}
};
/** Driver codes for a table or column the database lacks. */
var MISSING_SCHEMA_CODES = /* @__PURE__ */ new Set([
	"42P01",
	"42703",
	"ER_NO_SUCH_TABLE",
	"ER_BAD_FIELD_ERROR"
]);
var MISSING_SCHEMA_MESSAGE = /no such (?:table|column)|(?:relation|column) .+ does not exist|table .+ doesn't exist|unknown column/iu;
/**
* Whether a read failed because a table or column is missing, so the
* database needs migrations. ORMs may wrap the driver's error in `cause`.
*/
var isMissingSchemaError = (error) => {
	for (let depth = 0; error instanceof Object && depth < 8; depth += 1) {
		const { code, message, cause } = error;
		if (MISSING_SCHEMA_CODES.has(String(code)) || typeof message === "string" && MISSING_SCHEMA_MESSAGE.test(message)) return true;
		error = cause;
	}
	return false;
};
var readSettings = (adapter, keys) => adapter.get(SETTINGS_TABLE, keys.map((key) => [key]));
/**
* Throws unless every expected setting is stored with its value: one batch
* read. The error lists every setting missing or different; `fix` says how
* to create the plugins' tables on this database.
*/
var checkSchemaFence = async (adapter, adapterName, expected, fix) => {
	const keys = Object.keys(expected);
	let rows;
	try {
		rows = await readSettings(adapter, keys);
	} catch (cause) {
		if (!isMissingSchemaError(cause)) throw cause;
		throw new HotUpdaterSchemaMigrationRequiredError(adapterName, void 0, {
			key: ENGINE_SCHEMA_KEY,
			expected: "1",
			found: null
		}, { cause });
	}
	const settings = keys.flatMap((key, position) => {
		const found = rows[position]?.value;
		return found === expected[key] ? [] : [{
			key,
			expected: expected[key],
			found: typeof found === "string" ? found : null
		}];
	});
	const [first] = settings;
	if (first !== void 0) throw new HotUpdaterSchemaMigrationRequiredError(adapterName, void 0, first, {
		settings,
		...fix === void 0 ? {} : { fix }
	});
};
/** The database name a fenced adapter carries, so a server can fence its plugins' rows too. */
var FENCED = Symbol.for("@hot-updater/server/schema-fence");
/**
* The adapter a fence reads its settings through and the settings it
* expects, so a fence over it checks them with its own in one read. Another
* key than `FENCED`, whose value another copy of plugin-core reads as the
* name.
*/
var FENCED_SETTINGS = Symbol.for("@hot-updater/server/schema-fence-settings");
/** The database name an adapter behind the schema fence reports under. */
var fencedName = (adapter) => adapter[FENCED];
/**
* The adapter behind the schema fence: a process's first read or write
* checks the settings first. Success is kept; a failure is checked again on
* the next call. A fence over another one, as a server's plugins' over
* core's, checks the inner fence's settings with its own in that one read,
* so its refusal lists every setting missing or different.
*/
var withSchemaFence = (adapter, adapterName, expected, fix) => {
	const inner = adapter[FENCED_SETTINGS];
	const settings = inner === void 0 ? {
		adapter,
		expected
	} : {
		adapter: inner.adapter,
		expected: {
			...inner.expected,
			...expected
		}
	};
	let ready;
	const fence = () => {
		ready ??= checkSchemaFence(settings.adapter, adapterName, settings.expected, fix).catch((error) => {
			ready = void 0;
			throw error;
		});
		return ready;
	};
	return {
		...adapter,
		[FENCED]: adapterName,
		[FENCED_SETTINGS]: settings,
		get: (table, keys) => fence().then(() => adapter.get(table, keys)),
		query: (table, request) => fence().then(() => adapter.query(table, request)),
		write: (ops) => fence().then(() => adapter.write(ops)),
		...adapter.prune && { prune: (table, before, limit) => fence().then(() => adapter.prune(table, before, limit)) }
	};
};
var METER = Symbol.for("@hot-updater/plugin-core/read-meter");
/** The meter `meterReads` gave `database`, if it did. */
var readMeterOf = (database) => typeof database === "object" && database !== null ? database[METER] : void 0;
/** A channel's id is `channel:` and its name's channel key, so ids share channel_key's bound. */
var CHANNEL_ID = {
	type: "string",
	maxLength: 1408,
	ascii: true
};
var bundles = defineTable({
	id: {
		type: "string",
		maxLength: 36
	},
	platform: {
		type: "string",
		maxLength: 16
	},
	git_commit_hash: {
		type: "string",
		maxLength: 255,
		required: false
	},
	metadata: { type: "json" },
	manifest_storage_uri: { type: "string" },
	manifest_file_hash: { type: "string" },
	asset_base_storage_uri: { type: "string" }
}, {
	key: ["id"],
	indexes: {
		byPlatform: {
			eq: ["platform"],
			sort: ["id"]
		},
		all: {
			eq: [],
			sort: ["id"]
		}
	}
});
var bundlePatches = defineTable({
	id: {
		type: "string",
		maxLength: 255
	},
	bundle_id: {
		type: "string",
		maxLength: 36,
		references: {
			model: "bundles",
			onDelete: "cascade"
		}
	},
	base_bundle_id: {
		type: "string",
		maxLength: 36,
		references: {
			model: "bundles",
			onDelete: "cascade"
		}
	},
	base_file_hash: { type: "string" },
	patch_file_hash: { type: "string" },
	patch_storage_uri: { type: "string" },
	byte_size: { type: "integer" },
	order_index: { type: "integer" }
}, {
	key: ["id"],
	indexes: {
		pair: {
			eq: ["bundle_id", "base_bundle_id"],
			sort: [],
			unique: true
		},
		byBundle: {
			eq: ["bundle_id"],
			sort: ["order_index"],
			root: { model: "bundles" }
		},
		byBase: {
			eq: ["base_bundle_id"],
			sort: ["bundle_id"]
		}
	}
});
var releases = defineTable({
	id: {
		type: "string",
		maxLength: 36
	},
	revision: { type: "integer" },
	scope_key: {
		type: "string",
		maxLength: 2048,
		ascii: true
	},
	channel_id: {
		...CHANNEL_ID,
		references: {
			model: "channels",
			onDelete: "restrict"
		}
	},
	platform: {
		type: "string",
		maxLength: 16
	},
	kind: {
		type: "string",
		maxLength: 16
	},
	bundle_id: {
		type: "string",
		maxLength: 36,
		required: false,
		references: {
			model: "bundles",
			onDelete: "restrict"
		}
	},
	strategy: {
		type: "string",
		maxLength: 16
	},
	target_app_version: {
		type: "string",
		required: false
	},
	fingerprint_hash: {
		type: "string",
		maxLength: 255,
		required: false
	},
	enabled: { type: "boolean" },
	should_force_update: { type: "boolean" },
	message: {
		type: "string",
		required: false
	},
	rollout_cohort_count: { type: "integer" },
	target_cohorts: { type: "json" },
	operation: {
		type: "string",
		maxLength: 16
	},
	source_release_id: {
		type: "string",
		maxLength: 36,
		required: false,
		references: {
			model: "releases",
			onDelete: "none"
		}
	},
	created_at_ms: { type: "integer" },
	updated_at_ms: { type: "integer" }
}, {
	key: ["id"],
	indexes: {
		byScope: {
			eq: ["scope_key"],
			sort: ["id"],
			root: { model: "release_catalogs" }
		},
		byScopeEnabled: {
			eq: ["scope_key", "enabled"],
			sort: ["id"],
			root: { model: "release_catalogs" }
		},
		byChannelPlatform: {
			eq: ["channel_id", "platform"],
			sort: ["id"]
		},
		byChannelPlatformEnabled: {
			eq: [
				"channel_id",
				"platform",
				"enabled"
			],
			sort: ["id"]
		},
		byBundle: {
			eq: ["bundle_id"],
			sort: ["id"]
		},
		all: {
			eq: [],
			sort: ["id"]
		}
	}
});
/** One compiled catalog per scope; the update check reads exactly this row. */
var releaseCatalogs = defineTable({
	scope_key: {
		type: "string",
		maxLength: 2048,
		ascii: true
	},
	catalog_id: {
		type: "string",
		maxLength: 255
	},
	strategy: {
		type: "string",
		maxLength: 16
	},
	channel_id: {
		...CHANNEL_ID,
		references: {
			model: "channels",
			onDelete: "none"
		}
	},
	channel_key: {
		type: "string",
		maxLength: 1400,
		ascii: true
	},
	platform: {
		type: "string",
		maxLength: 16
	},
	fingerprint_hash: {
		type: "string",
		maxLength: 255,
		required: false
	},
	generation: { type: "integer" },
	payload: { type: "string" },
	catalog_hash: {
		type: "string",
		maxLength: 71
	},
	byte_size: { type: "integer" },
	is_tombstone: { type: "boolean" },
	updated_at_ms: { type: "integer" }
}, {
	key: ["scope_key"],
	indexes: { all: {
		eq: [],
		sort: ["scope_key"]
	} }
});
var channels = defineTable({
	id: CHANNEL_ID,
	name: {
		type: "string",
		maxLength: 255,
		unique: true
	}
}, {
	key: ["id"],
	indexes: { all: {
		eq: [],
		sort: ["name"]
	} }
});
/**
* The native builds `native-build android` and `native-build ios` track, newest first
* in each scope: a platform, a channel, and the fingerprint or app version
* the build compiled in. A sandbox build's scope has no channel: its app ID,
* URL scheme, artifact kind and distribution in its place, so pull requests
* reuse it across channels, while `channel_id` still names the channel it
* embeds. `min_bundle_id` names the build's built-in bundle,
* a `bundles` row no release publishes. Its references keep no counters, so
* adding this table changes no existing one; a channel with builds is
* refused deletion through `byChannel`. `build_key` is the native build key
* of every input the artifact was built from (`nbk1:` and a SHA-256), which
* a build with the same inputs reuses it by; a build registered without
* one is never reused. `build_number` is the artifact's `CFBundleVersion`
* or `versionCode`. `submitted_to`, `submitted_at_ms` and
* `submitted_version` record the store track a build went to, when, and
* the store's label of the build; they stay null for a build no store took.
* `is_store_build` is true on the build a person or a job says the store
* sells, and false on every other: deploys patch from it over the scope's
* newest build. The engine copies the scope key into `store_build_scope_key`
* for that build alone, so `byStoreBuild` holds one entry per scope at most,
* on every store, while any number of a scope's builds hold none.
* `is_sandbox` is true on a sandbox build, set from its artifact when it
* registers and never changed, and `sandbox_url_scheme` is the URL scheme its artifact registers,
* which its preview links open; null on any other build, and on a sandbox
* build registered before the column, which registered the derived one.
* `export_method` is how an `.ipa` was exported, read from its profile when
* it registers and never changed; null on any other artifact, on an `.ipa`
* whose profile couldn't be read, and on one registered before the column.
* `native_app_version` is the app version the artifact itself reports, its
* `CFBundleShortVersionString` or `versionName`, read from the artifact when
* it registers and never changed, whatever the update strategy; `app_version`
* stays the version OTAs target, null on a fingerprint build. It is null
* when the artifact's can't be read, and on a build registered before the
* column.
* Boolean columns follow one rule: `is_*` for a fact about the row or
* `should_*` for an instruction to the client, never null; a unique index over
* the rows where one is true keys a derived slot, not the boolean.
*/
var nativeBuilds = defineTable({
	id: {
		type: "string",
		maxLength: 36
	},
	scope_key: {
		type: "string",
		maxLength: 2048,
		ascii: true
	},
	platform: {
		type: "string",
		maxLength: 16
	},
	channel_id: {
		...CHANNEL_ID,
		references: {
			model: "channels",
			onDelete: "none"
		}
	},
	fingerprint_hash: {
		type: "string",
		maxLength: 255,
		required: false
	},
	app_version: {
		type: "string",
		required: false
	},
	min_bundle_id: {
		type: "string",
		maxLength: 36,
		unique: true,
		references: {
			model: "bundles",
			onDelete: "none"
		}
	},
	artifact_kind: {
		type: "string",
		maxLength: 16
	},
	artifact_storage_uri: { type: "string" },
	byte_size: { type: "integer" },
	git_commit_hash: {
		type: "string",
		maxLength: 255,
		required: false
	},
	created_at_ms: { type: "integer" },
	build_key: {
		type: "string",
		maxLength: 69,
		ascii: true,
		required: false
	},
	build_number: {
		type: "string",
		maxLength: 64,
		required: false
	},
	submitted_to: {
		type: "string",
		maxLength: 16,
		required: false
	},
	submitted_at_ms: {
		type: "integer",
		required: false
	},
	submitted_version: {
		type: "string",
		maxLength: 255,
		required: false
	},
	is_store_build: { type: "boolean" },
	is_sandbox: { type: "boolean" },
	sandbox_url_scheme: {
		type: "string",
		maxLength: 255,
		ascii: true,
		required: false
	},
	export_method: {
		type: "string",
		maxLength: 16,
		required: false
	},
	native_app_version: {
		type: "string",
		required: false
	}
}, {
	key: ["id"],
	derived: { store_build_scope_key: {
		type: "string",
		maxLength: 2048,
		ascii: true,
		compute: (row) => row.is_store_build ? row.scope_key : null
	} },
	indexes: {
		byScope: {
			eq: ["scope_key"],
			sort: ["id"]
		},
		byBuildKey: {
			eq: ["scope_key", "build_key"],
			sort: ["id"]
		},
		byScopeKind: {
			eq: ["scope_key", "artifact_kind"],
			sort: ["id"]
		},
		byStoreBuild: {
			eq: ["store_build_scope_key"],
			sort: [],
			unique: true
		},
		byChannel: {
			eq: ["channel_id"],
			sort: ["id"],
			root: { model: "channels" }
		},
		all: {
			eq: [],
			sort: ["id"]
		}
	}
});
/**
* The iPhones a team asks to install ad hoc builds on. A row decides what the
* CLI registers with Apple, not what an export includes: Xcode's automatic ad
* hoc profile lists every device the Apple account has enabled. `status` is
* `pending` until someone approves it, `approved` until a build or
* `native-build devices add` registers it with Apple, then `registered`;
* declining or removing one deletes its row. `udid` is the UDID in lower case.
* `apple_issuer_id` is the App Store Connect issuer whose key registered it,
* set once: a build signed by another account never registers these rows.
* `apple_error` is Apple's refusal of the device, or why it stopped counting
* it, cleared by the next success. `build_id` is the newest native build whose
* .ipa the CLI checked lists it; deleting that build never touches the row.
* It holds personal data: a UDID, a name, and the emails of who asked and who
* approved, null for the CLI.
*/
var iosDevices = defineTable({
	id: {
		type: "string",
		maxLength: 36
	},
	udid: {
		type: "string",
		maxLength: 40,
		ascii: true,
		unique: true
	},
	name: {
		type: "string",
		maxLength: 100
	},
	status: {
		type: "string",
		maxLength: 16
	},
	requested_by: {
		type: "string",
		maxLength: 320,
		required: false
	},
	created_at_ms: { type: "integer" },
	approved_by: {
		type: "string",
		maxLength: 320,
		required: false
	},
	approved_at_ms: {
		type: "integer",
		required: false
	},
	registered_at_ms: {
		type: "integer",
		required: false
	},
	apple_issuer_id: {
		type: "string",
		maxLength: 64,
		ascii: true,
		required: false
	},
	apple_error: {
		type: "string",
		maxLength: 512,
		required: false
	},
	build_id: {
		type: "string",
		maxLength: 36,
		required: false
	}
}, {
	key: ["id"],
	indexes: {
		byStatus: {
			eq: ["status"],
			sort: ["id"]
		},
		byRegistration: {
			eq: [],
			sort: ["registered_at_ms"]
		},
		all: {
			eq: [],
			sort: ["id"]
		}
	}
});
/**
* The Apple account the iOS device registry belongs to: one row, keyed
* `registry`, holding the App Store Connect issuer that first registered a
* device. A build claims it before it sends Apple anything, and its key makes
* the claim atomic on every store, so two builds of two accounts can't both
* spend a slot; another account's build then registers nothing. Removing
* devices never releases it.
*/
var iosDeviceAccount = defineTable({
	id: {
		type: "string",
		maxLength: 16,
		ascii: true
	},
	apple_issuer_id: {
		type: "string",
		maxLength: 64,
		ascii: true
	},
	claimed_at_ms: { type: "integer" }
}, {
	key: ["id"],
	indexes: { all: {
		eq: [],
		sort: ["id"]
	} }
});
/** Core's module: always installed, never a plugin. */
var coreModule = {
	id: "core",
	schema: {
		bundles,
		bundle_patches: bundlePatches,
		releases,
		release_catalogs: releaseCatalogs,
		channels,
		bundle_totals: defineAggregate({ platform_key: {
			type: "string",
			maxLength: 16
		} }, {
			key: ["platform_key"],
			counters: ["bundles"],
			indexes: { byPlatform: {
				eq: ["platform_key"],
				sort: []
			} }
		}),
		native_builds: nativeBuilds,
		ios_devices: iosDevices,
		ios_device_account: iosDeviceAccount
	}
};
var encoder = new TextEncoder();
var decoder = new TextDecoder();
var toBase64Url = (text) => {
	let binary = "";
	for (const byte of encoder.encode(text)) binary += String.fromCharCode(byte);
	return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
};
var fromBase64Url = (value) => {
	const binary = atob(value.replaceAll("-", "+").replaceAll("_", "/"));
	return decoder.decode(Uint8Array.from(binary, (char) => char.charCodeAt(0)));
};
/** A stable 32-bit FNV-1a hash of the text's UTF-8 bytes. */
var fnv1a = (text) => {
	let hash = 2166136261;
	for (const byte of encoder.encode(text)) hash = Math.imul(hash ^ byte, 16777619) >>> 0;
	return hash;
};
/** A hash of the request's identity; a cursor only resumes the same read. */
var cursorScope = (parts) => fnv1a(JSON.stringify(parts)).toString(36);
var encodeCursor = (scope, after) => toBase64Url(JSON.stringify([scope, after]));
/** The order tuple a cursor resumes after; rejects a cursor from another read. */
var decodeCursor = (scope, cursor) => {
	let decoded;
	try {
		decoded = JSON.parse(fromBase64Url(cursor));
	} catch {
		decoded = void 0;
	}
	const [from, after] = Array.isArray(decoded) ? decoded : [];
	if (typeof from !== "string" || !Array.isArray(after) || !after.every(isKeyValue)) throw new DatabaseCursorError("The cursor is malformed.");
	if (from !== scope) throw new DatabaseCursorError("The cursor belongs to a read with another model, index, filter, order, or range.");
	return after;
};
var definitionOf = (model) => model.definition;
/** Every change keyed by one value lands on one shard. */
var shardOf = (value, shards) => fnv1a(value) % shards;
/** Merges one `tx.aggregate` call into its shard row's pending changes. */
var recordAggregate = (changes, model, identity, values, shardBy) => {
	const { key: fields, counters, gauges, distinct, shards } = definitionOf(model);
	const fail = (message) => new DatabaseTransactionError(`${model.table.name}: ${message}`);
	if (Object.keys(identity).length !== fields.length || !fields.every((name) => isKeyValue(identity[name]))) throw fail(`aggregate takes exactly its identity fields: ${fields.join(", ")}.`);
	if (shardBy === void 0 && shards > 1 && gauges.some((gauge) => gauge in values)) throw fail("gauges of a sharded aggregate need shardBy.");
	const shard = shardBy === void 0 ? Math.floor(Math.random() * shards) : shardOf(shardBy, shards);
	const key = [...fields.map((name) => identity[name]), shard];
	const id = JSON.stringify([model.table.name, key]);
	const change = changes.get(id) ?? {
		model,
		key,
		deltas: {},
		sketches: {}
	};
	changes.set(id, change);
	for (const [metric, value] of Object.entries(values)) if (distinct.includes(metric) && typeof value === "string") change.sketches[metric] = mergeDistinct([change.sketches[metric], value]);
	else if ((counters.includes(metric) || gauges.includes(metric)) && Number.isSafeInteger(value)) change.deltas[metric] = (change.deltas[metric] ?? 0) + Number(value);
	else throw fail(`${metric} is not a counter, gauge, or sketch of this aggregate.`);
};
/** A shard row before its first change: every metric zero or empty. */
var blank$1 = (model, key) => {
	const { counters, gauges, distinct } = definitionOf(model);
	return Object.fromEntries([
		...model.table.key.map((column, position) => [column, key[position]]),
		...[...counters, ...gauges].map((name) => [name, 0]),
		...distinct.map((name) => [name, null]),
		["_v", 0]
	]);
};
/**
* A gauge computed below zero. Deltas from a row another writer has since
* moved do this, so the transaction reruns; it is thrown only when it lasts.
*/
var NegativeGaugeError = class extends DatabaseTransactionError {};
/** The guarded write that merges `change` into `current`: insert, patch, or delete at zero. */
var rewrite$1 = ({ model, key, deltas, sketches }, current) => {
	const { table } = model;
	const { counters, gauges, distinct } = definitionOf(model);
	const base = current ?? blank$1(model, key);
	const set = {};
	for (const [metric, delta] of Object.entries(deltas)) set[metric] = Number(base[metric] ?? 0) + delta;
	for (const [metric, sketch] of Object.entries(sketches)) set[metric] = mergeDistinct([base[metric], sketch]);
	if (current && Object.entries(set).every(([metric, value]) => current[metric] === value)) return;
	const row = {
		...base,
		...set
	};
	if (gauges.some((gauge) => Number(row[gauge]) < 0)) {
		if (current === null && table.retention) return void 0;
		throw new NegativeGaugeError(`${table.name}: a gauge went below 0.`);
	}
	const zero = distinct.length === 0 && [...counters, ...gauges].every((metric) => Number(row[metric]) === 0);
	if (current === null) return zero ? void 0 : {
		type: "insert",
		table,
		row
	};
	const guard = { v: Number(current["_v"]) };
	return zero ? {
		type: "delete",
		table,
		key,
		guard,
		previous: current
	} : {
		type: "patch",
		table,
		key,
		set,
		guard,
		previous: current
	};
};
/**
* Counter-only rows become blind increments that create the row when it is
* missing. Rows with gauges or sketches are read in one parallel batch per
* table, merged, and written back under a guard, so a conflict resends only
* them.
*/
var compileAggregates = async (adapter, changes) => {
	const ops = [];
	const merged = /* @__PURE__ */ new Map();
	for (const change of changes) {
		const { model, key, deltas, sketches } = change;
		if (Object.keys(sketches).length > 0 || definitionOf(model).gauges.some((gauge) => (deltas[gauge] ?? 0) !== 0)) merged.set(model, [...merged.get(model) ?? [], change]);
		else if (Object.values(deltas).some((delta) => delta !== 0)) {
			const { table } = model;
			const init = blank$1(model, key);
			ops.push({
				type: "increment",
				table,
				key,
				by: deltas,
				init
			});
		}
	}
	const groups = [...merged.values()];
	const current = await Promise.all(groups.map((group) => adapter.get(group[0].model.table, group.map(({ key }) => key))));
	groups.forEach((group, index) => group.forEach((change, position) => {
		const op = rewrite$1(change, current[index][position] ?? null);
		if (op !== void 0) ops.push(op);
	}));
	return ops;
};
/** Log rows spread over 8 tables, each its own DynamoDB partition. */
var LOG_TABLES = [
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	7
].map((at) => `aggregate_log_${at}`);
var LEASE_TABLE = "aggregate_lease";
var LEASE = { id: "compaction" };
/** How long a compaction holds the lease before another process may take it. */
var LEASE_MS = 3e4;
/** A commit compacts once this has passed since the last compaction. */
var WINDOW_MS = 6e4;
/** Log rows a compaction reads from each log table for one group. */
var LOG_PAGE = 200;
/**
* How old a log row this process can't apply must be before its reads step
* past it: older than any transaction still committing, between servers
* whose clocks agree this closely.
*/
var SKIP_AFTER_MS = 3e5;
/**
* Groups one compaction applies: after a commit, so the request that runs
* it waits for one group; before a read; and on flush.
*/
var GROUPS = {
	commit: 1,
	read: 8,
	flush: 256
};
/** Tries per write after a conflict or a transient error. */
var ATTEMPTS = 5;
var log = defineTable({
	id: {
		type: "string",
		maxLength: 32
	},
	changes: { type: "string" }
}, {
	key: ["id"],
	indexes: { oldest: {
		eq: [],
		sort: ["id"]
	} }
});
/**
* Held by `holder` until `until`; the next compaction is due at `next`.
* `applied` lists the log rows a compaction has applied and not yet deleted,
* as `[log table's index, id]` pairs, so no compaction applies them again.
*/
var lease = defineTable({
	id: {
		type: "string",
		maxLength: 16
	},
	holder: {
		type: "string",
		maxLength: 32
	},
	until: { type: "integer" },
	next: { type: "integer" },
	applied: { type: "string" }
}, { key: ["id"] });
/** The log and lease tables; an engine that batches has them in its schema. */
var aggregateBatchingModule = {
	id: "aggregateBatching",
	schema: {
		...Object.fromEntries(LOG_TABLES.map((table) => [table, log])),
		[LEASE_TABLE]: lease
	}
};
var shapeOf = (model) => model.definition;
var isBatched = (model) => model?.definition.kind === "aggregate" && shapeOf(model).batched === true;
var valuesOf = ({ deltas, sketches }) => ({
	...deltas,
	...sketches
});
/**
* Merges `values` into the change for `key`'s identity as `tx.aggregate`
* does: deltas add up and sketches merge. One constant `shardBy` keys each
* identity to one entry; `compile` writes it to shard 0.
*/
var merge = (into, model, key, values) => recordAggregate(into, model, Object.fromEntries(shapeOf(model).key.map((field, at) => [field, key[at]])), values, "");
var mergeAll = (into, changes) => {
	for (const change of changes) merge(into, change.model, change.key, valuesOf(change));
	return into;
};
/** A row's metrics as values to merge: counters, gauges, and the sketches it has. */
var metricsOf$1 = (model, row) => {
	const { counters, gauges, distinct } = shapeOf(model);
	return Object.fromEntries([...[...counters, ...gauges].map((name) => [name, Number(row[name] ?? 0)]), ...distinct.flatMap((name) => row[name] === null || row[name] === void 0 ? [] : [[name, row[name]]])]);
};
/** A shard row before its first change: every metric zero or empty. */
var blank = (model, key) => {
	const { counters, gauges, distinct } = shapeOf(model);
	return Object.fromEntries([
		...model.table.key.map((column, at) => [column, key[at]]),
		...[...counters, ...gauges].map((name) => [name, 0]),
		...distinct.map((name) => [name, null]),
		["_v", 0]
	]);
};
/** Whether a change needs its row: sketches merge, and a gauge may reach zero. */
var rewrites = ({ model, deltas, sketches }) => Object.keys(sketches).length > 0 || shapeOf(model).gauges.some((gauge) => (deltas[gauge] ?? 0) !== 0);
var increment = ({ model, deltas }, key) => Object.values(deltas).some((delta) => delta !== 0) ? {
	type: "increment",
	table: model.table,
	key,
	by: deltas,
	init: blank(model, key)
} : void 0;
/**
* The guarded write that merges `change` into `current`: insert, patch, or
* delete at zero. Unlike a transaction's, a gauge may go below zero here: a
* group can hold a loss without the gain before it, and reads sum every shard.
*/
var rewrite = (change, key, current) => {
	const { model } = change;
	const { table } = model;
	const { counters, gauges, distinct } = shapeOf(model);
	const base = current ?? blank(model, key);
	const sum = mergeAll(/* @__PURE__ */ new Map(), [change]);
	merge(sum, model, key, metricsOf$1(model, base));
	const set = valuesOf([...sum.values()][0]);
	if (current && Object.keys(set).every((name) => current[name] === set[name])) return void 0;
	const row = {
		...base,
		...set
	};
	const zero = distinct.length === 0 && [...counters, ...gauges].every((name) => Number(row[name]) === 0);
	if (current === null) return zero ? void 0 : {
		type: "insert",
		table,
		row
	};
	const guard = { v: Number(current["_v"]) };
	return zero ? {
		type: "delete",
		table,
		key,
		guard,
		previous: current
	} : {
		type: "patch",
		table,
		key,
		set,
		guard,
		previous: current
	};
};
/** A shard row's place in what `readCurrent` read. */
var rowId = (model, key) => JSON.stringify([model.table.name, key]);
/** The shard key each change writes: shard 0, since one compaction runs at a time. */
var keysOf = (changes) => changes.map(({ key }) => [...key.slice(0, -1), 0]);
/**
* The current rows of the changes that rewrite theirs (gauges and sketches),
* each once, in one batch per table.
*/
var readCurrent = async (adapter, changes) => {
	const keys = keysOf(changes);
	const reads = /* @__PURE__ */ new Map();
	changes.forEach((change, at) => {
		if (!rewrites(change)) return;
		const wanted = reads.get(change.model) ?? /* @__PURE__ */ new Map();
		wanted.set(rowId(change.model, keys[at]), keys[at]);
		reads.set(change.model, wanted);
	});
	const current = /* @__PURE__ */ new Map();
	await Promise.all([...reads].map(async ([model, wanted]) => {
		const keys = [...wanted.values()];
		const rows = await adapter.get(model.table, keys);
		keys.forEach((key, at) => {
			current.set(rowId(model, key), rows[at] ?? null);
		});
	}));
	return current;
};
/**
* The write for each change: a blind increment that creates the row for
* counters, and a guarded rewrite for gauges and sketches, over the rows
* `current` read.
*/
var build = (changes, current) => {
	const keys = keysOf(changes);
	return changes.map((change, at) => rewrites(change) ? rewrite(change, keys[at], current.get(rowId(change.model, keys[at])) ?? null) : increment(change, keys[at]));
};
var isOp = (op) => op !== void 0;
var sleep = (attempt) => new Promise((resolve) => setTimeout(resolve, Math.min(250, 5 * 2 ** attempt) * Math.random()));
/** Runs of one character, where shorter: a sparse sketch packs into a few. */
var pack = (text) => {
	const runs = (text.match(/(.)\1*/gsu) ?? []).flatMap((run) => [run[0], run.length]);
	return JSON.stringify(runs).length < JSON.stringify(text).length ? runs : text;
};
var unpack = (value) => Array.isArray(value) ? value.map((item, at) => at % 2 ? "" : item.repeat(value[at + 1])).join("") : value;
/** Raw deflate of `text` as base64, where the runtime has `CompressionStream`. */
var deflate = async (text) => {
	if (typeof CompressionStream === "undefined") return void 0;
	const stream = new Blob([text]).stream().pipeThrough(new CompressionStream("deflate-raw"));
	let binary = "";
	for (const byte of new Uint8Array(await new Response(stream).arrayBuffer())) binary += String.fromCharCode(byte);
	return btoa(binary);
};
var inflate = (base64) => new Response(new Blob([Uint8Array.from(atob(base64), (char) => char.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).text();
/**
* A log row's `changes`: entries of a table, an identity, and values, as
* JSON, or `z` and its deflate where shorter, so a row stays under the 1 KB
* that DynamoDB bills as one unit.
*/
var encode = async (changes) => {
	const json = JSON.stringify({
		v: 1,
		c: [...changes].map(({ model, key, deltas, sketches }) => {
			const packed = Object.entries(sketches).map(([name, sketch]) => [name, pack(sketch)]);
			const values = {
				...deltas,
				...Object.fromEntries(packed)
			};
			return [
				model.table.name,
				key.slice(0, -1),
				values
			];
		})
	});
	const zipped = await deflate(json);
	return zipped !== void 0 && zipped.length < json.length ? `z${zipped}` : json;
};
/**
* Batches changes to aggregates declared `batched`. A transaction writes
* them as one log row in its own atomic write, in place of their rows; a
* compaction later merges log rows into the aggregates and deletes them,
* atomically again, so each applies exactly once. One lease row keeps
* compactions one at a time.
*/
var createAggregateBatches = ({ engine, adapter, schema, batching: { windowMs = WINDOW_MS }, now }) => {
	if (!schema.models.has(LEASE_TABLE)) throw new DatabaseTransactionError("An engine that batches aggregates needs aggregateBatchingModule in its schema.");
	const holder = crypto.randomUUID().replaceAll("-", "");
	const table = (name) => schema.models.get(name).table;
	const warned = /* @__PURE__ */ new Set();
	const warn = (what) => (error) => {
		if (warned.has(what)) return;
		warned.add(what);
		console.warn(`[hot-updater] Aggregate ${what} failed.`, error);
	};
	/** A log row's changes, or undefined when it names an aggregate or metric this schema lacks. */
	const decode = async (text) => {
		const changes = /* @__PURE__ */ new Map();
		try {
			const json = text.startsWith("z") ? await inflate(text.slice(1)) : text;
			const { c } = JSON.parse(json);
			for (const [name, identity, values] of c) {
				const model = schema.models.get(name);
				if (!isBatched(model)) return void 0;
				const unpacked = Object.entries(values).map(([metric, value]) => [metric, unpack(value)]);
				merge(changes, model, [...identity, 0], Object.fromEntries(unpacked));
			}
		} catch (error) {
			warn("log decoding")(error);
			return;
		}
		return changes;
	};
	let nextDue = 0;
	let compacting;
	/** Log rows this process read, by `[log table's index, id]`, for the deletes after a group. */
	const known = /* @__PURE__ */ new Map();
	/**
	* Each log table's last row of a run at its head that this process can't
	* apply (it names an aggregate or metric this schema lacks), whose reads
	* start past it. The rows wait for a process that can apply them, and a
	* restart reads them again.
	*/
	const skipped = LOG_TABLES.map(() => void 0);
	const past = (shard) => skipped[shard] === void 0 ? {} : { range: { gt: skipped[shard] } };
	/** When a log row's transaction stamped its ID. */
	const stampOf = (id) => Number.parseInt(id.slice(0, 9), 36);
	const idOf = (shard, id) => JSON.stringify([shard, id]);
	/** The lease row as stored once `set` is written over it. */
	const leaseOp = (held, set) => {
		const next = {
			...held,
			...set,
			_v: Number(held._v) + 1
		};
		return {
			op: {
				type: "patch",
				table: table(LEASE_TABLE),
				key: [LEASE.id],
				set,
				guard: { v: Number(held._v) },
				previous: held
			},
			next
		};
	};
	/** The lease row as stored after this process takes it, or undefined when it is held or not due. */
	const takeLease = (force) => engine.transaction(async (tx) => {
		const at = now();
		const held = await tx.findOne(LEASE_TABLE, LEASE);
		const fields = {
			holder,
			until: at + LEASE_MS
		};
		if (held === null) {
			const row = {
				...LEASE,
				...fields,
				next: 0,
				applied: "[]"
			};
			tx.create(LEASE_TABLE, row);
			return {
				...row,
				_v: 0
			};
		}
		nextDue = Number(held.next);
		if (held.holder !== holder && Number(held.until) > at || !force && nextDue > at) return void 0;
		tx.update(LEASE_TABLE, held, fields);
		return {
			...held,
			...fields,
			_v: Number(held._v) + 1
		};
	});
	/**
	* Writes `ops` once, retrying transient errors; true when it committed.
	* A conflict leaves its log rows for the next compaction; a write whose
	* outcome is unknown throws, and the next compaction reads what it did.
	*/
	const commit = async (ops) => {
		for (let failures = 0; failures < ATTEMPTS; failures += 1) {
			const result = await adapter.write(ops);
			if (result.ok) return true;
			if (!("retry" in result)) return false;
			await sleep(failures);
		}
		return false;
	};
	/** Deletes the log rows `held` lists as applied, in parallel writes; true once none is left. */
	const deleteApplied = async (held) => {
		const applied = JSON.parse(String(held.applied));
		await Promise.all(LOG_TABLES.map(async (name, shard) => {
			const ids = applied.flatMap(([at, id]) => at === shard && !known.has(idOf(at, id)) ? [id] : []);
			if (ids.length === 0) return;
			const rows = await adapter.get(table(name), ids.map((id) => [id]));
			for (const row of rows) if (row) known.set(idOf(shard, row.id), row);
		}));
		const rows = applied.flatMap(([shard, id]) => {
			const row = known.get(idOf(shard, id));
			return row === void 0 ? [] : [{
				shard,
				row
			}];
		});
		if (adapter.deleteConsumed && await Promise.all(LOG_TABLES.map((name, at) => {
			const own = rows.flatMap(({ shard, row }) => shard === at ? [row] : []);
			return own.length > 0 && adapter.deleteConsumed(table(name), own);
		})).then(() => true, (error) => (warn("log cleanup")(error), false))) {
			for (const [shard, id] of applied) known.delete(idOf(shard, id));
			return true;
		}
		const deletes = rows.map(({ shard, row }) => {
			const guard = { v: Number(row["_v"]) };
			return {
				type: "delete",
				table: table(LOG_TABLES[shard]),
				key: [String(row.id)],
				guard,
				previous: row
			};
		});
		let size = deletes.length;
		while (size > 1 && !adapter.fits(deletes.slice(0, size))) size = Math.ceil(size / 2);
		const chunks = [];
		for (let at = 0; at < deletes.length; at += size) chunks.push(deletes.slice(at, at + size));
		if ((await Promise.all(chunks.map(commit))).includes(false)) return false;
		for (const [shard, id] of applied) known.delete(idOf(shard, id));
		return true;
	};
	/**
	* The oldest pending log rows this schema can read, a page from each
	* table; `more` when a page was full, so more may wait.
	*/
	const readLogs = async () => {
		let more = false;
		return {
			logs: (await Promise.all(LOG_TABLES.map(async (name, shard) => {
				const page = await engine.reads.findMany(name, {
					index: "oldest",
					limit: LOG_PAGE,
					...past(shard)
				});
				more ||= page.next !== void 0;
				const decoded = await Promise.all(page.rows.map(async (row) => ({
					shard,
					row,
					changes: await decode(String(row.changes))
				})));
				const settled = now() - SKIP_AFTER_MS;
				for (const { row, changes } of decoded) {
					const id = String(row.id);
					if (changes !== void 0 || stampOf(id) >= settled) break;
					skipped[shard] = id;
				}
				return decoded.flatMap(({ changes, ...entry }) => changes === void 0 ? [] : [{
					...entry,
					changes
				}]);
			}))).flat().sort((left, right) => compareUtf8(String(left.row.id), String(right.row.id))),
			more
		};
	};
	/**
	* Applies the oldest pending log rows whose merged changes fit in one
	* atomic write with the lease, which lists them as applied; the rows are
	* deleted after it. A log row too large for one write applies in parts,
	* keeping the rest in it. Returns the lease after the write and how many
	* log rows it applied whole, or undefined when a conflict stopped it.
	*/
	const applyGroup = async (held, logs) => {
		const current = await readCurrent(adapter, logs.flatMap((entry) => [...entry.changes.values()]));
		const rowsFor = (changes) => build(changes, current).filter(isOp);
		for (let count = logs.length; count > 0; count = Math.floor(count / 2)) {
			const batch = logs.slice(0, count);
			const changes = mergeAll(/* @__PURE__ */ new Map(), batch.flatMap((entry) => [...entry.changes.values()]));
			const applied = batch.map(({ shard, row }) => [shard, row.id]);
			const lease = leaseOp(held, { applied: JSON.stringify(applied) });
			const ops = [...rowsFor([...changes.values()]), lease.op];
			if (!adapter.fits(ops)) continue;
			for (const { shard, row } of batch) known.set(idOf(shard, row.id), row);
			return await commit(ops) ? {
				held: lease.next,
				count
			} : void 0;
		}
		const [{ shard, row, changes }] = logs;
		const name = LOG_TABLES[shard];
		const entries = [...changes.values()];
		for (let take = entries.length - 1; take > 0; take = Math.floor(take / 2)) {
			const kept = {
				type: "patch",
				table: table(name),
				key: [String(row.id)],
				set: { changes: await encode(entries.slice(take)) },
				guard: { v: Number(row["_v"]) },
				previous: row
			};
			const lease = leaseOp(held, {});
			const ops = [
				...rowsFor(entries.slice(0, take)),
				kept,
				lease.op
			];
			if (adapter.fits(ops)) return await commit(ops) ? {
				held: lease.next,
				count: 0
			} : void 0;
		}
		throw new DatabaseTransactionError(`${name}: one aggregate change does not fit in one write.`);
	};
	/**
	* Applies up to `groups` groups under the lease, deleting each group's log
	* rows before the next; the next compaction is due at once when some are
	* left. The lease release clears the applied list once its rows are gone.
	*/
	const run = async (force, groups) => {
		let held = await takeLease(force);
		if (held === void 0) return;
		let pending = true;
		let clear = false;
		let carried;
		try {
			for (let group = 0;; group += 1) {
				clear = await deleteApplied(held);
				if (!clear || !pending || group === groups) break;
				const { logs, more } = carried ?? await readLogs();
				if (logs.length === 0) {
					pending = false;
					break;
				}
				const applied = await applyGroup(held, logs);
				if (applied === void 0) break;
				[held, clear] = [applied.held, false];
				const rest = applied.count === 0 ? [] : logs.slice(applied.count);
				carried = rest.length > 0 ? {
					logs: rest,
					more
				} : void 0;
				pending = more || applied.count < logs.length;
			}
		} finally {
			nextDue = now() + (pending ? 0 : windowMs);
			const set = {
				until: 0,
				next: nextDue,
				...clear ? { applied: "[]" } : {}
			};
			await commit([leaseOp(held, set).op]);
			known.clear();
		}
	};
	/** One compaction at a time in this process; never rejects. */
	const compact = (force, groups) => compacting ??= run(force, groups).catch(warn("compaction")).finally(() => {
		compacting = void 0;
	});
	let checking;
	/** Whether any log row waits; reads at once share one check. */
	const hasPending = () => checking ??= Promise.all(LOG_TABLES.map((name, shard) => engine.reads.findMany(name, {
		index: "oldest",
		limit: 1,
		...past(shard)
	}))).then((pages) => pages.some((page) => page.rows.length > 0)).finally(() => {
		checking = void 0;
	});
	return {
		async transaction(fn) {
			let changes = /* @__PURE__ */ new Map();
			const result = await engine.transaction(async (tx) => {
				const attempt = /* @__PURE__ */ new Map();
				changes = attempt;
				let open = true;
				let failure;
				const aggregate = (name, identity, values, options) => {
					const model = schema.models.get(name);
					if (!isBatched(model)) return tx.aggregate(name, identity, values, options);
					try {
						if (!open) throw new DatabaseTransactionError("The transaction has ended.");
						recordAggregate(attempt, model, identity, values, options?.shardBy);
					} catch (error) {
						failure ??= { error };
						throw error;
					}
				};
				try {
					const value = await fn({
						...tx,
						aggregate
					});
					if (failure) throw failure.error;
					if (attempt.size > 0) {
						const id = `${now().toString(36).padStart(9, "0")}${holder.slice(0, 8)}${crypto.randomUUID().slice(0, 8)}`;
						const shard = Math.floor(Math.random() * LOG_TABLES.length);
						const merged = mergeAll(/* @__PURE__ */ new Map(), attempt.values());
						tx.create(LOG_TABLES[shard], {
							id,
							changes: await encode(merged.values())
						});
					}
					return value;
				} finally {
					open = false;
				}
			});
			if (changes.size > 0 && now() >= nextDue) await compact(false, GROUPS.commit);
			return result;
		},
		async beforeRead(name) {
			if (!isBatched(schema.models.get(name))) return;
			if (await hasPending().catch((error) => {
				warn("read")(error);
				return false;
			})) await compact(true, GROUPS.read);
		},
		async flush() {
			if (await hasPending()) await compact(true, GROUPS.flush);
		}
	};
};
var MINUTE_MS = 6e4;
var HOUR_MS = 60 * MINUTE_MS;
var DAY_MS = 24 * HOUR_MS;
/** A model's retention as its physical table carries it, which each adapter maps natively. */
var physicalRetention = ({ retention }) => retention === void 0 ? {} : { retention: {
	column: retention.field,
	ms: retention.days * DAY_MS
} };
/** Models in a reference or a rooted index, which an expired row's delete would break. */
var linkedModels = (schema) => Object.entries(schema).flatMap(([name, { fields, indexes }]) => [...Object.values(fields).map(({ references }) => references), ...Object.values(indexes).map(({ root }) => root)].flatMap((link) => link ? [name, link.model] : []));
/**
* What is wrong with a model's retention: it counts from an integer field,
* over whole days, and expired rows are deleted without cascades, counter
* moves, or root bumps, so the model is in no reference or rooted index.
*/
var retentionProblems = (schema, model) => {
	const definition = schema[model];
	if (definition.retention === void 0) return [];
	const { field, days } = definition.retention;
	const declared = definition.fields[field] ?? (definition.kind === "table" ? definition.derived[field] : void 0);
	return [
		...declared?.type !== "integer" || "multi" in declared && declared.multi === true ? [`retention field "${field}" is not an integer field`] : [],
		...Number.isSafeInteger(days) && days >= 1 ? [] : ["retention days must be a whole number of at least 1"],
		...linkedModels(schema).includes(model) ? ["a model with retention is in no reference or rooted index"] : []
	];
};
/**
* Rows a pass deletes from each table: one statement or two a table, so a
* pass stays well inside D1's 50 queries an invocation.
*/
var PASS_LIMIT = 500;
/** The lease row: when the next pass is due, in epoch ms. */
var LEASE_KEY = "retention.nextPassAt";
/**
* The adapter, pruning during its writes with no scheduler: once the lease
* row in `leaseTable` is due, the write that takes it first runs one bounded
* pass over the tables with retention, and other writers skip. The next pass
* is due in an hour, or in a minute while a pass still found a full batch of
* expired rows in some table; a pass that fails is due again at once. A
* backend that expires rows natively, or a schema without retention, gets its
* adapter back.
*/
var pruneDuringWrites = (adapter, tables, { leaseTable: table, now }) => {
	const expiring = tables.filter(({ retention }) => retention !== void 0);
	if (adapter.prune === void 0 || expiring.length === 0) return adapter;
	const key = [LEASE_KEY];
	let checkAt = 0;
	const lease = async (row, due) => {
		const value = String(due);
		const guard = { v: row === null ? -1 : Number(row._v) };
		const next = {
			key: LEASE_KEY,
			value,
			_v: guard.v + 1
		};
		const op = row === null ? {
			type: "insert",
			table,
			row: next
		} : {
			type: "patch",
			table,
			key,
			set: { value },
			guard,
			previous: row
		};
		return (await adapter.write([op])).ok ? next : null;
	};
	const pass = async () => {
		const at = now();
		if (at < checkAt) return;
		checkAt = at + MINUTE_MS;
		const [row = null] = await adapter.get(table, [key]);
		checkAt = row === null ? at : Number(row.value);
		if (checkAt > at) return;
		const held = await lease(row, at + HOUR_MS);
		if (held === null) return;
		checkAt = at + HOUR_MS;
		const deleted = [];
		try {
			for (const t of expiring) deleted.push(await adapter.prune(t, at - t.retention.ms, PASS_LIMIT));
		} catch (error) {
			checkAt = at + MINUTE_MS;
			await lease(held, at).catch(() => null);
			throw error;
		}
		if (deleted.includes(PASS_LIMIT) && await lease(held, at + MINUTE_MS) !== null) checkAt = at + MINUTE_MS;
	};
	const warn = (error) => console.warn("[hot-updater] Pruning expired rows failed.", error);
	return Object.assign(Object.create(adapter), { async write(ops) {
		await pass().catch(warn);
		return adapter.write(ops);
	} });
};
var SHARD_COLUMN = "_shard";
var NAME = /^[a-z][a-z0-9_]*$/u;
var INDEX_NAME = /^[A-Za-z][A-Za-z0-9_]*$/u;
var tableName = (module, model) => module.namespace ? `${module.namespace}_${model}` : model;
var integer = (name, defaulted = false) => ({
	name,
	type: "integer",
	nullable: false,
	...defaulted ? { default: 0 } : {}
});
/** A declared or derived field's type, and whether it holds several values. */
var fieldType = (model, name) => {
	const field = model.fields[name] ?? (model.kind === "table" ? model.derived[name] : void 0);
	return field && {
		type: field.type,
		multi: "multi" in field && !!field.multi
	};
};
var metricsOf = (model) => [
	...model.counters,
	...model.gauges,
	...model.distinct
];
/** Field names, the key, and each field's options. */
var fieldProblems = (definition, add) => {
	const names = [...Object.keys(definition.fields), ...definition.kind === "table" ? Object.keys(definition.derived) : metricsOf(definition)];
	for (const name of new Set(names)) {
		if (!NAME.test(name)) add(`field "${name}" must match ${NAME.source}`);
		if (names.indexOf(name) !== names.lastIndexOf(name)) add(`field "${name}" is declared twice`);
	}
	const { key } = definition;
	if (key.length === 0) add("key is empty");
	if (new Set(key).size !== key.length) add("key repeats a field");
	for (const name of key) {
		const field = definition.fields[name];
		if (field === void 0) add(`key field "${name}" is not a declared field`);
		else if (field.required === false) add(`key field "${name}" is nullable`);
		else if (field.type === "json") add(`key field "${name}" is json`);
	}
	const bounded = [...Object.entries(definition.fields), ...definition.kind === "table" ? Object.entries(definition.derived) : []];
	for (const [name, { type, maxLength, ascii }] of bounded) {
		if (maxLength !== void 0 && (type !== "string" || !Number.isSafeInteger(maxLength) || maxLength < 1)) add(`field "${name}" has an invalid maxLength`);
		if (ascii && type !== "string") add(`field "${name}" is ascii but not a string`);
	}
};
/** A table's derived fields and references. */
var tableProblems = (definition, add, table) => {
	for (const [name, derived] of Object.entries(definition.derived)) {
		if (typeof derived.compute !== "function") add(`derived field "${name}" has no compute function`);
		if (derived.multi && derived.type === "json") add(`derived field "${name}" cannot be multi-valued json`);
	}
	for (const [name, { type, references }] of Object.entries(definition.fields)) {
		if (references === void 0) continue;
		const target = table(references.model);
		const targetKey = target?.key.length === 1 ? target.fields[target.key[0]] : void 0;
		if (targetKey === void 0) add(`field "${name}" references "${references.model}", which is not a single-key table of this module`);
		else if (targetKey.type !== type) add(`field "${name}" and the key of "${references.model}" differ in type`);
		if (references.onDelete === "cascade" && !Object.values(definition.indexes).some(({ eq }) => eq.length === 1 && eq[0] === name)) add(`cascade on "${name}" needs an index whose eq is exactly [${name}]`);
	}
};
/** An aggregate's identity, metrics, and shards. */
var aggregateProblems = (definition, add) => {
	const identity = Object.keys(definition.fields);
	if (definition.key.join("\0") !== identity.join("\0")) add(`key must list the identity fields in declaration order: ${identity.join(", ")}`);
	if (metricsOf(definition).length === 0) add("aggregate has no metrics");
	if (definition.distinct.length > 0 && definition.counters.length + definition.gauges.length > 0) add("distinct sketches need an aggregate of their own");
	const { shards } = definition;
	if (!Number.isSafeInteger(shards) || shards < 1 || shards > 64) add(`shards must be 1–64`);
};
/** Every problem in one model's declaration, its roots and references included. */
var problemsOf = (module, model, definition) => {
	const problems = [];
	const add = (message) => problems.push(`${module.id}.${model}: ${message}`);
	const table = (name) => {
		const target = module.schema[name];
		return target?.kind === "table" ? target : void 0;
	};
	if (!NAME.test(model)) add("model names use lowercase letters, digits, and _");
	fieldProblems(definition, add);
	for (const [name, index] of Object.entries(definition.indexes)) {
		const columns = [...index.eq, ...index.sort];
		if (!INDEX_NAME.test(name)) add(`index "${name}" must match ${INDEX_NAME.source}`);
		if (columns.length === 0) add(`index "${name}" has no fields`);
		if (index.unique && index.sort.length > 0) add(`unique index "${name}" cannot sort`);
		if (columns.filter((column) => {
			const type = fieldType(definition, column);
			if (type === void 0) add(`index "${name}" names undeclared field "${column}"`);
			else if (type.type === "json") add(`index "${name}" names json field "${column}"`);
			else if (type.multi && index.sort.includes(column)) add(`index "${name}" sorts by multi-valued field "${column}"`);
			return type?.type !== "json" && type?.multi;
		}).length > 1) add(`index "${name}" has more than one multi-valued field`);
		if (index.root === void 0) continue;
		const root = table(index.root.model);
		if (root === void 0) add(`index "${name}" is rooted at unknown table "${index.root.model}"`);
		else if (root.key.length > index.eq.length || root.key.some((field, position) => fieldType(definition, index.eq[position])?.type !== root.fields[field].type)) add(`index "${name}" eq must start with the key of "${index.root.model}"`);
	}
	if (definition.kind === "table") tableProblems(definition, add, table);
	else aggregateProblems(definition, add);
	for (const problem of retentionProblems(module.schema, model)) add(problem);
	return problems;
};
/** Rejects invalid module schemas at startup, listing every problem. */
var validateSchema = (modules) => {
	const problems = [];
	const owners = /* @__PURE__ */ new Map();
	for (const module of modules) for (const [model, definition] of Object.entries(module.schema)) {
		const name = tableName(module, model);
		const owner = owners.get(name);
		if (owner !== void 0) problems.push(`${module.id}.${model}: table "${name}" is also declared by ${owner}`);
		owners.set(name, `${module.id}.${model}`);
		problems.push(...problemsOf(module, model, definition));
	}
	if (problems.length > 0) throw new DatabaseSchemaError(`Invalid database schema:\n- ${problems.join("\n- ")}`);
};
var indexesOf = (definition) => [...Object.entries(definition.indexes).map(([name, index]) => ({
	name,
	eq: [...index.eq],
	sort: [...index.sort],
	...index.unique ? { unique: true } : {}
})), ...Object.entries(definition.fields).flatMap(([name, field]) => field.unique ? [{
	name,
	eq: [name],
	sort: [],
	unique: true
}] : [])];
/** Validates the modules, then resolves them into physical tables with engine columns. */
var resolveSchema = (modules) => {
	validateSchema(modules);
	const references = [];
	for (const module of modules) for (const [model, definition] of Object.entries(module.schema)) {
		if (definition.kind !== "table") continue;
		const table = tableName(module, model);
		for (const [field, { references: to }] of Object.entries(definition.fields)) {
			if (to === void 0) continue;
			const { onDelete } = to;
			const target = tableName(module, to.model);
			const counter = onDelete === "none" ? {} : { counter: `_refs_${table}_${field}` };
			references.push({
				table,
				field,
				target,
				onDelete,
				...counter
			});
		}
	}
	const models = /* @__PURE__ */ new Map();
	for (const module of modules) for (const [model, definition] of Object.entries(module.schema)) {
		const name = tableName(module, model);
		const referencedBy = references.filter(({ target }) => target === name);
		const columns = Object.entries(definition.fields).map(([field, { type, required, maxLength, ascii }]) => ({
			name: field,
			type,
			nullable: required === false,
			...maxLength === void 0 ? {} : { maxLength },
			...ascii ? { ascii } : {}
		}));
		if (definition.kind === "table") for (const [field, { type, multi, maxLength, ascii }] of Object.entries(definition.derived)) columns.push({
			name: field,
			type,
			nullable: true,
			...multi ? { multi } : {},
			...maxLength === void 0 ? {} : { maxLength },
			...ascii ? { ascii } : {}
		});
		else columns.push(integer(SHARD_COLUMN), ...[...definition.counters, ...definition.gauges].map((metric) => integer(metric)), ...definition.distinct.map((metric) => ({
			name: metric,
			type: "string",
			nullable: true
		})));
		for (const { counter } of referencedBy) if (counter !== void 0) columns.push(integer(counter, true));
		columns.push(integer("_v", true));
		models.set(name, {
			module: module.id,
			model,
			definition,
			table: {
				name,
				columns,
				key: definition.kind === "aggregate" ? [...definition.key, SHARD_COLUMN] : [...definition.key],
				indexes: indexesOf(definition),
				...physicalRetention(definition)
			},
			references: references.filter(({ table }) => table === name),
			referencedBy,
			roots: new Map(Object.entries(definition.indexes).flatMap(([index, { root }]) => root === void 0 ? [] : [[index, tableName(module, root.model)]]))
		});
	}
	return {
		models,
		tables: [...models.values()].map(({ table }) => table)
	};
};
resolveSchema([coreModule]);
resolveSchema([aggregateBatchingModule]).tables;
/** Each plugin's `schema.<id>` settings row. */
var pluginSettings = (plugins) => Object.fromEntries(plugins.map(({ id, schemaVersion }) => [`schema.${id}`, schemaVersion]));
/** A plugin's schema as the engine resolves it: prefixed by its id unless it keeps its names. */
var pluginModule = ({ id, schema, namespace }) => ({
	id,
	schema,
	...namespace === false ? {} : { namespace: id }
});
/** A row this attempt read changed while it ran; the attempt reruns. */
var StaleReadError = class extends Error {};
var idOf = (table, key) => JSON.stringify([table, key]);
var versionOf = (row) => Number(row["_v"]);
var isKeyed = (value) => value !== null && value !== void 0;
var misuse = (table, message) => new DatabaseTransactionError(`${table}: ${message}`);
var once = (table) => misuse(table, "a transaction writes one key once.");
var hooks = globalThis.process?.getBuiltinModule?.("node:async_hooks");
/** Where the runtime tracks async context, `db.*` inside a transaction throws. */
var transactionScope = hooks && new hooks.AsyncLocalStorage();
var assertOutsideTransaction = () => {
	if (transactionScope?.getStore() !== void 0) throw new DatabaseTransactionError("Inside transaction(), read and write through its handle; db and core are not part of it.");
};
var createTransactions = ({ adapter, schema, reads, retry = {} }) => {
	const { attempts = 8, baseDelayMs = 5, maxDelayMs = 250, onRetry } = retry;
	const { modelOf } = reads;
	/**
	* A key-value index copy has no `_v`. A transaction guards what it reads,
	* so it reads such a row whole, and reruns if it changed since the copy.
	*/
	const complete = async ({ table }, rows) => {
		const copies = rows.filter((row) => !("_v" in row));
		if (copies.length === 0) return [...rows];
		const current = await adapter.get(table, copies.map((copy) => rowKey(table, copy)));
		return rows.map((row) => {
			const at = copies.indexOf(row);
			if (at < 0) return row;
			const whole = current[at];
			if (!whole || Object.keys(row).some((column) => canonicalJson(row[column]) !== canonicalJson(whole[column]))) throw new StaleReadError();
			return whole;
		});
	};
	const attempt = async (fn) => {
		const read = /* @__PURE__ */ new Map();
		/** Rows of rooted ranges: their root guards them, so they need no check of their own. */
		const ranged = /* @__PURE__ */ new Map();
		const writes = /* @__PURE__ */ new Map();
		/** Deleted keys, children before their parents. */
		const deleted = [];
		const aggregates = /* @__PURE__ */ new Map();
		let open = true;
		let failure;
		/** A failed call fails the attempt even when `fn` catches it. */
		const step = (method) => (...args) => {
			if (!open) throw new DatabaseTransactionError("The transaction has ended.");
			const fail = (error) => {
				failure ??= { error };
				throw error;
			};
			try {
				const result = method(...args);
				return result instanceof Promise ? result.catch(fail) : result;
			} catch (error) {
				return fail(error);
			}
		};
		const remember = (model, key, row) => {
			const id = idOf(model.table.name, key);
			const known = read.get(id);
			if (known !== void 0 && (known && row ? versionOf(known) !== versionOf(row) : known !== row)) throw new StaleReadError();
			read.set(id, row);
			return row;
		};
		const readRow = ({ table }, row) => {
			const id = idOf(table.name, rowKey(table, row));
			const known = read.get(id) ?? ranged.get(id);
			if (known && versionOf(known) === versionOf(row)) return known;
			throw misuse(table.name, "update and delete take a row this transaction read.");
		};
		const checkFields = ({ table, definition: { fields } }, values, creating) => {
			for (const field of Object.keys(values)) if (!(field in fields) || !creating && table.key.includes(field)) throw misuse(table.name, `${field} cannot be ${creating ? "set" : "changed"}.`);
			for (const [field, { required }] of Object.entries(fields)) if (required !== false && (creating || field in values) && !isKeyed(values[field])) throw misuse(table.name, `${field} is required.`);
		};
		/** Adds counter deltas to a key's pending op; an empty `by` still bumps `_v`. */
		const bump = (model, key, by) => {
			const id = idOf(model.table.name, key);
			const pending = writes.get(id);
			if (pending === void 0) writes.set(id, {
				model,
				key,
				type: "increment",
				row: { ...by }
			});
			else if (pending.type !== "delete") for (const [column, delta] of Object.entries(by)) pending.row[column] = Number(pending.row[column] ?? pending.read?.[column] ?? 0) + delta;
			else if (Object.values(by).some((delta) => delta > 0)) throw new DatabaseConstraintError("not_found", model.table.name);
		};
		/** Moves parent counters when a reference changes and bumps every rooted parent. */
		const touchParents = (model, before, after) => {
			for (const { field, counter, target } of model.references) {
				const [from, to] = [before?.[field], after?.[field]];
				if (counter === void 0 || from === to) continue;
				if (isKeyed(from)) bump(modelOf(target), [from], { [counter]: -1 });
				if (isKeyed(to)) bump(modelOf(target), [to], { [counter]: 1 });
			}
			for (const [index, root] of model.roots) {
				const parent = modelOf(root);
				const { eq } = model.table.indexes.find(({ name }) => name === index);
				for (const row of [before, after]) {
					const key = eq.slice(0, parent.table.key.length).map((field) => row?.[field]);
					if (row && key.every(isKeyed)) bump(parent, key, {});
				}
			}
		};
		const derive = ({ definition }, row) => {
			if (definition.kind === "table") for (const [name, derived] of Object.entries(definition.derived)) row[name] = derived.compute(row);
			return row;
		};
		/** Deletes a row after its cascaded children, or refuses a restricted delete. */
		const remove = async (model, known) => {
			const { table } = model;
			const key = rowKey(table, known);
			const id = idOf(table.name, key);
			const pending = writes.get(id);
			if (pending?.type === "delete") return;
			if (pending && pending.type !== "increment") throw once(table.name);
			writes.set(id, {
				model,
				key,
				type: "delete",
				row: {},
				read: known
			});
			touchParents(model, known, null);
			for (const reference of model.referencedBy) {
				const { counter, field, onDelete, table: name } = reference;
				if (counter === void 0) continue;
				const stored = Number(known[counter] ?? 0);
				const added = Number(pending?.row[counter] ?? 0);
				if (added > 0) throw new DatabaseConstraintError("referenced", table.name);
				if (stored + added <= 0) continue;
				if (onDelete === "restrict") {
					const [current] = await adapter.get(table, [key]);
					if (current && versionOf(current) === versionOf(known)) throw new DatabaseConstraintError("referenced", table.name);
					throw new StaleReadError();
				}
				const child = modelOf(name);
				const index = child.table.indexes.find(({ eq }) => eq.length === 1 && eq[0] === field);
				let cursor;
				let seen = 0;
				do {
					const page = await reads.findMany(name, {
						index: index.name,
						where: { [field]: key[0] },
						limit: Math.min(stored - seen, reads.maxPageSize),
						...cursor === void 0 ? {} : { cursor }
					});
					for (const row of await complete(child, page.rows)) {
						remember(child, rowKey(child.table, row), row);
						await remove(child, row);
					}
					seen += page.rows.length;
					cursor = page.next;
				} while (cursor !== void 0 && seen < stored);
			}
			deleted.push(id);
		};
		const tx = {
			findOne: step(async (name, lookup) => {
				const model = modelOf(name);
				const { table } = model;
				const found = await reads.findOne(name, lookup);
				if (found === null && !table.key.every((field) => field in lookup)) return null;
				const [row = null] = found ? await complete(model, [found]) : [];
				return remember(model, row ? rowKey(table, row) : table.key.map((field) => lookup[field]), row);
			}),
			findMany: step(async (name, input) => {
				const model = modelOf(name);
				const root = model.roots.get(input.index);
				if (root === void 0) throw new DatabaseQueryError(`${name}.${input.index} is not rooted; a transaction reads a range only under a guarded parent.`);
				const parent = modelOf(root);
				const { eq } = model.table.indexes.find(({ name: index }) => index === input.index);
				const where = input.where ?? {};
				const lookup = Object.fromEntries(parent.table.key.map((field, at) => [field, where[eq[at]]]));
				remember(parent, Object.values(lookup), await reads.findOne(root, lookup));
				const found = await reads.findMany(name, input);
				const rows = await complete(model, found.rows);
				for (const row of rows) ranged.set(idOf(name, rowKey(model.table, row)), row);
				return {
					...found,
					rows
				};
			}),
			create: step((name, values) => {
				const model = modelOf(name);
				checkFields(model, values, true);
				const defaults = model.table.columns.flatMap((column) => column.nullable || column.default !== void 0 ? [[column.name, column.default ?? null]] : []);
				const row = derive(model, {
					...Object.fromEntries(defaults),
					...values
				});
				const key = rowKey(model.table, row);
				const id = idOf(name, key);
				const pending = writes.get(id);
				if (pending && pending.type !== "increment") throw once(name);
				for (const [column, delta] of Object.entries(pending?.row ?? {})) row[column] = Number(row[column]) + Number(delta);
				writes.set(id, {
					model,
					key,
					type: "insert",
					row
				});
				touchParents(model, null, row);
			}),
			update: step((name, row, set) => {
				const model = modelOf(name);
				const known = readRow(model, row);
				checkFields(model, set, false);
				const key = rowKey(model.table, known);
				const id = idOf(name, key);
				const pending = writes.get(id);
				if (pending?.type === "insert" || pending?.type === "delete") throw once(name);
				const before = pending?.type === "patch" ? {
					...known,
					...pending.row
				} : known;
				const next = derive(model, {
					...before,
					...set
				});
				const changed = Object.entries(next).filter(([column, value]) => column !== "_v" && JSON.stringify(value) !== JSON.stringify(known[column]));
				const patch = Object.fromEntries(changed);
				writes.set(id, {
					model,
					key,
					type: "patch",
					row: patch,
					read: known
				});
				if (pending?.type === "increment") bump(model, key, pending.row);
				touchParents(model, before, next);
			}),
			delete: step(async (name, row) => {
				const model = modelOf(name);
				await remove(model, readRow(model, row));
			}),
			aggregate: step((name, identity, values, options) => {
				recordAggregate(aggregates, modelOf(name, "aggregate"), identity, values, options?.shardBy);
			})
		};
		try {
			const result = await (transactionScope ? transactionScope.run(tx, () => fn(tx)) : fn(tx));
			if (failure) throw failure.error;
			return {
				result,
				read,
				ops: compile(writes, read, deleted),
				aggregates: [...aggregates.values()]
			};
		} catch (error) {
			throw failure?.error instanceof StaleReadError ? failure.error : error;
		} finally {
			open = false;
		}
	};
	/** Inserts first, then patches and increments, then checks, then deletes, children before parents. */
	const compile = (writes, read, deleted) => {
		const toOp = (id) => {
			const { model, key, type, row, read: previous } = writes.get(id);
			const { table } = model;
			if (type === "insert") return {
				type,
				table,
				row
			};
			if (type === "increment") {
				const known = read.get(id);
				const by = row;
				return known ? {
					type,
					table,
					key,
					by,
					guard: { v: versionOf(known) }
				} : {
					type,
					table,
					key,
					by
				};
			}
			const guard = { v: versionOf(previous) };
			return type === "patch" ? {
				type,
				table,
				key,
				set: row,
				guard,
				previous
			} : {
				type,
				table,
				key,
				guard,
				previous
			};
		};
		const checks = [...read].flatMap(([id, row]) => {
			if (row === null || writes.has(id)) return [];
			const { table } = schema.models.get(JSON.parse(id)[0]);
			const guard = { v: versionOf(row) };
			return [{
				type: "check",
				table,
				key: rowKey(table, row),
				guard
			}];
		});
		const ofType = (...types) => [...writes.keys()].filter((id) => types.includes(writes.get(id).type));
		return [
			...[...ofType("insert"), ...ofType("patch", "increment")].map(toOp),
			...checks,
			...deleted.map(toOp)
		];
	};
	/** Only a constraint the current state confirms is reported; anything else reruns. */
	const classify = async (op, read) => {
		if (op.type === "check" || op.type === "delete") return void 0;
		if (op.type === "increment" && op.guard) return void 0;
		const { table } = op;
		const key = op.type === "insert" ? rowKey(table, op.row) : op.key;
		const [current] = await adapter.get(table, [key]);
		if (op.type === "increment") return current ? void 0 : "not_found";
		if (op.type === "insert" && current) {
			const known = read.get(idOf(table.name, key));
			return known === null || known !== void 0 && versionOf(known) !== versionOf(current) ? void 0 : "exists";
		}
		if (op.type === "patch" && current?.["_v"] !== op.guard.v) return;
		const row = op.type === "insert" ? op.row : {
			...current,
			...op.set
		};
		for (const index of table.indexes) {
			if (!index.unique) continue;
			for (const eq of indexEntries(table, index, row)) if ((await adapter.query(table, {
				index: index.name,
				eq,
				order: "asc",
				limit: 2
			})).some((other) => compareTuples(rowKey(table, other), key))) return "unique";
		}
	};
	return { async transaction(fn) {
		assertOutsideTransaction();
		let run;
		let negative;
		for (let round = 0; round < attempts; round += 1) {
			const delay = round && Math.min(maxDelayMs, baseDelayMs * 2 ** (round - 1));
			if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay / 2 + Math.random() * (delay / 2)));
			run ??= await attempt(fn).catch((error) => {
				if (error instanceof StaleReadError) return void 0;
				throw error;
			});
			if (run === void 0) {
				onRetry?.("rerun", round + 1);
				continue;
			}
			let aggregates;
			try {
				aggregates = await compileAggregates(adapter, run.aggregates);
			} catch (error) {
				if (!(error instanceof NegativeGaugeError)) throw error;
				negative = error;
				onRetry?.("rerun", round + 1);
				run = void 0;
				continue;
			}
			const ops = [...run.ops, ...aggregates];
			if (ops.length <= 1 && ops.every(({ type }) => type === "check")) return run.result;
			if (!adapter.fits(ops)) throw new DatabaseConstraintError("too_large", ops[0].table.name);
			let outcome;
			try {
				outcome = await adapter.write(ops);
			} catch (cause) {
				throw new DatabaseAmbiguousCommitError("The commit outcome is unknown.", { cause });
			}
			if (outcome.ok) return run.result;
			const failed = "failedOp" in outcome ? outcome.failedOp : void 0;
			if (failed === void 0 || failed >= run.ops.length) {
				onRetry?.("resend", round + 1);
				continue;
			}
			const reason = await classify(ops[failed], run.read);
			if (reason) throw new DatabaseConstraintError(reason, ops[failed].table.name);
			onRetry?.("rerun", round + 1);
			run = void 0;
		}
		throw negative ?? new DatabaseConflictError(`The transaction conflicted ${attempts} times.`);
	} };
};
var sameFields = (left, right) => left.length === right.length && left.every((field) => right.includes(field));
var keyValue = (value, field) => {
	if (isKeyValue(value)) return value;
	throw new DatabaseQueryError(`${field} needs a string, number, or boolean.`);
};
var bound = (exclusive, inclusive, columns) => {
	if (exclusive !== void 0 && inclusive !== void 0) throw new DatabaseQueryError(`range on ${columns[0]} sets both bounds of one side.`);
	const value = exclusive ?? inclusive;
	if (value === void 0) return void 0;
	const values = Array.isArray(value) ? value : [value];
	if (values.length === 0 || values.length > columns.length) throw new DatabaseQueryError(`range on ${columns[0]} takes 1–${columns.length} values of ${columns.join(", ")}.`);
	return {
		values: values.map((item, position) => keyValue(item, columns[position])),
		inclusive: inclusive !== void 0
	};
};
var createEngineReads = ({ adapter, schema, maxPageSize: requested = 500 }) => {
	const maxPageSize = Math.min(requested, 500);
	let count = {
		calls: 0,
		rows: 0
	};
	const returned = (rows) => {
		const size = Array.isArray(rows) ? rows.length : rows === null ? 0 : 1;
		count = {
			calls: count.calls + 1,
			rows: count.rows + size
		};
		return rows;
	};
	/** A model of `kind` by physical table name, for reads and transactions. */
	const modelOf = (name, kind = "table") => {
		const model = schema.models.get(name);
		if (model?.definition.kind === kind) return model;
		throw new DatabaseQueryError(model === void 0 ? `Unknown model ${name}.` : kind === "table" ? `${name} is an aggregate; read it with findAggregates and change it with aggregate.` : `${name} is a table; read it with findMany and change it with create, update, or delete.`);
	};
	const plan = ({ table }, input) => {
		const index = table.indexes.find(({ name }) => name === input.index);
		if (index === void 0) throw new DatabaseQueryError(`${table.name} has no index ${input.index}.`);
		const where = input.where ?? {};
		if (!sameFields(Object.keys(where), index.eq)) throw new DatabaseQueryError(`${table.name}.${index.name} reads need where on exactly: ${index.eq.join(", ") || "(none)"}.`);
		const { limit, order = "asc", range } = input;
		if (!Number.isSafeInteger(limit) || limit < 1 || limit > maxPageSize) throw new DatabaseQueryError(`limit must be 1–${maxPageSize}.`);
		const columns = indexOrderColumns(table, index);
		const eq = index.eq.map((field) => keyValue(where[field], `${table.name}.${field}`));
		const scope = cursorScope([
			table.name,
			index.name,
			eq,
			order,
			range
		]);
		let lower = bound(range?.gt, range?.gte, columns);
		let upper = bound(range?.lt, range?.lte, columns);
		if (input.cursor !== void 0) {
			const values = decodeCursor(scope, input.cursor);
			if (order === "asc") lower = {
				values,
				inclusive: false
			};
			else upper = {
				values,
				inclusive: false
			};
		}
		return {
			request: {
				index: index.name,
				eq,
				order,
				limit,
				...lower === void 0 ? {} : { lower },
				...upper === void 0 ? {} : { upper }
			},
			index,
			scope
		};
	};
	/** Reads rows by key in one batch; the results follow the keys' order. */
	const findByKeys = async (name, lookups) => {
		const { table } = modelOf(name, "table");
		const keys = lookups.map((lookup) => {
			if (!sameFields(Object.keys(lookup), table.key)) throw new DatabaseQueryError(`findByKeys on ${name} takes its key: ${table.key.join(", ")}.`);
			return table.key.map((field) => keyValue(lookup[field], `${name}.${field}`));
		});
		const rows = keys.length === 0 ? [] : await adapter.get(table, keys);
		returned(rows.filter((row) => row !== null));
		return rows.map((row) => row ?? null);
	};
	return {
		maxPageSize,
		modelOf,
		reads: {
			total: () => count,
			reset: () => {
				count = {
					calls: 0,
					rows: 0
				};
			}
		},
		findByKeys,
		async findOne(name, lookup) {
			const { table } = modelOf(name, "table");
			const fields = Object.keys(lookup);
			if (sameFields(fields, table.key)) return (await findByKeys(name, [lookup]))[0];
			const index = table.indexes.find(({ unique, eq }) => unique && sameFields(fields, eq));
			if (index === void 0) throw new DatabaseQueryError(`findOne on ${name} needs its key or a unique field, not ${fields.join(", ")}.`);
			const [row] = await adapter.query(table, {
				index: index.name,
				eq: index.eq.map((field) => keyValue(lookup[field], `${name}.${field}`)),
				order: "asc",
				limit: 1
			});
			return returned(row ?? null);
		},
		async findMany(name, input) {
			const model = modelOf(name, "table");
			const { request, index, scope } = plan(model, input);
			const rows = returned(await adapter.query(model.table, request));
			const last = rows.at(-1);
			return rows.length === input.limit && last !== void 0 ? {
				rows,
				next: encodeCursor(scope, indexOrderTuple(model.table, index, last))
			} : { rows };
		},
		async findAggregates(name, input) {
			const model = modelOf(name, "aggregate");
			const { table, definition } = model;
			if (definition.kind !== "aggregate") throw new DatabaseQueryError(name);
			const { request, index, scope } = plan(model, input);
			const rows = await adapter.query(table, request);
			const logicalKey = (row) => definition.key.map((column) => keyValue(row[column], column));
			const groups = /* @__PURE__ */ new Map();
			for (const row of rows) {
				const key = JSON.stringify(logicalKey(row));
				groups.set(key, [...groups.get(key) ?? [], row]);
			}
			const full = rows.length === input.limit;
			const last = [...groups.values()].at(-1);
			if (full && last !== void 0) {
				const seen = new Set(last.map((row) => row[SHARD_COLUMN]));
				const missing = Array.from({ length: definition.shards }, (_, shard) => shard).filter((shard) => !seen.has(shard));
				if (missing.length > 0) {
					const key = logicalKey(last[0]);
					const rest = await adapter.get(table, missing.map((shard) => [...key, shard]));
					last.push(...rest.filter((row) => row !== null));
				}
			}
			const merged = [...groups.values()].map((shards) => {
				const row = Object.fromEntries(definition.key.map((field) => [field, shards[0][field]]));
				for (const metric of [...definition.counters, ...definition.gauges]) row[metric] = shards.reduce((sum, shard) => sum + Number(shard[metric] ?? 0), 0);
				for (const metric of definition.distinct) row[metric] = mergeDistinct(shards.map((shard) => shard[metric]));
				return row;
			});
			returned(merged);
			if (!full || last === void 0) return { rows: merged };
			return {
				rows: merged,
				next: encodeCursor(scope, indexOrderTuple(table, index, last[0]).slice(0, -1))
			};
		}
	};
};
/** Storage semantics over one adapter, addressed by physical table name. */
var createStorageEngine = ({ adapter: given, schema, maxPageSize, verify, retry }) => {
	const verified = verify ? verifyAdapter(given) : void 0;
	const adapter = verified ?? given;
	const reads = createEngineReads({
		adapter,
		schema,
		maxPageSize
	});
	const { transaction } = createTransactions({
		adapter,
		schema,
		reads,
		retry
	});
	return {
		reads,
		transaction,
		async measureReads(read) {
			if (verified === void 0) throw new Error("measureReads needs an engine created with verify: true.");
			verified.reads.reset();
			reads.reads.reset();
			return {
				result: await read(),
				adapter: verified.reads.total(),
				engine: reads.reads.total()
			};
		}
	};
};
/** The engine plus `database(module)`, which hands a module its typed handle. */
var createDatabaseEngine = ({ batching, now = Date.now, meter, ...options }) => {
	const adapter = meter ? meter.wrap(options.adapter) : options.adapter;
	const engine = createStorageEngine({
		...options,
		adapter
	});
	const { reads } = engine;
	meter?.attach(reads.reads);
	const batches = batching && createAggregateBatches({
		engine,
		adapter,
		schema: options.schema,
		batching,
		now
	});
	const transaction = batches?.transaction ?? engine.transaction;
	const outside = (read) => (...args) => {
		assertOutsideTransaction();
		return read(...args);
	};
	/** No read outside a transaction returns `_v`, which a key-value index copy lacks. */
	const bare = (row) => row && Object.fromEntries(Object.entries(row).filter(([column]) => column !== "_v"));
	const barePage = async (page) => {
		const { rows, next } = await page;
		return {
			rows: rows.map(bare),
			...next === void 0 ? {} : { next }
		};
	};
	return {
		...engine,
		flush: async () => {
			await batches?.flush();
		},
		database(module) {
			const name = (model) => module.namespace ? `${module.namespace}_${model}` : model;
			return {
				findOne: outside(async (model, lookup) => bare(await reads.findOne(name(model), lookup))),
				findByKeys: outside(async (model, keys) => (await reads.findByKeys(name(model), keys)).map(bare)),
				findMany: outside((model, input) => barePage(reads.findMany(name(model), input))),
				findAggregates: outside(async (model, input) => {
					await batches?.beforeRead(name(model));
					return await barePage(reads.findAggregates(name(model), input));
				}),
				transaction: (fn) => transaction((tx) => fn({
					findOne: (model, lookup) => tx.findOne(name(model), lookup),
					findMany: (model, input) => tx.findMany(name(model), input),
					create: (model, row) => tx.create(name(model), row),
					update: (model, row, set) => tx.update(name(model), row, set),
					delete: (model, row) => tx.delete(name(model), row),
					aggregate: (model, identity, changes, options) => tx.aggregate(name(model), identity, changes, options)
				}))
			};
		}
	};
};
/**
* How to create plugins' tables on a database, by the tooling it offers:
* what the plugins' schema fence names when their settings rows are missing.
*/
var pluginTablesFix = (database) => {
	const { createMigrator, generateSchema } = database;
	const doctor = "Run `npx hot-updater doctor` in the project whose hot-updater.config.ts names this database: it names the command that migrates it.";
	const serverProject = "Run `hot-updater db` commands in the server's project: they load the server file named on the command line, or src/hotUpdater.* or src/db.*, and don't read hot-updater.config.ts.";
	return createMigrator !== void 0 ? `${doctor} In a server project, run \`hot-updater db migrate\`. ${serverProject}` : generateSchema !== void 0 ? `${doctor} On a database \`hot-updater init\` created, that is init again with its saved inputs; for your own server, run \`hot-updater db generate\` and apply the file it writes. ${serverProject}` : `${doctor} On a database \`hot-updater init\` created, that is init again with its saved inputs.`;
};
/**
* The storage engine over a database, as a server runs it: core's tables
* and the plugins', with the plugins' settings rows fenced on a fenced
* database, expired rows pruned during writes, aggregates batched when the
* database batches them, and reads metered when it came from `meterReads`.
* `createHotUpdater` runs core and its plugins on one; tests and tools run
* a plugin on one without a server. Wrap the adapter with `verifyAdapter`
* to check every call against the adapter contract.
*/
var createEngine = (database, { plugins = [], now = Date.now } = {}) => {
	const modules = /* @__PURE__ */ new Map();
	for (const plugin of plugins) {
		if (plugin.id === coreModule.id) throw new HotUpdaterConfigError(`Plugin id "${plugin.id}" is core's own.`);
		if (modules.has(plugin.id)) throw new HotUpdaterConfigError(`Plugin "${plugin.id}" is registered twice.`);
		modules.set(plugin.id, pluginModule(plugin));
	}
	if (modules.size > 0) validateSchema([coreModule, ...modules.values()]);
	const name = fencedName(database.adapter);
	const fenced = name === void 0 || plugins.length === 0 ? database.adapter : withSchemaFence(database.adapter, name, pluginSettings(plugins), pluginTablesFix(database));
	const batching = database.aggregateBatching;
	const schema = resolveSchema([
		coreModule,
		...modules.values(),
		...batching === void 0 ? [] : [aggregateBatchingModule]
	]);
	const meter = readMeterOf(database);
	const engine = createDatabaseEngine({
		adapter: pruneDuringWrites(fenced, schema.tables, {
			leaseTable: SETTINGS_TABLE,
			now
		}),
		schema,
		...database.retry === void 0 ? {} : { retry: database.retry },
		...batching === void 0 ? {} : {
			batching,
			now
		},
		...meter === void 0 ? {} : { meter }
	});
	return {
		core: engine.database(coreModule),
		database: (plugin) => {
			const module = modules.get(plugin.id);
			if (module === void 0) throw new HotUpdaterConfigError(`Plugin "${plugin.id}" is not one of this engine's plugins.`);
			return engine.database(module);
		},
		flush: () => engine.flush()
	};
};
var HOT_UPDATER_SERVER_VERSION = "1.2.0-rc.44";
/**
* `/version` on both mounts. The admin mount also lists the ids of the
* plugins the server runs, sorted; apps never learn which plugins a server
* runs.
*/
var createVersionRouteHandlers = (plugins = []) => {
	const version = {
		adminProtocol: 2,
		infrastructureGeneration: 1,
		version: HOT_UPDATER_SERVER_VERSION
	};
	const adminVersion = {
		...version,
		plugins: [...plugins].sort()
	};
	return {
		version: async () => Response.json(version),
		adminVersion: async () => Response.json(adminVersion)
	};
};
/**
* The brand Hot Updater's own plugin factories set. It is a registered
* symbol, not a module-private one, so a plugin made by one package's ESM
* build still carries it when another's CommonJS build reads it, as a config
* loaded through `require` may; no plugin sets it by accident. Each official
* plugin package sets it with a copy of its own, so no package imports
* another's internals for it. It guards Hot Updater's ids against a
* clash, not against a determined impostor.
*/
var OFFICIAL = Symbol.for("@hot-updater/server/official-plugin");
/**
* The ids of Hot Updater's own plugins. The console and tooling tell
* features apart by plugin id, so no other plugin may take one.
*/
var OFFICIAL_IDS = /* @__PURE__ */ new Set([
	"insights",
	"apiKeys",
	"remoteConfig"
]);
/** Whether one of Hot Updater's own factories made `plugin`. */
var isOfficialPlugin = (plugin) => typeof plugin === "object" && plugin !== null && Reflect.get(plugin, OFFICIAL) === true;
/**
* Refuses a plugin that takes one of Hot Updater's own ids without being
* that plugin: `at` names it in the error, such as `plugins[0]`.
*/
var checkReservedId = (plugin, at) => {
	const id = typeof plugin === "object" && plugin !== null ? Reflect.get(plugin, "id") : void 0;
	if (typeof id === "string" && OFFICIAL_IDS.has(id) && !isOfficialPlugin(plugin)) throw new HotUpdaterConfigError(`${at} takes the id "${id}", which is reserved for Hot Updater's ${id}() plugin; give this plugin another id.`);
};
var EXPORT_NAME = /^[A-Za-z_$][\w$]*$/u;
/**
* Names app code cannot import as they are: reserved words, and the names
* the printed app code declares itself.
*/
var UNAVAILABLE_NAMES = /* @__PURE__ */ new Set([
	"App",
	"HotUpdater",
	"arguments",
	"await",
	"break",
	"case",
	"catch",
	"class",
	"const",
	"continue",
	"debugger",
	"default",
	"delete",
	"do",
	"else",
	"enum",
	"eval",
	"export",
	"extends",
	"false",
	"finally",
	"for",
	"function",
	"if",
	"implements",
	"import",
	"in",
	"instanceof",
	"interface",
	"let",
	"new",
	"null",
	"package",
	"private",
	"protected",
	"public",
	"return",
	"static",
	"super",
	"switch",
	"this",
	"throw",
	"true",
	"try",
	"typeof",
	"var",
	"void",
	"while",
	"with",
	"yield"
]);
var isRecord$3 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
/**
* The client plugins an app adds for the plugins, each once, in plugin
* order: what init prints in `HotUpdater.init`'s `plugins`. A malformed one,
* or one name from two modules, throws `HotUpdaterConfigError`.
*/
var clientPluginsOf = (plugins) => {
	if (!Array.isArray(plugins)) throw new HotUpdaterConfigError("plugins must be an array of plugins.");
	const found = [];
	plugins.forEach((plugin, position) => checkReservedId(plugin, `plugins[${position}]`));
	for (const plugin of plugins) {
		if (!isRecord$3(plugin) || !isRecord$3(plugin.cli)) continue;
		const value = plugin.cli.clientPlugin;
		if (value === void 0) continue;
		const id = String(plugin.id);
		if (!isRecord$3(value) || typeof value.module !== "string" || value.module === "" || typeof value.name !== "string" || !EXPORT_NAME.test(value.name) || UNAVAILABLE_NAMES.has(value.name)) throw new HotUpdaterConfigError(`Plugin "${id}" cli.clientPlugin needs a module and an export name the app can import: an identifier other than a reserved word, App, or HotUpdater.`);
		const { module, name } = value;
		const named = found.find((entry) => entry.name === name);
		if (named === void 0) found.push({
			module,
			name
		});
		else if (named.module !== module) throw new HotUpdaterConfigError(`Plugin "${id}" names the client plugin "${name}" from ${module}, but another plugin names it from ${named.module}.`);
	}
	return found;
};
/** A stored catalog payload, checked against its strategy's shape. */
var parseCompiledCatalog = (payload, strategy) => {
	const parsed = JSON.parse(payload);
	if (typeof parsed !== "object" || parsed === null || Reflect.get(parsed, "schemaVersion") !== 1 || Reflect.get(parsed, "strategy") !== strategy || Reflect.get(parsed, "fallbackPolicy") !== "BUILTIN_IF_ACTIVE_INELIGIBLE" || !Array.isArray(Reflect.get(parsed, "releaseDescriptors"))) throw new Error("Stored Release catalog payload is invalid");
	if (strategy === "APP_VERSION" && !Array.isArray(Reflect.get(parsed, "segments"))) throw new Error("Stored app-version Release catalog is invalid");
	if (strategy === "FINGERPRINT" && !Array.isArray(Reflect.get(parsed, "releaseIndexes"))) throw new Error("Stored fingerprint Release catalog is invalid");
	return parsed;
};
/** The scope key an update check reads. */
var releaseCatalogScopeKeyOf = (input) => input.strategy === "APP_VERSION" ? createReleaseCatalogScopeKey({
	channelKey: input.channelKey,
	platform: input.platform,
	strategy: "APP_VERSION"
}) : createReleaseCatalogScopeKey({
	channelKey: input.channelKey,
	fingerprintHash: input.fingerprintHash,
	platform: input.platform,
	strategy: "FINGERPRINT"
});
/** Projects a stored catalog row for one update check; null when the row is not this scope's. */
var projectReleaseCatalogRow = (row, input, scopeKey = releaseCatalogScopeKeyOf(input)) => {
	if (row === null || row.platform !== input.platform || row.strategy !== input.strategy || row.channel_key !== input.channelKey || row.scope_key !== scopeKey || row.fingerprint_hash !== (input.strategy === "FINGERPRINT" ? input.fingerprintHash : null)) return null;
	const compiled = parseCompiledCatalog(row.payload, input.strategy);
	const appVersion = input.strategy === "APP_VERSION" ? input.appVersion : void 0;
	return {
		catalogId: row.catalog_id,
		catalogHash: row.catalog_hash,
		fallbackPolicy: RELEASE_CATALOG_FALLBACK_POLICY,
		generation: row.generation,
		releases: projectCompiledCatalog(compiled, appVersion),
		rollbackReleases: projectCompiledRollbackCatalog(compiled, appVersion),
		schemaVersion: 1,
		scopeKey
	};
};
var HBC_ASSET_PATH_RE = /\.bundle$/;
var asByteSize = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? value : null;
var resolveUniqueHbcAssetPath = (manifest) => {
	const candidates = Object.keys(manifest.assets).sort((left, right) => left.localeCompare(right)).filter((candidate) => HBC_ASSET_PATH_RE.test(candidate));
	return candidates.length === 1 ? candidates[0] : null;
};
var isBundleManifest = (value) => {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const manifest = value;
	if (typeof manifest.bundleId !== "string") return false;
	if (!manifest.assets || typeof manifest.assets !== "object") return false;
	return Object.values(manifest.assets).every((asset) => {
		if (!asset || typeof asset !== "object" || Array.isArray(asset)) return false;
		const manifestAsset = asset;
		return typeof manifestAsset.fileHash === "string" && (manifestAsset.signature === void 0 || typeof manifestAsset.signature === "string");
	});
};
async function fetchBundleManifest(storageUri, readStorageText) {
	const storageText = await readStorageText(storageUri);
	if (storageText === null) return null;
	let payload;
	try {
		payload = JSON.parse(storageText);
	} catch {
		return null;
	}
	if (!isBundleManifest(payload)) return null;
	return payload;
}
function resolveHbcPatchPlan({ currentBundle, targetBundle, targetManifest }) {
	const matchingPatch = currentBundle ? getBundlePatch(targetBundle, currentBundle.id) : null;
	const patchAssetPath = resolveUniqueHbcAssetPath(targetManifest);
	if (!currentBundle || !matchingPatch || !patchAssetPath || !matchingPatch.patchStorageUri || !matchingPatch.patchFileHash || !matchingPatch.baseFileHash) return null;
	return {
		assetPath: patchAssetPath,
		patch: {
			baseBundleId: matchingPatch.baseBundleId,
			baseFileHash: matchingPatch.baseFileHash,
			byteSize: asByteSize(matchingPatch.byteSize),
			patchFileHash: matchingPatch.patchFileHash,
			storageUri: matchingPatch.patchStorageUri
		}
	};
}
function createManifestArtifactPlan({ assetBaseStorageUri, currentBundle, targetBundle, targetManifest }) {
	const patchCandidate = resolveHbcPatchPlan({
		currentBundle,
		targetBundle,
		targetManifest
	});
	return { assets: Object.entries(targetManifest.assets).map(([assetPath, asset]) => {
		const downloadByteSize = asByteSize(asset.downloadByteSize);
		const downloadPath = getManifestAssetDownloadPath(assetPath);
		const isTransformedDownload = downloadPath !== assetPath;
		const hasValidDownloadFileHash = isContentAddressedAssetFileHash(asset.downloadFileHash);
		const file = {
			byteSize: downloadByteSize !== null && (hasValidDownloadFileHash || !isTransformedDownload && asset.downloadFileHash === void 0) ? downloadByteSize : null,
			storageUri: resolveManifestAssetStorageUri({
				assetBaseStorageUri,
				assetPath: downloadPath,
				downloadFileHash: asset.downloadFileHash,
				fileHash: asset.fileHash
			})
		};
		if (isTransformedDownload) file.compression = "br";
		const patch = patchCandidate?.assetPath === assetPath ? patchCandidate.patch : null;
		return {
			assetPath,
			file,
			fileHash: asset.fileHash,
			patch
		};
	}) };
}
async function resolveAssets(plan, resolveFileUrl) {
	const patchAsset = plan.assets.find((asset) => asset.patch !== null);
	let resolvedPatch = null;
	if (patchAsset?.patch) {
		const patchUrl = await resolveFileUrl(patchAsset.patch.storageUri);
		if (patchUrl) resolvedPatch = {
			assetPath: patchAsset.assetPath,
			patch: {
				algorithm: "bsdiff",
				baseBundleId: patchAsset.patch.baseBundleId,
				baseFileHash: patchAsset.patch.baseFileHash,
				patchFileHash: patchAsset.patch.patchFileHash,
				patchUrl,
				...patchAsset.patch.byteSize === null ? {} : { byteSize: patchAsset.patch.byteSize }
			}
		};
	}
	const entries = await Promise.all(plan.assets.map(async (asset) => {
		let patch = resolvedPatch?.assetPath === asset.assetPath ? resolvedPatch.patch : null;
		let fileUrl = null;
		try {
			fileUrl = await resolveFileUrl(asset.file.storageUri);
		} catch (error) {
			if (!patch) throw error;
		}
		if (fileUrl && patch && asset.file.byteSize !== null && asset.patch !== null && asset.patch.byteSize !== null && asset.patch.byteSize >= asset.file.byteSize) patch = null;
		if (!fileUrl) return null;
		const changedAsset = {
			file: { url: fileUrl },
			fileHash: asset.fileHash
		};
		if (asset.file.compression) changedAsset.file.compression = asset.file.compression;
		if (patch) changedAsset.patch = patch;
		return { asset: [asset.assetPath, changedAsset] };
	}));
	if (entries.some((entry) => entry === null)) return null;
	const resolvedEntries = entries.filter((entry) => entry !== null);
	return { assets: Object.fromEntries(resolvedEntries.map((entry) => entry.asset)) };
}
/**
* Legacy: artifact protocol v1. Signs a URL for every file of the target, which grows with the
* Bundle's file count; apps whose SDK predates protocol v2 still ask for it.
* Remove with the `/artifacts/v1` route once no supported app uses it.
*/
async function resolveManifestArtifacts({ currentBundle, resolveFileUrl, readStorageText, targetBundle }) {
	const manifestStorageUri = targetBundle ? getManifestStorageUri(targetBundle) : null;
	const manifestFileHash = targetBundle ? getManifestFileHash(targetBundle) : null;
	const assetBaseStorageUri = targetBundle ? getAssetBaseStorageUri(targetBundle) : null;
	if (!targetBundle || !manifestStorageUri || !manifestFileHash || !assetBaseStorageUri) return null;
	const targetManifest = await fetchBundleManifest(manifestStorageUri, readStorageText);
	if (!targetManifest) return null;
	const plan = createManifestArtifactPlan({
		assetBaseStorageUri,
		currentBundle,
		targetBundle,
		targetManifest
	});
	const manifestUrl = await resolveFileUrl(manifestStorageUri);
	if (!manifestUrl) return null;
	const resolved = await resolveAssets(plan, resolveFileUrl);
	if (!resolved) return null;
	let archiveUrl = null;
	const archive = targetManifest.archive;
	if (archive && isContentAddressedAssetFileHash(archive.downloadFileHash) && (asByteSize(archive.downloadByteSize) ?? 0) > 0 && (asByteSize(archive.tarByteSize) ?? 0) > 0) try {
		archiveUrl = await resolveFileUrl(getBundleArchiveStorageUri({
			manifestStorageUri,
			bundleId: targetBundle.id
		}));
	} catch {}
	return {
		artifactProtocolVersion: 1,
		assets: resolved.assets,
		manifestFileHash,
		manifestUrl,
		...archiveUrl ? { archiveUrl } : {}
	};
}
/** The target's manifest and its plan, or null for a Bundle without one. */
async function loadTargetPlan({ currentBundle, readStorageText, targetBundle }) {
	const manifestStorageUri = getManifestStorageUri(targetBundle);
	const manifestFileHash = getManifestFileHash(targetBundle);
	const assetBaseStorageUri = getAssetBaseStorageUri(targetBundle);
	if (!manifestStorageUri || !manifestFileHash || !assetBaseStorageUri) return null;
	const targetManifest = await fetchBundleManifest(manifestStorageUri, readStorageText);
	if (!targetManifest) return null;
	return {
		manifestFileHash,
		manifestStorageUri,
		plan: createManifestArtifactPlan({
			assetBaseStorageUri,
			currentBundle,
			targetBundle,
			targetManifest
		}),
		targetManifest
	};
}
/**
* Artifact protocol v2: the manifest, the archive, and the one Hermes patch,
* but no URL per file. A device asks {@link resolveManifestArtifactFiles}
* for the files it downloads one by one, so signing and the response stay
* the same size however many files the Bundle has.
*/
async function resolveManifestArtifactsV2({ currentBundle, resolveFileUrl, readStorageText, targetBundle }) {
	const target = await loadTargetPlan({
		currentBundle,
		readStorageText,
		targetBundle
	});
	if (!target) return null;
	const manifestUrl = await resolveFileUrl(target.manifestStorageUri);
	if (!manifestUrl) return null;
	const patched = target.plan.assets.find((asset) => asset.patch !== null);
	let patch;
	if (patched?.patch && !(patched.file.byteSize !== null && patched.patch.byteSize !== null && patched.patch.byteSize >= patched.file.byteSize)) try {
		const patchUrl = await resolveFileUrl(patched.patch.storageUri);
		if (patchUrl) patch = {
			algorithm: "bsdiff",
			assetPath: patched.assetPath,
			baseBundleId: patched.patch.baseBundleId,
			baseFileHash: patched.patch.baseFileHash,
			patchFileHash: patched.patch.patchFileHash,
			patchUrl,
			...patched.patch.byteSize === null ? {} : { byteSize: patched.patch.byteSize }
		};
	} catch {}
	let archiveUrl = null;
	const archive = target.targetManifest.archive;
	if (archive && isContentAddressedAssetFileHash(archive.downloadFileHash) && (asByteSize(archive.downloadByteSize) ?? 0) > 0 && (asByteSize(archive.tarByteSize) ?? 0) > 0) try {
		archiveUrl = await resolveFileUrl(getBundleArchiveStorageUri({
			manifestStorageUri: target.manifestStorageUri,
			bundleId: targetBundle.id
		}));
	} catch {}
	return {
		artifactProtocolVersion: 2,
		manifestFileHash: target.manifestFileHash,
		manifestUrl,
		...archiveUrl ? { archiveUrl } : {},
		...patch ? { patch } : {}
	};
}
/**
* Download URLs for the files a device downloads one by one. Only paths the
* target's manifest names are signed, at most
* {@link ARTIFACT_FILES_REQUEST_LIMIT}; null when any path is unknown or a
* URL cannot be resolved.
*/
async function resolveManifestArtifactFiles({ paths, resolveFileUrl, readStorageText, targetBundle }) {
	if (paths.length === 0 || paths.length > 100 || new Set(paths).size !== paths.length) return null;
	const target = await loadTargetPlan({
		currentBundle: null,
		readStorageText,
		targetBundle
	});
	if (!target) return null;
	const planned = new Map(target.plan.assets.map((asset) => [asset.assetPath, asset]));
	const requested = paths.map((path) => planned.get(path));
	if (requested.some((asset) => asset === void 0)) return null;
	const files = await Promise.all(requested.map(async (asset) => {
		const url = await resolveFileUrl(asset.file.storageUri);
		if (!url) return null;
		const file = { url };
		if (asset.file.compression) file.compression = asset.file.compression;
		return [asset.assetPath, file];
	}));
	if (files.some((file) => file === null)) return null;
	return { files: Object.fromEntries(files.filter((file) => file !== null)) };
}
/** A compiled segment as a range: its version when it holds exactly one. */
var segmentRange = ({ lower, upper }) => lower?.inclusive && upper?.inclusive && lower.version === upper.version ? lower.version : [lower === null ? "" : `${lower.inclusive ? ">=" : ">"}${lower.version}`, upper === null ? "" : `${upper.inclusive ? "<=" : "<"}${upper.version}`].join(" ").trim() || "*";
/**
* Auto-patch bases from a scope's compiled Release Catalog, which holds
* every enabled bundle release of the scope: those whose range intersects
* `range` (all of them in a fingerprint scope), newest release first, each
* bundle once and older than `bundleId`, at most `limit`.
*/
var baseBundleIdsOf = (row, range, bundleId, limit) => {
	const catalog = parseCompiledCatalog(row.payload, row.strategy);
	const serving = new Set(catalog.strategy === "FINGERPRINT" ? catalog.rollbackReleaseIndexes : catalog.segments.flatMap((segment) => range !== null && rangesIntersect(range, segmentRange(segment)) ? segment.rollbackReleaseIndexes : []));
	const newestFirst = catalog.releaseDescriptors.map((descriptor, index) => ({
		descriptor,
		index
	})).sort((left, right) => left.descriptor.releaseId < right.descriptor.releaseId ? 1 : -1);
	const ids = [];
	for (const { descriptor, index } of newestFirst) {
		if (ids.length >= limit) break;
		const id = descriptor.bundleId;
		if (serving.has(index) && id !== null && id < bundleId && !ids.includes(id)) ids.push(id);
	}
	return ids;
};
var PAGE$2 = 500;
var pick$2 = (fields) => (row) => Object.fromEntries(fields.map((field) => [field, row[field]]));
var toBundleRow = pick$2([
	"id",
	"platform",
	"git_commit_hash",
	"metadata",
	"manifest_storage_uri",
	"manifest_file_hash",
	"asset_base_storage_uri"
]);
var toPatchRow = pick$2([
	"id",
	"bundle_id",
	"base_bundle_id",
	"base_file_hash",
	"patch_file_hash",
	"patch_storage_uri",
	"byte_size",
	"order_index"
]);
var toReleaseRow = pick$2([
	"id",
	"revision",
	"scope_key",
	"channel_id",
	"platform",
	"kind",
	"bundle_id",
	"strategy",
	"target_app_version",
	"fingerprint_hash",
	"enabled",
	"should_force_update",
	"message",
	"rollout_cohort_count",
	"target_cohorts",
	"operation",
	"source_release_id",
	"created_at_ms",
	"updated_at_ms"
]);
var toCatalogRow = pick$2([
	"scope_key",
	"catalog_id",
	"strategy",
	"channel_id",
	"channel_key",
	"platform",
	"fingerprint_hash",
	"generation",
	"payload",
	"catalog_hash",
	"byte_size",
	"is_tombstone",
	"updated_at_ms"
]);
var toChannelRow = pick$2(["id", "name"]);
/** Every page of one read, in order. */
var drain = async (read) => {
	const rows = [];
	let cursor;
	do {
		const page = await read(cursor === void 0 ? {} : { cursor });
		rows.push(...page.rows);
		cursor = page.next;
	} while (cursor !== void 0);
	return rows;
};
/** A keyset page's range: the keys strictly after `after`, in `order`. */
/** A keyset read's range on its index's order: past `after`, up to `through`. */
var after = (input) => {
	const asc = (input.order ?? "asc") === "asc";
	const range = {
		...input.after === void 0 ? {} : asc ? { gt: input.after } : { lt: input.after },
		...input.through === void 0 ? {} : asc ? { lte: input.through } : { gte: input.through }
	};
	return Object.keys(range).length === 0 ? {} : { range };
};
/** Core's reads, each through one declared index or key. */
var createCoreReads = (db, storage) => {
	/** A bundle row's patches, exactly as many as its reference counter holds. */
	const detail = async (row) => {
		const count = row._refs_bundle_patches_bundle_id ?? 0;
		const patches = [];
		let cursor;
		while (patches.length < count) {
			const page = await db.findMany("bundle_patches", {
				index: "byBundle",
				where: { bundle_id: row.id },
				limit: Math.min(count - patches.length, PAGE$2),
				...cursor === void 0 ? {} : { cursor }
			});
			patches.push(...page.rows.map(toPatchRow));
			if (page.next === void 0) break;
			cursor = page.next;
		}
		return {
			bundle: toBundleRow(row),
			patches,
			childCount: row._refs_bundle_patches_base_bundle_id ?? 0
		};
	};
	return {
		async getReleaseCatalog(input) {
			const scopeKey = releaseCatalogScopeKeyOf(input);
			const row = await db.findOne("release_catalogs", { scope_key: scopeKey });
			return projectReleaseCatalogRow(row === null ? null : toCatalogRow(row), input, scopeKey);
		},
		getArtifactInfo: (async (targetBundleId, currentBundleId, artifactProtocolVersion) => {
			const { readStorageText } = storage;
			if (artifactProtocolVersion !== 1 && artifactProtocolVersion !== 2 || readStorageText === void 0) return null;
			const withCurrent = currentBundleId !== NIL_UUID;
			const [[target, current], patch] = await Promise.all([db.findByKeys("bundles", withCurrent ? [{ id: targetBundleId }, { id: currentBundleId }] : [{ id: targetBundleId }]), withCurrent ? db.findOne("bundle_patches", {
				bundle_id: targetBundleId,
				base_bundle_id: currentBundleId
			}) : null]);
			if (target === null || target === void 0) return null;
			const input = {
				currentBundle: current ? rowToBundle(toBundleRow(current)) : null,
				readStorageText,
				resolveFileUrl: storage.resolveFileUrl,
				targetBundle: rowToBundle(toBundleRow(target), patch === null ? [] : [toPatchRow(patch)])
			};
			return artifactProtocolVersion === 2 ? resolveManifestArtifactsV2(input) : resolveManifestArtifacts(input);
		}),
		async getArtifactFiles(bundleId, paths) {
			const { readStorageText } = storage;
			if (readStorageText === void 0) return null;
			const row = await db.findOne("bundles", { id: bundleId });
			if (row === null) return null;
			return resolveManifestArtifactFiles({
				paths,
				readStorageText,
				resolveFileUrl: storage.resolveFileUrl,
				targetBundle: rowToBundle(toBundleRow(row))
			});
		},
		async getBundle(id) {
			const row = await db.findOne("bundles", { id });
			return row === null ? null : detail(row);
		},
		async countBundleChildren(baseBundleIds) {
			const ids = [...new Set(baseBundleIds)];
			if (ids.length === 0) return {};
			const rows = await db.findByKeys("bundles", ids.map((id) => ({ id })));
			return Object.fromEntries(ids.map((id, position) => [id, rows[position]?._refs_bundle_patches_base_bundle_id ?? 0]));
		},
		async listPatchesFromBase(baseBundleId, input) {
			return (await db.findMany("bundle_patches", {
				index: "byBase",
				where: { base_bundle_id: baseBundleId },
				order: input.order ?? "asc",
				limit: input.limit,
				...after(input)
			})).rows.map(toPatchRow);
		},
		async listBundles(input) {
			const page = input.platform === void 0 ? await db.findMany("bundles", {
				index: "all",
				where: {},
				order: input.order ?? "asc",
				limit: input.limit,
				...after(input)
			}) : await db.findMany("bundles", {
				index: "byPlatform",
				where: { platform: input.platform },
				order: input.order ?? "asc",
				limit: input.limit,
				...after(input)
			});
			return Promise.all(page.rows.map(detail));
		},
		async countBundles(platform) {
			const { rows } = await db.findAggregates("bundle_totals", {
				index: "byPlatform",
				where: { platform_key: platform ?? "*" },
				limit: 1
			});
			return rows[0]?.bundles ?? 0;
		},
		async findBaseBundleIds(candidateKey, bundleId, limit) {
			const query = parseBaseCandidateKey(candidateKey);
			if (query === null) return [];
			const row = await db.findOne("release_catalogs", { scope_key: query.scopeKey });
			return row === null ? [] : baseBundleIdsOf(toCatalogRow(row), query.range, bundleId, limit);
		},
		async getRelease(id) {
			const row = await db.findOne("releases", { id });
			return row === null ? null : toReleaseRow(row);
		},
		async listReleases(input) {
			const { filter } = input;
			const options = {
				order: input.order ?? "asc",
				limit: input.limit,
				...after(input)
			};
			return (filter.kind === "all" ? await db.findMany("releases", {
				index: "all",
				where: {},
				...options
			}) : filter.kind === "bundle" ? await db.findMany("releases", {
				index: "byBundle",
				where: { bundle_id: filter.bundleId },
				...options
			}) : filter.kind === "scope" ? filter.enabled === void 0 ? await db.findMany("releases", {
				index: "byScope",
				where: { scope_key: filter.scopeKey },
				...options
			}) : await db.findMany("releases", {
				index: "byScopeEnabled",
				where: {
					scope_key: filter.scopeKey,
					enabled: filter.enabled
				},
				...options
			}) : filter.enabled === void 0 ? await db.findMany("releases", {
				index: "byChannelPlatform",
				where: {
					channel_id: filter.channelId,
					platform: filter.platform
				},
				...options
			}) : await db.findMany("releases", {
				index: "byChannelPlatformEnabled",
				where: {
					channel_id: filter.channelId,
					platform: filter.platform,
					enabled: filter.enabled
				},
				...options
			})).rows.map(toReleaseRow);
		},
		async latestReleaseId(scopeKey) {
			const { rows } = await db.findMany("releases", {
				index: "byScope",
				where: { scope_key: scopeKey },
				order: "desc",
				limit: 1
			});
			return rows[0]?.id ?? null;
		},
		async getReleaseCatalogRow(scopeKey) {
			const row = await db.findOne("release_catalogs", { scope_key: scopeKey });
			return row === null ? null : toCatalogRow(row);
		},
		async listReleaseCatalogs(input) {
			return (await db.findMany("release_catalogs", {
				index: "all",
				where: {},
				order: input.order ?? "asc",
				limit: input.limit,
				...after(input)
			})).rows.map(toCatalogRow);
		},
		async listChannels() {
			return (await drain((page) => db.findMany("channels", {
				index: "all",
				where: {},
				limit: PAGE$2,
				...page
			}))).map(toChannelRow);
		},
		async findChannelByName(name) {
			const row = await db.findOne("channels", { name });
			return row === null ? null : toChannelRow(row);
		}
	};
};
/**
* A device's UDID: 40 hex digits, or 8 and 16 joined by a hyphen. The same
* rule as `normalizeIosUdid` of `@hot-updater/protocol/native-artifact`,
* implemented here so the server's runtime never loads the artifact readers.
*/
var UDID = /^(?:[0-9a-f]{40}|[0-9a-f]{8}-[0-9a-f]{16})$/iu;
/** The form the registry stores and compares a UDID in, or null for text that isn't one. */
var normalizeIosUdid = (value) => {
	const trimmed = value.trim();
	return UDID.test(trimmed) ? trimmed.toLowerCase() : null;
};
/** `ios_devices.name`'s bound in core's schema. */
var NAME_MAX_LENGTH = 100;
/** `ios_devices.requested_by` and `approved_by`'s bound: an email address. */
var EMAIL_MAX_LENGTH = 320;
/** `ios_devices.apple_issuer_id`'s bound. */
var ISSUER_MAX_LENGTH = 64;
/** The one row of `ios_device_account`. */
var ACCOUNT_ROW = "registry";
/** `ios_devices.apple_error`'s bound. */
var ERROR_MAX_LENGTH = 512;
var STATUSES = [
	"pending",
	"approved",
	"registered"
];
var OUTCOMES = [
	"registered",
	"refused",
	"disabled",
	"missing"
];
/** The `apple_error` of a device Apple has disabled. */
var IOS_DEVICE_DISABLED_ERROR = "Disabled in the Apple account.";
/** The `apple_error` of a registered device Apple no longer lists. */
var IOS_DEVICE_MISSING_ERROR = "Gone from the Apple account. Approve it again to register it.";
/** A device or registry request core cannot store: the caller's input. */
var IosDeviceInputError = class extends TypeError {
	name = "IosDeviceInputError";
};
var pick$1 = (row) => ({
	id: row.id,
	udid: row.udid,
	name: row.name,
	status: row.status,
	requested_by: row.requested_by ?? null,
	created_at_ms: row.created_at_ms,
	approved_by: row.approved_by ?? null,
	approved_at_ms: row.approved_at_ms ?? null,
	registered_at_ms: row.registered_at_ms ?? null,
	apple_issuer_id: row.apple_issuer_id ?? null,
	apple_error: row.apple_error ?? null,
	build_id: row.build_id ?? null
});
var udidOf = (udid) => {
	const key = typeof udid === "string" ? normalizeIosUdid(udid) : null;
	if (key === null) throw new IosDeviceInputError("Invalid iOS device: udid must be 40 hex digits, or 8 and 16 joined by a hyphen.");
	return key;
};
var nameOf = (name) => {
	const trimmed = typeof name === "string" ? name.trim() : "";
	if (trimmed.length === 0 || trimmed.length > NAME_MAX_LENGTH) throw new IosDeviceInputError(`Invalid iOS device: name must be 1 to ${NAME_MAX_LENGTH} characters.`);
	return trimmed;
};
/** An email, lower-cased, or null for the CLI. */
var personOf = (value, field) => {
	if (value === null) return null;
	const email = typeof value === "string" ? value.trim().toLowerCase() : "";
	if (email.length === 0 || email.length > EMAIL_MAX_LENGTH) throw new IosDeviceInputError(`Invalid iOS device: ${field} must be an email of at most ${EMAIL_MAX_LENGTH} characters, or null.`);
	return email;
};
/** Apple's words, on one line and within the column's bound. */
var errorText = (text) => {
	const line = text.replace(/\s+/gu, " ").trim();
	return line.length > ERROR_MAX_LENGTH ? `${line.slice(0, 511)}…` : line;
};
/**
* The iOS device registry: the iPhones and iPads a team asked to install ad hoc
* builds on. The Console writes requests and approvals, and the CLI what Apple
* said, each over the row it read.
*/
var createIosDeviceApi = (db, { now = Date.now } = {}) => {
	const findIosDevice = async (udid) => {
		const key = normalizeIosUdid(udid);
		if (key === null) return null;
		const row = await db.findOne("ios_devices", { udid: key });
		return row === null ? null : pick$1(row);
	};
	/**
	* The issuer of the registry's earliest registration among its rows, by
	* when and then by ID, or null when no row names one: read only while the
	* registry has no account yet, in one read of its first registration. A
	* row names an issuer exactly when it has a registration time: both are
	* set by its first registration and never cleared.
	*/
	const accountOfRows = async () => {
		const { rows } = await db.findMany("ios_devices", {
			index: "byRegistration",
			where: {},
			order: "asc",
			limit: 1,
			range: { gte: 0 }
		});
		return (rows[0] === void 0 ? null : pick$1(rows[0]))?.apple_issuer_id ?? null;
	};
	return {
		async listIosDevices(input) {
			if (input.status !== void 0 && !STATUSES.includes(input.status)) throw new IosDeviceInputError(`Invalid iOS device status: ${String(input.status)}. Expected ${STATUSES.join(", ")}.`);
			const page = {
				order: input.order ?? "asc",
				limit: input.limit,
				...after(input)
			};
			const { rows } = input.status === void 0 ? await db.findMany("ios_devices", {
				index: "all",
				where: {},
				...page
			}) : await db.findMany("ios_devices", {
				index: "byStatus",
				where: { status: input.status },
				...page
			});
			return rows.map(pick$1);
		},
		findIosDevice,
		async requestIosDevice(input) {
			const udid = udidOf(input.udid);
			const name = nameOf(input.name);
			const requestedBy = personOf(input.requestedBy, "requestedBy");
			const existing = await db.findOne("ios_devices", { udid });
			if (existing !== null) return {
				device: pick$1(existing),
				created: false
			};
			const device = {
				id: createUUIDv7(),
				udid,
				name,
				status: "pending",
				requested_by: requestedBy,
				created_at_ms: now(),
				approved_by: null,
				approved_at_ms: null,
				registered_at_ms: null,
				apple_issuer_id: null,
				apple_error: null,
				build_id: null
			};
			try {
				await db.transaction(async (tx) => {
					tx.create("ios_devices", device);
				});
			} catch (error) {
				if (error instanceof DatabaseConstraintError && error.reason === "unique") {
					const winner = await db.findOne("ios_devices", { udid });
					if (winner !== null) return {
						device: pick$1(winner),
						created: false
					};
				}
				throw error;
			}
			return {
				device,
				created: true
			};
		},
		async approveIosDevice(id, input) {
			const name = input.name === void 0 ? void 0 : nameOf(input.name);
			const approvedBy = personOf(input.approvedBy, "approvedBy");
			return db.transaction(async (tx) => {
				const row = await tx.findOne("ios_devices", { id });
				if (row === null) return null;
				const device = pick$1(row);
				const set = {
					...name === void 0 || name === device.name ? {} : { name },
					...device.status === "pending" ? {
						status: "approved",
						approved_by: approvedBy,
						approved_at_ms: now()
					} : {}
				};
				if (Object.keys(set).length === 0) return device;
				tx.update("ios_devices", row, set);
				return {
					...device,
					...set
				};
			});
		},
		async renameIosDevice(id, input) {
			const name = nameOf(input);
			return db.transaction(async (tx) => {
				const row = await tx.findOne("ios_devices", { id });
				if (row === null) return null;
				const device = pick$1(row);
				if (device.name === name) return device;
				tx.update("ios_devices", row, { name });
				return {
					...device,
					name
				};
			});
		},
		async recordIosDeviceOutcome({ id, seen, issuerId, outcome, reason }) {
			if (!OUTCOMES.includes(outcome)) throw new IosDeviceInputError(`Invalid iOS device outcome: ${String(outcome)}. Expected ${OUTCOMES.join(", ")}.`);
			if (typeof issuerId !== "string" || issuerId.trim().length === 0 || issuerId.length > ISSUER_MAX_LENGTH) throw new IosDeviceInputError(`Invalid iOS device outcome: issuerId must be an App Store Connect issuer of at most ${ISSUER_MAX_LENGTH} characters.`);
			return db.transaction(async (tx) => {
				const row = await tx.findOne("ios_devices", { id });
				if (row === null) return null;
				const device = pick$1(row);
				if (device.status !== seen.status || device.approved_at_ms !== seen.approvedAtMs || device.apple_issuer_id !== null && device.apple_issuer_id !== issuerId) return null;
				let set;
				switch (outcome) {
					case "registered":
						if (device.status === "pending") return null;
						set = {
							status: "registered",
							registered_at_ms: device.registered_at_ms ?? now(),
							apple_issuer_id: issuerId,
							apple_error: null
						};
						break;
					case "refused":
						if (device.status !== "approved") return null;
						set = { apple_error: errorText(reason === void 0 || reason.trim() === "" ? "Apple refused it." : reason) };
						break;
					case "disabled":
						if (device.status === "pending") return null;
						set = { apple_error: IOS_DEVICE_DISABLED_ERROR };
						break;
					case "missing":
						if (device.status !== "registered") return null;
						set = {
							status: "pending",
							approved_by: null,
							approved_at_ms: null,
							apple_error: IOS_DEVICE_MISSING_ERROR
						};
				}
				if (Object.entries(set).some(([column, value]) => device[column] !== (value ?? null))) tx.update("ios_devices", row, set);
				return {
					...device,
					...set
				};
			});
		},
		async markIosDevicesInBuild({ buildId, ids }) {
			for (const id of new Set(ids)) await db.transaction(async (tx) => {
				const row = await tx.findOne("ios_devices", { id });
				if (row === null || typeof row.build_id === "string" && row.build_id >= buildId) return;
				tx.update("ios_devices", row, { build_id: buildId });
			});
		},
		async findIosDeviceAccount() {
			const existing = await db.findOne("ios_device_account", { id: ACCOUNT_ROW });
			const issuerId = existing === null ? await accountOfRows() : existing.apple_issuer_id;
			return issuerId === null ? null : { issuerId };
		},
		async claimIosDeviceAccount(issuerId) {
			if (typeof issuerId !== "string" || issuerId.trim().length === 0 || issuerId.length > ISSUER_MAX_LENGTH) throw new IosDeviceInputError(`Invalid iOS device account: issuerId must be an App Store Connect issuer of at most ${ISSUER_MAX_LENGTH} characters.`);
			const answer = (held) => ({
				issuerId: held,
				claimed: held === issuerId
			});
			const existing = await db.findOne("ios_device_account", { id: ACCOUNT_ROW });
			if (existing !== null) return answer(existing.apple_issuer_id);
			const holder = await accountOfRows() ?? issuerId;
			try {
				await db.transaction(async (tx) => {
					tx.create("ios_device_account", {
						id: ACCOUNT_ROW,
						apple_issuer_id: holder,
						claimed_at_ms: now()
					});
				});
				return answer(holder);
			} catch (error) {
				if (error instanceof DatabaseConstraintError && (error.reason === "exists" || error.reason === "unique")) {
					const winner = await db.findOne("ios_device_account", { id: ACCOUNT_ROW });
					if (winner !== null) return answer(winner.apple_issuer_id);
				}
				throw error;
			}
		},
		async deleteIosDevice(id, only) {
			const requestedBy = only?.requestedBy === void 0 ? void 0 : personOf(only.requestedBy, "requestedBy");
			return db.transaction(async (tx) => {
				const row = await tx.findOne("ios_devices", { id });
				if (row === null) return null;
				const device = pick$1(row);
				if (only?.status !== void 0 && device.status !== only.status || requestedBy !== void 0 && device.requested_by !== requestedBy) return null;
				await tx.delete("ios_devices", row);
				return device;
			});
		}
	};
};
/** Store destinations accepted for each native platform. */
var NATIVE_BUILD_SUBMISSION_DESTINATIONS = {
	android: [
		"play-internal",
		"play-closed",
		"play-open",
		"play-production"
	],
	ios: ["testflight"]
};
var PAGE$1 = 500;
/** Moves one bundle into or out of its platform's total and the overall total. */
var countBundle = (tx, platform, delta) => {
	for (const key of [platform, "*"]) tx.aggregate("bundle_totals", { platform_key: key }, { bundles: delta });
};
var insertBundle = (tx, row) => {
	tx.create("bundles", row);
	countBundle(tx, row.platform, 1);
};
/**
* Updates a bundle; a platform change moves it between platform totals,
* except for a native build's built-in bundle, which they never count.
*/
var updateBundle = (tx, current, set, { counted = true } = {}) => {
	tx.update("bundles", current, set);
	if (counted && set.platform !== void 0 && set.platform !== current.platform) {
		countBundle(tx, current.platform, -1);
		countBundle(tx, set.platform, 1);
	}
};
/** Deletes a bundle and, by cascade, every patch to or from it; a release on it refuses. */
var deleteBundle = async (tx, current) => {
	await tx.delete("bundles", current);
	countBundle(tx, current.platform, -1);
};
/**
* Replaces a bundle's patches with `rows`: kept patches are updated where
* they changed, others deleted or created, so no key is written twice.
* `checkNew` sees each patch it is about to create, and refuses one by
* throwing, which leaves the transaction's writes undone.
*/
var replaceBundlePatches = async (tx, bundle, rows, checkNew) => {
	const wanted = new Map(rows.map((row) => [row.id, row]));
	const count = bundle._refs_bundle_patches_bundle_id ?? 0;
	let cursor;
	for (let seen = 0; seen < count;) {
		const page = await tx.findMany("bundle_patches", {
			index: "byBundle",
			where: { bundle_id: bundle.id },
			limit: Math.min(count - seen, PAGE$1),
			...cursor === void 0 ? {} : { cursor }
		});
		for (const stored of page.rows) {
			const next = wanted.get(stored.id);
			wanted.delete(stored.id);
			if (next === void 0) {
				await tx.delete("bundle_patches", stored);
				continue;
			}
			const set = Object.fromEntries(Object.entries(next).filter(([field, value]) => field !== "id" && stored[field] !== value));
			if (Object.keys(set).length > 0) tx.update("bundle_patches", stored, set);
		}
		seen += page.rows.length;
		if (page.next === void 0) break;
		cursor = page.next;
	}
	if (checkNew !== void 0) for (const row of wanted.values()) await checkNew(row);
	for (const row of wanted.values()) tx.create("bundle_patches", row);
};
/** A channel by name, created when missing; a concurrent creator's row is returned instead. */
var insertChannel = async (db, row) => {
	for (let attempt = 1;; attempt += 1) try {
		return await db.transaction(async (tx) => {
			const existing = await tx.findOne("channels", { name: row.name });
			if (existing !== null) return {
				row: toChannelRow(existing),
				inserted: false
			};
			tx.create("channels", row);
			return {
				row,
				inserted: true
			};
		});
	} catch (error) {
		if (attempt < 3 && error instanceof DatabaseConstraintError && (error.reason === "unique" || error.reason === "exists")) continue;
		throw error;
	}
};
/** Deletes a channel no release or native build uses: 1 read, 1 query, 1 write. */
var deleteChannel = (db, id) => db.transaction(async (tx) => {
	const row = await tx.findOne("channels", { id });
	if (row === null) return {
		deleted: false,
		reason: "not_found"
	};
	if ((row._refs_releases_channel_id ?? 0) > 0) return {
		deleted: false,
		reason: "not_empty"
	};
	const { rows: builds } = await tx.findMany("native_builds", {
		index: "byChannel",
		where: { channel_id: id },
		limit: 1
	});
	if (builds.length > 0) return {
		deleted: false,
		reason: "not_empty"
	};
	await tx.delete("channels", row);
	return { deleted: true };
});
/** The artifacts each platform's build produces. */
var ARTIFACT_KINDS = {
	android: ["apk", "aab"],
	ios: ["ipa", "app"]
};
/** `native_builds.scope_key`'s bound in core's schema. */
var SCOPE_KEY_MAX_LENGTH = 2048;
/** The `git_commit_hash` bound of `bundles` and `native_builds`. */
var GIT_COMMIT_HASH_MAX_LENGTH = 255;
/**
* A native build key: `nbk1:` and a SHA-256, as the CLI computes it. The
* format is the CLI's convention, implemented here so the registry stores
* and looks up nothing else.
*/
var BUILD_KEY = /^nbk1:[0-9a-f]{64}$/;
/** `native_builds.sandbox_url_scheme`'s bound in core's schema. */
var SANDBOX_URL_SCHEME_MAX_LENGTH = 255;
/**
* A URL scheme as RFC 3986 spells it, in lower case: what a sandbox build's
* artifact registers, as `@hot-updater/protocol/native-artifact` reads it.
*/
var URL_SCHEME = new RegExp(`^[a-z][a-z0-9+.-]{0,254}$`);
/**
* A bundle identifier or application ID, as an artifact reports it: letters,
* digits, dots, dashes and underscores, which a scope key holds as they are.
*/
var APP_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,254}$/;
/** A fingerprint hash as a Release Catalog scope key holds it. */
var FINGERPRINT_HASH = /^[A-Za-z0-9._~-]{1,255}$/;
/** How each kind of artifact can install. */
var DISTRIBUTIONS = {
	apk: ["direct"],
	app: ["direct"],
	aab: ["store"],
	ipa: ["direct", "store"]
};
/** A native build or scope core cannot store or look up: the caller's input. */
var NativeBuildInputError = class extends TypeError {
	name = "NativeBuildInputError";
};
var pick = (row) => ({
	id: row.id,
	scope_key: row.scope_key,
	platform: row.platform,
	channel_id: row.channel_id,
	fingerprint_hash: row.fingerprint_hash ?? null,
	app_version: row.app_version ?? null,
	min_bundle_id: row.min_bundle_id,
	artifact_kind: row.artifact_kind,
	artifact_storage_uri: row.artifact_storage_uri,
	byte_size: row.byte_size,
	git_commit_hash: row.git_commit_hash ?? null,
	created_at_ms: row.created_at_ms,
	build_key: row.build_key ?? null,
	build_number: row.build_number ?? null,
	submitted_to: row.submitted_to ?? null,
	submitted_at_ms: row.submitted_at_ms ?? null,
	submitted_version: row.submitted_version ?? null,
	is_store_build: row.is_store_build === true,
	is_sandbox: row.is_sandbox === true,
	sandbox_url_scheme: row.sandbox_url_scheme ?? null,
	export_method: row.export_method ?? null,
	native_app_version: row.native_app_version ?? null
});
/** The export methods an `.ipa` registers with. */
var EXPORT_METHODS = /* @__PURE__ */ new Set([
	"app-store",
	"ad-hoc",
	"development",
	"enterprise"
]);
/**
* How many older builds of a scope one read takes, looking for one older than
* a bundle when a build made after the bundle is the newest.
*/
var OLDER_BUILDS_PAGE = 20;
/**
* How many pages of older builds that look reads before it answers null: 100
* builds made after the bundle in one scope, where a deploy's new bundle has
* none or a few registered while it deploys.
*/
var OLDER_BUILDS_PAGES = 5;
/** How many times a mark runs again after losing its scope's mark to another. */
var MARK_ATTEMPTS = 8;
/** `native_builds.build_number`'s bound in core's schema. */
var BUILD_NUMBER_MAX_LENGTH = 64;
/** `native_builds.submitted_version`'s bound in core's schema. */
var SUBMITTED_VERSION_MAX_LENGTH = 255;
var checkedScopeKey = (scopeKey) => {
	if (scopeKey.length > SCOPE_KEY_MAX_LENGTH) throw new NativeBuildInputError(`Invalid native build scope: its key is longer than ${SCOPE_KEY_MAX_LENGTH} characters; shorten the channel or app version.`);
	return scopeKey;
};
/**
* How a registered artifact installs: an `.ipa` by its export method, and
* `unknown` for one whose export no profile confirmed, which no lookup asks
* for, so it is never reused as either.
*/
var registeredDistribution = (kind, exportMethod) => kind !== "ipa" ? DISTRIBUTIONS[kind][0] : exportMethod === void 0 || exportMethod === null ? "unknown" : exportMethod === "app-store" ? "store" : "direct";
/**
* A sandbox build scope's key, which names no channel: the app ID, URL
* scheme, artifact kind and distribution in its place, then the fingerprint,
* or the app-version strategy and the exact app version. `v1:sandbox:` is no
* Release Catalog strategy, so it never meets a normal build's key.
*/
var sandboxScopeKey = (scope, sandbox) => {
	const { appId, urlScheme, artifactKind, distribution } = sandbox;
	const problem = typeof appId !== "string" || !APP_ID.test(appId) ? "its app ID must be a bundle identifier or application ID, up to 255 characters" : typeof urlScheme !== "string" || !URL_SCHEME.test(urlScheme) ? `its URL scheme must be a URL scheme in lower case, up to ${SANDBOX_URL_SCHEME_MAX_LENGTH} characters` : !ARTIFACT_KINDS[scope.platform]?.includes(artifactKind) ? `its artifact kind must be one an ${scope.platform} build makes` : distribution !== "unknown" && !DISTRIBUTIONS[artifactKind].includes(distribution) ? `an .${artifactKind} doesn't install as ${String(distribution)}` : scope.fingerprintHash !== null && !FINGERPRINT_HASH.test(scope.fingerprintHash) ? "its fingerprint hash must be 1-255 URL-safe ASCII characters" : null;
	if (problem !== null) throw new NativeBuildInputError(`Invalid sandbox build scope: ${problem}.`);
	const target = scope.fingerprintHash === null ? `app-version:${encodeURIComponent(scope.appVersion)}` : `fingerprint:${scope.fingerprintHash}`;
	return checkedScopeKey(`v1:sandbox:${scope.platform}:${appId}:${urlScheme}:${artifactKind}:${distribution}:${target}`);
};
/**
* A native build scope's key: the Release Catalog scope key of a
* fingerprint, or of the app-version strategy followed by the exact app
* version the build compiled in. One key serves both strategies, so one
* index finds the newest build of either. A sandbox scope's key names no
* channel, so pull requests find a sandbox build on any.
*/
var nativeBuildScopeKey = (scope) => {
	const { sandbox } = scope;
	if (sandbox !== void 0 && sandbox !== null) {
		if (sandbox.distribution !== "direct" && sandbox.distribution !== "store") throw new NativeBuildInputError("Invalid sandbox build scope: its distribution must be direct or store.");
		return sandboxScopeKey(scope, sandbox);
	}
	let scopeKey;
	try {
		const channelKey = encodeChannelKey(scope.channel);
		scopeKey = scope.fingerprintHash === null ? `${createReleaseCatalogScopeKey({
			channelKey,
			platform: scope.platform,
			strategy: "APP_VERSION"
		})}:${encodeURIComponent(scope.appVersion)}` : createReleaseCatalogScopeKey({
			channelKey,
			fingerprintHash: scope.fingerprintHash,
			platform: scope.platform,
			strategy: "FINGERPRINT"
		});
	} catch (error) {
		throw new NativeBuildInputError(`Invalid native build scope: ${error instanceof Error ? error.message : String(error)}.`);
	}
	return checkedScopeKey(scopeKey);
};
/** The channel row a registration names, or the refusal of its channel. */
var channelIdOf = (channel) => {
	try {
		return `channel:${encodeChannelKey(channel)}`;
	} catch (error) {
		throw new NativeBuildInputError(`Invalid native build scope: ${error instanceof Error ? error.message : String(error)}.`);
	}
};
/**
* A registration's scope key, from the registration's own facts: a sandbox
* build's from what its artifact says, whatever `sandbox` it names.
*/
var registrationScopeKey = (registration) => {
	channelIdOf(registration.channel);
	return registration.isSandbox === true ? sandboxScopeKey(registration, {
		appId: registration.sandboxAppId,
		urlScheme: registration.sandboxUrlScheme,
		artifactKind: registration.artifact.kind,
		distribution: registeredDistribution(registration.artifact.kind, registration.exportMethod)
	}) : nativeBuildScopeKey({
		...registration,
		sandbox: null
	});
};
/**
* Refuses a patch from a sandbox build's built-in bundle: no deploy patches
* from one, so no store or test install of the app gets a patch made for a
* sandbox build. One unique read of the base.
*/
var refuseSandboxPatchBase = async (db, baseBundleId) => {
	if ((await db.findOne("native_builds", { min_bundle_id: baseBundleId }))?.is_sandbox === true) throw new NativeBuildInputError("A sandbox build's built-in bundle is no patch base.");
};
/** Whether `bundleId` is a native build's built-in bundle: one unique read. */
var isBuiltInBundle = async (db, bundleId) => await db.findOne("native_builds", { min_bundle_id: bundleId }) !== null;
var problemOf = ({ id, minBundleId, platform, channel, fingerprintHash, appVersion, gitCommitHash, buildKey, buildNumber, isSandbox, sandboxUrlScheme, sandboxAppId, exportMethod, nativeAppVersion, artifact }) => {
	if (!isUUIDv7(id)) return "id must be a UUIDv7";
	if (!isUUIDv7(minBundleId)) return "minBundleId must be the UUIDv7 a release build compiles in";
	if (platform !== "ios" && platform !== "android") return "platform must be ios or android";
	if (channel.trim().length === 0) return "channel is required";
	if (isSandbox !== void 0 && typeof isSandbox !== "boolean") return "isSandbox must be true or false";
	if (sandboxUrlScheme !== void 0 && sandboxUrlScheme !== null) {
		if (isSandbox !== true) return "sandboxUrlScheme is a sandbox build's, and this isn't one";
		if (typeof sandboxUrlScheme !== "string" || !URL_SCHEME.test(sandboxUrlScheme)) return `sandboxUrlScheme must be a URL scheme in lower case, up to ${SANDBOX_URL_SCHEME_MAX_LENGTH} characters, or null`;
	}
	if (sandboxAppId !== void 0 && sandboxAppId !== null) {
		if (isSandbox !== true) return "sandboxAppId is a sandbox build's, and this isn't one";
		if (typeof sandboxAppId !== "string" || !APP_ID.test(sandboxAppId)) return "sandboxAppId must be the artifact's bundle identifier or application ID, up to 255 characters";
	}
	if (isSandbox === true) {
		if (sandboxUrlScheme === void 0 || sandboxUrlScheme === null) return "a sandbox build needs the sandboxUrlScheme its artifact registers";
		if (sandboxAppId === void 0 || sandboxAppId === null) return "a sandbox build needs the sandboxAppId its artifact reports, which an older hot-updater CLI doesn't send. Upgrade the hot-updater CLI to the version that matches this server, and build again";
	}
	if (gitCommitHash !== null && gitCommitHash.length > GIT_COMMIT_HASH_MAX_LENGTH) return `gitCommitHash must be at most ${GIT_COMMIT_HASH_MAX_LENGTH} characters`;
	if (fingerprintHash === null === (appVersion === null)) return "exactly one of fingerprintHash and appVersion is required";
	if (buildKey !== null && !BUILD_KEY.test(buildKey)) return "buildKey must be nbk1: and a SHA-256, or null";
	if (buildNumber !== void 0 && buildNumber !== null && (buildNumber.trim().length === 0 || buildNumber.length > BUILD_NUMBER_MAX_LENGTH)) return `buildNumber must be the artifact's build number, up to ${BUILD_NUMBER_MAX_LENGTH} characters, or null`;
	if (nativeAppVersion !== void 0 && nativeAppVersion !== null && (typeof nativeAppVersion !== "string" || nativeAppVersion.trim().length === 0)) return "nativeAppVersion must be the artifact's app version, or null";
	const kinds = ARTIFACT_KINDS[platform];
	if (!kinds.includes(artifact.kind)) return `artifact.kind of an ${platform} build must be ${kinds.join(" or ")}`;
	if (exportMethod !== void 0 && exportMethod !== null) {
		if (artifact.kind !== "ipa") return "exportMethod is an .ipa's, and this artifact isn't one";
		if (!EXPORT_METHODS.has(exportMethod)) return `exportMethod must be ${[...EXPORT_METHODS].join(", ")}, or null`;
	}
	if (!Number.isSafeInteger(artifact.byteSize) || artifact.byteSize < 0) return "artifact.byteSize must be a byte count";
	return null;
};
/** The other install target of an iOS sandbox build's native code. */
var SIBLING_KINDS = {
	app: "ipa",
	ipa: "app"
};
/**
* Whether a build is one a person installs from its file: a Simulator `.app`,
* or an `.ipa` exported for direct install, that no store took and that isn't
* the store build. One rule for a sibling and the build it is found from, so
* a build that shows its sibling is shown by it.
*/
var isInstallTarget = (build) => !build.is_store_build && build.submitted_to === null && (build.artifact_kind === "app" || build.artifact_kind === "ipa" && build.export_method !== null && build.export_method !== "app-store");
/**
* The scope key of the other install target of a sandbox build, from its own
* key's app ID and URL scheme, which hold no colon, and its row's fingerprint
* or app version, through `sandboxScopeKey`; null for a key it didn't make.
*/
var siblingSandboxScopeKey = (build, artifactKind) => {
	const [version, sandbox, platform, appId, urlScheme] = build.scope_key.split(":");
	if (version !== "v1" || sandbox !== "sandbox" || platform !== build.platform || appId === void 0 || urlScheme === void 0) return null;
	const target = build.fingerprint_hash === null ? {
		platform: build.platform,
		fingerprintHash: null,
		appVersion: build.app_version ?? ""
	} : {
		platform: build.platform,
		fingerprintHash: build.fingerprint_hash,
		appVersion: null
	};
	try {
		return sandboxScopeKey(target, {
			appId,
			urlScheme,
			artifactKind: build.artifact_kind,
			distribution: registeredDistribution(build.artifact_kind, build.export_method)
		}) === build.scope_key ? sandboxScopeKey(target, {
			appId,
			urlScheme,
			artifactKind,
			distribution: "direct"
		}) : null;
	} catch {
		return null;
	}
};
/** The native build registry: core's `native_builds` and the built-in bundle rows. */
var createNativeBuildApi = (db, { now = Date.now } = {}) => ({
	async registerNativeBuild(registration) {
		const problem = problemOf(registration);
		if (problem !== null) throw new NativeBuildInputError(`Invalid native build: ${problem}.`);
		const scopeKey = registrationScopeKey(registration);
		const channelId = channelIdOf(registration.channel);
		const { embeddedBundle } = registration;
		const row = {
			id: registration.id,
			scope_key: scopeKey,
			platform: registration.platform,
			channel_id: channelId,
			fingerprint_hash: registration.fingerprintHash,
			app_version: registration.appVersion,
			min_bundle_id: registration.minBundleId,
			artifact_kind: registration.artifact.kind,
			artifact_storage_uri: registration.artifact.storageUri,
			byte_size: registration.artifact.byteSize,
			git_commit_hash: registration.gitCommitHash,
			created_at_ms: now(),
			build_key: registration.buildKey,
			build_number: registration.buildNumber ?? null,
			submitted_to: null,
			submitted_at_ms: null,
			submitted_version: null,
			is_store_build: false,
			is_sandbox: registration.isSandbox === true,
			sandbox_url_scheme: registration.sandboxUrlScheme ?? null,
			export_method: registration.exportMethod ?? null,
			native_app_version: registration.nativeAppVersion ?? null
		};
		for (let attempt = 1;; attempt += 1) {
			await insertChannel(db, {
				id: channelId,
				name: registration.channel
			});
			try {
				await db.transaction(async (tx) => {
					tx.create("bundles", {
						id: registration.minBundleId,
						platform: registration.platform,
						git_commit_hash: registration.gitCommitHash,
						metadata: embeddedBundle.metadata ?? {},
						manifest_storage_uri: embeddedBundle.manifestStorageUri,
						manifest_file_hash: embeddedBundle.manifestFileHash,
						asset_base_storage_uri: embeddedBundle.assetBaseStorageUri
					});
					tx.create("native_builds", row);
				});
				break;
			} catch (error) {
				if (!(error instanceof DatabaseConstraintError)) throw error;
				if (error.reason === "exists" || error.reason === "unique") throw new DatabaseConstraintError(error.reason, "native_builds");
				if (attempt < 3 && error.reason === "not_found" && error.model === "channels") continue;
				throw error;
			}
		}
		return row;
	},
	async getNativeBuild(id) {
		const row = await db.findOne("native_builds", { id });
		return row === null ? null : pick(row);
	},
	async findNativeBuildByBuiltInBundle(bundleId) {
		const row = await db.findOne("native_builds", { min_bundle_id: bundleId });
		return row === null ? null : pick(row);
	},
	async findNativeBuild(scope, options) {
		const scopeKey = nativeBuildScopeKey(scope);
		const buildKey = options?.buildKey;
		if (buildKey !== void 0 && !BUILD_KEY.test(buildKey)) throw new NativeBuildInputError("Invalid native build key: it must be nbk1: and a SHA-256.");
		const artifactKind = options?.artifactKind;
		if (artifactKind !== void 0 && !ARTIFACT_KINDS[scope.platform].includes(artifactKind)) throw new NativeBuildInputError(`Invalid native build kind: an ${scope.platform} build is ${ARTIFACT_KINDS[scope.platform].join(" or ")}.`);
		const ofKind = (row) => artifactKind === void 0 || row.artifact_kind === artifactKind;
		if (options?.storeBuild) {
			const marked = await db.findOne("native_builds", { store_build_scope_key: scopeKey });
			return marked === null || !ofKind(marked) ? null : pick(marked);
		}
		const read = (limit, before) => {
			const page = {
				order: "desc",
				limit,
				...before === void 0 ? {} : { range: { lt: before } }
			};
			return buildKey !== void 0 ? db.findMany("native_builds", {
				index: "byBuildKey",
				where: {
					scope_key: scopeKey,
					build_key: buildKey
				},
				...page
			}) : artifactKind !== void 0 ? db.findMany("native_builds", {
				index: "byScopeKind",
				where: {
					scope_key: scopeKey,
					artifact_kind: artifactKind
				},
				...page
			}) : db.findMany("native_builds", {
				index: "byScope",
				where: { scope_key: scopeKey },
				...page
			});
		};
		const bundleId = options?.builtInOlderThan;
		if (bundleId !== void 0 && scope.sandbox !== void 0 && scope.sandbox !== null) return null;
		const { rows } = await read(1);
		const newest = (rows[0] === void 0 ? void 0 : pick(rows[0])) ?? (artifactKind !== void 0 && buildKey === void 0 ? await db.findMany("native_builds", {
			index: "byScope",
			where: { scope_key: scopeKey },
			order: "desc",
			limit: 1
		}).then(({ rows: [row] }) => row?.artifact_kind === artifactKind ? pick(row) : void 0) : void 0);
		if (newest === void 0 || !ofKind(newest)) return null;
		if (bundleId === void 0 || newest.min_bundle_id < bundleId) return newest;
		let before = newest.id;
		for (let page = 0; page < OLDER_BUILDS_PAGES; page += 1) {
			const { rows: older } = await read(OLDER_BUILDS_PAGE, before);
			const usable = older.find(({ min_bundle_id }) => min_bundle_id < bundleId);
			if (usable !== void 0) return ofKind(usable) ? pick(usable) : null;
			const last = older.at(-1);
			if (older.length < OLDER_BUILDS_PAGE || last === void 0) return null;
			before = last.id;
		}
		return null;
	},
	async findNativeBuildSibling(build) {
		const artifactKind = SIBLING_KINDS[build.artifact_kind];
		if (build.platform !== "ios" || !build.is_sandbox || artifactKind === void 0 || !isInstallTarget(build)) return null;
		const scopeKey = siblingSandboxScopeKey(build, artifactKind);
		if (scopeKey === null) return null;
		const { rows } = await db.findMany("native_builds", {
			index: "byScope",
			where: { scope_key: scopeKey },
			order: "desc",
			limit: 1
		});
		const sibling = rows[0] === void 0 ? null : pick(rows[0]);
		return sibling !== null && isInstallTarget(sibling) ? sibling : null;
	},
	async recordNativeBuildSubmission(id, { destination, version }) {
		if (version.trim().length === 0 || version.length > SUBMITTED_VERSION_MAX_LENGTH) throw new NativeBuildInputError(`Invalid native build submission: version must be the store's label of the build, up to ${SUBMITTED_VERSION_MAX_LENGTH} characters.`);
		return db.transaction(async (tx) => {
			const row = await tx.findOne("native_builds", { id });
			if (row === null) return null;
			const build = pick(row);
			if (!NATIVE_BUILD_SUBMISSION_DESTINATIONS[build.platform].includes(destination)) throw new NativeBuildInputError(`Invalid native build submission: an ${build.platform} build is submitted to ${NATIVE_BUILD_SUBMISSION_DESTINATIONS[build.platform].join(" or ")}, not ${destination}.`);
			if (build.is_sandbox && destination !== "testflight" && destination !== "play-internal") throw new NativeBuildInputError("A sandbox build can submit only to TestFlight or Play internal testing.");
			const set = {
				submitted_to: destination,
				submitted_at_ms: now(),
				submitted_version: version
			};
			tx.update("native_builds", row, set);
			return {
				...build,
				...set
			};
		});
	},
	async markNativeBuild(id, { storeBuild }) {
		for (let attempt = 1;; attempt += 1) try {
			return await db.transaction(async (tx) => {
				const row = await tx.findOne("native_builds", { id });
				if (row === null) return null;
				const build = pick(row);
				if (!storeBuild) {
					if (build.is_store_build) tx.update("native_builds", row, { is_store_build: false });
					return {
						nativeBuild: {
							...build,
							is_store_build: false
						},
						previous: null
					};
				}
				if (build.is_sandbox) throw new NativeBuildInputError("A sandbox build can't be the store build.");
				if (build.is_store_build) return {
					nativeBuild: build,
					previous: null
				};
				const holder = await tx.findOne("native_builds", { store_build_scope_key: build.scope_key });
				if (holder !== null) tx.update("native_builds", holder, { is_store_build: false });
				tx.update("native_builds", row, { is_store_build: true });
				return {
					nativeBuild: {
						...build,
						is_store_build: true
					},
					previous: holder === null ? null : {
						...pick(holder),
						is_store_build: false
					}
				};
			});
		} catch (error) {
			if (attempt < MARK_ATTEMPTS && error instanceof DatabaseConstraintError && error.reason === "unique") continue;
			throw error;
		}
	},
	async deleteNativeBuild(id) {
		return db.transaction(async (tx) => {
			const row = await tx.findOne("native_builds", { id });
			if (row === null) return {
				deleted: false,
				reason: "not_found"
			};
			await tx.delete("native_builds", row);
			const bundle = await tx.findOne("bundles", { id: row.min_bundle_id });
			if (bundle !== null) await tx.delete("bundles", bundle);
			return {
				deleted: true,
				nativeBuild: pick(row)
			};
		});
	},
	async listNativeBuilds(input) {
		const page = {
			order: input.order ?? "asc",
			limit: input.limit
		};
		const { rows } = input.channelId === void 0 ? await db.findMany("native_builds", {
			index: "all",
			where: {},
			...page,
			...after(input)
		}) : await db.findMany("native_builds", {
			index: "byChannel",
			where: { channel_id: input.channelId },
			...page,
			...after(input)
		});
		return rows.map(pick);
	}
});
var PAGE = 500;
var fail$1 = (code, message) => {
	throw new ReleaseCatalogMutationError(code, message);
};
var checkScope = (scope) => {
	const channelKey = encodeChannelKey(scope.channelName);
	const expected = scope.strategy === "APP_VERSION" ? createReleaseCatalogScopeKey({
		channelKey,
		platform: scope.platform,
		strategy: "APP_VERSION"
	}) : createReleaseCatalogScopeKey({
		channelKey,
		fingerprintHash: scope.fingerprintHash ?? "",
		platform: scope.platform,
		strategy: "FINGERPRINT"
	});
	if (scope.strategy === "FINGERPRINT" !== (scope.fingerprintHash !== null) || scope.scopeKey !== expected) fail$1("INVALID_SCOPE", "Release catalog scope metadata is inconsistent");
};
/** A scope's enabled releases, all of them, under the catalog's guard. */
var enabledReleases = async (tx, scopeKey) => {
	const rows = [];
	let cursor;
	do {
		const page = await tx.findMany("releases", {
			index: "byScopeEnabled",
			where: {
				scope_key: scopeKey,
				enabled: true
			},
			limit: PAGE,
			...cursor === void 0 ? {} : { cursor }
		});
		rows.push(...page.rows.map(toReleaseRow));
		cursor = page.next;
	} while (cursor !== void 0);
	return rows;
};
/** The scope's newest release id: `byScope` descending, limit 1. */
var latestReleaseId = async (tx, scopeKey) => {
	const { rows } = await tx.findMany("releases", {
		index: "byScope",
		where: { scope_key: scopeKey },
		order: "desc",
		limit: 1
	});
	return rows[0]?.id ?? null;
};
/** Compiles `enabled` and writes it as the scope's next catalog generation. */
var writeCatalog = async (tx, scope, stored, enabled, updatedAtMs) => {
	const compilation = await compileReleaseCatalog({
		strategy: scope.strategy,
		releases: enabled.map(releaseRowToRelease)
	});
	const generation = (stored.generation ?? 0) + 1;
	if (!Number.isSafeInteger(generation)) fail$1("CATALOG_GENERATION_EXHAUSTED", `Catalog "${scope.scopeKey}" exhausted its generation counter`);
	const catalog = {
		scope_key: scope.scopeKey,
		catalog_id: stored.catalog?.catalog_id ?? createUUIDv7(),
		strategy: scope.strategy,
		channel_id: scope.channelId,
		channel_key: encodeChannelKey(scope.channelName),
		platform: scope.platform,
		fingerprint_hash: scope.fingerprintHash,
		generation,
		payload: compilation.canonicalPayload,
		catalog_hash: compilation.catalogHash,
		byte_size: compilation.byteSize,
		is_tombstone: compilation.payload.releaseDescriptors.length === 0,
		updated_at_ms: updatedAtMs
	};
	const { scope_key: _scopeKey, ...set } = catalog;
	if (stored.row === null) tx.create("release_catalogs", catalog);
	else tx.update("release_catalogs", stored.row, set);
	return {
		catalog,
		compilation
	};
};
/** The scope's catalog row, and its compiled catalog and generation if it has one. */
var readCatalog = async (tx, scopeKey) => {
	const row = await tx.findOne("release_catalogs", { scope_key: scopeKey });
	return {
		row,
		generation: row?.generation ?? null,
		catalog: row === null ? null : toCatalogRow(row)
	};
};
/** A scope with releases and no compiled catalog lost its history. */
var assertHistory = (stored, hasReleases) => {
	if (stored.catalog === null && hasReleases) fail$1("CATALOG_IDENTITY_MISSING", "Catalog history is missing. Restore its catalog row from backup before rebuilding or deploying.");
};
/** One release change and its scope's next catalog, inside `tx`. */
var changeRelease = async (tx, { scope, change, bundle, updatedAtMs }) => {
	checkScope(scope);
	const stored = await readCatalog(tx, scope.scopeKey);
	const enabled = await enabledReleases(tx, scope.scopeKey);
	if (bundle !== void 0) {
		insertBundle(tx, bundle.row);
		for (const patch of bundle.patches) tx.create("bundle_patches", patch);
	}
	let before = null;
	let release;
	if (change.operation === "insert") {
		const latest = await latestReleaseId(tx, scope.scopeKey);
		assertHistory(stored, latest !== null);
		const floor = [latest, bundle && isUUIDv7(bundle.row.id) ? bundle.row.id : null].filter((id) => id !== null).sort().at(-1);
		const id = change.row.id ?? createUUIDv7After(floor ?? null);
		if (latest !== null && id <= latest) fail$1("NON_MONOTONIC_RELEASE_ID", `Release "${id}" must sort after "${latest}"`);
		release = {
			...change.row,
			id
		};
		if (release.scope_key !== scope.scopeKey || release.channel_id !== scope.channelId || release.platform !== scope.platform || release.strategy !== scope.strategy || release.fingerprint_hash !== scope.fingerprintHash || release.revision !== 1) fail$1("INVALID_SCOPE", "Inserted Release does not match its catalog scope");
		tx.create("releases", release);
	} else {
		const row = await tx.findOne("releases", { id: change.id });
		if (row === null || row.scope_key !== scope.scopeKey) return fail$1("RELEASE_NOT_FOUND", `Release "${change.id}" was not found in scope "${scope.scopeKey}"`);
		assertHistory(stored, true);
		before = toReleaseRow(row);
		if (change.operation === "delete") {
			await tx.delete("releases", row);
			release = null;
		} else {
			const set = {
				...change.update,
				revision: before.revision + 1
			};
			tx.update("releases", row, set);
			release = {
				...before,
				...set
			};
		}
	}
	const changedId = before?.id ?? release?.id;
	const { catalog, compilation } = await writeCatalog(tx, scope, stored, [...enabled.filter(({ id }) => id !== changedId), ...release?.enabled ? [release] : []].sort((left, right) => left.id < right.id ? -1 : 1), updatedAtMs);
	return {
		catalog,
		release,
		diagnostics: compilation.diagnostics
	};
};
/**
* Release changes rooted at their catalogs: each reads its scope's catalog
* and enabled releases, applies the change, and writes the next catalog
* generation, all in one transaction. A concurrent change in a scope bumps
* its catalog row, so this transaction reruns instead of publishing a stale
* catalog.
*/
var changeReleases = (db, inputs) => {
	if (new Set(inputs.map(({ scope }) => scope.scopeKey)).size !== inputs.length) fail$1("INVALID_SCOPE", "A batch cannot change one catalog scope twice");
	return db.transaction(async (tx) => {
		const results = [];
		for (const input of inputs) results.push(await changeRelease(tx, input));
		return results;
	});
};
/** Recompiles a scope's catalog from its enabled releases inside `tx`; an unchanged catalog is not rewritten. */
var rebuildScope = async (tx, scope, updatedAtMs) => {
	checkScope(scope);
	const stored = await readCatalog(tx, scope.scopeKey);
	assertHistory(stored, await latestReleaseId(tx, scope.scopeKey) !== null);
	const enabled = await enabledReleases(tx, scope.scopeKey);
	const compilation = await compileReleaseCatalog({
		strategy: scope.strategy,
		releases: enabled.map(releaseRowToRelease)
	});
	const current = stored.catalog;
	if (current !== null && current.strategy === scope.strategy && current.channel_id === scope.channelId && current.channel_key === encodeChannelKey(scope.channelName) && current.platform === scope.platform && current.fingerprint_hash === scope.fingerprintHash && current.catalog_hash === compilation.catalogHash) return {
		catalog: current,
		current,
		changed: false,
		diagnostics: compilation.diagnostics
	};
	const written = await writeCatalog(tx, scope, stored, enabled, updatedAtMs);
	return {
		catalog: written.catalog,
		current,
		changed: true,
		diagnostics: written.compilation.diagnostics
	};
};
/** Carries a preflight's result out of the transaction it stops, so nothing is written. */
var Preflight = class extends Error {
	result;
	constructor(result) {
		super("preflight");
		this.result = result;
	}
};
var dryRun = async (db, read) => {
	try {
		await db.transaction(async (tx) => {
			throw new Preflight(await read(tx));
		});
	} catch (error) {
		if (error instanceof Preflight) return error.result;
		throw error;
	}
	throw new Error("A preflight transaction returned without its result.");
};
/** A channel's catalog scope for a platform, and a fingerprint when it has one. */
var scopeOf = (channel, platform, fingerprintHash) => {
	const channelKey = encodeChannelKey(channel.name);
	return fingerprintHash === null ? {
		channelId: channel.id,
		channelName: channel.name,
		fingerprintHash,
		platform,
		scopeKey: createReleaseCatalogScopeKey({
			channelKey,
			platform,
			strategy: "APP_VERSION"
		}),
		strategy: "APP_VERSION"
	} : {
		channelId: channel.id,
		channelName: channel.name,
		fingerprintHash,
		platform,
		scopeKey: createReleaseCatalogScopeKey({
			channelKey,
			fingerprintHash,
			platform,
			strategy: "FINGERPRINT"
		}),
		strategy: "FINGERPRINT"
	};
};
/** A release and its scope, checked against the revision the caller saw. */
var loadTarget = async (tx, { releaseId, expectedRevision }) => {
	const row = await tx.findOne("releases", { id: releaseId });
	if (row === null) throw new ReleaseManagementError("RELEASE_NOT_FOUND", `Release "${releaseId}" was not found.`);
	const release = toReleaseRow(row);
	if (expectedRevision !== void 0 && expectedRevision !== release.revision) throw new ReleaseManagementError("VERSION_CONFLICT", `Release "${release.id}" is revision ${release.revision}; expected ${expectedRevision}.`);
	const catalog = await tx.findOne("release_catalogs", { scope_key: release.scope_key });
	if (catalog === null) throw new ReleaseCatalogMutationError("INVALID_SCOPE", `Release "${release.id}" has no catalog projection.`);
	return {
		release,
		scope: {
			channelId: release.channel_id,
			channelName: decodeChannelKey(catalog.channel_key),
			fingerprintHash: release.fingerprint_hash,
			platform: release.platform,
			scopeKey: release.scope_key,
			strategy: release.strategy
		}
	};
};
var policyUpdate = (release, patch, updatedAtMs) => {
	if (patch.fingerprintHash !== void 0 && patch.fingerprintHash !== release.fingerprint_hash) throw new ReleaseManagementError("SCOPE_MOVE_UNSUPPORTED", "Changing a fingerprint target requires an atomic Release scope move.");
	return {
		...patch.enabled === void 0 ? {} : { enabled: patch.enabled },
		...patch.message === void 0 ? {} : { message: patch.message },
		...patch.rolloutCohortCount === void 0 ? {} : { rollout_cohort_count: patch.rolloutCohortCount },
		...patch.shouldForceUpdate === void 0 ? {} : { should_force_update: patch.shouldForceUpdate },
		...patch.targetAppVersion === void 0 ? {} : { target_app_version: patch.targetAppVersion },
		...patch.targetCohorts === void 0 ? {} : { target_cohorts: [...patch.targetCohorts] },
		updated_at_ms: updatedAtMs
	};
};
var mutationResult = ({ catalog, release }) => ({
	attempts: 1,
	catalog,
	release
});
/** The scope a catalog row names, for a rebuild. */
var catalogScope = async (tx, scopeKey) => {
	const row = await tx.findOne("release_catalogs", { scope_key: scopeKey });
	if (row === null) throw new Error(`Release catalog "${scopeKey}" was not found.`);
	return {
		channelId: row.channel_id,
		channelName: decodeChannelKey(row.channel_key),
		fingerprintHash: row.fingerprint_hash,
		platform: row.platform,
		scopeKey: row.scope_key,
		strategy: row.strategy
	};
};
/**
* Core's typed writes: each runs in one engine transaction rooted at the
* catalogs it changes, so a concurrent change reruns it instead of
* publishing a stale catalog.
*/
var createCoreOperations = (db, { now = Date.now } = {}) => {
	const ensureChannel = async (name) => (await insertChannel(db, {
		id: `channel:${encodeChannelKey(name)}`,
		name
	})).row;
	/**
	* Runs a write that ensured its channels first. A channel deleted between
	* that and the write refuses the write, so it runs again and ensures it anew.
	*/
	const withChannels = async (write) => {
		for (let attempt = 1;; attempt += 1) try {
			return await write();
		} catch (error) {
			if (attempt < 3 && error instanceof DatabaseConstraintError && error.reason === "not_found" && error.model === "channels") continue;
			throw error;
		}
	};
	const deployOnce = async (deployments) => {
		const channels = /* @__PURE__ */ new Map();
		for (const { release } of deployments) if (!channels.has(release.channel)) channels.set(release.channel, await ensureChannel(release.channel));
		const platforms = /* @__PURE__ */ new Map();
		for (const deployment of deployments) {
			if (!("bundleId" in deployment)) {
				for (const { baseBundleId } of deployment.bundle.patches ?? []) await refuseSandboxPatchBase(db, baseBundleId);
				continue;
			}
			if (platforms.has(deployment.bundleId)) continue;
			const row = await db.findOne("bundles", { id: deployment.bundleId });
			if (row === null) throw new DatabaseBundleNotFoundError(deployment.bundleId);
			if (await isBuiltInBundle(db, deployment.bundleId)) throw new ReleaseManagementError("TARGET_RELEASE_INVALID", `Bundle "${deployment.bundleId}" is a native build's built-in bundle, which no release publishes.`);
			platforms.set(deployment.bundleId, toBundleRow(row).platform);
		}
		const updatedAtMs = now();
		return (await changeReleases(db, deployments.map((deployment) => {
			const { release: policy } = deployment;
			const stored = "bundleId" in deployment;
			const bundleId = stored ? deployment.bundleId : deployment.bundle.id;
			const platform = stored ? platforms.get(deployment.bundleId) : deployment.bundle.platform;
			const scope = scopeOf(channels.get(policy.channel), platform, policy.fingerprintHash);
			return {
				scope,
				...stored ? {} : { bundle: {
					row: bundleToRow(deployment.bundle),
					patches: bundleToPatchRows(deployment.bundle)
				} },
				change: {
					operation: "insert",
					row: {
						bundle_id: bundleId,
						channel_id: scope.channelId,
						created_at_ms: updatedAtMs,
						enabled: policy.enabled,
						fingerprint_hash: policy.fingerprintHash,
						kind: "BUNDLE",
						message: policy.message,
						operation: "DEPLOY",
						platform,
						revision: 1,
						rollout_cohort_count: policy.rolloutCohortCount ?? 1e3,
						scope_key: scope.scopeKey,
						should_force_update: policy.shouldForceUpdate,
						source_release_id: null,
						strategy: scope.strategy,
						target_app_version: policy.targetAppVersion,
						target_cohorts: policy.targetCohorts ?? [],
						updated_at_ms: updatedAtMs
					}
				},
				updatedAtMs
			};
		}))).map(mutationResult);
	};
	return {
		deploy: (deployments) => withChannels(() => deployOnce(deployments)),
		updateReleasePolicy: (input) => {
			const updatedAtMs = now();
			return db.transaction(async (tx) => {
				const { release, scope } = await loadTarget(tx, input);
				return mutationResult(await changeRelease(tx, {
					scope,
					change: {
						operation: "update",
						id: release.id,
						update: policyUpdate(release, input.patch, updatedAtMs)
					},
					updatedAtMs
				}));
			});
		},
		preflightReleasePolicy: (input) => {
			const updatedAtMs = now();
			return dryRun(db, async (tx) => {
				const { release, scope } = await loadTarget(tx, input);
				const stored = await readCatalog(tx, scope.scopeKey);
				const changed = await changeRelease(tx, {
					scope,
					change: {
						operation: "update",
						id: release.id,
						update: policyUpdate(release, input.patch, updatedAtMs)
					},
					updatedAtMs
				});
				return {
					catalog: changed.catalog,
					currentCatalog: stored.catalog,
					diagnostics: changed.diagnostics,
					expectedReleaseRevision: release.revision,
					release: changed.release
				};
			});
		},
		deleteRelease: (input) => db.transaction(async (tx) => {
			const { release, scope } = await loadTarget(tx, input);
			if (release.enabled) throw new ReleaseManagementError("ENABLED_RELEASE", `Disable Release "${release.id}" before hard deletion.`);
			const bundle = release.bundle_id === null ? null : await tx.findOne("bundles", { id: release.bundle_id });
			const result = mutationResult(await changeRelease(tx, {
				scope,
				change: {
					operation: "delete",
					id: release.id
				},
				updatedAtMs: now()
			}));
			if (bundle !== null && (bundle._refs_releases_bundle_id ?? 0) <= 1) await deleteBundle(tx, bundle);
			return result;
		}),
		promoteRelease: (input) => withChannels(async () => {
			const checkSource = (source) => {
				if (source.bundle_id === null) throw new ReleaseManagementError("TARGET_RELEASE_INVALID", "Only a Bundle Release can be promoted.");
			};
			checkSource((await db.transaction((tx) => loadTarget(tx, input))).release);
			const targetChannel = input.targetChannel.trim();
			if (targetChannel.length === 0) throw new ReleaseManagementError("TARGET_RELEASE_INVALID", "Promotion requires a target channel.");
			const channel = await ensureChannel(targetChannel);
			const updatedAtMs = now();
			return db.transaction(async (tx) => {
				const { release: source, scope: sourceScope } = await loadTarget(tx, input);
				checkSource(source);
				const targetScope = scopeOf(channel, source.platform, source.fingerprint_hash);
				if (targetScope.scopeKey === sourceScope.scopeKey) throw new ReleaseManagementError("TARGET_RELEASE_INVALID", "Source and target Release scopes are the same.");
				const { rows } = await tx.findMany("releases", {
					index: "byScope",
					where: { scope_key: targetScope.scopeKey },
					order: "desc",
					limit: 1
				});
				const floor = [
					rows[0]?.id ?? null,
					source.id,
					source.bundle_id
				].filter((id) => id !== null && isUUIDv7(id)).sort().at(-1);
				const moved = input.action === "move" ? await changeRelease(tx, {
					scope: sourceScope,
					change: {
						operation: "update",
						id: source.id,
						update: {
							enabled: false,
							updated_at_ms: updatedAtMs
						}
					},
					updatedAtMs
				}) : null;
				const target = await changeRelease(tx, {
					scope: targetScope,
					change: {
						operation: "insert",
						row: {
							...source,
							id: createUUIDv7After(floor ?? null, updatedAtMs),
							revision: 1,
							scope_key: targetScope.scopeKey,
							channel_id: targetScope.channelId,
							enabled: true,
							rollout_cohort_count: 1e3,
							target_cohorts: [],
							operation: "PROMOTE",
							source_release_id: source.id,
							created_at_ms: updatedAtMs,
							updated_at_ms: updatedAtMs
						}
					},
					updatedAtMs
				});
				return {
					source: moved === null ? null : mutationResult(moved),
					target: mutationResult(target)
				};
			});
		}),
		rebuildReleaseCatalog: (scopeKey) => {
			const updatedAtMs = now();
			return db.transaction(async (tx) => {
				const { current: _current, ...rebuilt } = await rebuildScope(tx, await catalogScope(tx, scopeKey), updatedAtMs);
				return {
					attempts: 1,
					...rebuilt
				};
			});
		},
		preflightReleaseCatalogRebuild: (scopeKey) => {
			const updatedAtMs = now();
			return dryRun(db, async (tx) => {
				const rebuilt = await rebuildScope(tx, await catalogScope(tx, scopeKey), updatedAtMs);
				return {
					changed: rebuilt.changed,
					currentCatalog: rebuilt.current,
					diagnostics: rebuilt.diagnostics,
					projectedCatalog: rebuilt.catalog
				};
			});
		},
		ensureChannel,
		deleteChannel: (id) => deleteChannel(db, id),
		updateBundle: (id, update) => db.transaction(async (tx) => {
			const current = await tx.findOne("bundles", { id });
			if (current === null) throw new DatabaseBundleNotFoundError(id);
			const { patches, ...fields } = update;
			const next = {
				...rowToBundle(toBundleRow(current)),
				...fields,
				id
			};
			const { id: _id, ...set } = bundleToRow(next);
			updateBundle(tx, current, set, { counted: set.platform === current.platform || !await isBuiltInBundle(tx, id) });
			if (patches !== void 0) await replaceBundlePatches(tx, current, bundleToPatchRows({
				...next,
				patches
			}), (row) => refuseSandboxPatchBase(tx, row.base_bundle_id));
		}),
		deleteBundles: async (ids) => {
			try {
				await db.transaction(async (tx) => {
					for (const id of new Set(ids)) {
						const current = await tx.findOne("bundles", { id });
						if (current === null) continue;
						if (await isBuiltInBundle(tx, id)) throw new DatabaseRowReferencedError();
						await deleteBundle(tx, current);
					}
				});
			} catch (error) {
				if (error instanceof DatabaseConstraintError && error.reason === "referenced") throw new DatabaseRowReferencedError();
				throw error;
			}
		}
	};
};
/**
* The update check answers from one Release Catalog row, so a transaction
* changes what the cacheable client routes answer only when it writes one.
* The purge runs once, after the attempt that commits.
*/
var purgingCachedRoutes = (db, onCachedRoutesChange) => {
	if (onCachedRoutesChange === void 0) return db;
	return {
		...db,
		async transaction(fn) {
			let changed = false;
			const result = await db.transaction((tx) => {
				changed = false;
				return fn({
					...tx,
					create: (model, row) => {
						changed ||= model === "release_catalogs";
						tx.create(model, row);
					},
					update: (model, row, set) => {
						changed ||= model === "release_catalogs";
						tx.update(model, row, set);
					},
					delete: (model, row) => {
						changed ||= model === "release_catalogs";
						return tx.delete(model, row);
					}
				});
			});
			if (changed) await onCachedRoutesChange();
			return result;
		}
	};
};
/** Core's reads and typed writes over one database handle. */
var createCoreApi = (db, storage, options = {}) => {
	const reads = createCoreReads(db, storage);
	return {
		...reads,
		...createCoreOperations(purgingCachedRoutes(db, options.onCachedRoutesChange), options),
		...createNativeBuildApi(db, options),
		...createIosDeviceApi(db, options),
		ready: async () => {
			await reads.listReleaseCatalogs({ limit: 1 });
		}
	};
};
var PLUGIN_KEYS = /* @__PURE__ */ new Set([
	"id",
	"provides",
	"schemaVersion",
	"schema",
	"namespace",
	"init",
	"cli"
]);
var CLI_KEYS = /* @__PURE__ */ new Set(["clientCredential", "clientPlugin"]);
var INSTANCE_KEYS = /* @__PURE__ */ new Set([
	"api",
	"endpoints",
	"clientAuth"
]);
var METHODS = /* @__PURE__ */ new Set([
	"GET",
	"POST",
	"PUT",
	"PATCH",
	"DELETE"
]);
/** An id that prefixes table names is a SQL name; one that does not may use camelCase. */
var PREFIX_ID = /^[a-z][a-z0-9_]*$/u;
var UNPREFIXED_ID = /^[a-z][A-Za-z0-9_]*$/u;
var PATH = /^(\/(:?[A-Za-z0-9_.~-]+))+$/u;
var fail = (message) => {
	throw new HotUpdaterConfigError(message);
};
var isRecord$2 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var checkPlugin = (value, at) => {
	if (!isRecord$2(value)) return fail(`${at} is not a plugin.`);
	const unknown = Object.keys(value).find((key) => !PLUGIN_KEYS.has(key));
	if (unknown !== void 0) fail(`${at} has an unknown key "${unknown}".`);
	const plugin = value;
	if (plugin.namespace !== void 0 && plugin.namespace !== false) fail(`${at} may only set namespace: false.`);
	const pattern = plugin.namespace === false ? UNPREFIXED_ID : PREFIX_ID;
	if (typeof plugin.id !== "string" || !pattern.test(plugin.id)) fail(`${at} needs an id matching ${pattern.source}.`);
	if (plugin.id === "core") fail(`${at} uses the id "core", which is core's own.`);
	checkReservedId(value, at);
	if (typeof plugin.schemaVersion !== "string" || !isRecord$2(plugin.schema) || typeof plugin.init !== "function") fail(`Plugin "${plugin.id}" needs a schemaVersion, a schema, and init.`);
	const provides = plugin.provides;
	if (provides !== void 0 && (!isRecord$2(provides) || Object.entries(provides).some(([key, flag]) => key !== "clientAuth" || flag !== true))) fail(`Plugin "${plugin.id}" may only declare provides: { clientAuth: true }.`);
	const cli = value.cli;
	if (cli !== void 0) {
		if (!isRecord$2(cli) || Object.keys(cli).some((key) => !CLI_KEYS.has(key))) fail(`Plugin "${plugin.id}" cli may only hold clientCredential and clientPlugin.`);
		if (cli.clientCredential !== void 0 && plugin.provides?.clientAuth !== true) fail(`Plugin "${plugin.id}" adds cli.clientCredential without declaring provides: { clientAuth: true }.`);
	}
	return plugin;
};
var checkEndpoint = (id, value) => {
	const endpoint = isRecord$2(value) ? value : {};
	if (!METHODS.has(endpoint.method) || typeof endpoint.path !== "string" || !PATH.test(endpoint.path) || endpoint.access !== "client" && endpoint.access !== "admin" || typeof endpoint.handler !== "function") fail(`Plugin "${id}" has an endpoint that needs a method, a path like /name/:param, access "client" or "admin", and a handler.`);
	return {
		...endpoint,
		plugin: id
	};
};
var checkInstance = (plugin, instance) => {
	const { id } = plugin;
	if (!isRecord$2(instance)) return fail(`Plugin "${id}" init returned no instance.`);
	if (typeof instance.then === "function") fail(`Plugin "${id}" init returned a promise; init must be synchronous.`);
	const unknown = Object.keys(instance).find((key) => !INSTANCE_KEYS.has(key));
	if (unknown !== void 0 || !("api" in instance)) fail(`Plugin "${id}" init must return { api, endpoints?, clientAuth? }${unknown === void 0 ? "" : `, not "${unknown}"`}.`);
	const declared = plugin.provides?.clientAuth === true;
	const clientAuth = instance.clientAuth;
	if (declared !== (clientAuth !== void 0)) fail(declared ? `Plugin "${id}" declares provides: { clientAuth: true } but its instance has no clientAuth.` : `Plugin "${id}" returns clientAuth without declaring provides: { clientAuth: true }.`);
	if (clientAuth !== void 0 && (typeof clientAuth.authenticate !== "function" || !Array.isArray(clientAuth.varyHeaders) || !clientAuth.varyHeaders.every((header) => typeof header === "string"))) fail(`Plugin "${id}" clientAuth needs varyHeaders and authenticate.`);
	const endpoints = instance.endpoints ?? [];
	if (!Array.isArray(endpoints)) fail(`Plugin "${id}" endpoints must be an array.`);
	return {
		api: instance.api,
		clientAuth,
		endpoints: endpoints.map((endpoint) => checkEndpoint(id, endpoint))
	};
};
/**
* Checks every plugin, runs each `init` once against one engine over the
* database, and collects APIs, endpoints, and clientAuth. Core's reads run
* on the same engine, so plugins read core through `ctx.core`.
*/
var assemblePlugins = (value, database, { now = Date.now, storage = { resolveFileUrl: async () => null } } = {}) => {
	if (!Array.isArray(value)) return fail("plugins must be an array of plugins.");
	const plugins = value.map((plugin, position) => checkPlugin(plugin, `plugins[${position}]`));
	const ids = /* @__PURE__ */ new Set();
	for (const { id } of plugins) {
		if (ids.has(id)) fail(`Plugin "${id}" is registered twice.`);
		ids.add(id);
	}
	clientPluginsOf(plugins);
	const engine = createEngine(database, {
		plugins,
		now
	});
	const { onCachedRoutesChange } = database;
	const core = createCoreApi(engine.core, storage, {
		now,
		...onCachedRoutesChange === void 0 ? {} : { onCachedRoutesChange: () => onCachedRoutesChange.call(database) }
	});
	const reads = createCoreReads(engine.core, storage);
	const api = {};
	const endpoints = [];
	let clientAuth;
	for (const plugin of plugins) {
		const instance = checkInstance(plugin, plugin.init({
			db: engine.database(plugin),
			core: reads,
			now
		}));
		if (instance.clientAuth !== void 0) {
			if (clientAuth !== void 0) fail(`Plugins "${clientAuth.plugin}" and "${plugin.id}" both provide clientAuth; keep one.`);
			const provided = instance.clientAuth;
			clientAuth = {
				plugin: plugin.id,
				varyHeaders: provided.varyHeaders,
				authenticate: (headers) => provided.authenticate(headers)
			};
		}
		endpoints.push(...instance.endpoints);
		api[plugin.id] = instance.api;
	}
	return {
		core,
		api,
		endpoints,
		...clientAuth === void 0 ? {} : { clientAuth },
		flush: engine.flush
	};
};
var HandlerBadRequestError = class extends Error {
	name = "HandlerBadRequestError";
	constructor(message) {
		super(message);
	}
};
var decodeMaybe = (value) => {
	if (value === void 0) return void 0;
	try {
		return decodeURIComponent(value);
	} catch {
		return value;
	}
};
var isPlatform = (value) => value === "ios" || value === "android";
var requireRouteParam = (params, key) => {
	const value = params[key];
	if (!value) throw new HandlerBadRequestError(`Missing route parameter: ${key}`);
	return value;
};
var requirePlatformParam = (params) => {
	const platform = requireRouteParam(params, "platform");
	if (!isPlatform(platform)) throw new HandlerBadRequestError(`Invalid platform: ${platform}. Expected 'ios' or 'android'.`);
	return platform;
};
var parseBooleanSearchParam = (url, key) => {
	const value = url.searchParams.get(key);
	if (value === null) return void 0;
	if (value === "true") return true;
	if (value === "false") return false;
	throw new HandlerBadRequestError(`The '${key}' query parameter must be 'true' or 'false'.`);
};
var json = (body, status = 200) => Response.json(body, { status });
var notFound = () => json({ error: "Not found" }, 404);
var noContent = () => new Response(null, { status: 204 });
/** Runs `route` on core, answering its refusals. */
var onCore = (route) => async (params, request, api) => answer(() => route(api.core, request, params));
/** Core's refusals as HTTP answers; anything else is a server error. */
var answer = async (operation) => {
	try {
		return await operation();
	} catch (error) {
		if (error instanceof ReleaseManagementError || error instanceof ReleaseCatalogMutationError) {
			const status = error.code === "RELEASE_NOT_FOUND" ? 404 : error.code === "VERSION_CONFLICT" ? 409 : 400;
			return json({
				code: error.code,
				error: error.message
			}, status);
		}
		if (error instanceof DatabaseBundleNotFoundError) return json({
			code: "BUNDLE_NOT_FOUND",
			error: error.message
		}, 404);
		if (error instanceof DatabaseRowReferencedError) return json({
			code: "REFERENCED",
			error: error.message
		}, 409);
		if (error instanceof DatabaseConstraintError && error.model === "native_builds") return json({
			code: "NATIVE_BUILD_EXISTS",
			error: "A native build with this ID or built-in bundle ID is already registered."
		}, 409);
		throw error;
	}
};
var LIMITS = {
	defaultValue: 50,
	maxValue: 500
};
/** `order`, `cursor`, and `limit`: one keyset page. */
var keyset = (url, maxValue = LIMITS.maxValue) => {
	const order = url.searchParams.get("order") ?? "desc";
	if (order !== "asc" && order !== "desc") throw new HandlerBadRequestError("order must be 'asc' or 'desc'.");
	const limitParam = url.searchParams.get("limit");
	const limit = limitParam === null ? Math.min(LIMITS.defaultValue, maxValue) : Number(limitParam);
	if (!Number.isSafeInteger(limit) || limit < 1 || limit > maxValue) throw new HandlerBadRequestError(`limit must be between 1 and ${maxValue}.`);
	const cursor = url.searchParams.get("cursor");
	const through = url.searchParams.get("through");
	return {
		order,
		limit,
		...cursor === null ? {} : { after: cursor },
		...through === null ? {} : { through }
	};
};
/** A page and the cursor of the next one, when the page is full. */
var page = (rows, { limit }, keyOf, extra = {}) => json({
	data: rows,
	...rows.length === limit && rows.length > 0 ? { next: keyOf(rows.at(-1)) } : {},
	...extra
});
var platformOf = (url) => {
	const platform = url.searchParams.get("platform");
	if (platform === null) return void 0;
	if (!isPlatform(platform)) throw new HandlerBadRequestError(`Invalid platform: ${platform}. Expected 'ios' or 'android'.`);
	return platform;
};
/** The one filter set a release list names; any other mix of filters is refused. */
var releaseFilter = (url) => {
	const params = url.searchParams;
	const named = [
		"channelId",
		"platform",
		"bundleId",
		"scopeKey"
	].filter((name) => params.has(name));
	const enabled = parseBooleanSearchParam(url, "enabled");
	const withEnabled = enabled === void 0 ? {} : { enabled };
	const set = named.join(",");
	if (set === "" && enabled === void 0) return { kind: "all" };
	if (set === "channelId,platform") {
		const platform = platformOf(url);
		return {
			kind: "channelPlatform",
			channelId: params.get("channelId"),
			platform,
			...withEnabled
		};
	}
	if (set === "bundleId" && enabled === void 0) return {
		kind: "bundle",
		bundleId: params.get("bundleId")
	};
	if (set === "scopeKey") return {
		kind: "scope",
		scopeKey: params.get("scopeKey"),
		...withEnabled
	};
	throw new HandlerBadRequestError("Releases filter by none, channelId and platform (with enabled), bundleId, or scopeKey (with enabled).");
};
var isRecord$1 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var body = async (request) => {
	const value = await request.json();
	if (!isRecord$1(value)) throw new HandlerBadRequestError("Invalid body");
	return value;
};
var isText = (value) => typeof value === "string" && value.length > 0;
var isTextOrNull = (value) => value === null || isText(value);
var isBundle = (bundle) => isRecord$1(bundle) && isText(bundle.id) && typeof bundle.platform === "string" && isPlatform(bundle.platform) && isTextOrNull(bundle.gitCommitHash) && isText(bundle.manifestStorageUri) && isText(bundle.manifestFileHash) && isText(bundle.assetBaseStorageUri) && (bundle.metadata === void 0 || isRecord$1(bundle.metadata)) && (bundle.patches === void 0 || bundle.patches === null || Array.isArray(bundle.patches));
var isReleasePolicy = (release) => isRecord$1(release) && isText(release.channel) && typeof release.enabled === "boolean" && typeof release.shouldForceUpdate === "boolean" && isTextOrNull(release.fingerprintHash) && isTextOrNull(release.targetAppVersion) && (release.message === null || typeof release.message === "string") && (release.rolloutCohortCount === void 0 || Number.isSafeInteger(release.rolloutCohortCount) && release.rolloutCohortCount >= 0 && release.rolloutCohortCount <= 1e3) && (release.targetCohorts === void 0 || Array.isArray(release.targetCohorts) && release.targetCohorts.every(isText));
/** A deployment's shape: a new bundle or a stored bundle's id, and its release policy. */
var isDeployment = (value) => isRecord$1(value) && isReleasePolicy(value.release) && ("bundleId" in value ? isText(value.bundleId) && !("bundle" in value) : isBundle(value.bundle));
/** An expected release revision from a body number or a query string. */
var revisionOf = (value) => {
	if (value === void 0 || value === null || value === "") return void 0;
	const revision = typeof value === "string" ? Number(value) : value;
	if (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 1) throw new HandlerBadRequestError("Invalid expected Release revision");
	return revision;
};
/** A policy change's body: `{ expectedRevision?, patch }`. */
var policyInput = async (request) => {
	const input = await body(request);
	if (!isRecord$1(input.patch)) throw new HandlerBadRequestError("Invalid Release policy mutation");
	const expectedRevision = revisionOf(input.expectedRevision);
	return {
		patch: input.patch,
		...expectedRevision === void 0 ? {} : { expectedRevision }
	};
};
/** A bundle update's body: the fields it changes, never another bundle's id. */
var bundleUpdateOf = (value, bundleId) => {
	if (!isRecord$1(value)) throw new HandlerBadRequestError("Invalid bundle payload");
	const { id, ...update } = value;
	if (id !== void 0 && id !== bundleId) throw new HandlerBadRequestError("Bundle id mismatch");
	return update;
};
var NATIVE_BUILD_ARTIFACT_KINDS = /* @__PURE__ */ new Set([
	"apk",
	"aab",
	"ipa",
	"app"
]);
/** A native build's scope: `fingerprintHash` or `appVersion`, never both. */
var nativeBuildScopeOf = (url) => {
	const params = url.searchParams;
	const platform = platformOf(url);
	const channel = params.get("channel");
	const fingerprintHash = params.get("fingerprintHash");
	const appVersion = params.get("appVersion");
	if (platform === void 0 || !isText(channel) || fingerprintHash === null === (appVersion === null) || fingerprintHash === "" || appVersion === "") throw new HandlerBadRequestError("A native build lookup needs platform, channel, and fingerprintHash or appVersion.");
	const sandbox = sandboxScopeOf(params);
	const scope = fingerprintHash !== null ? {
		platform,
		channel,
		fingerprintHash,
		appVersion: null
	} : {
		platform,
		channel,
		fingerprintHash: null,
		appVersion
	};
	return sandbox === null ? scope : {
		...scope,
		sandbox
	};
};
/** The query parameters a sandbox lookup names, all four or none. */
var SANDBOX_SCOPE_PARAMS = [
	"sandboxAppId",
	"sandboxUrlScheme",
	"artifactKind",
	"distribution"
];
/**
* A lookup's sandbox scope: null without one, and a bad request for one
* named in part. Core checks each value.
*/
var sandboxScopeOf = (params) => {
	const [appId, urlScheme, artifactKind, distribution] = SANDBOX_SCOPE_PARAMS.map((name) => params.get(name));
	const named = [
		appId,
		urlScheme,
		artifactKind,
		distribution
	].filter((value) => value !== null).length;
	if (named === 0) return null;
	if (named !== SANDBOX_SCOPE_PARAMS.length) throw new HandlerBadRequestError(`A sandbox build lookup needs ${SANDBOX_SCOPE_PARAMS.join(", ")}.`);
	return {
		appId,
		urlScheme,
		artifactKind,
		distribution
	};
};
/** A native build or scope core refuses: a bad request. */
var refusingInvalid = async (operation) => {
	try {
		return await operation();
	} catch (error) {
		if (error instanceof NativeBuildInputError || error instanceof IosDeviceInputError) throw new HandlerBadRequestError(error.message);
		throw error;
	}
};
var isNativeBuildRegistration = (value) => isRecord$1(value) && isText(value.id) && isText(value.minBundleId) && typeof value.platform === "string" && isPlatform(value.platform) && isText(value.channel) && isTextOrNull(value.fingerprintHash) && isTextOrNull(value.appVersion) && value.fingerprintHash === null !== (value.appVersion === null) && isTextOrNull(value.gitCommitHash) && isTextOrNull(value.buildKey) && (value.buildNumber === void 0 || isTextOrNull(value.buildNumber)) && (value.isSandbox === void 0 || typeof value.isSandbox === "boolean") && (value.sandboxUrlScheme === void 0 || isTextOrNull(value.sandboxUrlScheme)) && (value.sandboxAppId === void 0 || isTextOrNull(value.sandboxAppId)) && (value.exportMethod === void 0 || isTextOrNull(value.exportMethod)) && (value.nativeAppVersion === void 0 || isTextOrNull(value.nativeAppVersion)) && isRecord$1(value.artifact) && typeof value.artifact.kind === "string" && NATIVE_BUILD_ARTIFACT_KINDS.has(value.artifact.kind) && isText(value.artifact.storageUri) && Number.isSafeInteger(value.artifact.byteSize) && value.artifact.byteSize >= 0 && isRecord$1(value.embeddedBundle) && isText(value.embeddedBundle.manifestStorageUri) && isText(value.embeddedBundle.manifestFileHash) && isText(value.embeddedBundle.assetBaseStorageUri) && (value.embeddedBundle.metadata === void 0 || isRecord$1(value.embeddedBundle.metadata));
var scopeKeyOf = (params) => decodeMaybe(requireRouteParam(params, "scopeKey")) ?? "";
/** Every admin route's handler, by the name `ADMIN_ROUTES` mounts it under. */
var createAdminRouteHandlers = () => ({
	listBundles: onCore(async (core, request) => {
		const url = new URL(request.url);
		const input = keyset(url, 100);
		const platform = platformOf(url);
		const withTotal = parseBooleanSearchParam(url, "total") === true;
		const [rows, total] = await Promise.all([core.listBundles({
			...input,
			...platform ? { platform } : {}
		}), withTotal ? core.countBundles(platform) : void 0]);
		return page(rows, input, (row) => row.bundle.id, total === void 0 ? {} : { total });
	}),
	getBundle: onCore(async (core, _request, params) => {
		const detail = await core.getBundle(requireRouteParam(params, "id"));
		return detail === null ? notFound() : json({ data: detail });
	}),
	listReleases: onCore(async (core, request) => {
		const url = new URL(request.url);
		const input = keyset(url);
		return page(await core.listReleases({
			...input,
			filter: releaseFilter(url)
		}), input, (row) => row.id);
	}),
	listReleaseCatalogs: onCore(async (core, request) => {
		const input = keyset(new URL(request.url));
		return page(await core.listReleaseCatalogs(input), input, (row) => row.scope_key);
	}),
	getChannels: onCore(async (core, request) => {
		const name = new URL(request.url).searchParams.get("name");
		if (name === null) return json({ data: await core.listChannels() });
		const channel = await core.findChannelByName(name);
		return channel === null ? notFound() : json({ data: channel });
	}),
	createChannel: onCore(async (core, request) => {
		const { name } = await body(request);
		if (typeof name !== "string" || name.trim().length === 0) throw new HandlerBadRequestError("Invalid channel name");
		return json({ data: await core.ensureChannel(name) });
	}),
	deleteChannel: onCore(async (core, _request, params) => {
		const result = await core.deleteChannel(decodeMaybe(requireRouteParam(params, "id")) ?? "");
		if (result.deleted) return noContent();
		return json({ data: result }, result.reason === "not_found" ? 404 : 409);
	}),
	getRelease: onCore(async (core, _request, params) => {
		const row = await core.getRelease(requireRouteParam(params, "id"));
		return row === null ? notFound() : json({ data: row });
	}),
	updateRelease: onCore(async (core, request, params) => json({ data: await core.updateReleasePolicy({
		...await policyInput(request),
		releaseId: requireRouteParam(params, "id")
	}) })),
	preflightRelease: onCore(async (core, request, params) => json({ data: await core.preflightReleasePolicy({
		...await policyInput(request),
		releaseId: requireRouteParam(params, "id")
	}) })),
	deleteRelease: onCore(async (core, request, params) => {
		const releaseId = requireRouteParam(params, "id");
		const url = new URL(request.url);
		if (url.searchParams.get("confirm") !== releaseId) throw new HandlerBadRequestError("Release hard deletion requires confirm=<release-id>");
		const expectedRevision = revisionOf(url.searchParams.get("expectedRevision"));
		return json({ data: await core.deleteRelease({
			releaseId,
			...expectedRevision === void 0 ? {} : { expectedRevision }
		}) });
	}),
	getReleaseCatalogRow: onCore(async (core, _request, params) => {
		const row = await core.getReleaseCatalogRow(scopeKeyOf(params));
		return row === null ? notFound() : json({ data: row });
	}),
	rebuildReleaseCatalog: onCore(async (core, _request, params) => json({ data: await core.rebuildReleaseCatalog(scopeKeyOf(params)) })),
	updateBundle: onCore(async (core, request, params) => {
		const bundleId = requireRouteParam(params, "id");
		const update = bundleUpdateOf(await request.json(), bundleId);
		await refusingInvalid(() => core.updateBundle(bundleId, update));
		return noContent();
	}),
	countBundles: onCore(async (core, request) => json({ data: await core.countBundles(platformOf(new URL(request.url))) })),
	countBundleChildren: onCore(async (core, request) => {
		const ids = (new URL(request.url).searchParams.get("ids") ?? "").split(",").filter((id) => id.length > 0);
		if (ids.length === 0 || ids.length > 100) throw new HandlerBadRequestError("Bundle child counts take ids=<bundle id>,... with 1 to 100 ids.");
		return json({ data: await core.countBundleChildren(ids) });
	}),
	listBundleChildren: onCore(async (core, request, params) => {
		const input = keyset(new URL(request.url));
		return page(await core.listPatchesFromBase(requireRouteParam(params, "id"), input), input, (row) => row.bundle_id);
	}),
	findBaseCandidates: onCore(async (core, request, params) => {
		const url = new URL(request.url);
		const before = url.searchParams.get("before");
		const limit = Number(url.searchParams.get("limit") ?? "3");
		if (before === null || !Number.isSafeInteger(limit) || limit < 1 || limit > 100) throw new HandlerBadRequestError("Base candidates need before=<bundle id> and a limit between 1 and 100.");
		return json({ data: await core.findBaseBundleIds(decodeMaybe(requireRouteParam(params, "candidateKey")) ?? "", before, limit) });
	}),
	deployReleases: onCore(async (core, request) => {
		const { deployments } = await body(request);
		if (!Array.isArray(deployments) || deployments.length === 0 || !deployments.every(isDeployment)) throw new HandlerBadRequestError("Deploy needs deployments, each a bundle and its release policy.");
		return json({ data: await refusingInvalid(() => core.deploy(deployments)) }, 201);
	}),
	promoteRelease: onCore(async (core, request, params) => {
		const input = await body(request);
		if (typeof input.targetChannel !== "string" || input.action !== void 0 && input.action !== "copy" && input.action !== "move") throw new HandlerBadRequestError("Invalid Release promotion");
		const expectedRevision = revisionOf(input.expectedRevision);
		return json({ data: await core.promoteRelease({
			releaseId: requireRouteParam(params, "id"),
			targetChannel: input.targetChannel,
			...input.action === void 0 ? {} : { action: input.action },
			...expectedRevision === void 0 ? {} : { expectedRevision }
		}) });
	}),
	preflightReleaseCatalogRebuild: onCore(async (core, _request, params) => json({ data: await core.preflightReleaseCatalogRebuild(scopeKeyOf(params)) })),
	registerNativeBuild: onCore(async (core, request) => {
		const input = await body(request);
		if (!isNativeBuildRegistration(input)) throw new HandlerBadRequestError("Invalid native build");
		return json({ data: await refusingInvalid(() => core.registerNativeBuild(input)) }, 201);
	}),
	findNativeBuild: onCore(async (core, request) => {
		const url = new URL(request.url);
		const scope = nativeBuildScopeOf(url);
		const buildKey = url.searchParams.get("buildKey");
		const builtInOlderThan = url.searchParams.get("builtInOlderThan");
		const kind = url.searchParams.get("kind");
		const options = {
			...buildKey === null ? {} : { buildKey },
			...url.searchParams.get("storeBuild") === "true" ? { storeBuild: true } : {},
			...builtInOlderThan === null ? {} : { builtInOlderThan },
			...kind === null ? {} : { artifactKind: kind }
		};
		return json({ data: await refusingInvalid(() => Object.keys(options).length === 0 ? core.findNativeBuild(scope) : core.findNativeBuild(scope, options)) });
	}),
	findNativeBuildSibling: onCore(async (core, _request, params) => {
		const build = await core.getNativeBuild(requireRouteParam(params, "id"));
		return json({ data: build === null ? null : await core.findNativeBuildSibling(build) });
	}),
	getNativeBuild: onCore(async (core, _request, params) => json({ data: await core.getNativeBuild(requireRouteParam(params, "id")) })),
	findNativeBuildByBuiltInBundle: onCore(async (core, _request, params) => json({ data: await core.findNativeBuildByBuiltInBundle(requireRouteParam(params, "bundleId")) })),
	listNativeBuilds: onCore(async (core, request) => {
		const url = new URL(request.url);
		const input = keyset(url);
		const channelId = url.searchParams.get("channelId");
		return page(await core.listNativeBuilds({
			...input,
			...channelId === null ? {} : { channelId }
		}), input, ({ id }) => id);
	}),
	recordNativeBuildSubmission: onCore(async (core, request, params) => {
		const input = await body(request);
		if (!isRecord$1(input) || !Object.values(NATIVE_BUILD_SUBMISSION_DESTINATIONS).flat().includes(input.destination) || !isText(input.version)) throw new HandlerBadRequestError("A native build submission needs a valid store destination and version.");
		const submission = {
			destination: input.destination,
			version: input.version
		};
		return json({ data: await refusingInvalid(() => core.recordNativeBuildSubmission(requireRouteParam(params, "id"), submission)) });
	}),
	markNativeBuild: onCore(async (core, request, params) => {
		const input = await body(request);
		if (!isRecord$1(input) || typeof input.storeBuild !== "boolean") throw new HandlerBadRequestError("A native build's store build mark needs storeBuild, true or false.");
		const mark = { storeBuild: input.storeBuild };
		return json({ data: await refusingInvalid(() => core.markNativeBuild(requireRouteParam(params, "id"), mark)) });
	}),
	deleteNativeBuild: onCore(async (core, _request, params) => json({ data: await core.deleteNativeBuild(requireRouteParam(params, "id")) })),
	listIosDevices: onCore(async (core, request) => {
		const url = new URL(request.url);
		const input = keyset(url);
		const status = url.searchParams.get("status");
		return page(await refusingInvalid(() => core.listIosDevices({
			...input,
			...status === null ? {} : { status }
		})), input, ({ id }) => id);
	}),
	findIosDevice: onCore(async (core, _request, params) => json({ data: await core.findIosDevice(requireRouteParam(params, "udid")) })),
	requestIosDevice: onCore(async (core, request) => {
		const input = await body(request);
		if (!isText(input.udid) || !isText(input.name) || !isTextOrNull(input.requestedBy)) throw new HandlerBadRequestError("An iOS device request needs udid, name, and requestedBy, an email or null.");
		const device = {
			udid: input.udid,
			name: input.name,
			requestedBy: input.requestedBy
		};
		return json({ data: await refusingInvalid(() => core.requestIosDevice(device)) });
	}),
	approveIosDevice: onCore(async (core, request, params) => {
		const input = await body(request);
		if (!isTextOrNull(input.approvedBy) || input.name !== void 0 && !isText(input.name)) throw new HandlerBadRequestError("An iOS device approval needs approvedBy, an email or null, and an optional name.");
		const approval = {
			approvedBy: input.approvedBy,
			...input.name === void 0 ? {} : { name: input.name }
		};
		return json({ data: await refusingInvalid(() => core.approveIosDevice(requireRouteParam(params, "id"), approval)) });
	}),
	renameIosDevice: onCore(async (core, request, params) => {
		const input = await body(request);
		if (!isText(input.name)) throw new HandlerBadRequestError("An iOS device's new name is required.");
		const name = input.name;
		return json({ data: await refusingInvalid(() => core.renameIosDevice(requireRouteParam(params, "id"), name)) });
	}),
	recordIosDeviceOutcome: onCore(async (core, request, params) => {
		const input = await body(request);
		const seen = input.seen;
		if (!isRecord$1(seen) || typeof seen.status !== "string" || !(seen.approvedAtMs === null || Number.isSafeInteger(seen.approvedAtMs)) || !isText(input.issuerId) || typeof input.outcome !== "string" || input.reason !== void 0 && typeof input.reason !== "string") throw new HandlerBadRequestError("An iOS device outcome needs seen { status, approvedAtMs }, issuerId, outcome, and an optional reason.");
		const outcome = {
			id: requireRouteParam(params, "id"),
			seen: {
				status: seen.status,
				approvedAtMs: seen.approvedAtMs
			},
			issuerId: input.issuerId,
			outcome: input.outcome,
			...input.reason === void 0 ? {} : { reason: input.reason }
		};
		return json({ data: await refusingInvalid(() => core.recordIosDeviceOutcome(outcome)) });
	}),
	claimIosDeviceAccount: onCore(async (core, request) => {
		const { issuerId } = await body(request);
		if (!isText(issuerId)) throw new HandlerBadRequestError("Claiming the iOS device account needs issuerId.");
		return json({ data: await refusingInvalid(() => core.claimIosDeviceAccount(issuerId)) });
	}),
	findIosDeviceAccount: onCore(async (core) => json({ data: await core.findIosDeviceAccount() })),
	markIosDevicesInBuild: onCore(async (core, request) => {
		const { buildId, ids } = await body(request);
		if (!isText(buildId) || !Array.isArray(ids) || !ids.every((id) => isText(id))) throw new HandlerBadRequestError("Marking iOS devices in a build needs buildId and ids.");
		await core.markIosDevicesInBuild({
			buildId,
			ids
		});
		return noContent();
	}),
	deleteIosDevice: onCore(async (core, request, params) => {
		const url = new URL(request.url);
		const status = url.searchParams.get("status");
		const requestedBy = url.searchParams.get("requestedBy");
		const only = {
			...status === null ? {} : { status },
			...requestedBy === null ? {} : { requestedBy }
		};
		return json({ data: await refusingInvalid(() => Object.keys(only).length === 0 ? core.deleteIosDevice(requireRouteParam(params, "id")) : core.deleteIosDevice(requireRouteParam(params, "id"), only)) });
	}),
	deleteBundles: onCore(async (core, request) => {
		const { ids } = await body(request);
		if (!Array.isArray(ids) || !ids.every((id) => typeof id === "string" && id.length > 0)) throw new HandlerBadRequestError("Bundle deletion needs ids");
		await core.deleteBundles(ids);
		return noContent();
	})
});
/** The admin mount's routes, by the handler that serves each. */
var ADMIN_ROUTES = [
	{
		method: "POST",
		path: "/releases",
		handler: "deployReleases"
	},
	{
		method: "POST",
		path: "/releases/:id/promote",
		handler: "promoteRelease"
	},
	{
		method: "GET",
		path: "/releases/:id",
		handler: "getRelease"
	},
	{
		method: "GET",
		path: "/releases",
		handler: "listReleases"
	},
	{
		method: "PATCH",
		path: "/releases/:id",
		handler: "updateRelease"
	},
	{
		method: "POST",
		path: "/releases/:id/preflight",
		handler: "preflightRelease"
	},
	{
		method: "DELETE",
		path: "/releases/:id",
		handler: "deleteRelease"
	},
	{
		method: "GET",
		path: "/release-catalogs/:scopeKey",
		handler: "getReleaseCatalogRow"
	},
	{
		method: "GET",
		path: "/release-catalogs",
		handler: "listReleaseCatalogs"
	},
	{
		method: "POST",
		path: "/release-catalogs/:scopeKey/rebuild",
		handler: "rebuildReleaseCatalog"
	},
	{
		method: "POST",
		path: "/release-catalogs/:scopeKey/preflight",
		handler: "preflightReleaseCatalogRebuild"
	},
	{
		method: "GET",
		path: "/channels",
		handler: "getChannels"
	},
	{
		method: "POST",
		path: "/channels",
		handler: "createChannel"
	},
	{
		method: "DELETE",
		path: "/channels/:id",
		handler: "deleteChannel"
	},
	{
		method: "GET",
		path: "/bundles/count",
		handler: "countBundles"
	},
	{
		method: "GET",
		path: "/bundles/child-counts",
		handler: "countBundleChildren"
	},
	{
		method: "GET",
		path: "/bundles/:id",
		handler: "getBundle"
	},
	{
		method: "GET",
		path: "/bundles",
		handler: "listBundles"
	},
	{
		method: "PATCH",
		path: "/bundles/:id",
		handler: "updateBundle"
	},
	{
		method: "POST",
		path: "/bundles/delete",
		handler: "deleteBundles"
	},
	{
		method: "GET",
		path: "/bundles/:id/children",
		handler: "listBundleChildren"
	},
	{
		method: "GET",
		path: "/base-candidates/:candidateKey",
		handler: "findBaseCandidates"
	},
	{
		method: "POST",
		path: "/native-builds",
		handler: "registerNativeBuild"
	},
	{
		method: "GET",
		path: "/native-builds/latest",
		handler: "findNativeBuild"
	},
	{
		method: "GET",
		path: "/native-builds/built-in/:bundleId",
		handler: "findNativeBuildByBuiltInBundle"
	},
	{
		method: "GET",
		path: "/native-builds/:id/sibling",
		handler: "findNativeBuildSibling"
	},
	{
		method: "GET",
		path: "/native-builds/:id",
		handler: "getNativeBuild"
	},
	{
		method: "GET",
		path: "/native-builds",
		handler: "listNativeBuilds"
	},
	{
		method: "POST",
		path: "/native-builds/:id/submission",
		handler: "recordNativeBuildSubmission"
	},
	{
		method: "POST",
		path: "/native-builds/:id/store-build",
		handler: "markNativeBuild"
	},
	{
		method: "DELETE",
		path: "/native-builds/:id",
		handler: "deleteNativeBuild"
	},
	{
		method: "GET",
		path: "/ios-devices",
		handler: "listIosDevices"
	},
	{
		method: "POST",
		path: "/ios-devices",
		handler: "requestIosDevice"
	},
	{
		method: "GET",
		path: "/ios-devices/udid/:udid",
		handler: "findIosDevice"
	},
	{
		method: "POST",
		path: "/ios-devices/in-build",
		handler: "markIosDevicesInBuild"
	},
	{
		method: "GET",
		path: "/ios-devices/account",
		handler: "findIosDeviceAccount"
	},
	{
		method: "POST",
		path: "/ios-devices/account",
		handler: "claimIosDeviceAccount"
	},
	{
		method: "POST",
		path: "/ios-devices/:id/approval",
		handler: "approveIosDevice"
	},
	{
		method: "POST",
		path: "/ios-devices/:id/outcome",
		handler: "recordIosDeviceOutcome"
	},
	{
		method: "PATCH",
		path: "/ios-devices/:id",
		handler: "renameIosDevice"
	},
	{
		method: "DELETE",
		path: "/ios-devices/:id",
		handler: "deleteIosDevice"
	}
];
var CATALOG_CONTENT_TYPE = "application/vnd.hot-updater.release-catalog+json; version=1";
var ARTIFACT_CONTENT_TYPE = "application/vnd.hot-updater.artifact+json; version=1";
var ARTIFACT_V2_CONTENT_TYPE = "application/vnd.hot-updater.artifact+json; version=2";
var ORIGIN_CACHE_TTL_MS = 5e3;
var ORIGIN_CACHE_MAX_ENTRIES = 128;
/** Marks the 404 of a scope that has no catalog. */
var NO_CATALOG_HEADER = "x-hot-updater-catalog";
/** A shared cache keeps a catalog, or a scope's lack of one, five seconds. */
var CATALOG_CACHE_CONTROL = "public, max-age=0, s-maxage=5";
/**
* The same five seconds for a CDN that reads `CDN-Cache-Control` (RFC 9213),
* such as Cloudflare's Workers Cache, which then ignores `Cache-Control`.
* `s-maxage` forbids serving stale, so there an expired catalog held requests
* at that location until the origin answered. Here, for five more seconds,
* the CDN answers with the expired copy while it revalidates in the
* background. `stale-if-error=0` keeps origin errors visible: without it,
* Cloudflare serves a stale copy on error indefinitely.
*
* A device can see a catalog up to 15 seconds after a deploy or a Roll back
* replaced it: the origin's 5-second catalog memo, then 5 seconds fresh and
* 5 stale at the CDN. A revoked API key can read a cached catalog up to
* 10 seconds. Devices and caches that don't read the header keep
* `Cache-Control`.
*/
var CATALOG_CDN_CACHE_CONTROL = "public, max-age=5, stale-while-revalidate=5, stale-if-error=0";
/** The paths of an artifact files request, or null when malformed. */
var readArtifactFilePaths = async (request) => {
	let body;
	try {
		body = await request.json();
	} catch {
		return null;
	}
	const paths = body?.paths;
	if (!Array.isArray(paths) || paths.length === 0 || paths.length > 100 || !paths.every((path) => typeof path === "string" && path.length > 0) || new Set(paths).size !== paths.length) return null;
	return paths;
};
var privateNotFound = () => Response.json({ error: "Not found" }, {
	status: 404,
	headers: { "cache-control": "private, no-store" }
});
var badRequest = (error) => Response.json({ error }, {
	status: 400,
	headers: { "cache-control": "private, no-store" }
});
/**
* A 400 for a catalog path whose scope is malformed, such as a channel name
* where its base64url key belongs; null for a well-formed scope.
*/
var invalidScope = (input) => {
	try {
		createReleaseCatalogScopeKey(input);
		return null;
	} catch (error) {
		return badRequest(error instanceof Error ? error.message : "Invalid Release Catalog scope");
	}
};
/**
* A scope with no catalog yet, such as a store version before its first
* OTA release: cached like a catalog, so its update checks don't all reach
* the origin, and it holds nothing an API key protects. The header tells it
* apart from a 404 for a wrong URL: clients read it as "no update", and
* doctor as a live catalog route.
*/
var missingCatalog = () => Response.json({ error: "Not found" }, {
	status: 404,
	headers: {
		"cache-control": CATALOG_CACHE_CONTROL,
		"cdn-cache-control": CATALOG_CDN_CACHE_CONTROL,
		vary: "Accept-Encoding",
		[NO_CATALOG_HEADER]: "none"
	}
});
var responseHash = async (body) => {
	const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(body));
	return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
};
var catalogResponse = async (catalog, request) => {
	if (catalog === null) return missingCatalog();
	const body = JSON.stringify(catalog);
	const etag = `"sha256:${await responseHash(body)}"`;
	const headers = {
		"cache-control": CATALOG_CACHE_CONTROL,
		"cdn-cache-control": CATALOG_CDN_CACHE_CONTROL,
		"content-type": CATALOG_CONTENT_TYPE,
		etag,
		vary: "Accept-Encoding"
	};
	if (request.headers.get("if-none-match") === etag) return new Response(null, {
		headers,
		status: 304
	});
	return new Response(body, {
		headers,
		status: 200
	});
};
var createReleaseCatalogRouteHandlers = () => {
	const cache = /* @__PURE__ */ new Map();
	const inFlight = /* @__PURE__ */ new Map();
	const loadCatalog = async (key, load) => {
		const cached = cache.get(key);
		if (cached !== void 0 && cached.expiresAt > Date.now()) {
			cache.delete(key);
			cache.set(key, cached);
			return cached.catalog;
		}
		if (cached !== void 0) cache.delete(key);
		const pending = inFlight.get(key);
		if (pending !== void 0) return pending;
		const next = load().then((catalog) => {
			if (catalog !== null) {
				cache.set(key, {
					catalog,
					expiresAt: Date.now() + ORIGIN_CACHE_TTL_MS
				});
				while (cache.size > ORIGIN_CACHE_MAX_ENTRIES) {
					const oldestKey = cache.keys().next().value;
					if (oldestKey === void 0) break;
					cache.delete(oldestKey);
				}
			}
			return catalog;
		});
		inFlight.set(key, next);
		try {
			return await next;
		} finally {
			inFlight.delete(key);
		}
	};
	return {
		appVersionReleaseCatalog: async (params, request, { core }) => {
			const rawAppVersion = requireRouteParam(params, "appVersion");
			const appVersion = canonicalizeAppVersion(rawAppVersion);
			if (appVersion === null || appVersion !== rawAppVersion) return badRequest("Invalid app version");
			const input = {
				appVersion,
				channelKey: requireRouteParam(params, "channelKey"),
				platform: requirePlatformParam(params),
				strategy: "APP_VERSION"
			};
			const invalid = invalidScope(input);
			if (invalid) return invalid;
			return catalogResponse(await loadCatalog(`app-version:${JSON.stringify(input)}`, () => core.getReleaseCatalog(input)), request);
		},
		fingerprintReleaseCatalog: async (params, request, { core }) => {
			const input = {
				channelKey: requireRouteParam(params, "channelKey"),
				fingerprintHash: requireRouteParam(params, "fingerprintHash"),
				platform: requirePlatformParam(params),
				strategy: "FINGERPRINT"
			};
			const invalid = invalidScope(input);
			if (invalid) return invalid;
			return catalogResponse(await loadCatalog(`fingerprint:${JSON.stringify(input)}`, () => core.getReleaseCatalog(input)), request);
		},
		artifactV2: async (params, _request, { core }) => {
			const info = await core.getArtifactInfo(requireRouteParam(params, "targetBundleId"), requireRouteParam(params, "currentBundleId"), 2);
			if (info === null) return privateNotFound();
			return new Response(JSON.stringify(info), {
				status: 200,
				headers: {
					"cache-control": "private, no-store",
					"content-type": ARTIFACT_V2_CONTENT_TYPE
				}
			});
		},
		artifactFilesV2: async (params, request, { core }) => {
			const paths = await readArtifactFilePaths(request);
			if (paths === null) return badRequest(`paths must be 1 to 100 unique strings`);
			const files = await core.getArtifactFiles(requireRouteParam(params, "targetBundleId"), paths);
			if (files === null) return privateNotFound();
			return new Response(JSON.stringify(files), {
				status: 200,
				headers: {
					"cache-control": "private, no-store",
					"content-type": ARTIFACT_V2_CONTENT_TYPE
				}
			});
		},
		artifactV1: async (params, _request, { core }) => {
			const info = await core.getArtifactInfo(requireRouteParam(params, "targetBundleId"), requireRouteParam(params, "currentBundleId"), 1);
			if (info === null) return privateNotFound();
			return new Response(JSON.stringify(info), {
				status: 200,
				headers: {
					"cache-control": "private, no-store",
					"content-type": ARTIFACT_CONTENT_TYPE
				}
			});
		}
	};
};
var normalizePath = (path) => {
	if (!path) return "/";
	if (path === "/") return path;
	const withLeadingSlash = path.startsWith("/") ? path : `/${path}`;
	return withLeadingSlash.endsWith("/") ? withLeadingSlash.slice(0, -1) : withLeadingSlash;
};
var toSegments = (path) => {
	const normalized = normalizePath(path);
	return normalized === "/" ? [] : normalized.slice(1).split("/");
};
function createRouter() {
	return { routes: [] };
}
function addRoute(router, method, path, data) {
	const segments = toSegments(path);
	const paramNames = segments.filter((segment) => segment.startsWith(":")).map((segment) => segment.slice(1));
	router.routes.push({
		data,
		method: method.toUpperCase(),
		paramNames,
		segments
	});
}
function findRoute(router, method, path) {
	const normalizedMethod = method.toUpperCase();
	const pathSegments = toSegments(path);
	for (const route of router.routes) {
		if (route.method !== normalizedMethod) continue;
		if (route.segments.length !== pathSegments.length) continue;
		const params = {};
		let matched = true;
		for (let index = 0; index < route.segments.length; index += 1) {
			const routeSegment = route.segments[index];
			const pathSegment = pathSegments[index];
			if (routeSegment.startsWith(":")) {
				params[routeSegment.slice(1)] = pathSegment;
				continue;
			}
			if (routeSegment !== pathSegment) {
				matched = false;
				break;
			}
		}
		if (matched) return {
			data: route.data,
			params
		};
	}
}
var withPrivateNoStore = (response) => {
	const headers = new Headers(response.headers);
	headers.set("cache-control", "private, no-store");
	return new Response(response.body, {
		headers,
		status: response.status,
		statusText: response.statusText
	});
};
var errorResponse = (error, status) => Response.json({ error }, {
	headers: { "cache-control": "private, no-store" },
	status
});
/** `/version` never passes through the client policy. */
var PUBLIC_CLIENT_ROUTES = /* @__PURE__ */ new Set(["version"]);
var routesOf = Symbol.for("@hot-updater/server/routes");
var withVary = (response, varyHeaders) => {
	const cacheControl = response.headers.get("cache-control") ?? "";
	if (varyHeaders.length === 0 || cacheControl === "" || /private|no-store/u.test(cacheControl)) return response;
	const headers = new Headers(response.headers);
	headers.set("vary", [response.headers.get("vary"), ...varyHeaders].filter(Boolean).join(", "));
	return new Response(response.body, {
		headers,
		status: response.status,
		statusText: response.statusText
	});
};
var createRequestHandler = ({ api, clientPolicy, privateResponses = false, routeHandlers, router }) => async (request) => {
	try {
		const match = findRoute(router, request.method, new URL(request.url).pathname);
		if (!match) return errorResponse("Not found", 404);
		const guarded = clientPolicy !== void 0 && !PUBLIC_CLIENT_ROUTES.has(match.data);
		if (guarded) {
			let authenticated;
			try {
				authenticated = await clientPolicy.authenticate(request);
			} catch {
				return errorResponse("Service unavailable", 503);
			}
			if (!authenticated) return errorResponse("Unauthorized", 401);
		}
		const handler = routeHandlers[match.data];
		if (!handler) return errorResponse("Handler not found", 500);
		const response = await handler(match.params, request, api);
		if (privateResponses) return withPrivateNoStore(response);
		return guarded ? withVary(response, clientPolicy.varyHeaders) : response;
	} catch (error) {
		if (error instanceof HandlerBadRequestError) return errorResponse(error.message, 400);
		if (error instanceof HotUpdaterSchemaMigrationRequiredError) {
			console.error(error.message);
			return errorResponse("Service unavailable", 503);
		}
		console.error("Hot Updater handler error:", error);
		return Response.json({ error: "Internal server error" }, {
			headers: { "cache-control": "private, no-store" },
			status: 500
		});
	}
};
function createHotUpdaterHandlers({ api, clientPolicy, endpoints = [], plugins = [] }) {
	const routeHandlers = {
		...createVersionRouteHandlers(plugins),
		...createReleaseCatalogRouteHandlers(),
		...createAdminRouteHandlers()
	};
	const routes = [];
	const shapes = /* @__PURE__ */ new Map();
	const mount = (router, admin) => (method, path, handler) => {
		const shape = `${admin ? "admin" : "client"} ${method} ${path.replaceAll(/:[^/]+/gu, ":")}`;
		const taken = shapes.get(shape);
		if (taken !== void 0) throw new HotUpdaterConfigError(`${handler} (${method} ${path}) collides with ${taken} on handlers.${admin ? "admin" : "client"}.`);
		shapes.set(shape, handler);
		addRoute(router, method, path, handler);
		routes.push({
			method,
			path,
			access: admin ? "admin" : PUBLIC_CLIENT_ROUTES.has(handler) ? "public" : "client"
		});
	};
	const clientRouter = createRouter();
	const addClientRoute = mount(clientRouter, false);
	addClientRoute("GET", "/version", "version");
	addClientRoute("GET", "/release-catalogs/app-version/:platform/:channelKey/:appVersion", "appVersionReleaseCatalog");
	addClientRoute("GET", "/release-catalogs/fingerprint/:platform/:channelKey/:fingerprintHash", "fingerprintReleaseCatalog");
	addClientRoute("GET", "/artifacts/v1/:targetBundleId/from/:currentBundleId", "artifactV1");
	addClientRoute("GET", "/artifacts/v2/:targetBundleId/from/:currentBundleId", "artifactV2");
	addClientRoute("POST", "/artifacts/v2/:targetBundleId/files", "artifactFilesV2");
	const adminRouter = createRouter();
	const addAdminRoute = mount(adminRouter, true);
	addAdminRoute("GET", "/version", "adminVersion");
	for (const route of ADMIN_ROUTES) addAdminRoute(route.method, route.path, route.handler);
	for (const endpoint of endpoints) {
		const name = `plugin ${endpoint.plugin}: ${endpoint.method} ${endpoint.path}`;
		routeHandlers[name] = (params, request) => endpoint.handler(request, params);
		(endpoint.access === "admin" ? addAdminRoute : addClientRoute)(endpoint.method, endpoint.path, name);
	}
	const handlers = {
		client: createRequestHandler({
			api,
			...clientPolicy === void 0 ? {} : { clientPolicy },
			routeHandlers,
			router: clientRouter
		}),
		admin: createRequestHandler({
			api,
			privateResponses: true,
			routeHandlers,
			router: adminRouter
		})
	};
	Object.defineProperty(handlers, routesOf, { value: Object.freeze(routes) });
	return Object.freeze(handlers);
}
/** A URL devices download from, which only an absolute HTTP(S) URL can be. */
var assertRemoteUrl = (value) => {
	let protocol;
	try {
		protocol = new URL(value).protocol;
	} catch {}
	if (protocol !== "http:" && protocol !== "https:") throw new Error("Storage getDownloadUrl must resolve to an absolute HTTP(S) URL.");
	return value;
};
var getStorageProtocol = (storageUri) => new URL(storageUri).protocol.replace(":", "");
var isRemoteUrlProtocol = (protocol) => protocol === "http" || protocol === "https";
/**
* Reads and download URLs over the server's storage, for the URIs of its
* protocol; an HTTP(S) URI is used as it is.
*/
var createStorageAccess = (storageAdapter) => {
	const findStorage = (protocol) => storageAdapter.protocol === protocol ? storageAdapter : void 0;
	const readStorageResponse = async (storageUri) => {
		const protocol = getStorageProtocol(storageUri);
		const storage = findStorage(protocol);
		if (storage) {
			if (!storage.get) return null;
			return (await storage.get({ storageUri })).response;
		}
		if (isRemoteUrlProtocol(protocol)) {
			const response = await fetch(storageUri);
			return response.ok ? response : null;
		}
		throw new Error(`No storage adapter for protocol: ${protocol}`);
	};
	const resolveFileUrl = async (storageUri) => {
		if (!storageUri) return null;
		const protocol = getStorageProtocol(storageUri);
		const storage = findStorage(protocol);
		if (!storage) {
			if (isRemoteUrlProtocol(protocol)) return storageUri;
			throw new Error(`No storage adapter for protocol: ${protocol}`);
		}
		if (!storage.getDownloadUrl) return null;
		const { url: downloadUrl } = await storage.getDownloadUrl({ storageUri });
		return assertRemoteUrl(downloadUrl);
	};
	const readStorageText = async (storageUri) => {
		return (await readStorageResponse(storageUri))?.text() ?? null;
	};
	return {
		readStorageText,
		resolveFileUrl
	};
};
var isRecord = (value) => typeof value === "object" && value !== null;
var isAdapter = (value) => isRecord(value) && [
	"fits",
	"get",
	"query",
	"write"
].every((method) => typeof value[method] === "function");
/** The configured database, when it runs on the storage engine. */
var databaseOf = (value) => {
	if (isRecord(value) && typeof value.name === "string") {
		if (isAdapter(value.adapter)) return value;
		if ("core" in value && "fetchAdmin" in value) throw new HotUpdaterConfigError("standaloneRepository reaches a server's admin API from the CLI and console. createHotUpdater needs the server's own database, such as kyselyAdapter(...).");
	}
	throw new HotUpdaterConfigError("database must be a Hot Updater database adapter, such as kyselyAdapter(...) or postgres(...).");
};
/** The configured storage, when it is a storage adapter. */
var storageOf = (value) => {
	if (isRecord(value) && typeof value.name === "string" && typeof value.protocol === "string") return value;
	throw new HotUpdaterConfigError("storage must be a storage adapter, such as s3Storage(...): the one hot-updater.config.ts uploads with.");
};
/** `"public"`, or nothing. */
var isPublic = (value) => {
	if (value === void 0) return false;
	if (value === "public") return true;
	throw new HotUpdaterConfigError("clientAccess must be \"public\"; to protect client routes, add a plugin that provides clientAuth to plugins.");
};
function createHotUpdater(options) {
	const database = databaseOf(options.database);
	const storage = storageOf(options.storage);
	const { readStorageText, resolveFileUrl } = createStorageAccess(storage);
	const publicClients = isPublic(options.clientAccess);
	const configured = Object.freeze([...options.plugins ?? []]);
	const plugins = assemblePlugins(configured, database, { storage: {
		readStorageText,
		resolveFileUrl
	} });
	const clientPlugins = Object.freeze(clientPluginsOf(configured));
	const clientAuth = plugins.clientAuth;
	if (clientAuth !== void 0 && publicClients) throw new HotUpdaterConfigError(`Plugin "${clientAuth.plugin}" provides clientAuth, so remove clientAccess.`);
	if (clientAuth === void 0 && !publicClients) throw new HotUpdaterConfigError("Set clientAccess to \"public\", or add a plugin that provides clientAuth.");
	const varyHeaders = Object.freeze((clientAuth?.varyHeaders ?? []).map((header) => header.toLowerCase()));
	const clientPolicy = clientAuth === void 0 ? void 0 : {
		varyHeaders,
		authenticate: (request) => clientAuth.authenticate(request.headers)
	};
	const handlers = createHotUpdaterHandlers({
		api: { core: plugins.core },
		...clientPolicy === void 0 ? {} : { clientPolicy },
		endpoints: plugins.endpoints,
		plugins: Object.keys(plugins.api)
	});
	let serving = false;
	return {
		adapterName: database.name,
		get handlers() {
			if (!serving) {
				assertStorageOperations(storage, ["get", "getDownloadUrl"]);
				serving = true;
			}
			return handlers;
		},
		core: plugins.core,
		api: plugins.api,
		flush: plugins.flush,
		database,
		storage,
		plugins: configured,
		clientPlugins,
		clientEndpoints: Object.freeze(plugins.endpoints.filter((endpoint) => endpoint.access === "client").map(({ plugin, method, path }) => Object.freeze({
			plugin,
			method,
			path
		}))),
		...clientAuth === void 0 ? {} : { clientAuth: Object.freeze({
			plugin: clientAuth.plugin,
			varyHeaders
		}) }
	};
}
/**
* Core and the plugins over `database`, assembled by `createHotUpdater` as
* the server assembles them, with public client routes unless a plugin
* provides clientAuth: the console mounts no handlers. cli-tools'
* `assembleServer` does the same for the CLI; the console keeps its own
* copy, since a hosted console never loads cli-tools.
*/
var assemble = (database, storage, plugins) => createHotUpdater({
	database,
	storage,
	plugins,
	...plugins.some((plugin) => plugin.provides?.clientAuth) ? {} : { clientAccess: "public" }
});
var getConsoleAuthAdapter = async () => {
	return (await import("./auth-Z-wLddzh.mjs")).default;
};
var resolveConsoleConfig = async (request) => {
	const { default: source } = await import("./config-CjIBFhJX.mjs");
	const config = typeof source === "function" ? await source(request) : source;
	const { database, storage, plugins = [] } = config;
	const { gitUrl, deviceApprovers = [] } = config.console ?? {};
	const consoleOptions = {
		...gitUrl === void 0 ? {} : { gitUrl },
		deviceApprovers: deviceApprovers.map((email) => email.trim().toLowerCase()).filter((email) => email.length > 0)
	};
	if (isRemoteDatabase(database)) {
		const checked = assemble({
			name: "memory",
			adapter: createMemoryAdapter()
		}, storage, plugins);
		return {
			...consoleOptions,
			database,
			core: database.core,
			storage,
			plugins: checked.plugins
		};
	}
	const server = assemble(database, storage, plugins);
	return {
		...consoleOptions,
		database,
		core: server.core,
		storage,
		plugins: server.plugins,
		api: server.api
	};
};
var accessError = (access) => new Response(access.status === "unauthenticated" ? "Unauthorized" : "Forbidden", { status: access.status === "unauthenticated" ? 401 : 403 });
var accessByRequest = /* @__PURE__ */ new WeakMap();
var getConsoleAccess = (request) => {
	let access = accessByRequest.get(request);
	if (!access) {
		access = getConsoleAuthAdapter().then((adapter) => adapter.getAccess(request));
		accessByRequest.set(request, access);
	}
	return access;
};
var getConsoleAuthProviders = async (request) => {
	return (await getConsoleAuthAdapter()).getProviders(request);
};
var handleConsoleAuth = async (request) => {
	return (await getConsoleAuthAdapter()).handle(request);
};
var requireConsoleAccess = async (request) => {
	const access = await getConsoleAccess(request);
	if (access.status !== "authorized") throw accessError(access);
	return access.principal;
};
//#endregion
export { getConsoleAccess, getConsoleAuthProviders, handleConsoleAuth, requireConsoleAccess, resolveConsoleConfig as t };
