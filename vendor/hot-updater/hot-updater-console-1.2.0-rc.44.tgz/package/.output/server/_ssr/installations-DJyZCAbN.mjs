import { i as __toESM } from "../_runtime.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { X as ChevronDown, Z as Check, _ as RefreshCw, at as ArrowLeft, m as Search, nt as ArrowUpRight, t as X } from "../_libs/lucide-react.mjs";
import { C as Skeleton, O as buttonVariants, k as cn, r as Separator$1, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as CardHeader, n as CardContent, o as CardTitle, r as CardDescription, t as Card } from "./card-CsUxqR3-.mjs";
import { a as FieldLabel, t as Field } from "./field-BVbdqLG6.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-4qgdiham.mjs";
import { c as useElementScrollRestoration, h as Link, o as useLocation } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useInsightsEventsQuery, c as useInsightsInstallationsQuery, l as useInsightsRetention, n as formatDays, o as useInsightsInstallationEventsQuery, s as useInsightsInstallationQuery, t as DEFAULT_INSIGHTS_RETENTION } from "./insights-api-DGzoZoEY.mjs";
import { i as InputGroupInput, n as InputGroupAddon, r as InputGroupButton, t as InputGroup } from "./input-group-DpNq5b5O.mjs";
import { a as PeriodSelector, n as InsightsErrorAlert, r as InsightsPageHeader, s as isBuiltinBundle, t as BuiltinBundleBadge } from "./InsightsPageHeader-DdY_p5TY.mjs";
import { n as shortenIdentifier, t as HashValueDisplay } from "./HashValueDisplay-BAS89lvP.mjs";
import { a as HttpResponseDetails, n as EventTimestamp, o as useInsightsTimeFormat, r as EventTypeDetails, t as EventBundleTransition } from "./EventDetails-DNlQeQSr.mjs";
import { a as installationsScrollRestorationKey, i as eventRanges, n as Route, o as widerEventRange, r as eventRangeBounds, t as EVENT_RANGES } from "./installations-BlpvXBld.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/installations-DJyZCAbN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EventHistoryList({ events, formatter, renderIdentity }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 pb-2 text-xs text-muted-foreground sm:px-6",
		children: "Time in your browser zone"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		"aria-label": "Events",
		className: "divide-y border-y",
		children: events.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex min-w-0 flex-col gap-3 px-4 py-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-x-4 gap-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTypeDetails, { event }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs tabular-nums",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTimestamp, {
							value: event.receivedAtMs,
							formatter,
							touch: true
						})
					})]
				}),
				renderIdentity?.(event),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "flex flex-wrap gap-x-2 gap-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "sr-only",
						children: "App"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [
						event.platform === "ios" ? "iOS" : "Android",
						" ",
						event.appVersion
					] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "sr-only",
							children: "Channel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "wrap-anywhere",
							children: event.channel
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs",
					"aria-label": "Bundle",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventBundleTransition, {
						event,
						touch: true
					})
				})
			]
		}, event.id))
	})] });
}
function InsightsPagination({ hasPrevious, label, nextCursor, onNext, onPrevious, pageLength, pageNumber }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": `${label} pagination`,
		className: "flex flex-wrap items-center justify-between gap-3 border-t px-4 py-3 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted-foreground tabular-nums",
			children: [
				"Page ",
				pageNumber,
				" · ",
				pageLength.toLocaleString(),
				" rows"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
				className: "h-11 min-w-11 px-3 lg:h-8 lg:min-w-0 lg:px-2",
				disabled: !hasPrevious,
				onClick: onPrevious,
				size: "sm",
				type: "button",
				variant: "outline",
				children: "Previous"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
				className: "h-11 min-w-11 px-3 lg:h-8 lg:min-w-0 lg:px-2",
				disabled: nextCursor === null,
				onClick: onNext,
				size: "sm",
				type: "button",
				variant: "outline",
				children: "Next"
			})]
		})]
	});
}
/** The ranges within the days raw events are kept, the shortest always. */
var rangesWithin = (days) => EVENT_RANGES.filter((value, position) => position === 0 || eventRanges[value].durationMs <= days * 864e5);
function EventIdentity({ event, eventsLocation, touch = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: touch ? "flex min-w-0 flex-wrap items-center justify-between gap-2" : "flex min-w-0 flex-col items-start gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			className: buttonVariants({
				className: touch ? "-ml-2 h-auto min-h-11 min-w-0 flex-1 justify-start gap-2 whitespace-normal text-sm" : "-ml-2 max-w-full justify-start",
				size: "sm",
				variant: "ghost"
			}),
			to: "/installations",
			search: {
				...eventsLocation,
				query: event.installId || void 0,
				installId: event.installId
			},
			state: (previous) => ({ insightsPagination: { eventsBack: previous.insightsPagination?.eventsBack } }),
			"aria-label": `View history for ${event.userId ?? "anonymous installation"} (${event.installId})`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: touch ? "min-w-0 text-left wrap-anywhere" : "truncate",
				children: event.userId ?? "Anonymous installation"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
				"aria-hidden": "true",
				"data-icon": "inline-end"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
			value: event.installId,
			maxLength: 13,
			buttonClassName: touch ? "min-h-11 px-3" : void 0
		})]
	});
}
function EventHistoryCard({ children, description, error, eventsLocation, history, isFetching, isLoading, onNext, onPrevious, onRangeChange, onRefresh, pageNumber, range, rawDays = 90, title = "All events" }) {
	const dateTimeFormat = useInsightsTimeFormat();
	const hasPrevious = pageNumber > 1;
	const ranges = rangesWithin(rawDays);
	const next = range === void 0 ? void 0 : widerEventRange(range);
	const wider = next !== void 0 && ranges.includes(next) ? next : void 0;
	const widen = wider !== void 0 && onRangeChange ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
		className: "h-11 px-3 lg:h-8",
		onClick: () => onRangeChange(wider),
		type: "button",
		variant: "outline",
		children: `Show the last ${eventRanges[wider].period}`
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "@container min-w-0 shadow-sm",
		"aria-busy": isFetching,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
			className: "gap-4 p-4 sm:p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: title }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [range !== void 0 && onRangeChange ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PeriodSelector, {
							label: "Time range",
							onPeriodChange: onRangeChange,
							period: range,
							periods: ranges.map((value) => ({
								value,
								name: `Last ${eventRanges[value].period}`
							}))
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							className: "h-11 lg:h-8",
							disabled: isFetching,
							onClick: onRefresh,
							size: "lg",
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
								"aria-hidden": "true",
								"data-icon": "inline-start"
							}), "Refresh"]
						})]
					})]
				}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: description }) : null]
			}), children]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "min-w-0 p-0",
			children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 p-6",
				role: "status",
				"aria-label": "Loading events",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" })
				]
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-6 pb-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
					error,
					fallbackTitle: "Event history unavailable"
				})
			}) : history ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				history.data.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "@[58rem]:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventHistoryList, {
						events: history.data,
						formatter: dateTimeFormat,
						renderIdentity: (event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventIdentity, {
							event,
							eventsLocation,
							touch: true
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden @[58rem]:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						className: "min-w-4xl table-fixed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "[&>th]:px-4 sm:[&>th]:px-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-64",
									children: "Time"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-48",
									children: "Event"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-48",
									children: "User / installation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-32",
									children: "App"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-52",
									children: "Bundle"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: history.data.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "[&>td]:px-4 [&>td]:py-4 [&>td]:align-top sm:[&>td]:px-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "whitespace-normal text-xs tabular-nums",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTimestamp, {
										value: event.receivedAtMs,
										formatter: dateTimeFormat
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTypeDetails, { event }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventIdentity, {
									event,
									eventsLocation
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "whitespace-normal text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											event.platform === "ios" ? "iOS" : "Android",
											" ",
											event.appVersion
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: event.channel
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "whitespace-normal text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventBundleTransition, { event })
								})
							]
						}, event.id)) })]
					})
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 px-4 pb-4 sm:px-6 sm:pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: hasPrevious ? "No older events in this range." : range !== void 0 ? `No events in the last ${eventRanges[range].period}.` : title === "All events" ? "No events recorded yet" : "No matching reports in this period"
					}), hasPrevious ? null : widen]
				}),
				range !== void 0 && history.nextCursor === null && (history.data.length > 0 || hasPrevious) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 border-t px-4 py-3 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Start of range reached"
					}), widen]
				}) : null,
				history.data.length > 0 || hasPrevious || history.nextCursor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsPagination, {
					hasPrevious,
					label: title,
					nextCursor: history.nextCursor,
					onNext,
					onPrevious,
					pageLength: history.data.length,
					pageNumber
				}) : null
			] }) : null
		})]
	});
}
var getUserLabel$1 = (event) => event.userId ?? "—";
/** A download or a failed update leaves the installation on the bundle it ran. */
var getLastKnownBundleId$1 = (event) => "lastKnownBundleId" in event ? event.lastKnownBundleId : event.type === "UPDATE_DOWNLOADED" || event.type === "UPDATE_FAILED" ? event.fromBundleId : event.toBundleId;
function InstallationHistoryCard({ error, history, isLoading, onNext, onPrevious, onRefresh, pageNumber, retention = DEFAULT_INSIGHTS_RETENTION, selectedEvent, selectedInstallId }) {
	const dateTimeFormat = useInsightsTimeFormat();
	const lastKnownBundleId = selectedEvent ? getLastKnownBundleId$1(selectedEvent) : void 0;
	const pendingBundleId = selectedEvent && "pendingBundleId" in selectedEvent ? selectedEvent.pendingBundleId : selectedEvent && "type" in selectedEvent && selectedEvent.type === "UPDATE_DOWNLOADED" ? selectedEvent.toBundleId : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "@container min-h-0 min-w-0 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
			className: "p-4 sm:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-col gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-sm font-medium",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: selectedInstallId !== void 0 ? "Installation history" : "Select an installation" })
					}), selectedInstallId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDescription, { children: [
						"Bundle changes and update failures are kept for",
						" ",
						formatDays(retention.rawDays),
						"; the latest report, for",
						" ",
						formatDays(retention.dailyDays),
						" after the installation last reports."
					] }) : null]
				}), onRefresh && selectedInstallId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					className: "h-11 lg:h-8",
					size: "lg",
					variant: "outline",
					onClick: onRefresh,
					disabled: isLoading,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						"aria-hidden": "true",
						"data-icon": "inline-start"
					}), "Refresh"]
				}) : null]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "min-h-0 p-0",
			children: [selectedInstallId !== void 0 && selectedEvent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "latest-installation-state",
				className: "px-4 pb-4 sm:px-6 sm:pb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "sr-only",
						id: "latest-installation-state",
						children: "Latest reported state"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid grid-cols-2 gap-4 @[36rem]:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-2 min-w-0 @[36rem]:col-span-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "User ID"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm font-medium wrap-anywhere",
									children: getUserLabel$1(selectedEvent)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Install ID"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-mono text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
										value: selectedInstallId,
										buttonClassName: "min-h-11 px-3 lg:min-h-0 lg:px-1.5"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Last known bundle"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "mt-1 flex min-w-0 flex-wrap items-center gap-2 font-mono text-xs",
									children: [lastKnownBundleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
										value: lastKnownBundleId,
										buttonClassName: "min-h-11 px-3 lg:min-h-0 lg:px-1.5"
									}) : "—", isBuiltinBundle(lastKnownBundleId, selectedEvent.minBundleId) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuiltinBundleBadge, {}) : null]
								})]
							}),
							pendingBundleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-2 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Downloaded · Not launched yet"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, { value: pendingBundleId })
								})]
							}) : null
						]
					}),
					selectedEvent.httpResponse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HttpResponseDetails, { event: selectedEvent })
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator$1, {})] }) : null, selectedInstallId !== void 0 ? isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 p-6",
				role: "status",
				"aria-label": "Loading installation history",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })
				]
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
					error: error instanceof Error ? error : /* @__PURE__ */ new Error(),
					fallbackTitle: "Installation history unavailable"
				})
			}) : history && history.data.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "@[48rem]:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventHistoryList, {
						events: history.data,
						formatter: dateTimeFormat
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden @[48rem]:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						className: "min-w-3xl table-fixed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "[&>th]:px-4 sm:[&>th]:px-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-64",
									children: "Time"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-48",
									children: "Event"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-32",
									children: "App"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "w-52",
									children: "Bundle"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: history.data.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "[&>td]:px-4 [&>td]:py-4 [&>td]:align-top sm:[&>td]:px-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "whitespace-normal text-xs tabular-nums",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTimestamp, {
										value: event.receivedAtMs,
										formatter: dateTimeFormat
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTypeDetails, { event }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "whitespace-normal text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											event.platform === "ios" ? "iOS" : "Android",
											" ",
											event.appVersion
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: event.channel
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "whitespace-normal text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventBundleTransition, { event })
								})
							]
						}, event.id)) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsPagination, {
					hasPrevious: pageNumber > 1,
					label: "Installation history",
					nextCursor: history.nextCursor,
					onNext,
					onPrevious,
					pageLength: history.data.length,
					pageNumber
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-6 text-sm text-muted-foreground",
				children: pageNumber > 1 ? "No older bundle changes." : "No bundle changes recorded yet."
			}), history && (pageNumber > 1 || history.nextCursor) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsPagination, {
				hasPrevious: pageNumber > 1,
				label: "Installation history",
				nextCursor: history.nextCursor,
				onNext,
				onPrevious,
				pageLength: 0,
				pageNumber
			}) : null] }) : null]
		})]
	});
}
var getLastKnownBundleId = (event) => event.lastKnownBundleId;
var getUserLabel = (event) => event.userId ?? "—";
function InstallationMatchesCard({ error, onNext, onPrevious, onSelect, pageNumber, results, selectedInstallId }) {
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	const contentId = (0, import_react.useId)();
	const triggerRef = (0, import_react.useRef)(null);
	const canCollapse = !error && results && results.data.length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "min-h-0 min-w-0 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
			className: "p-4 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-w-0 flex-col gap-1.5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-sm font-medium",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Matching installations" })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex shrink-0 items-center gap-2",
					children: canCollapse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
						"aria-controls": contentId,
						"aria-expanded": expanded,
						"aria-label": expanded ? "Hide matching installations" : "Show matching installations",
						className: "size-11 lg:hidden",
						onClick: () => setExpanded(!expanded),
						ref: triggerRef,
						size: "icon-lg",
						variant: "ghost",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
							"aria-hidden": "true",
							className: cn(expanded && "rotate-180")
						})
					}) : null
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: cn("min-h-0 p-0", canCollapse && !expanded && "hidden lg:block"),
			id: contentId,
			children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsErrorAlert, {
					error: error instanceof Error ? error : /* @__PURE__ */ new Error(),
					fallbackTitle: "Installation search unavailable"
				})
			}) : results && results.data.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				"aria-label": "Matching installations",
				className: "divide-y",
				children: results.data.map((event) => {
					const currentBundleId = getLastKnownBundleId(event);
					const isSelected = event.installId === selectedInstallId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						"aria-label": `${getUserLabel(event)}, install ID ${event.installId}`,
						"aria-pressed": isSelected,
						className: "group flex w-full min-w-0 flex-col gap-2 border-l-2 border-transparent px-4 py-4 text-left outline-none transition-colors hover:bg-muted/40 focus-visible:border-ring focus-visible:bg-muted/40 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring/30 aria-pressed:border-primary aria-pressed:bg-muted/60 motion-reduce:transition-none sm:px-6",
						onClick: () => {
							onSelect(event.installId);
							setExpanded(false);
							triggerRef.current?.focus();
						},
						type: "button",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex w-full min-w-0 items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 truncate text-sm font-medium",
									children: getUserLabel(event)
								}), isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex shrink-0 items-center gap-1 text-xs font-medium text-primary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										"aria-hidden": "true",
										className: "size-3.5"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Selected"
									})]
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex flex-wrap items-center gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs",
									title: event.installId,
									children: shortenIdentifier(event.installId)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex min-w-0 flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: "Bundle"
								}), currentBundleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs",
									title: currentBundleId,
									children: shortenIdentifier(currentBundleId)
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: "—"
								})]
							})
						]
					}) }, event.installId);
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 p-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No matches"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: buttonVariants({
						variant: "outline",
						className: "h-11 px-3 lg:h-8"
					}),
					href: "#installation-history-search",
					children: "Edit search"
				})]
			}), results && (results.data.length > 0 || pageNumber > 1 || results.nextCursor) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsPagination, {
				hasPrevious: pageNumber > 1,
				label: "Installation results",
				nextCursor: results.nextCursor,
				onNext,
				onPrevious,
				pageLength: results.data.length,
				pageNumber
			}) : null]
		})]
	});
}
function InstallationSearchPanel({ draftQuery, onDraftQueryChange, onSubmit, onClear }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
		"aria-label": "Find installation",
		onSubmit: (event) => {
			event.preventDefault();
			if (draftQuery.trim()) onSubmit();
		},
		role: "search",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
			className: "gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				className: "sr-only",
				htmlFor: "installation-history-search",
				children: "User ID or installation ID"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputGroup, {
					className: "h-11 w-auto min-w-0 flex-1 basis-44 lg:h-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { "aria-hidden": "true" }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupInput, {
							autoComplete: "off",
							className: "h-11 text-base md:text-base lg:h-8 lg:text-xs",
							id: "installation-history-search",
							maxLength: 1024,
							name: "installation",
							onChange: (event) => onDraftQueryChange(event.target.value),
							placeholder: "User ID or installation ID",
							spellCheck: false,
							type: "search",
							value: draftQuery
						}),
						draftQuery.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, {
							align: "inline-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupButton, {
								"aria-label": "Clear installation lookup",
								className: "size-11 lg:size-5",
								onClick: onClear,
								size: "icon-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "aria-hidden": "true" })
							})
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
					"aria-label": "Find installation",
					className: "h-11 px-3 lg:h-8",
					disabled: draftQuery.trim().length === 0,
					size: "lg",
					type: "submit",
					variant: "outline",
					children: "Find"
				})]
			})]
		})
	});
}
function InstallationResultsSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-stretch gap-6 lg:min-h-96 lg:grid-cols-[minmax(18rem,20rem)_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full lg:h-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full lg:h-full" })]
	});
}
var SEARCH_LIMIT = 20;
var EVENT_LIMIT = 50;
var freshBefore = () => Date.now();
var pushCursor = (stack, cursor) => [...stack, cursor ?? ""];
var popCursor = (stack) => ({
	cursor: stack?.at(-1) || void 0,
	stack: stack.slice(0, -1)
});
function InstallationsPage() {
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	const retention = useInsightsRetention();
	const [draftQuery, setDraftQuery] = (0, import_react.useState)(search.query ?? "");
	const [initialEventsBefore] = (0, import_react.useState)(freshBefore);
	const [initialHistoryBefore] = (0, import_react.useState)(freshBefore);
	const pagination = useLocation({ select: (location) => location.state.insightsPagination });
	const eventsBack = pagination?.eventsBack ?? [];
	const searchBack = pagination?.searchBack ?? [];
	const historyBack = pagination?.historyBack ?? [];
	const query = search.query?.trim() ?? "";
	const hasSearchQuery = query.length > 0;
	const hasSelection = search.installId !== void 0;
	const hasLookup = hasSearchQuery || hasSelection;
	const eventsBefore = search.eventsBefore ?? initialEventsBefore;
	const eventsRange = search.eventsRange ?? "7d";
	const historyBefore = search.historyBefore ?? initialHistoryBefore;
	const updateSearch = (next, replace = false, nextPagination = {}) => {
		navigate({
			to: "/installations",
			search: {
				...search,
				...next
			},
			state: (previous) => ({
				...previous,
				insightsPagination: {
					...previous.insightsPagination,
					...nextPagination
				}
			}),
			replace
		});
	};
	(0, import_react.useEffect)(() => {
		setDraftQuery(search.query ?? "");
	}, [search.query]);
	(0, import_react.useEffect)(() => {
		if (search.eventsBefore === void 0) updateSearch({ eventsBefore }, true);
	}, [eventsBefore, search.eventsBefore]);
	(0, import_react.useEffect)(() => {
		if (hasSelection && search.historyBefore === void 0) updateSearch({ historyBefore }, true);
	}, [
		hasSelection,
		historyBefore,
		search.historyBefore
	]);
	const events = useInsightsEventsQuery({
		...eventRangeBounds(eventsRange, eventsBefore),
		cursor: search.eventsCursor,
		limit: 20
	}, !hasLookup);
	const matches = useInsightsInstallationsQuery({
		cursor: search.searchCursor,
		identity: query,
		limit: SEARCH_LIMIT
	}, hasSearchQuery);
	(0, import_react.useEffect)(() => {
		const firstInstallId = matches.data?.data[0]?.installId;
		if (!hasSearchQuery || hasSelection || firstInstallId === void 0) return;
		updateSearch({
			historyBefore: freshBefore(),
			historyCursor: void 0,
			installId: firstInstallId
		}, true, { historyBack: [] });
	}, [
		hasSearchQuery,
		hasSelection,
		matches.data?.data
	]);
	const selectedInstallation = useInsightsInstallationQuery(search.installId ?? "", hasSelection);
	const history = useInsightsInstallationEventsQuery({
		beforeReceivedAtMs: historyBefore,
		cursor: search.historyCursor,
		installId: search.installId ?? "",
		limit: EVENT_LIMIT
	}, hasSelection);
	const selectedEvent = selectedInstallation.data ?? matches.data?.data.find(({ installId }) => installId === search.installId) ?? history.data?.data[0];
	const scrollRestorationId = hasLookup ? `installation-history-${search.historyCursor ?? "first"}` : `all-events-${search.eventsCursor ?? "first"}`;
	const scrollRef = (0, import_react.useRef)(null);
	const scrollEntry = useElementScrollRestoration({
		id: scrollRestorationId,
		getKey: installationsScrollRestorationKey
	});
	(0, import_react.useLayoutEffect)(() => {
		if (!hasLookup && !events.isLoading && scrollRef.current) scrollRef.current.scrollTop = scrollEntry?.scrollY ?? 0;
	}, [
		events.isLoading,
		hasLookup,
		scrollEntry?.scrollY,
		scrollRestorationId
	]);
	const clearLookup = () => {
		setDraftQuery("");
		updateSearch({
			historyBefore: void 0,
			historyCursor: void 0,
			installId: void 0,
			query: void 0,
			searchCursor: void 0
		}, false, {
			historyBack: [],
			searchBack: []
		});
	};
	const installationLookup = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallationSearchPanel, {
		draftQuery,
		onClear: clearLookup,
		onDraftQueryChange: setDraftQuery,
		onSubmit: () => {
			const nextQuery = draftQuery.trim();
			if (!nextQuery) {
				clearLookup();
				return;
			}
			updateSearch({
				historyBefore: void 0,
				historyCursor: void 0,
				installId: void 0,
				query: nextQuery,
				searchCursor: void 0
			}, false, {
				historyBack: [],
				searchBack: []
			});
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsPageHeader, { view: "events" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scrollRef,
			"data-scroll-restoration-id": scrollRestorationId,
			id: "insights-events-scroll",
			className: "min-h-0 min-w-0 flex-1 overflow-y-auto bg-muted/5 p-3 sm:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-7xl flex-col gap-4 sm:gap-6",
				children: [hasLookup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "shadow-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "flex flex-col gap-3 p-4 sm:p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							className: "-ml-2 h-11 self-start lg:h-8",
							onClick: clearLookup,
							variant: "ghost",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
								"aria-hidden": "true",
								"data-icon": "inline-start"
							}), "Back to all events"]
						}), installationLookup]
					})
				}) : null, !hasLookup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventHistoryCard, {
					description: `Downloads, launches, crashes, update failures, and other changes to what an installation runs, newest first, kept for ${formatDays(retention.rawDays)}. Launches that change nothing aren't listed.`,
					error: events.error,
					eventsLocation: {
						eventsBefore,
						eventsCursor: search.eventsCursor,
						eventsRange: search.eventsRange
					},
					history: events.data,
					isFetching: events.isFetching,
					isLoading: events.isLoading,
					onNext: () => {
						if (!events.data?.nextCursor) return;
						updateSearch({ eventsCursor: events.data.nextCursor }, true, { eventsBack: pushCursor(eventsBack, search.eventsCursor) });
					},
					onPrevious: () => {
						const previous = popCursor(eventsBack);
						updateSearch({ eventsCursor: previous.cursor }, true, { eventsBack: previous.stack });
					},
					onRangeChange: (range) => {
						updateSearch({
							eventsBefore: freshBefore(),
							eventsCursor: void 0,
							eventsRange: range
						}, false, { eventsBack: [] });
					},
					onRefresh: () => {
						updateSearch({
							eventsBefore: freshBefore(),
							eventsCursor: void 0
						}, true, { eventsBack: [] });
					},
					pageNumber: eventsBack.length + 1,
					range: eventsRange,
					rawDays: retention.rawDays,
					children: installationLookup
				}) : matches.isLoading && hasSearchQuery ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallationResultsSkeleton, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `grid min-h-0 min-w-0 items-stretch gap-4 sm:gap-6 ${hasSearchQuery ? "lg:min-h-96 lg:grid-cols-[minmax(18rem,20rem)_minmax(0,1fr)]" : "lg:grid-cols-1"}`,
					children: [hasSearchQuery ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallationMatchesCard, {
						error: matches.error,
						onNext: () => {
							if (!matches.data?.nextCursor) return;
							updateSearch({
								installId: void 0,
								searchCursor: matches.data.nextCursor
							}, true, { searchBack: pushCursor(searchBack, search.searchCursor) });
						},
						onPrevious: () => {
							const previous = popCursor(searchBack);
							updateSearch({
								installId: void 0,
								searchCursor: previous.cursor
							}, true, { searchBack: previous.stack });
						},
						onSelect: (installId) => {
							updateSearch({
								historyBefore: freshBefore(),
								historyCursor: void 0,
								installId
							}, false, { historyBack: [] });
						},
						pageNumber: searchBack.length + 1,
						results: matches.data,
						selectedInstallId: search.installId
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallationHistoryCard, {
						error: history.error ?? selectedInstallation.error,
						history: history.data,
						isLoading: history.isLoading || selectedInstallation.isLoading,
						onNext: () => {
							if (!history.data?.nextCursor) return;
							updateSearch({ historyCursor: history.data.nextCursor }, true, { historyBack: pushCursor(historyBack, search.historyCursor) });
						},
						onPrevious: () => {
							const previous = popCursor(historyBack);
							updateSearch({ historyCursor: previous.cursor }, true, { historyBack: previous.stack });
						},
						onRefresh: () => {
							updateSearch({
								historyBefore: freshBefore(),
								historyCursor: void 0
							}, true, { historyBack: [] });
						},
						pageNumber: historyBack.length + 1,
						retention,
						selectedEvent,
						selectedInstallId: search.installId
					})]
				})]
			})
		}, scrollRestorationId)]
	});
}
//#endregion
export { InstallationsPage as component };
