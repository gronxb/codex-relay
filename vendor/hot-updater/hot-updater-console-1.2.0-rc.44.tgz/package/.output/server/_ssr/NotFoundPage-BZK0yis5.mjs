import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { O as buttonVariants } from "./sidebar-COdOWPGC.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/NotFoundPage-BZK0yis5.js
var import_jsx_runtime = require_jsx_runtime();
var homeSearch = {
	afterReleaseId: void 0,
	beforeReleaseId: void 0,
	bundleId: void 0,
	channelId: void 0,
	enabled: void 0,
	platform: void 0,
	releaseId: void 0,
	scopeKey: void 0
};
function NotFoundPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-svh flex-1 items-center justify-center px-6 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex max-w-md flex-col items-center text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-foreground",
				children: "Page not found"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				className: buttonVariants({
					className: "mt-6",
					size: "lg"
				}),
				to: "/",
				search: homeSearch,
				children: "Go to home"
			})]
		})
	});
}
//#endregion
export { NotFoundPage as t };
