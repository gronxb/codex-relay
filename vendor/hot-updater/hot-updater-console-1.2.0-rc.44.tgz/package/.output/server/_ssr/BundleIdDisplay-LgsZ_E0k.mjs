import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { k as cn } from "./sidebar-COdOWPGC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/BundleIdDisplay-LgsZ_E0k.js
var import_jsx_runtime = require_jsx_runtime();
function BundleIdDisplay({ bundleId, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		translate: "no",
		className: cn("break-all font-mono text-xs tabular-nums", className),
		children: bundleId
	});
}
//#endregion
export { BundleIdDisplay as t };
