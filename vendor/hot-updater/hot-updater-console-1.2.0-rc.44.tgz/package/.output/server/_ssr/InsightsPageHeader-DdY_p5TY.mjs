import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { A as Info, O as List, Q as ChartNoAxesCombined, i as TriangleAlert } from "../_libs/lucide-react.mjs";
import { O as buttonVariants, S as SidebarTrigger } from "./sidebar-COdOWPGC.mjs";
import { a as Badge, i as AlertTitle, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { r as isConsoleFeatureUnavailableError } from "./console-features-DTYyXrWO.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useConsoleFeature } from "./console-features-api-DbEAU6JB.mjs";
import { n as usageMetrics } from "./insights-usage-BVm7CDw9.mjs";
import { i as TabsTrigger, r as TabsList, t as Tabs$1 } from "./tabs-Bw-XniPE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/InsightsPageHeader-DdY_p5TY.js
var import_jsx_runtime = require_jsx_runtime();
function InsightsErrorAlert({ error, fallbackTitle }) {
	if (isConsoleFeatureUnavailableError(error)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { "aria-hidden": "true" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Insights not installed" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: error.message })
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "destructive",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { "aria-hidden": "true" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: fallbackTitle }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Refresh to try again. If this keeps happening, check your Insights provider connection." })
		]
	});
}
/** A segmented control over fixed periods, each shown by its short value. */
function PeriodSelector({ label, onPeriodChange, period, periods }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs$1, {
		value: period,
		onValueChange: (value) => {
			const next = periods.find((item) => item.value === value);
			if (next) onPeriodChange(next.value);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
			"aria-label": label,
			className: "min-h-11 sm:min-h-9",
			children: periods.map(({ value, name }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value,
				"aria-label": name,
				className: "min-w-12 px-3",
				children: value
			}, value))
		})
	});
}
var reportingPeriods = [
	"24h",
	"7d",
	"30d"
].map((value) => ({
	value,
	name: usageMetrics[value].period
}));
var usagePeriods = Object.keys(usageMetrics).map((value) => ({
	value,
	name: usageMetrics[value].period
}));
function InsightsPeriodSelector({ window, onWindowChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PeriodSelector, {
		label: "Reporting period",
		onPeriodChange: onWindowChange,
		period: window,
		periods: reportingPeriods
	});
}
/** App usage's periods: the reporting periods, and 12 months where daily totals cover it. */
function UsagePeriodSelector({ window, onWindowChange, twelveMonths = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PeriodSelector, {
		label: "Reporting period",
		onPeriodChange: onWindowChange,
		period: window,
		periods: usagePeriods.filter(({ value }) => twelveMonths || value !== "12m")
	});
}
/**
* A built-in bundle's ID: every native build makes it from its build time with
* zero random bits, and builds an earlier `hot-updater native-build` made, in
* the field still, have a node of a platform byte (`01` iOS, `02` Android) and
* random bits; or the nil UUID in a debug build. A deployed bundle's ID is a
* random UUIDv7, so it practically never has this shape.
*/
var BUILTIN_BUNDLE_ID = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-7000-8000-(?:000000000000|0[12][0-9a-f]{10})|00000000-0000-0000-0000-000000000000)$/iu;
/**
* Whether a reported bundle is one a native build shipped: the report's
* `minBundleId`, or, from an SDK that reports none, an ID in the built-in
* shape.
*/
var isBuiltinBundle = (bundleId, minBundleId) => bundleId !== null && bundleId !== void 0 && (bundleId === minBundleId || BUILTIN_BUNDLE_ID.test(bundleId));
/** Marks a bundle ID as the bundle its native build shipped. */
function BuiltinBundleBadge() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		className: "shrink-0 font-sans font-normal",
		title: "The bundle the native build shipped",
		variant: "secondary",
		children: "Built-in bundle"
	});
}
function InsightsPageHeader({ view, overviewSearch }) {
	const overview = useConsoleFeature("insightsAnalytics");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-10 flex shrink-0 flex-wrap items-center gap-3 border-b bg-background px-3 py-3 sm:bg-card/70 sm:px-4 sm:backdrop-blur-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1 size-11 lg:size-7" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartNoAxesCombined, {
					"aria-hidden": "true",
					className: "size-3.5 text-muted-foreground"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-sm font-medium",
					children: "Insights"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Insights views",
				className: "ml-auto flex gap-2",
				children: [overview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					"aria-current": view === "overview" ? "page" : void 0,
					className: buttonVariants({
						className: "h-11 px-3 lg:h-8 lg:px-2.5",
						size: "lg",
						variant: view === "overview" ? "secondary" : "ghost"
					}),
					search: overviewSearch,
					to: "/insights",
					children: "Overview"
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					"aria-current": view === "events" ? "page" : void 0,
					className: buttonVariants({
						className: "h-11 px-3 lg:h-8 lg:px-2.5",
						size: "lg",
						variant: view === "events" ? "secondary" : "ghost"
					}),
					to: "/installations",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
						"aria-hidden": "true",
						"data-icon": "inline-start"
					}), "All events"]
				})]
			})
		]
	});
}
//#endregion
export { PeriodSelector as a, InsightsPeriodSelector as i, InsightsErrorAlert as n, UsagePeriodSelector as o, InsightsPageHeader as r, isBuiltinBundle as s, BuiltinBundleBadge as t };
