import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { A as createSsrRpc } from "./sidebar-COdOWPGC.mjs";
import { i as useQuery, t as useInfiniteQuery } from "../_libs/tanstack__react-query.mjs";
import { c as readUpdateFailuresInput } from "./insights-failures-DGO2_3Vx.mjs";
import { n as readFailureReportsInput } from "./insights-errors-DwUaDs0Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-api-DGzoZoEY.js
var getUpdateFailuresRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readUpdateFailuresInput).handler(createSsrRpc("0d1dacdd1e5ee6b100e5c142fb9af03602b6f2c6fe6af79312b36c223d7f8f97"));
var listFailureReportsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readFailureReportsInput).handler(createSsrRpc("b4388826a9b515fb4d2113270aa8ded1c50ba13d7f07ac2b268c41396e87d0a3"));
/** `insights()`'s defaults, for a server that does not report its periods. */
var DEFAULT_INSIGHTS_RETENTION = {
	rawDays: 90,
	dailyDays: 400
};
var formatDays = (days) => `${days.toLocaleString("en")} ${days === 1 ? "day" : "days"}`;
/** Whether daily totals cover App usage's 12-month period: 52 weeks. */
var keepsTwelveMonths = ({ dailyDays }) => dailyDays >= 364;
/** The Insights reads, once the console's access check and the feature guard pass. */
var readOverview = (input) => input;
var readEventsPage = (input) => input;
var readInstallationEventsPage = (input) => input;
var readInstallationPage = (input) => input;
var readInstallId = (input) => input;
createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readOverview).handler(createSsrRpc("ff00311d412c8cdfa8ad5b0ba1eb6aa7471d0cc12170e6cc645deb91603d42dd"));
var listInsightsEventsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readEventsPage).handler(createSsrRpc("d4c50f40701055145f24873dc90f3c55a5494457a6a03a743339b2ac4545eb19"));
var listInsightsInstallationEventsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readInstallationEventsPage).handler(createSsrRpc("3c04bc6624be6dfdd80cf96819f9c6d0455e59a7bb4c0374b6afb0162ffd15b0"));
var getInsightsInstallationRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readInstallId).handler(createSsrRpc("6726f1ed9eda1f0cb4c1f1ad1023faee435ddcfd0b7c55ef08ca7f2f7f577370"));
/** How long the server's `insights()` keeps rows. */
var getInsightsRetentionRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(createSsrRpc("c6f18db42ac40385dbff247095197ee9f3fd3a97dc914efd368ce0ded1f098c6"));
var findInsightsInstallationsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readInstallationPage).handler(createSsrRpc("735c501f6d5ea81a445ff2b6b2ea6a1b589e3c6f63a465a881822c80ae71e7d1"));
var STALE_TIME_MS = 3e4;
var queryKeys = {
	reportingInstallations: (input) => [
		"insights",
		"reporting-installations",
		input
	],
	events: (input) => [
		"insights",
		"events",
		input
	],
	installations: (input) => [
		"insights",
		"installations",
		input
	],
	installation: (installId) => [
		"insights",
		"installation",
		installId
	],
	installationEvents: (input) => [
		"insights",
		"installation-events",
		input
	]
};
var useInsightsEventsQuery = (input, enabled) => useQuery({
	queryKey: queryKeys.events(input),
	queryFn: () => listInsightsEventsRpc({ data: input }),
	enabled,
	refetchOnWindowFocus: true,
	staleTime: STALE_TIME_MS
});
var useInsightsInstallationsQuery = (input, enabled) => useQuery({
	queryKey: queryKeys.installations(input),
	queryFn: () => findInsightsInstallationsRpc({ data: input }),
	enabled: enabled && input.identity.length > 0,
	staleTime: STALE_TIME_MS
});
var useInsightsInstallationQuery = (installId, enabled) => useQuery({
	queryKey: queryKeys.installation(installId),
	queryFn: () => getInsightsInstallationRpc({ data: { installId } }),
	enabled: enabled && installId.length > 0,
	staleTime: STALE_TIME_MS
});
var useInsightsInstallationEventsQuery = (input, enabled) => useQuery({
	queryKey: queryKeys.installationEvents(input),
	queryFn: () => listInsightsInstallationEventsRpc({ data: input }),
	enabled: enabled && input.installId.length > 0,
	refetchOnWindowFocus: true,
	staleTime: STALE_TIME_MS
});
/** A release's or a channel's update failures; lifetime for a release without a window. */
var useUpdateFailuresQuery = (input, enabled = true) => useQuery({
	queryKey: [
		"insights",
		"update-failures",
		input
	],
	queryFn: () => getUpdateFailuresRpc({ data: readUpdateFailuresInput(input) }),
	enabled,
	refetchOnWindowFocus: true,
	staleTime: STALE_TIME_MS
});
/**
* How long the server keeps Insights rows; the defaults until it answers, or
* when it does not report them.
*/
var useInsightsRetention = () => useQuery({
	queryKey: ["insights", "retention"],
	queryFn: () => getInsightsRetentionRpc(),
	staleTime: Infinity
}).data ?? DEFAULT_INSIGHTS_RETENTION;
var useFailureReportsQuery = (input, enabled) => useInfiniteQuery({
	queryKey: [
		"insights",
		"failure-reports",
		input
	],
	queryFn: ({ pageParam }) => listFailureReportsRpc({ data: {
		...input,
		cursor: pageParam
	} }),
	initialPageParam: void 0,
	getNextPageParam: (page) => page.nextCursor ?? void 0,
	enabled,
	staleTime: STALE_TIME_MS
});
//#endregion
export { useInsightsEventsQuery as a, useInsightsInstallationsQuery as c, useFailureReportsQuery as i, useInsightsRetention as l, formatDays as n, useInsightsInstallationEventsQuery as o, keepsTwelveMonths as r, useInsightsInstallationQuery as s, DEFAULT_INSIGHTS_RETENTION as t, useUpdateFailuresQuery as u };
