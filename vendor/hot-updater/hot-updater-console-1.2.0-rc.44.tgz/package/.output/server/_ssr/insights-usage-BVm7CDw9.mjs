//#region node_modules/.nitro/vite/services/ssr/assets/insights-usage-BVm7CDw9.js
var usageMetrics = {
	"24h": {
		label: "DAU",
		period: "24 hours",
		interval: "hour"
	},
	"7d": {
		label: "WAU",
		period: "7 days",
		interval: "6 hours"
	},
	"30d": {
		label: "MAU",
		period: "30 days",
		interval: "day"
	},
	"12m": {
		label: "YAU",
		period: "12 months",
		interval: "week"
	}
};
function readAppUsageInput(input) {
	if (!input || input.platform !== "all" && input.platform !== "ios" && input.platform !== "android" || typeof input.channel !== "string" || !input.channel.trim() || input.channel.length > 1024 || !Object.hasOwn(usageMetrics, input.window) || input.appVersion !== void 0 && (typeof input.appVersion !== "string" || !input.appVersion.trim() || input.appVersion.length > 1024)) throw new Error("Choose App usage filters and a time window.");
	return input;
}
//#endregion
export { usageMetrics as n, readAppUsageInput as t };
