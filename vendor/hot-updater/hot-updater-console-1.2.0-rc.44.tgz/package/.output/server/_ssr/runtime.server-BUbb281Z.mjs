import { i as resolveConsoleFeatures, n as consoleFeatures, t as ConsoleFeatureUnavailableError } from "./console-features-DTYyXrWO.mjs";
import { t as isRemoteDatabase } from "./databaseConfig-B56IJxlu.mjs";
import { a as createInsightsReads, i as createInsightsAdminReads, n as createRemoteConfigAdminApi, o as createInsightsModel, r as RemoteConfigValidationError } from "./plugins-D9CCkDjn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/runtime.server-BUbb281Z.js
var invalidOf = (error) => {
	if (error instanceof RemoteConfigValidationError) return {
		status: "invalid",
		issues: error.issues
	};
	throw error;
};
/**
* Remote Config over the `remoteConfig()` API the console assembled on the
* database, or over the admin routes, which answer as the API does.
*/
var createLocalRemoteConfig = (api) => ({
	getActive: () => api.getActive(),
	listVersions: (input) => api.listVersions(input),
	getVersion: (version) => api.getVersion(version),
	publish: (input) => api.publish(input).catch(invalidOf),
	rollback: (input) => api.rollback(input)
});
/**
* Remote Config over a self-hosted server's admin routes. A route the server
* does not mount answers core's 404: it runs without `remoteConfig()`.
*/
var createAdminRemoteConfig = (fetchAdmin) => createLocalRemoteConfig(createRemoteConfigAdminApi(fetchAdmin, { unavailable: () => new ConsoleFeatureUnavailableError("remoteConfig", { remote: true }) }));
var featureApi = (api) => api;
/** What serves each console feature, keyed like `consoleFeatures`. */
var consoleFeatureApis = {
	insights: featureApi({
		local: createInsightsReads,
		remote: (fetchAdmin) => createInsightsAdminReads(fetchAdmin, { unavailable: () => new ConsoleFeatureUnavailableError("insights", { remote: true }) })
	}),
	insightsAnalytics: featureApi({ local: (api) => createInsightsModel(api) }),
	remoteConfig: featureApi({
		local: (api) => createLocalRemoteConfig(api),
		remote: createAdminRemoteConfig
	}),
	apiKeys: featureApi({ local: (api) => api })
};
var isRecord = (value) => typeof value === "object" && value !== null;
/**
* Whether one of Hot Updater's own factories made `plugin`: the brand they
* set under a registered symbol, read here with a copy of the key so the
* console imports no package's internals. Assembly refuses any other plugin
* that takes one of their ids, so features key on it.
*/
var isOfficialPlugin = (plugin) => isRecord(plugin) && Reflect.get(plugin, Symbol.for("@hot-updater/server/official-plugin")) === true;
var featureIds = Object.keys(consoleFeatureApis);
/**
* What serves each feature, built by its factory: over the plugins' APIs the
* console assembled, or over a self-hosted server's admin API. A feature
* without its plugin, or without a factory for the admin API, has none.
*/
var featureApis = (build) => Object.fromEntries(featureIds.flatMap((feature) => {
	const api = build(feature);
	return api === void 0 ? [] : [[feature, api]];
}));
/**
* The console's features and what serves them, for the plugins its config
* lists, the plugins the server runs:
* - a self-hosted server (`standaloneRepository`) runs them itself; the
*   console serves what that server's admin API serves of their features,
*   and nothing that needs the database;
* - otherwise the console runs them over the database, as the server does,
*   and serves their features through `api`, their APIs.
*/
var createConsoleRuntime = (config) => {
	const { database } = config;
	const official = new Set(config.plugins.filter(isOfficialPlugin).map((plugin) => plugin.id));
	if (isRemoteDatabase(database)) {
		const { fetchAdmin } = database;
		const features = resolveConsoleFeatures([...official], { remote: true });
		return {
			remote: true,
			features: async () => features,
			apis: featureApis((feature) => consoleFeatureApis[feature].remote?.(fetchAdmin))
		};
	}
	const api = config.api ?? {};
	const features = resolveConsoleFeatures([...official], { remote: false });
	return {
		remote: false,
		features: async () => features,
		apis: featureApis((feature) => {
			const { plugin } = consoleFeatures[feature];
			const pluginApi = official.has(plugin) ? api[plugin] : void 0;
			return pluginApi === void 0 ? void 0 : consoleFeatureApis[feature].local(pluginApi);
		})
	};
};
/**
* What serves `feature`. Every feature's server function asks for it first,
* so a feature the console does not serve is refused with one error the
* client recognizes, before anything is read.
*/
var requireFeature = async (runtime, feature) => {
	const api = runtime.apis[feature];
	if (api === void 0 || !(await runtime.features())[feature]) throw new ConsoleFeatureUnavailableError(feature, { remote: runtime.remote });
	return api;
};
//#endregion
export { createConsoleRuntime, requireFeature };
