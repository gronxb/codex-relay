//#region node_modules/.nitro/vite/services/ssr/assets/auth-Z-wLddzh.js
var principal = {
	email: "local@hot-updater.dev",
	name: "Local Console"
};
var auth_default = {
	async handle() {
		return new Response("Not Found", { status: 404 });
	},
	async getAccess() {
		return {
			status: "authorized",
			principal
		};
	},
	async getProviders() {
		return [];
	}
};
//#endregion
export { auth_default as default };
