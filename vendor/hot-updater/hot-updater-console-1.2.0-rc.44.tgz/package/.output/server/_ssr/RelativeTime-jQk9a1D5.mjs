import { i as __toESM } from "../_runtime.mjs";
import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { J as ChevronRight, Y as ChevronLeft } from "../_libs/lucide-react.mjs";
import { C as Skeleton, O as buttonVariants, k as cn, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as TableHeader, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-4qgdiham.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_dayjs_min, t as require_relativeTime } from "../_libs/dayjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RelativeTime-jQk9a1D5.js
var import_jsx_runtime = require_jsx_runtime();
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
var import_relativeTime = /* @__PURE__ */ __toESM(require_relativeTime());
/** The bordered frame; the table or card list inside it scrolls. */
/**
* A list's frame. By default it fills what the page leaves and scrolls inside;
* on a page that scrolls as a whole, such as one with a card above the list,
* `flex-none` keeps it at its content's height, so nothing is cut off.
*/
function DataTableFrame({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("min-h-0 min-w-0 flex-1 overflow-hidden rounded-lg border bg-card text-card-foreground shadow-sm [&_[data-slot=table-container]]:h-full [&_[data-slot=table-container]]:overflow-auto", className),
		children
	});
}
/**
* A table as wide as its columns, with an uppercase header row. With
* `rowGroups`, its children are `DataTableBody` groups, such as a list's
* folds, each a group a control can name.
*/
function DataTable({ header, children, className, rowGroups = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
		className: cn("min-w-max", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, {
			className: "bg-muted/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
				className: "border-b border-border/60 hover:bg-transparent [&>th]:h-10 [&>th]:text-xs [&>th]:font-semibold [&>th]:uppercase [&>th]:text-muted-foreground",
				children: header
			})
		}), rowGroups ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children })]
	});
}
/** One group of a `rowGroups` table's rows, its last row ruled like the others. */
function DataTableBody({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, {
		className: cn("[&_tr:last-child]:border-b", className),
		...props
	});
}
/**
* Opens an item from a click anywhere on its row or card, except on a
* control inside it, which keeps its own action.
*/
var openOutsideControls = (open) => (event) => {
	if (event.target instanceof Element && event.target.closest("button, a, input, select, textarea")) return;
	open();
};
/**
* A row that opens its item: a click outside its controls, or Enter or Space
* on the focused row, with hover, focus, and selection as one style.
*/
function DataTableRow({ className, onOpen, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
		onClick: openOutsideControls(onOpen),
		onKeyDown: (event) => {
			if (event.target !== event.currentTarget || event.key !== "Enter" && event.key !== " ") return;
			event.preventDefault();
			onOpen();
		},
		tabIndex: 0,
		className: cn("cursor-pointer transition-[background-color,filter] hover:bg-muted/10 focus-within:bg-muted/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring motion-reduce:transition-none data-[state=selected]:bg-muted/15 [&>td]:py-3", className),
		...props
	});
}
/** Placeholder rows while the first page loads. */
function DataTableSkeletonRows({ columns, label }) {
	return Array.from({ length: 7 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
		colSpan: columns,
		children: [index === 0 && label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: label
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" })]
	}) }, index));
}
/** A row across every column, for an empty list or an inline message. */
function DataTableFullRow({ columns, className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
		className: cn("h-44 text-center text-muted-foreground", className),
		colSpan: columns,
		children
	}) });
}
/**
* What an empty list says: the page's icon, what is missing, and what to do
* about it, in a table row or a card list.
*/
function DataTableEmpty({ icon: Icon, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-sm flex-col items-center gap-2 whitespace-normal text-center text-sm text-muted-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				"aria-hidden": "true",
				className: "size-5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium text-foreground",
				children: title
			}),
			children
		]
	});
}
/** The empty card list on a narrow screen. */
function DataCardsEmpty({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-8",
		children
	});
}
/** Placeholder cards while the first page loads on a narrow screen. */
function DataCardSkeletons({ label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 p-4",
		children: [label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: label
		}) : null, Array.from({ length: 5 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-44 w-full" }, index))]
	});
}
/** One item's card on a narrow screen; a tap opens it. */
function DataCard({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: cn("flex cursor-pointer touch-manipulation flex-col gap-4 border-b p-4 transition-[background-color,filter] last:border-b-0 hover:bg-muted/10 active:bg-muted/20 motion-reduce:transition-none data-[state=selected]:bg-muted/15", className),
		...props
	});
}
/**
* The bar under a list: how many entries show, and Previous and Next, links
* to the newer and older pages, or disabled at either end. Newest shows on any
* page but the first.
*/
function DataTablePagination({ count, noun, folded, label, pending = false, newest, previous, next }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": label,
		className: "flex flex-col gap-3 px-2 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs font-medium text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground",
					children: count
				}),
				" ",
				count === 1 ? noun[0] : noun[1],
				", newest first",
				folded === void 0 || folded.count === 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: " · "
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: ", "
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-foreground",
						children: [folded.count, folded.more ? "+" : ""]
					}),
					" ",
					folded.label,
					" folded"
				] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3 sm:justify-end",
			children: [
				newest && !pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: buttonVariants({
						className: "h-11 flex-1 px-3 text-xs sm:h-8 sm:flex-none",
						size: "sm",
						variant: "ghost"
					}),
					search: newest.search,
					to: newest.to,
					children: "Newest"
				}) : null,
				previous && !pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					className: buttonVariants({
						className: "h-11 flex-1 px-3 text-xs sm:h-8 sm:flex-none",
						size: "sm",
						variant: "outline"
					}),
					search: previous.search,
					to: previous.to,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { "data-icon": "inline-start" }), "Previous"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					className: "h-11 flex-1 px-3 text-xs sm:h-8 sm:flex-none",
					disabled: true,
					size: "sm",
					variant: "outline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { "data-icon": "inline-start" }), "Previous"]
				}),
				next && !pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					className: buttonVariants({
						className: "h-11 flex-1 px-3 text-xs sm:h-8 sm:flex-none",
						size: "sm",
						variant: "outline"
					}),
					search: next.search,
					to: next.to,
					children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { "data-icon": "inline-end" })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					className: "h-11 flex-1 px-3 text-xs sm:h-8 sm:flex-none",
					disabled: true,
					size: "sm",
					variant: "outline",
					children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { "data-icon": "inline-end" })]
				})
			]
		})]
	});
}
import_dayjs_min.default.extend(import_relativeTime.default);
/**
* When something was created, as the Bundles and Native builds lists show
* it: relative, such as "4 hours ago", with the exact time on hover. A card
* has no hover, so `withDate` puts the exact time under it.
*/
function RelativeTime({ ms, withDate = false }) {
	const date = (0, import_dayjs_min.default)(ms);
	const exact = date.format("YYYY-MM-DD HH:mm:ss");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("time", {
		className: "flex flex-col whitespace-nowrap tabular-nums",
		dateTime: date.toISOString(),
		title: exact,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: date.fromNow() }), withDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: exact
		}) : null]
	});
}
//#endregion
export { DataTableBody as a, DataTableFullRow as c, DataTableSkeletonRows as d, RelativeTime as f, DataTable as i, DataTablePagination as l, DataCardSkeletons as n, DataTableEmpty as o, openOutsideControls as p, DataCardsEmpty as r, DataTableFrame as s, DataCard as t, DataTableRow as u };
