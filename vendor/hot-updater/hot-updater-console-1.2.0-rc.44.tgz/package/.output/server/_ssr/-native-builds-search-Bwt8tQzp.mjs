import { n as assertCanonicalChannelName } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
import { n as DEFAULT_CHANNEL } from "./constants-BjsJZqaU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/-native-builds-search-Bwt8tQzp.js
var text = (value) => typeof value === "string" && value.length > 0 ? value : void 0;
/** A channel name a build can embed, or undefined. */
var channelName = (value) => {
	const channel = text(value);
	if (channel === void 0) return void 0;
	try {
		assertCanonicalChannelName(channel);
		return channel;
	} catch {
		return;
	}
};
var defined = (values) => Object.fromEntries(Object.entries(values).filter(([, value]) => value !== void 0));
var validateNativeBuildsSearch = (search) => {
	const before = text(search.before);
	const channel = channelName(search.channel);
	return defined({
		channel,
		channels: channel === void 0 && search.channels === "all" ? "all" : void 0,
		before,
		after: before === void 0 ? text(search.after) : void 0
	});
};
/**
* The page the list reads. A URL that names no channel opens on the default
* channel, or on every channel when the project has no such channel;
* undefined until the channel names, which the page reads anyway, arrive.
*/
var resolveNativeBuildsSearch = ({ channels, ...page }, channelNames) => {
	if (page.channel !== void 0 || channels === "all") return page;
	if (channelNames === void 0) return void 0;
	return channelNames.includes("production") ? {
		channel: DEFAULT_CHANNEL,
		...page
	} : page;
};
/** A native build page's URL: one page of the patches from it. */
var validateNativeBuildDetailSearch = (search) => {
	const patchesBefore = text(search.patchesBefore);
	return defined({
		patchesBefore,
		patchesAfter: patchesBefore === void 0 ? text(search.patchesAfter) : void 0
	});
};
var IOS_DEVICE_STATUSES = [
	"pending",
	"approved",
	"registered"
];
var validateIosDevicesSearch = (search) => typeof search.status === "string" && IOS_DEVICE_STATUSES.includes(search.status) ? { status: search.status } : {};
//#endregion
export { validateNativeBuildsSearch as i, validateIosDevicesSearch as n, validateNativeBuildDetailSearch as r, resolveNativeBuildsSearch as t };
