import { i as __toESM } from "../_runtime.mjs";
import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { A as Info, C as OctagonX, D as LoaderCircle, E as LogOut, G as CircleCheck, M as HardDrive, V as Copy, c as Sun, h as RotateCw, i as TriangleAlert, nt as ArrowUpRight, w as Moon, x as Package } from "../_libs/lucide-react.mjs";
import { A as createSsrRpc, E as TooltipProvider, M as useSidebar, O as buttonVariants, S as SidebarTrigger, _ as SidebarInset, b as SidebarMenuItem, d as SidebarContent, f as SidebarFooter, g as SidebarHeader, h as SidebarGroupLabel, m as SidebarGroupContent, p as SidebarGroup, t as Button$1, u as Sidebar, v as SidebarMenu, x as SidebarProvider, y as SidebarMenuButton } from "./sidebar-COdOWPGC.mjs";
import { i as useQuery, r as queryOptions, s as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { a as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, i as Scripts, m as createRootRouteWithContext, p as createFileRoute, s as useRouterState, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as requireConsoleFeature, t as consoleFeaturesQueryOptions } from "./console-features-api-DbEAU6JB.mjs";
import { t as NotFoundPage } from "./NotFoundPage-BZK0yis5.mjs";
import { i as EmptyHeader, n as EmptyContent, o as EmptyTitle, r as EmptyDescription, t as Empty } from "./empty-qtSrrSOA.mjs";
import { d as consolePathFromRouter } from "./native-builds-lEyKQemV.mjs";
import { t as Route$10 } from "./insights-Cq1Qojom.mjs";
import { t as Route$11 } from "./insights_.distribution-C-cLCobe.mjs";
import { n as Route$12 } from "./installations-BlpvXBld.mjs";
import { t as Route$13 } from "./native-builds-BN0EyqQH.mjs";
import { a as isIosBrowser, r as forgetKeptIosDevice } from "./IosInstall-CUO4c1oT.mjs";
import { t as Route$14 } from "./native-builds_._buildId-C_VAJYD2.mjs";
import { t as Route$15 } from "./native-builds_.devices-ClVa2IkG.mjs";
import { n as Route$16 } from "./remote-config-VR-rSDYE.mjs";
import { c as useFeatureUi, n as Route$17 } from "./routes-CdByvccx.mjs";
import { t as setupRouterSsrQueryIntegration } from "../_libs/@tanstack/react-router-ssr-query+[...].mjs";
import { t as z } from "../_libs/next-themes.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CGWnDYZs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HotUpdaterLogo({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		"aria-label": "Hot Updater",
		className,
		viewBox: "0 0 447 652",
		xmlns: "http://www.w3.org/2000/svg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
			id: "hot-updater-gradient",
			x1: "223.54",
			y1: "0.36",
			x2: "223.54",
			y2: "711.23",
			gradientUnits: "userSpaceOnUse",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "0",
					stopColor: "#ff7f33"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "0.4",
					stopColor: "#f9602b"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "0.76",
					stopColor: "#f54c25"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "1",
					stopColor: "#f44523"
				})
			]
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M150.25,8.58c16.28,31.85,42.09,116-68.18,212.22C75.46,226.57,70,233,63.72,239.62c-28.48,30-84.71,114.89-55.82,207,.69,2.18,1.31,4.37,1.91,6.57,5.25,19.33,38.08,121,155.56,157.25a5.14,5.14,0,0,0,6-7.39c-14.72-26.53-46.07-96.89-8.89-162.55,0,0,11.5,44.5,50.5,83.5,6,6,14.72,15.64,19.53,21.23,14.47,16.77,32.24,53.55,1.82,98.18a5.63,5.63,0,0,0,6.85,8.34c75.64-32.1,333.29-164.6,128.68-410.85a7,7,0,0,0-12.46,4.15c-1.77,39.31-14.84,129-96.18,148.06a31.08,31.08,0,0,1-24.3-4.16c-13.34-8.9-25.41-32.06.53-92.3a250.9,250.9,0,0,1,20.12-37.29C282.78,220.56,356.18,79.83,157.33.77A5.64,5.64,0,0,0,150.25,8.58Z",
			fill: "url(#hot-updater-gradient)"
		})]
	});
}
var ThemeContext = (0, import_react.createContext)(void 0);
var LIGHT_THEME_COLOR = "#fbfbfa";
var DARK_THEME_COLOR = "#1f1d1c";
var REFRESH_THEME_CHROME_EVENT = "hot-updater:refresh-theme-chrome";
function ThemeProvider({ children, defaultTheme = "dark", storageKey = "hot-updater-theme" }) {
	const [theme, setTheme] = (0, import_react.useState)(defaultTheme);
	(0, import_react.useEffect)(() => {
		let stored = null;
		try {
			stored = localStorage.getItem(storageKey);
		} catch {}
		if (stored) setTheme(stored);
	}, [storageKey]);
	(0, import_react.useEffect)(() => {
		const root = window.document.documentElement;
		const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
		const themeColorMeta = window.document.querySelector("meta[name=\"theme-color\"]");
		const colorSchemeMeta = window.document.querySelector("meta[name=\"color-scheme\"]");
		const applyResolvedTheme = (resolvedTheme) => {
			root.classList.remove("light", "dark");
			root.classList.add(resolvedTheme);
			root.style.colorScheme = resolvedTheme;
			if (themeColorMeta) themeColorMeta.setAttribute("content", resolvedTheme === "dark" ? DARK_THEME_COLOR : LIGHT_THEME_COLOR);
			if (colorSchemeMeta) colorSchemeMeta.setAttribute("content", resolvedTheme === "dark" ? "dark light" : "light dark");
		};
		const syncTheme = () => {
			applyResolvedTheme(theme === "system" ? mediaQuery.matches ? "dark" : "light" : theme);
		};
		syncTheme();
		const refreshThemeChrome = () => {
			window.requestAnimationFrame(syncTheme);
		};
		window.addEventListener(REFRESH_THEME_CHROME_EVENT, refreshThemeChrome);
		window.addEventListener("pageshow", refreshThemeChrome);
		document.addEventListener("visibilitychange", refreshThemeChrome);
		if (theme === "system") mediaQuery.addEventListener("change", syncTheme);
		return () => {
			if (theme === "system") mediaQuery.removeEventListener("change", syncTheme);
			window.removeEventListener(REFRESH_THEME_CHROME_EVENT, refreshThemeChrome);
			window.removeEventListener("pageshow", refreshThemeChrome);
			document.removeEventListener("visibilitychange", refreshThemeChrome);
		};
	}, [theme]);
	const value = {
		theme,
		setTheme: (newTheme) => {
			try {
				localStorage.setItem(storageKey, newTheme);
			} catch {}
			setTheme(newTheme);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeContext.Provider, {
		value,
		children
	});
}
function useTheme$1() {
	const context = (0, import_react.useContext)(ThemeContext);
	if (context === void 0) throw new Error("useTheme must be used within a ThemeProvider");
	return context;
}
function AppSidebar({ canSignOut = false }) {
	const { setOpenMobile } = useSidebar();
	const closeMobileSidebar = () => setOpenMobile(false);
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const featureUi = useFeatureUi();
	const { theme, setTheme } = useTheme$1();
	const routerState = useRouterState();
	const currentPath = routerState.location.pathname;
	const navigation = [
		{
			label: "Bundles",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, {}),
			active: currentPath === "/",
			link: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				onClick: closeMobileSidebar,
				search: {
					afterReleaseId: void 0,
					beforeReleaseId: void 0,
					channelId: void 0,
					enabled: void 0,
					releaseId: void 0,
					platform: void 0,
					bundleId: void 0,
					scopeKey: void 0
				}
			})
		},
		{
			label: "Native builds",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, {}),
			active: currentPath === "/native-builds" || currentPath.startsWith("/native-builds/"),
			link: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/native-builds",
				onClick: closeMobileSidebar,
				search: {}
			})
		},
		...featureUi.flatMap(({ features, label, navigation }) => navigation === void 0 ? [] : [{
			label,
			icon: navigation.icon,
			active: navigation.paths.includes(currentPath),
			link: navigation.link({
				features,
				onClick: closeMobileSidebar
			})
		}])
	];
	const signOut = async () => {
		setSigningOut(true);
		try {
			if (isIosBrowser(navigator)) await forgetKeptIosDevice(consolePathFromRouter(window.location, routerState.location.pathname));
			if (!(await fetch("/api/auth/sign-out", {
				body: "{}",
				headers: { "content-type": "application/json" },
				method: "POST"
			})).ok) throw new Error("Sign-out failed. Please try again.");
			window.location.reload();
		} catch {
			setSigningOut(false);
			toast.error("Sign-out failed. Please try again.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sidebar, {
		collapsible: "icon",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarHeader, {
				className: "h-12 justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					onClick: closeMobileSidebar,
					search: {
						afterReleaseId: void 0,
						beforeReleaseId: void 0,
						channelId: void 0,
						enabled: void 0,
						releaseId: void 0,
						platform: void 0,
						bundleId: void 0,
						scopeKey: void 0
					},
					className: "flex items-center gap-3 p-1 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:p-2 max-md:min-h-11",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HotUpdaterLogo, { className: "h-7 w-7 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-0 group-data-[collapsible=icon]:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold tracking-tight text-sidebar-foreground leading-tight",
							children: "Hot Updater"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-sidebar-foreground/60 leading-tight",
							children: "Console"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarGroupLabel, { children: "Navigation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarGroupContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenu, { children: navigation.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuButton, {
				isActive: item.active,
				render: item.link,
				tooltip: item.label,
				children: [item.icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
			}) }, item.label)) }) })] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenu, { children: [canSignOut ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuButton, {
				disabled: signingOut,
				onClick: () => void signOut(),
				tooltip: "Sign out",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: signingOut ? "Signing out…" : "Sign out" })]
			}) }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuButton, {
				onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
				tooltip: theme === "dark" ? "Light mode" : "Dark mode",
				children: [theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: theme === "dark" ? "Light mode" : "Dark mode" })]
			}) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "https://hot-updater.dev",
				target: "_blank",
				rel: "noreferrer",
				className: "px-2 pb-1 text-[11px] text-sidebar-foreground/60 hover:text-sidebar-foreground group-data-[collapsible=icon]:hidden max-md:flex max-md:min-h-11 max-md:items-center",
				children: "Powered by hot-updater"
			})] })
		]
	});
}
var providerLabel = {
	github: "GitHub",
	google: "Google"
};
/** A path on this console, or the root for anything that could leave it. */
var consolePath = (target) => target.startsWith("/") && !/^\/[/\\]/.test(target) ? target : "/";
/**
* Where sign-in returns to: the page that asked for it, as a path on this
* console, so a link to a build lands on that build. A page a route sent
* here names its own target in `returnTo`, relative to the page, as the
* native build download does: sign-in returns there instead, when it is on
* this console's origin. Anything that could leave the console, such as
* `//host` or `/\host`, returns to the page, or to the root.
*/
var signInCallbackURL = (location) => {
	const page = consolePath(`${location.pathname}${location.search}`);
	const returnTo = new URLSearchParams(location.search).get("returnTo");
	if (returnTo === null) return page;
	try {
		const target = new URL(returnTo, location.href);
		return target.origin === new URL(location.href).origin ? consolePath(`${target.pathname}${target.search}`) : page;
	} catch {
		return page;
	}
};
/** Whether sign-in returns to a native build's download. */
var returnsToDownload = (callbackURL) => /\/api\/native-builds\/[^/]+\/download$/.test(callbackURL);
function ConsoleAccessPage({ access, providers }) {
	const [pendingProvider, setPendingProvider] = (0, import_react.useState)(null);
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const [downloadAfterSignIn, setDownloadAfterSignIn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setDownloadAfterSignIn(returnsToDownload(signInCallbackURL(window.location)));
	}, []);
	const [error, setError] = (0, import_react.useState)(null);
	const signIn = async (provider) => {
		setPendingProvider(provider);
		setError(null);
		try {
			const response = await fetch("/api/auth/sign-in/social", {
				body: JSON.stringify({
					callbackURL: signInCallbackURL(window.location),
					provider
				}),
				headers: { "content-type": "application/json" },
				method: "POST"
			});
			const result = await response.json();
			if (!response.ok || typeof result.url !== "string") throw new Error("The identity provider did not return a sign-in URL.");
			window.location.assign(result.url);
		} catch (cause) {
			setPendingProvider(null);
			setError(cause instanceof Error ? cause.message : "Sign-in failed.");
		}
	};
	const signOut = async () => {
		setSigningOut(true);
		setError(null);
		try {
			if (!(await fetch("/api/auth/sign-out", {
				body: "{}",
				headers: { "content-type": "application/json" },
				method: "POST"
			})).ok) throw new Error("Sign-out failed.");
			window.location.reload();
		} catch (cause) {
			setSigningOut(false);
			setError(cause instanceof Error ? cause.message : "Sign-out failed.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "bg-background text-foreground flex min-h-screen items-center justify-center p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "border-border bg-card w-full max-w-sm rounded-xl border p-6 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HotUpdaterLogo, { className: "h-10 w-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-lg font-semibold",
						children: "Hot Updater Console"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground text-sm",
						children: downloadAfterSignIn ? "Sign in to download the build. It starts once you're in." : "Sign in to manage OTA bundles."
					})] })]
				}),
				access.status === "forbidden" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Access denied"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground text-sm",
							children: [access.principal.email, " is not in the console allowlist."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
							className: "w-full",
							disabled: signingOut,
							onClick: () => void signOut(),
							size: "lg",
							variant: "outline",
							children: signingOut ? "Signing out…" : "Sign out"
						})
					]
				}) : providers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground text-sm",
					children: "No OAuth provider is configured for this console."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: providers.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
						className: "w-full",
						disabled: pendingProvider !== null,
						onClick: () => void signIn(provider),
						size: "lg",
						variant: "outline",
						children: pendingProvider === provider ? "Redirecting…" : `Continue with ${providerLabel[provider]}`
					}, provider))
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-destructive mt-3 text-sm",
					role: "alert",
					children: error
				}) : null
			]
		})
	});
}
var DOCTOR_COMMAND = "npx hot-updater doctor";
var DOCTOR_GUIDE_URL = "https://hot-updater.dev/docs/guides/doctor";
/**
* What the console shows instead of a page while the schema fence refuses
* its database: the settings a migration writes, and doctor, which names the
* command that runs it. Every page reads through the fence, so one notice
* stands for all.
*/
function SchemaMigrationRequired({ status, onRetry }) {
	const [checking, setChecking] = (0, import_react.useState)(false);
	const command = DOCTOR_COMMAND;
	const configFile = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
		className: "font-mono whitespace-nowrap",
		children: "hot-updater.config.ts"
	});
	const copyCommand = async () => {
		try {
			await navigator.clipboard.writeText(command);
			toast.success("Command copied");
		} catch {
			toast.error("Could not copy the command");
		}
	};
	const checkAgain = async () => {
		setChecking(true);
		try {
			await onRetry();
		} finally {
			setChecking(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-10 flex shrink-0 items-center gap-3 border-b bg-background px-3 py-3 sm:min-h-12 sm:bg-card/70 sm:px-4 sm:backdrop-blur-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-sm font-medium",
				children: "Database migration"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-h-0 min-w-0 flex-1 overflow-y-auto bg-muted/5 p-3 sm:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyHeader, { children: status.migratable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "The database needs a migration" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyDescription, { children: [
				"Its schema is older than this console's, so the console stops before reading it. Run this where ",
				configFile,
				" names the database: it names the command that migrates it. Then check again."
			] })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "The database's schema doesn't match" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyDescription, { children: [
				"A newer Hot Updater migrated it, or it uses a layout this console can't migrate, so the console stops before reading it. Run this where ",
				configFile,
				" names the database to see what it needs."
			] })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full items-center gap-2 rounded-md border bg-muted/40 py-1 pr-1 pl-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "min-w-0 flex-1 overflow-x-auto text-left font-mono text-xs whitespace-nowrap",
						children: command
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
						"aria-label": "Copy command",
						onClick: copyCommand,
						size: "icon-sm",
						variant: "ghost",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { "aria-hidden": "true" })
					})]
				}),
				status.settings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "w-full space-y-1 text-left text-xs text-muted-foreground",
					children: status.settings.map(({ key, expected, found }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "font-mono",
							children: key
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								found ?? "missing",
								" → ",
								expected
							]
						})]
					}, key))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
						disabled: checking,
						onClick: checkAgain,
						variant: "outline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {
							"aria-hidden": "true",
							className: checking ? "motion-safe:animate-spin" : void 0,
							"data-icon": "inline-start"
						}), checking ? "Checking…" : "Check again"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: buttonVariants({ variant: "ghost" }),
						href: DOCTOR_GUIDE_URL,
						rel: "noreferrer",
						target: "_blank",
						children: ["Doctor guide", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
							"aria-hidden": "true",
							"data-icon": "inline-end"
						})]
					})]
				})
			] })] })
		})]
	});
}
var Toaster$1 = ({ ...props }) => {
	const { theme = "system" } = z();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		theme,
		className: "toaster group",
		icons: {
			success: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }),
			info: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" }),
			warning: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4" }),
			error: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonX, { className: "size-4" }),
			loading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin motion-reduce:animate-none" })
		},
		style: {
			"--normal-bg": "var(--popover)",
			"--normal-text": "var(--popover-foreground)",
			"--normal-border": "var(--border)",
			"--border-radius": "var(--radius)"
		},
		toastOptions: { classNames: { toast: "cn-toast" } },
		...props
	});
};
var getConsoleAccessRpc = createServerFn({ method: "GET" }).handler(createSsrRpc("c504696e68ba764b48c48aa8a40275938640941e473cf9cfdd7b2322d99f9d13"));
var getConsoleAuthProvidersRpc = createServerFn({ method: "GET" }).handler(createSsrRpc("fa8c48f0489d97c62b9b68fd0caf0a61b15bad25a42b3866ec36264b4b30bb74"));
/**
* Whether the schema fence refuses the console's database, and what it
* found: one read through core, which the console makes only after a page's
* read failed. Null when the read passes or fails for another reason, which
* the page reports itself.
*/
var getSchemaMigrationRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(createSsrRpc("28ea8c9bdbeb67f80c776990bb5bcb5c990f5129520631f241faf074d90fea02"));
var schemaMigrationQueryKey = ["schema-migration"];
var schemaMigrationQueryOptions = () => queryOptions({
	queryKey: schemaMigrationQueryKey,
	queryFn: () => getSchemaMigrationRpc(),
	retry: false
});
var isSchemaQuery = (queryKey) => queryKey[0] === schemaMigrationQueryKey[0];
/**
* The schema fence's refusal of the console's database, asked for once any
* page's read fails, so a healthy console reads nothing more. `retry` asks
* again, and once the fence passes, reads the failed pages again.
*/
var useSchemaMigration = () => {
	const queryClient = useQueryClient();
	const cache = queryClient.getQueryCache();
	const failing = (0, import_react.useSyncExternalStore)((onChange) => cache.subscribe(onChange), () => cache.getAll().some(({ queryKey, state }) => !isSchemaQuery(queryKey) && state.fetchFailureCount > 0), () => false);
	const { data } = useQuery({
		...schemaMigrationQueryOptions(),
		enabled: failing
	});
	const retry = (0, import_react.useCallback)(async () => {
		if (await queryClient.fetchQuery({
			...schemaMigrationQueryOptions(),
			staleTime: 0
		}) !== null) return;
		await queryClient.resetQueries({ predicate: ({ queryKey, state }) => !isSchemaQuery(queryKey) && (state.fetchFailureCount > 0 || state.status === "error") });
	}, [queryClient]);
	return {
		status: data ?? null,
		retry
	};
};
var styles_default = "/assets/styles-CiSUsSSk.css";
var Route$9 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{
				name: "theme-color",
				content: "#1f1d1c"
			},
			{
				name: "color-scheme",
				content: "dark light"
			},
			{ title: "Hot Updater Console" }
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}]
	}),
	loader: async ({ context }) => {
		const [access, providers] = await Promise.all([getConsoleAccessRpc(), getConsoleAuthProvidersRpc()]);
		if (access.status === "authorized") await context.queryClient.prefetchQuery(consoleFeaturesQueryOptions());
		return {
			access,
			providers
		};
	},
	component: RootLayout,
	notFoundComponent: NotFoundPage,
	shellComponent: RootDocument
});
function RootDocument({ children }) {
	const [localDevtools, setLocalDevtools] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeProvider, {
			defaultTheme: "dark",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, { children: [
				children,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {}),
				localDevtools ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(localDevtools.Devtools, {
					config: { position: "bottom-right" },
					plugins: [{
						name: "Tanstack Router",
						render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(localDevtools.RouterPanel, {})
					}]
				}) : null
			] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootLayout() {
	const { access, providers } = Route$9.useLoaderData();
	if (access.status !== "authorized") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleAccessPage, {
		access,
		providers
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthorizedConsole, { canSignOut: providers.length > 0 });
}
function AuthorizedConsole({ canSignOut }) {
	const schema = useSchemaMigration();
	(0, import_react.useEffect)(() => {}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppSidebar, { canSignOut }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarInset, {
		className: "min-h-0 min-w-0 overflow-hidden",
		children: schema.status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SchemaMigrationRequired, {
			status: schema.status,
			onRetry: schema.retry
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	})] });
}
var $$splitComponentImporter = () => import("./api-keys-B0kG9UlP.mjs");
var $$splitNotFoundComponentImporter = () => import("./api-keys-SwwUDM4p.mjs");
var Route$8 = createFileRoute("/api-keys")({
	beforeLoad: ({ context }) => requireConsoleFeature(context.queryClient, "apiKeys"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var Route$7 = createFileRoute("/_hot-updater/devices/device-response")({ server: { handlers: { ANY: async ({ request }) => {
	const [{ receiveDeviceResponse }, { loadConsole }] = await Promise.all([import("./iosDeviceProfile-Devn8Dp4.mjs"), import("./config.server-CvAlgb8E.mjs")]);
	return receiveDeviceResponse(request, async () => (await loadConsole(request)).core);
} } } });
var Route$6 = createFileRoute("/_hot-updater/devices/device.mobileconfig")({ server: { handlers: { ANY: async ({ request }) => {
	const { serveDeviceProfile } = await import("./iosDeviceProfile-Devn8Dp4.mjs");
	return serveDeviceProfile(request);
} } } });
var Route$5 = createFileRoute("/_hot-updater/devices/receipt")({ server: { handlers: { ANY: async ({ request }) => {
	const [cookie, { iosDeviceViewer }, { requireConsoleAccess }, config] = await Promise.all([
		import("./iosDeviceCookie-rAFkNN6E.mjs"),
		import("./iosDevices-mJefvrvf.mjs"),
		import("./auth.server-BtwE9LLM.mjs"),
		import("./config.server-CvAlgb8E.mjs")
	]);
	const loaded = () => config.prepareConfig(request);
	return cookie.handleIosDeviceReceipt(request, {
		viewer: async () => iosDeviceViewer(await requireConsoleAccess(request), (await loaded()).config.deviceApprovers),
		core: async () => (await loaded()).core
	});
} } } });
var Route$4 = createFileRoute("/_hot-updater/devices/request")({ server: { handlers: { ANY: async ({ request }) => {
	const [cookie, { iosDeviceViewer }, { requireConsoleAccess }, config] = await Promise.all([
		import("./iosDeviceCookie-rAFkNN6E.mjs"),
		import("./iosDevices-mJefvrvf.mjs"),
		import("./auth.server-BtwE9LLM.mjs"),
		import("./config.server-CvAlgb8E.mjs")
	]);
	const loaded = () => config.prepareConfig(request);
	return cookie.handleIosDeviceRequest(request, {
		viewer: async () => iosDeviceViewer(await requireConsoleAccess(request), (await loaded()).config.deviceApprovers),
		core: async () => (await loaded()).core
	});
} } } });
var handleAuthRequest = async ({ request }) => {
	const { handleConsoleAuth } = await import("./auth.server-BtwE9LLM.mjs");
	return handleConsoleAuth(request);
};
var Route$3 = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: handleAuthRequest,
	POST: handleAuthRequest
} } });
var Route$2 = createFileRoute("/_hot-updater/native-builds/$buildId/manifest.plist")({ server: { handlers: { GET: async ({ params, request }) => {
	const [{ serveNativeBuildManifest }, { loadConsole }] = await Promise.all([import("./nativeBuildInstall-KCHXNr-F.mjs"), import("./config.server-CvAlgb8E.mjs")]);
	return serveNativeBuildManifest(request, params.buildId, () => loadConsole(request));
} } } });
var Route$1 = createFileRoute("/api/bundles/$bundleId/download")({ server: { handlers: { GET: async ({ params, request }) => {
	const { prepareConfig } = await import("./config.server-CvAlgb8E.mjs");
	const { downloadBundle } = await import("./downloadBundle-C1KOnpiF.mjs");
	const { core, storage } = await prepareConfig(request);
	return downloadBundle(params.bundleId, {
		core,
		storage
	});
} } } });
/**
* Whether a request is a browser opening the URL as a page, as a phone does
* after scanning a QR code, rather than a script fetching it.
*/
var isNavigation = (request) => request.headers.get("sec-fetch-mode") === "navigate" || (request.headers.get("accept") ?? "").includes("text/html");
var Route = createFileRoute("/api/native-builds/$buildId/download")({ server: { handlers: { GET: async ({ params, request }) => {
	const { loadConsole, prepareConfig } = await import("./config.server-CvAlgb8E.mjs");
	const { downloadNativeBuild } = await import("./nativeBuilds-S1_ZcH6M.mjs");
	const token = new URL(request.url).searchParams.get("t");
	if (token !== null) {
		const { refuseNativeBuildDownloadToken } = await import("./nativeBuildDownloadLink-CgZaRE6C.mjs");
		return await refuseNativeBuildDownloadToken(request, params.buildId, token) ?? downloadNativeBuild(params.buildId, await loadConsole(request));
	}
	let deps;
	try {
		deps = await prepareConfig(request);
	} catch (error) {
		if (error instanceof Response && error.status === 401 && isNavigation(request)) {
			const buildId = encodeURIComponent(params.buildId);
			const returnTo = encodeURIComponent(`../api/native-builds/${buildId}/download`);
			return new Response(null, {
				headers: {
					"cache-control": "no-store",
					location: `../../../native-builds/${buildId}?returnTo=${returnTo}`
				},
				status: 302
			});
		}
		throw error;
	}
	return downloadNativeBuild(params.buildId, deps);
} } } });
var rootRouteChildren = {
	IndexRoute: Route$17.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$9
	}),
	ApiKeysRoute: Route$8.update({
		id: "/api-keys",
		path: "/api-keys",
		getParentRoute: () => Route$9
	}),
	InsightsRoute: Route$10.update({
		id: "/insights",
		path: "/insights",
		getParentRoute: () => Route$9
	}),
	InstallationsRoute: Route$12.update({
		id: "/installations",
		path: "/installations",
		getParentRoute: () => Route$9
	}),
	NativeBuildsRoute: Route$13.update({
		id: "/native-builds",
		path: "/native-builds",
		getParentRoute: () => Route$9
	}),
	RemoteConfigRoute: Route$16.update({
		id: "/remote-config",
		path: "/remote-config",
		getParentRoute: () => Route$9
	}),
	InsightsDistributionRoute: Route$11.update({
		id: "/insights_/distribution",
		path: "/insights/distribution",
		getParentRoute: () => Route$9
	}),
	NativeBuildsBuildIdRoute: Route$14.update({
		id: "/native-builds_/$buildId",
		path: "/native-builds/$buildId",
		getParentRoute: () => Route$9
	}),
	NativeBuildsDevicesRoute: Route$15.update({
		id: "/native-builds_/devices",
		path: "/native-builds/devices",
		getParentRoute: () => Route$9
	}),
	HotUpdaterDevicesDeviceResponseRoute: Route$7.update({
		id: "/_hot-updater/devices/device-response",
		path: "/_hot-updater/devices/device-response",
		getParentRoute: () => Route$9
	}),
	HotUpdaterDevicesDeviceDotmobileconfigRoute: Route$6.update({
		id: "/_hot-updater/devices/device.mobileconfig",
		path: "/_hot-updater/devices/device.mobileconfig",
		getParentRoute: () => Route$9
	}),
	HotUpdaterDevicesReceiptRoute: Route$5.update({
		id: "/_hot-updater/devices/receipt",
		path: "/_hot-updater/devices/receipt",
		getParentRoute: () => Route$9
	}),
	HotUpdaterDevicesRequestRoute: Route$4.update({
		id: "/_hot-updater/devices/request",
		path: "/_hot-updater/devices/request",
		getParentRoute: () => Route$9
	}),
	ApiAuthSplatRoute: Route$3.update({
		id: "/api/auth/$",
		path: "/api/auth/$",
		getParentRoute: () => Route$9
	}),
	HotUpdaterNativeBuildsBuildIdManifestDotplistRoute: Route$2.update({
		id: "/_hot-updater/native-builds/$buildId/manifest.plist",
		path: "/_hot-updater/native-builds/$buildId/manifest.plist",
		getParentRoute: () => Route$9
	}),
	ApiBundlesBundleIdDownloadRoute: Route$1.update({
		id: "/api/bundles/$bundleId/download",
		path: "/api/bundles/$bundleId/download",
		getParentRoute: () => Route$9
	}),
	ApiNativeBuildsBuildIdDownloadRoute: Route.update({
		id: "/api/native-builds/$buildId/download",
		path: "/api/native-builds/$buildId/download",
		getParentRoute: () => Route$9
	})
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
/** A location's scroll-restoration key: its route's own, else its history entry's. */
var routeScrollRestorationKey = (router, location) => {
	const [, , foundRoute] = router.getMatchedRoutes(location.pathname);
	const routeKey = foundRoute?.options.staticData?.scrollRestorationKey;
	return routeKey?.(location) ?? location.state.__TSR_key;
};
var getRouter = () => {
	const queryClient = new QueryClient({ defaultOptions: { queries: { retry: (failures) => failures < 3 && !queryClient.getQueryData(schemaMigrationQueryKey) } } });
	const router = createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		getScrollRestorationKey: (location) => routeScrollRestorationKey(router, location),
		defaultPreloadStaleTime: 0
	});
	setupRouterSsrQueryIntegration({
		router,
		queryClient
	});
	return router;
};
//#endregion
export { getRouter };
