import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as validateIosDevicesSearch } from "./-native-builds-search-Bwt8tQzp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-builds_.devices-ClVa2IkG.js
var $$splitComponentImporter = () => import("./native-builds_.devices-DJ0rI3s8.mjs");
var Route = createFileRoute("/native-builds_/devices")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	validateSearch: validateIosDevicesSearch
});
//#endregion
export { Route as t };
