import { t as ConsoleFeatureUnavailable } from "./ConsoleFeatureUnavailable--3q0wW_8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights_.distribution-e1SO9twP.js
/** How a distribution row's bundle reads aloud. */
/** The bundle an app version's native build shipped, by its ID. */
var SplitNotFoundComponent = ConsoleFeatureUnavailable;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
