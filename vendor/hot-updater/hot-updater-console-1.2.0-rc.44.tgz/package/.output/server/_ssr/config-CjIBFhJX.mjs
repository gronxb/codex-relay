import { loadConfig } from "@hot-updater/cli-tools";
//#region node_modules/.nitro/vite/services/ssr/assets/config-CjIBFhJX.js
var config_default = async () => {
	const config = await loadConfig(null);
	if (config.database === void 0) throw new Error("Set database in hot-updater.config.ts: the database your server runs on, such as d1Database(...), or standaloneRepository({ baseUrl }) to reach a self-hosted server through its admin API.");
	if (config.storage === void 0) throw new Error("Set storage in hot-updater.config.ts: where your server stores bundles, which the console reads, such as r2Storage(...).");
	return {
		database: config.database,
		storage: config.storage,
		plugins: config.plugins,
		console: { gitUrl: config.console.gitUrl }
	};
};
//#endregion
export { config_default as default };
