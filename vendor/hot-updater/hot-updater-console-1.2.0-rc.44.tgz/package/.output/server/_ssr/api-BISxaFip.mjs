import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { A as createSsrRpc } from "./sidebar-COdOWPGC.mjs";
import { i as useQuery, n as useMutation, s as useQueryClient, t as useInfiniteQuery } from "../_libs/tanstack__react-query.mjs";
import { n as assertCanonicalChannelName } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
import { u as channelIdOf } from "./native-builds-lEyKQemV.mjs";
import { n as readReleaseFilter } from "./listReleases-QF91GLE7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-BISxaFip.js
/** The bounds of a fold, checked: IDs as text. */
var readFoldInput = (input) => {
	const text = (value) => typeof value === "string" && value !== "";
	if (!text(input.to) || input.from !== void 0 && !text(input.from) || input.after !== void 0 && !text(input.after)) throw new Error("A fold is its to, and optionally from and after.");
	return {
		to: input.to,
		...input.from === void 0 ? {} : { from: input.from },
		...input.after === void 0 ? {} : { after: input.after }
	};
};
var getReleases = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	filter: readReleaseFilter(input?.filter),
	...input?.afterReleaseId === void 0 ? {} : { afterReleaseId: input.afterReleaseId },
	...input?.beforeReleaseId === void 0 ? {} : { beforeReleaseId: input.beforeReleaseId },
	...input?.releaseId === void 0 ? {} : { releaseId: input.releaseId }
})).handler(createSsrRpc("206547cb1526f961070a989818ca7b9e34f6b2b0e4ab851698c3807fe9fb5e0c"));
/** One chunk of a release page's fold. */
var getReleaseFold = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	filter: readReleaseFilter(input.filter),
	...readFoldInput(input)
})).handler(createSsrRpc("b30a0e32e3e84050037368e4405bfc34507fda8891a64faefe1a7acd019e9f3c"));
var getRelease = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("a6f23116eeaf76166d405e28a95213123025613c6603030894e519015bf48032"));
var updateRelease = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("7ea0186f19f9f2bc2ca4b26e3c59636891cf046957f84287b6783f8d88bd8cb7"));
var preflightRelease = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("b46c95dba95a6a3e8fa5c9d100e3622fa5ae7af4f38e10fb1ed2fa48289a3a8f"));
var deleteRelease = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("d5b58722ce514e3b63a377f736b4823c2011782495442ae4870ed547e392c70b"));
var promoteRelease = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("956539a300d79a7efa191c1cc2d529d62fc4bfd940442548fdbc1404e0d53078"));
var getReleaseCatalogDiagnostics = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("e8c24b7247936f045a145ffd5c177fd0e3df3b52769d67dfbd8d1de491d66396"));
var getConfig = createServerFn().middleware([consoleAccess]).handler(createSsrRpc("51a34c05479a893c7d320bd4cd1604427289d667698c48b9f30a01aabf8a5e68"));
var getChannels = createServerFn().middleware([consoleAccess]).handler(createSsrRpc("79ada05964de8f2123bfcd62b10097d59bf8fd689ef5c7161031e5871d8396c5"));
var createChannel = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => {
	const name = typeof input?.name === "string" ? input.name.trim() : "";
	if (name.length === 0) throw new Error("Channel name is required.");
	return { name };
}).handler(createSsrRpc("2b9b8d1f49f79a511589617d8d4bfc6094a3acf5264f33651b9569ba66d3f321"));
var deleteChannel = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("52756dde414919a906bfe83d1ab6d29910c63bcafdb47653d6f1df562d958920"));
var getBundle = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("1bd85c2a50e24785cb6abb023a247a9f048f37ddfa85cbb1c57e579563bad013"));
var getBundleChildren = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("4370f1bf70b91f1168d85379d3008449a1bedb915e9878ca4ef89d5f3a80fa7f"));
var getBundleChildCounts = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => {
	if (!Array.isArray(input?.bundleIds) || input.bundleIds.length > 100) throw new Error("Choose up to 100 bundles.");
	return input;
}).handler(createSsrRpc("4ca367070b00f58179a572f0bb8196a4ccdd3881e9b1dbfe33deee0cb6e1f549"));
/** A channel name the list filters by, as its channel ID. */
var channelIdFilter = (channel) => {
	if (channel === void 0) return {};
	if (typeof channel !== "string") throw new Error("channel must be a name.");
	assertCanonicalChannelName(channel);
	return { channelId: channelIdOf(channel) };
};
var getNativeBuilds = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	...input?.before === void 0 ? {} : { before: input.before },
	...input?.after === void 0 ? {} : { after: input.after },
	...channelIdFilter(input?.channel)
})).handler(createSsrRpc("17a54fe7c5ad6ca53457914b1d02b3d6887811aa6b5fa6598a1ee107796ce8f0"));
/** One chunk of a native build page's fold. */
var getNativeBuildFold = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	...channelIdFilter(input.channel),
	...readFoldInput(input)
})).handler(createSsrRpc("1fc98b1499df6f62eeb3e84712ff4bd12e428d2ddd08880d541463d24ccd0233"));
/** A native build's page: the build, its built-in bundle, what it is served, and its patches. */
var getNativeBuildDetail = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("c101ad0315790cf226f182906274176b64a93b9bf5b410cacec5067208c70a04"));
/** One page of the patches from a native build's built-in bundle. */
var getNativeBuildPatches = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	minBundleId: input.minBundleId,
	...input.before === void 0 ? {} : { before: input.before },
	...input.after === void 0 ? {} : { after: input.after }
})).handler(createSsrRpc("2e3fab89483b2e4fea0c2f996071b2dbb15b8bc072e7dae78c75a9a9d854d5b9"));
/**
* The native build new deploys to a release's scope patch from: the scope's
* store build in one read, or with no mark its newest build in one more. A
* release of an app version range has no one build: it reads nothing. A
* sandbox build is never in the scope, so it is never the one.
*/
var getReleaseNativeBuild = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("868ce85f0b63ad138a1f82a573d1d6b12f80c7ca44aefec3dadf01b5fa7db86c"));
/**
* Marks a build as what the store sells, replacing its scope's mark, or clears
* its mark: only for a signed-in caller. It creates no patch: a hosted Console
* doesn't run the diff.
*/
var markNativeBuild = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("a6c8cfa907e2f75bf69aa90044bd52a3ee684d1a0462d23781161a1a3531aa33"));
/**
* The URL a phone downloads a build from when the Console can't sign a link,
* or null when the storage gives none: the storage's download URL, resolved
* again each time it is read, since it may expire.
*/
var getNativeBuildDownloadUrl = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("936ef8582ff49d97077d1d80e8403d0b4106831c955591c5c471a88f96007fe9"));
/**
* A new signed link to one build's download, which works without the
* console's sign-in until it expires: only for a signed-in caller.
*/
var createNativeBuildDownloadLink = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("c6ff40bd8faad0b2d7aba3e94179c18e02a918a76bff25849d771ff31f688208"));
/**
* What an iPhone can do with one build: read from the IPA on demand, one row
* and a few storage requests, with the Install button's link when it can
* install. A POST, since it signs that link, and only for a signed-in caller.
*/
var getNativeBuildInstallEligibility = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createSsrRpc("67cea9f69773d83e69e68e20b81116a2bee9ee4ab3e378698ff74149f1d59ad0"));
var releaseListQueryKey = ["releases"];
var queryKeys = {
	config: ["config"],
	channels: ["channels"],
	releases: {
		all: releaseListQueryKey,
		list: (filters) => [...releaseListQueryKey, filters ?? {}],
		fold: (filter, fold) => [
			...releaseListQueryKey,
			"fold",
			filter ?? {},
			fold
		]
	},
	release: (releaseId) => ["release", releaseId],
	releaseCatalog: (scopeKey) => ["release-catalog", scopeKey],
	bundleChildren: {
		all: ["bundle-children"],
		list: (baseBundleId) => ["bundle-children", baseBundleId],
		counts: (bundleIds) => [
			"bundle-children",
			"counts",
			...bundleIds
		]
	},
	bundle: (bundleId) => ["bundle", bundleId],
	nativeBuilds: {
		all: ["native-builds"],
		list: (page) => ["native-builds", page],
		fold: (channel, fold) => [
			"native-builds",
			"fold",
			channel ?? null,
			fold
		]
	},
	nativeBuild: (id) => ["native-build", id],
	nativeBuildPatches: (minBundleId, page) => [
		"native-build-patches",
		minBundleId,
		page
	],
	nativeBuildDownloadUrl: (id) => ["native-build-download-url", id],
	nativeBuildDownloadLink: (id) => ["native-build-download-link", id],
	nativeBuildInstallEligibility: (id, udid) => [
		"native-build-install-eligibility",
		id,
		udid
	],
	releaseNativeBuild: (release) => ["release-native-build", release]
};
/**
* How long a storage download URL counts as fresh. Storage gives no lifetime
* with the URL, and adapters let it be configured down to minutes, so a
* person coming back to the page after this gets a new one.
*/
var DOWNLOAD_URL_STALE_MS = 6e4;
/**
* How long a build page's signed link counts as fresh: far inside its 30 days,
* so a page left open never shows an expired one, and it costs one request
* a day.
*/
var DOWNLOAD_LINK_STALE_MS = 1440 * 60 * 1e3;
/**
* How long an iPhone keeps a build's install details and Install link, which
* lasts an hour: past this, an open page reads and signs again.
*/
var INSTALL_ELIGIBILITY_STALE_MS = 1800 * 1e3;
function useConfigQuery() {
	return useQuery({
		queryKey: queryKeys.config,
		queryFn: () => getConfig(),
		staleTime: Infinity
	});
}
function useChannelsQuery() {
	return useQuery({
		queryKey: queryKeys.channels,
		queryFn: () => getChannels(),
		staleTime: Infinity
	});
}
function useReleasesQuery(filters, { enabled = true } = {}) {
	return useQuery({
		queryKey: queryKeys.releases.list(filters),
		queryFn: () => getReleases({ data: filters }),
		placeholderData: (previousData) => previousData,
		enabled
	});
}
/**
* A fold's releases, a chunk at a time, read once it opens: the page that
* folded them reads nothing more when one opens.
*/
function useReleaseFoldQuery(filter, fold, enabled) {
	return useInfiniteQuery({
		queryKey: queryKeys.releases.fold(filter, fold),
		queryFn: ({ pageParam }) => getReleaseFold({ data: {
			...fold,
			...filter === void 0 ? {} : { filter },
			...pageParam === void 0 ? {} : { after: pageParam }
		} }),
		initialPageParam: void 0,
		getNextPageParam: (last) => last.next,
		enabled
	});
}
function useReleaseQuery(releaseId) {
	return useQuery({
		enabled: releaseId.length > 0,
		queryFn: () => getRelease({ data: { releaseId } }),
		queryKey: queryKeys.release(releaseId)
	});
}
function useReleaseCatalogDiagnosticsQuery(scopeKey) {
	return useQuery({
		enabled: scopeKey.length > 0,
		queryFn: () => getReleaseCatalogDiagnostics({ data: { scopeKey } }),
		queryKey: queryKeys.releaseCatalog(scopeKey)
	});
}
function useBundleQuery(bundleId) {
	return useQuery({
		queryKey: queryKeys.bundle(bundleId),
		queryFn: () => getBundle({ data: { bundleId } }),
		staleTime: Infinity,
		enabled: !!bundleId
	});
}
function useBundleChildrenQuery(baseBundleId) {
	return useQuery({
		queryKey: queryKeys.bundleChildren.list(baseBundleId),
		queryFn: () => getBundleChildren({ data: { baseBundleId } }),
		staleTime: Infinity,
		enabled: !!baseBundleId
	});
}
function useBundleChildCountsQuery(bundleIds) {
	const normalizedBundleIds = [...bundleIds].sort((left, right) => left.localeCompare(right));
	return useQuery({
		queryKey: queryKeys.bundleChildren.counts(normalizedBundleIds),
		queryFn: () => getBundleChildCounts({ data: { bundleIds: normalizedBundleIds } }),
		staleTime: Infinity,
		enabled: normalizedBundleIds.length > 0
	});
}
/** A fold's native builds, a chunk at a time, read once it opens. */
function useNativeBuildFoldQuery(channel, fold, enabled) {
	return useInfiniteQuery({
		queryKey: queryKeys.nativeBuilds.fold(channel, fold),
		queryFn: ({ pageParam }) => getNativeBuildFold({ data: {
			...fold,
			...channel === void 0 ? {} : { channel },
			...pageParam === void 0 ? {} : { after: pageParam }
		} }),
		initialPageParam: void 0,
		getNextPageParam: (last) => last.next,
		enabled,
		staleTime: 6e4
	});
}
/** One page of native builds, newest first, kept on screen while the next loads. */
function useNativeBuildsQuery(page, { enabled = true } = {}) {
	return useQuery({
		queryKey: queryKeys.nativeBuilds.list(page),
		queryFn: () => getNativeBuilds({ data: page }),
		placeholderData: (previousData) => previousData,
		staleTime: 6e4,
		enabled
	});
}
/**
* A native build's page in one round trip, or null for an unknown ID. The
* page reads it again when it opens, since its catalog and patches change
* with each deploy.
*/
function useNativeBuildDetailQuery(id) {
	return useQuery({
		queryKey: queryKeys.nativeBuild(id),
		queryFn: () => getNativeBuildDetail({ data: { id } }),
		enabled: id.length > 0
	});
}
/**
* A page of patches from a built-in bundle other than the newest, which the
* build's page already holds; kept on screen while the next one loads.
*/
function useNativeBuildPatchesQuery(minBundleId, page, enabled) {
	return useQuery({
		queryKey: queryKeys.nativeBuildPatches(minBundleId, page),
		queryFn: () => getNativeBuildPatches({ data: {
			minBundleId,
			...page
		} }),
		enabled: enabled && minBundleId.length > 0,
		placeholderData: (previousData) => previousData
	});
}
/**
* The newest native build of a release's scope, or none: read only for a
* release one build can serve, by its fingerprint or one exact app version.
*/
function useReleaseNativeBuildQuery(release) {
	return useQuery({
		queryKey: queryKeys.releaseNativeBuild(release ?? {
			platform: "ios",
			channel: "",
			fingerprintHash: null,
			targetAppVersion: null
		}),
		queryFn: () => getReleaseNativeBuild({ data: release }),
		enabled: release !== null,
		staleTime: 6e4
	});
}
/**
* The signed link of a build's page, which its QR code, download button, and
* copyable link all use: one request when the page opens.
*/
function useNativeBuildDownloadLinkQuery(id) {
	return useQuery({
		queryKey: queryKeys.nativeBuildDownloadLink(id),
		queryFn: () => createNativeBuildDownloadLink({ data: { id } }),
		staleTime: DOWNLOAD_LINK_STALE_MS
	});
}
/**
* What this iPhone can do with a build, and the link Install opens: requested
* only by an iPhone on the page of an IPA, and again before that link, which
* lasts about an hour, runs out.
*/
function useNativeBuildInstallEligibilityQuery(id, udid) {
	return useQuery({
		queryKey: queryKeys.nativeBuildInstallEligibility(id, udid),
		queryFn: () => getNativeBuildInstallEligibility({ data: {
			id,
			...udid === null ? {} : { udid }
		} }),
		staleTime: INSTALL_ELIGIBILITY_STALE_MS,
		refetchInterval: INSTALL_ELIGIBILITY_STALE_MS
	});
}
/**
* The storage URL a phone downloads a build from when the Console can't sign
* a link: read once, and again only when someone comes back to the page.
*/
function useNativeBuildDownloadUrlQuery(id) {
	return useQuery({
		queryKey: queryKeys.nativeBuildDownloadUrl(id),
		queryFn: () => getNativeBuildDownloadUrl({ data: { id } }),
		staleTime: DOWNLOAD_URL_STALE_MS
	});
}
function useCreateChannelMutation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (input) => createChannel({ data: input }).then((response) => response.data),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: queryKeys.channels });
		}
	});
}
function useDeleteChannelMutation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (input) => deleteChannel({ data: input }).then((response) => response.data),
		onSettled: async () => {
			await queryClient.invalidateQueries({ queryKey: queryKeys.channels });
		}
	});
}
/**
* Marks a build as its scope's store build, or clears it. The mark it replaced
* is on another build's page, in the list and in a release sheet's link, so
* they read again.
*/
function useMarkNativeBuildMutation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (input) => markNativeBuild({ data: input }),
		onSettled: async () => {
			await Promise.all([
				queryClient.invalidateQueries({ queryKey: ["native-build"] }),
				queryClient.invalidateQueries({ queryKey: queryKeys.nativeBuilds.all }),
				queryClient.invalidateQueries({ queryKey: ["release-native-build"] })
			]);
		}
	});
}
function useUpdateReleaseMutation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (input) => updateRelease({ data: input }),
		onSuccess: async (_, input) => {
			await Promise.all([
				queryClient.invalidateQueries({ queryKey: queryKeys.releases.all }),
				queryClient.invalidateQueries({ queryKey: queryKeys.release(input.releaseId) }),
				queryClient.invalidateQueries({ queryKey: ["release-catalog"] }),
				queryClient.invalidateQueries({ queryKey: queryKeys.channels })
			]);
		}
	});
}
function usePreflightReleaseMutation() {
	return useMutation({ mutationFn: (input) => preflightRelease({ data: input }) });
}
function useDeleteReleaseMutation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (input) => deleteRelease({ data: input }),
		onSuccess: async (_, input) => {
			queryClient.removeQueries({ queryKey: queryKeys.release(input.releaseId) });
			await Promise.all([
				queryClient.invalidateQueries({ queryKey: queryKeys.releases.all }),
				queryClient.invalidateQueries({ queryKey: ["release-catalog"] }),
				queryClient.invalidateQueries({ queryKey: queryKeys.channels }),
				queryClient.invalidateQueries({ queryKey: ["bundle"] }),
				queryClient.invalidateQueries({ queryKey: queryKeys.bundleChildren.all })
			]);
		}
	});
}
function usePromoteReleaseMutation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (input) => promoteRelease({ data: input }),
		onSuccess: async () => {
			await Promise.all([
				queryClient.invalidateQueries({ queryKey: queryKeys.releases.all }),
				queryClient.invalidateQueries({ queryKey: ["release"] }),
				queryClient.invalidateQueries({ queryKey: ["release-catalog"] }),
				queryClient.invalidateQueries({ queryKey: queryKeys.channels })
			]);
		}
	});
}
//#endregion
export { useReleasesQuery as C, useReleaseQuery as S, usePreflightReleaseMutation as _, useConfigQuery as a, useReleaseFoldQuery as b, useDeleteReleaseMutation as c, useNativeBuildDownloadLinkQuery as d, useNativeBuildDownloadUrlQuery as f, useNativeBuildsQuery as g, useNativeBuildPatchesQuery as h, useChannelsQuery as i, useMarkNativeBuildMutation as l, useNativeBuildInstallEligibilityQuery as m, useBundleChildrenQuery as n, useCreateChannelMutation as o, useNativeBuildFoldQuery as p, useBundleQuery as r, useDeleteChannelMutation as s, useBundleChildCountsQuery as t, useNativeBuildDetailQuery as u, usePromoteReleaseMutation as v, useUpdateReleaseMutation as w, useReleaseNativeBuildQuery as x, useReleaseCatalogDiagnosticsQuery as y };
