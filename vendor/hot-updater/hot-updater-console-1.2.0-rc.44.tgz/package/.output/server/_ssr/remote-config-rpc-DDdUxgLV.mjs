import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/remote-config-rpc-DDdUxgLV.js
/** Remote Config, once the console's access check and the feature guard pass. */
var remoteConfig = async () => {
	const [{ prepareConfig }, { requireFeature }] = await Promise.all([import("./config.server-CvAlgb8E.mjs"), import("./runtime.server-BUbb281Z.mjs")]);
	const { runtime } = await prepareConfig();
	return requireFeature(runtime, "remoteConfig");
};
var field = (input, key) => typeof input === "object" && input !== null ? Reflect.get(input, key) : void 0;
var versionNumber = (value, name) => {
	if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0) throw new TypeError(`${name} must be a non-negative integer.`);
	return value;
};
var parseCursor = (input) => {
	const cursor = field(input, "cursor");
	if (cursor !== void 0 && typeof cursor !== "string") throw new TypeError("cursor must be text.");
	return cursor === void 0 ? {} : { cursor };
};
var parseVersion = (input) => ({ version: versionNumber(field(input, "version"), "version") });
var parsePublish = (input) => {
	const description = field(input, "description");
	if (description !== void 0 && typeof description !== "string") throw new TypeError("description must be text.");
	return {
		template: field(input, "template"),
		baseVersion: versionNumber(field(input, "baseVersion"), "baseVersion"),
		...description === void 0 ? {} : { description }
	};
};
var parseRollback = (input) => ({
	version: versionNumber(field(input, "version"), "version"),
	baseVersion: versionNumber(field(input, "baseVersion"), "baseVersion")
});
var CONTEXT_FIELDS = [
	"platform",
	"appVersion",
	"channel",
	"cohort",
	"fingerprintHash"
];
var parsePreview = (input) => {
	const raw = field(input, "context");
	const context = {};
	for (const key of CONTEXT_FIELDS) {
		const value = field(raw, key);
		if (typeof value === "string" && value.trim().length > 0) context[key] = value.trim();
	}
	if (context.platform !== void 0 && context.platform !== "ios" && context.platform !== "android") throw new TypeError("platform must be \"ios\" or \"android\".");
	const now = field(raw, "now");
	if (now !== void 0 && (typeof now !== "number" || !Number.isFinite(now))) throw new TypeError("now must be a time in milliseconds since the epoch.");
	return {
		template: field(input, "template"),
		context: {
			...context,
			now: now ?? Date.now()
		}
	};
};
var getRemoteConfigRpc_createServerFn_handler = createServerRpc({
	id: "0ccfae64b399b03d820328fa98a38e2caa0b622d3da5a7ca633c5a0e8101e3f6",
	name: "getRemoteConfigRpc",
	filename: "src/lib/remote-config-rpc.ts"
}, (opts) => getRemoteConfigRpc.__executeServer(opts));
var getRemoteConfigRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(getRemoteConfigRpc_createServerFn_handler, async () => (await remoteConfig()).getActive());
var listRemoteConfigVersionsRpc_createServerFn_handler = createServerRpc({
	id: "3377db68b9d1d971971595469029c0466da0777a177b294d655cd0c039737f1a",
	name: "listRemoteConfigVersionsRpc",
	filename: "src/lib/remote-config-rpc.ts"
}, (opts) => listRemoteConfigVersionsRpc.__executeServer(opts));
var listRemoteConfigVersionsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(parseCursor).handler(listRemoteConfigVersionsRpc_createServerFn_handler, async ({ data }) => (await remoteConfig()).listVersions({
	limit: 20,
	...data
}));
var getRemoteConfigVersionRpc_createServerFn_handler = createServerRpc({
	id: "af71e3c55a659ce46093e33b9d70e729359610eec7d576502e8f0e26c785b317",
	name: "getRemoteConfigVersionRpc",
	filename: "src/lib/remote-config-rpc.ts"
}, (opts) => getRemoteConfigVersionRpc.__executeServer(opts));
var getRemoteConfigVersionRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(parseVersion).handler(getRemoteConfigVersionRpc_createServerFn_handler, async ({ data }) => (await remoteConfig()).getVersion(data.version));
var publishRemoteConfigRpc_createServerFn_handler = createServerRpc({
	id: "4182bf9ccbb675700638f30bc6122517ccd90b16a339a6823a0f5f6c808d70a6",
	name: "publishRemoteConfigRpc",
	filename: "src/lib/remote-config-rpc.ts"
}, (opts) => publishRemoteConfigRpc.__executeServer(opts));
var publishRemoteConfigRpc = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator(parsePublish).handler(publishRemoteConfigRpc_createServerFn_handler, async ({ data }) => (await remoteConfig()).publish(data));
var rollbackRemoteConfigRpc_createServerFn_handler = createServerRpc({
	id: "98c10bdc514eb4d3fe65af546be44452b492a81092cfe45625778a4c9f731727",
	name: "rollbackRemoteConfigRpc",
	filename: "src/lib/remote-config-rpc.ts"
}, (opts) => rollbackRemoteConfigRpc.__executeServer(opts));
var rollbackRemoteConfigRpc = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator(parseRollback).handler(rollbackRemoteConfigRpc_createServerFn_handler, async ({ data }) => (await remoteConfig()).rollback(data));
var previewRemoteConfigRpc_createServerFn_handler = createServerRpc({
	id: "1371bff16085636e2c44b60a573ae434b556c63045c40a0a93a93ab69ec47999",
	name: "previewRemoteConfigRpc",
	filename: "src/lib/remote-config-rpc.ts"
}, (opts) => previewRemoteConfigRpc.__executeServer(opts));
var previewRemoteConfigRpc = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator(parsePreview).handler(previewRemoteConfigRpc_createServerFn_handler, async ({ data }) => {
	await remoteConfig();
	const { evaluateRemoteConfig, RemoteConfigValidationError, validateRemoteConfigTemplate } = await import("./plugins-D9CCkDjn.mjs").then((n) => n.t);
	try {
		return {
			status: "ok",
			parameters: evaluateRemoteConfig(validateRemoteConfigTemplate(data.template), data.context)
		};
	} catch (error) {
		if (error instanceof RemoteConfigValidationError) return {
			status: "invalid",
			issues: error.issues
		};
		throw error;
	}
});
//#endregion
export { getRemoteConfigRpc_createServerFn_handler, getRemoteConfigVersionRpc_createServerFn_handler, listRemoteConfigVersionsRpc_createServerFn_handler, previewRemoteConfigRpc_createServerFn_handler, publishRemoteConfigRpc_createServerFn_handler, rollbackRemoteConfigRpc_createServerFn_handler };
