import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
import { n as readRecoveryInput } from "./insights-recovery-Cdg3Msrj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-recovery-rpc-DFiuGbxf.js
function readBundleActivityInput(inputs) {
	if (!Array.isArray(inputs) || inputs.length > 20) throw new Error("Choose up to 20 bundles.");
	return inputs.map((input) => {
		readRecoveryInput({
			...input,
			window: "30d"
		});
		if (!input.releaseId) throw new Error("Choose a bundle ID.");
		return input;
	});
}
var getBundleActivityRpc_createServerFn_handler = createServerRpc({
	id: "b4bf4c461903edcdc44eea52468c737b5b600a586f542138ff022dcbbe86c45c",
	name: "getBundleActivityRpc",
	filename: "src/lib/insights-recovery-rpc.ts"
}, (opts) => getBundleActivityRpc.__executeServer(opts));
var getBundleActivityRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readBundleActivityInput).handler(getBundleActivityRpc_createServerFn_handler, async ({ data }) => {
	const [{ prepareConfig }, { getBundleActivity }, { requireFeature }] = await Promise.all([
		import("./config.server-CvAlgb8E.mjs"),
		import("./bundleActivity-a-pEDiqu.mjs"),
		import("./runtime.server-BUbb281Z.mjs")
	]);
	const { runtime } = await prepareConfig();
	return getBundleActivity(await requireFeature(runtime, "insightsAnalytics"), data);
});
//#endregion
export { getBundleActivityRpc_createServerFn_handler };
