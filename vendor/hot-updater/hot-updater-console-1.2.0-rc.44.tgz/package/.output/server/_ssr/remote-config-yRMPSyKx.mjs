import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { n as Route, t as RemoteConfigPage } from "./remote-config-VR-rSDYE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/remote-config-yRMPSyKx.js
var import_jsx_runtime = require_jsx_runtime();
function RemoteConfigRoute() {
	const { tab = "parameters" } = Route.useSearch();
	const navigate = Route.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemoteConfigPage, {
		onTabChange: (next) => void navigate({
			search: next === "parameters" ? {} : { tab: next },
			replace: true
		}),
		tab
	});
}
//#endregion
export { RemoteConfigRoute as component };
