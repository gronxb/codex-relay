import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
import { c as readUpdateFailuresInput } from "./insights-failures-DGO2_3Vx.mjs";
import { n as readFailureReportsInput } from "./insights-errors-DwUaDs0Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-failures-rpc-HwnD8fbl.js
var getUpdateFailuresRpc_createServerFn_handler = createServerRpc({
	id: "0d1dacdd1e5ee6b100e5c142fb9af03602b6f2c6fe6af79312b36c223d7f8f97",
	name: "getUpdateFailuresRpc",
	filename: "src/lib/insights-failures-rpc.ts"
}, (opts) => getUpdateFailuresRpc.__executeServer(opts));
var getUpdateFailuresRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readUpdateFailuresInput).handler(getUpdateFailuresRpc_createServerFn_handler, async ({ data }) => {
	const [{ prepareConfig }, { getUpdateFailuresReport }, { requireFeature }] = await Promise.all([
		import("./config.server-CvAlgb8E.mjs"),
		import("./updateFailures-BwDwIoNu.mjs"),
		import("./runtime.server-BUbb281Z.mjs")
	]);
	const { runtime, core } = await prepareConfig();
	return getUpdateFailuresReport(await requireFeature(runtime, "insights"), data, Date.now(), core);
});
var listFailureReportsRpc_createServerFn_handler = createServerRpc({
	id: "b4388826a9b515fb4d2113270aa8ded1c50ba13d7f07ac2b268c41396e87d0a3",
	name: "listFailureReportsRpc",
	filename: "src/lib/insights-failures-rpc.ts"
}, (opts) => listFailureReportsRpc.__executeServer(opts));
var listFailureReportsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readFailureReportsInput).handler(listFailureReportsRpc_createServerFn_handler, async ({ data }) => {
	const [{ prepareConfig }, { listFailureReports }, { requireFeature }] = await Promise.all([
		import("./config.server-CvAlgb8E.mjs"),
		import("./failureReports-BVufgM3l.mjs"),
		import("./runtime.server-BUbb281Z.mjs")
	]);
	const { runtime } = await prepareConfig();
	return listFailureReports(await requireFeature(runtime, "insights"), data);
});
//#endregion
export { getUpdateFailuresRpc_createServerFn_handler, listFailureReportsRpc_createServerFn_handler };
