import { r as recoveryWindows } from "./insights-recovery-Cdg3Msrj.mjs";
import { n as readFailureReportsInput } from "./insights-errors-DwUaDs0Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/failureReports-BVufgM3l.js
/** Bounded raw-event reads, with continuation even when a batch finds no failures. */
async function listFailureReports(reads, input) {
	readFailureReportsInput(input);
	const { rawDays } = await reads.getRetention();
	const duration = Math.min(90 * 864e5, rawDays * 864e5, input.window ? recoveryWindows[input.window].durationMs : Infinity);
	const sinceMs = Math.max(0, input.beforeReceivedAtMs - duration);
	const data = [];
	let cursor = input.cursor;
	let scanned = 0;
	for (let batch = 0; batch < 5; batch += 1) {
		const page = await reads.listEvents({
			sinceMs,
			beforeReceivedAtMs: input.beforeReceivedAtMs,
			limit: 100,
			...cursor === void 0 ? {} : { cursor }
		});
		scanned += page.data.length;
		data.push(...page.data.filter((event) => event.type === "UPDATE_FAILED" && (input.platform === "all" || event.platform === input.platform) && event.channel === input.channel && (input.releaseId === void 0 || event.failure?.stage !== "check" && event.toReleaseId === input.releaseId)));
		cursor = page.nextCursor ?? void 0;
		if (!cursor || data.length >= 50) break;
	}
	return {
		data,
		scanned,
		sinceMs,
		nextCursor: cursor ?? null
	};
}
//#endregion
export { listFailureReports };
