//#region node_modules/.nitro/vite/services/ssr/assets/databaseConfig-B56IJxlu.js
/** Whether a configured database is a self-hosted server's. */
var isRemoteDatabase = (value) => typeof value === "object" && value !== null && "core" in value && "fetchAdmin" in value;
//#endregion
export { isRemoteDatabase as t };
