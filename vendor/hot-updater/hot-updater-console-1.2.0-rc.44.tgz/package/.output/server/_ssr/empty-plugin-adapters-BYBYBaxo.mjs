//#region node_modules/.nitro/vite/services/ssr/assets/empty-plugin-adapters-BYBYBaxo.js
var pluginSerializationAdapters = [];
var hasPluginAdapters = false;
//#endregion
export { hasPluginAdapters, pluginSerializationAdapters };
