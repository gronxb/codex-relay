import { t as createMiddleware } from "./createMiddleware-C3ACsfuG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/console-access-mW5AcyIb.js
/**
* Refuses a caller the console does not authorize before a server function
* reads its input. TanStack Start runs a function's middleware before the
* function's own validator, so an anonymous or unlisted caller gets the access
* check's 401 or 403, never an input error, whatever it sends. Every server
* function except the sign-in reads in `auth-rpc.ts` uses it, and
* `console-access.spec.ts` checks that.
*/
var consoleAccess = createMiddleware({ type: "function" }).server(async ({ next }) => {
	const [{ getRequest }, { requireConsoleAccess }] = await Promise.all([import("../_libs/_.mjs").then((n) => n.t), import("./auth.server-BtwE9LLM.mjs")]);
	await requireConsoleAccess(getRequest());
	return next();
});
//#endregion
export { consoleAccess as t };
