import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { F as FingerprintPattern, V as Copy, k as KeyRound, x as Package } from "../_libs/lucide-react.mjs";
import { t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as HashValueDisplay } from "./HashValueDisplay-BAS89lvP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/TargetDisplay-CwHH2uJ2.js
var import_jsx_runtime = require_jsx_runtime();
/** A command or link on one line, with a button that copies it. */
function CopyableText({ label, value, wrap = false }) {
	const copy = async () => {
		try {
			await navigator.clipboard.writeText(value);
			toast.success("Copied to clipboard");
		} catch {
			toast.error(`Could not copy ${label}`);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-full min-w-0 items-center gap-2 rounded-md border bg-muted/40 py-1 pr-1 pl-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: wrap ? "min-w-0 flex-1 text-left font-mono text-xs whitespace-normal sm:whitespace-nowrap" : "min-w-0 flex-1 overflow-x-auto text-left font-mono text-xs whitespace-nowrap",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			"aria-label": `Copy ${label}`,
			className: "size-11 sm:size-7",
			onClick: () => void copy(),
			size: "icon-sm",
			variant: "ghost",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { "aria-hidden": "true" })
		})]
	});
}
/** A hash behind its icon, shortened to `xxxxxxxx…xxxx` and copied on click. */
function IconHash({ icon: Icon, value, display }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
			display,
			maxLength: 12,
			value
		})]
	});
}
/** The cell of a missing value, such as an imported build's build key. */
function NoValue() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted-foreground",
		children: "-"
	});
}
/** An app version behind its icon, as the Target column shows one. */
function AppVersion({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-4 shrink-0 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: value
		})]
	});
}
/**
* What OTAs target: an app version, or a fingerprint. The Bundles table's
* Target column and a native build's show one release's target the same way,
* so the two compare at a glance. A native build also passes
* `nativeAppVersion`, the app version its artifact reports: a fingerprint
* build shows it over its fingerprint, so every build names its version in
* the column's width. Without one, as on a build registered before it was
* recorded, the fingerprint shows alone.
*/
function TargetDisplay({ appVersion, fingerprintHash, nativeAppVersion }) {
	if (appVersion) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppVersion, { value: appVersion });
	if (fingerprintHash) {
		const hash = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconHash, {
			icon: FingerprintPattern,
			value: fingerprintHash
		});
		if (!nativeAppVersion) return hash;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col items-start gap-3 sm:gap-1",
			"data-target-display": "",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				title: "The app version this build reports",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "App version "
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppVersion, { value: nativeAppVersion })]
			}), hash]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoValue, {});
}
/**
* A native build's build key, `nbk1:` and a SHA-256 of the build's inputs,
* shown past its prefix as a fingerprint is, and copied whole; none for an
* imported build.
*/
function BuildKeyDisplay({ value }) {
	return value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconHash, {
		display: value.replace(/^nbk1:/, ""),
		icon: KeyRound,
		value
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoValue, {});
}
//#endregion
export { TargetDisplay as i, CopyableText as n, NoValue as r, BuildKeyDisplay as t };
