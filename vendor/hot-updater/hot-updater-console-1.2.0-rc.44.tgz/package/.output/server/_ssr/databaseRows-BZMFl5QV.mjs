import { a as isDatabaseMetadataObject, t as DatabaseAdapterInputError } from "./databaseJsonValue-DuUoft8j.mjs";
import { a as getAssetBaseStorageUri, c as getManifestFileHash, l as getManifestStorageUri, s as getBundlePatches } from "./dist-CiOq3ygH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/databaseRows-BZMFl5QV.js
var bundleMetadataToRow = (metadata) => {
	if (metadata === void 0) return {};
	if (!isDatabaseMetadataObject(metadata)) throw new DatabaseAdapterInputError("invalid-data");
	return metadata;
};
var releaseRowToRelease = (row) => ({
	id: row.id,
	revision: row.revision,
	channelId: row.channel_id,
	platform: row.platform,
	kind: row.kind,
	bundleId: row.bundle_id,
	strategy: row.strategy,
	targetAppVersion: row.target_app_version,
	fingerprintHash: row.fingerprint_hash,
	enabled: row.enabled,
	shouldForceUpdate: row.should_force_update,
	message: row.message,
	rolloutCohortCount: row.rollout_cohort_count,
	targetCohorts: row.target_cohorts,
	operation: row.operation,
	sourceReleaseId: row.source_release_id,
	createdAtMs: row.created_at_ms,
	updatedAtMs: row.updated_at_ms
});
var bundleToRow = (bundle) => {
	const metadata = bundleMetadataToRow(bundle.metadata);
	return {
		id: bundle.id,
		platform: bundle.platform,
		git_commit_hash: bundle.gitCommitHash,
		metadata,
		manifest_storage_uri: getManifestStorageUri(bundle),
		manifest_file_hash: getManifestFileHash(bundle),
		asset_base_storage_uri: getAssetBaseStorageUri(bundle)
	};
};
var bundleToPatchRows = (bundle) => getBundlePatches(bundle).map((patch, orderIndex) => ({
	id: `${bundle.id}:${patch.baseBundleId}`,
	bundle_id: bundle.id,
	base_bundle_id: patch.baseBundleId,
	base_file_hash: patch.baseFileHash,
	patch_file_hash: patch.patchFileHash,
	patch_storage_uri: patch.patchStorageUri,
	byte_size: patch.byteSize,
	order_index: orderIndex
}));
var comparePatchRows = (left, right) => left.order_index - right.order_index || left.id.localeCompare(right.id);
var patchRowToArtifact = (row) => ({
	baseBundleId: row.base_bundle_id,
	baseFileHash: row.base_file_hash,
	byteSize: row.byte_size,
	patchFileHash: row.patch_file_hash,
	patchStorageUri: row.patch_storage_uri
});
var rowToBundle = (row, patchRows = []) => {
	const patches = patchRows.slice().sort(comparePatchRows).map(patchRowToArtifact);
	return {
		id: row.id,
		platform: row.platform,
		gitCommitHash: row.git_commit_hash,
		metadata: row.metadata,
		manifestStorageUri: row.manifest_storage_uri,
		manifestFileHash: row.manifest_file_hash,
		assetBaseStorageUri: row.asset_base_storage_uri,
		patches
	};
};
//#endregion
export { rowToBundle as i, bundleToRow as n, releaseRowToRelease as r, bundleToPatchRows as t };
