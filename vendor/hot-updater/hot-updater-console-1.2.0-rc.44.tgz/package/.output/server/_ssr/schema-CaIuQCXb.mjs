//#region node_modules/.nitro/vite/services/ssr/assets/schema-CaIuQCXb.js
var defineTable = (fields, options) => ({
	kind: "table",
	fields,
	key: options.key,
	derived: options.derived ?? {},
	indexes: options.indexes ?? {},
	...options.retention === void 0 ? {} : { retention: options.retention }
});
var defineAggregate = (fields, options) => ({
	kind: "aggregate",
	fields,
	key: options.key,
	counters: options.counters ?? [],
	gauges: options.gauges ?? [],
	distinct: options.distinct ?? [],
	shards: options.shards ?? 1,
	indexes: options.indexes ?? {},
	...options.batched ? { batched: true } : {},
	...options.retention === void 0 ? {} : { retention: options.retention }
});
//#endregion
export { defineTable as n, defineAggregate as t };
