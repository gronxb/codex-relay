import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { k as cn } from "./sidebar-COdOWPGC.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as tabsListVariants } from "./tabs-Bw-XniPE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/NativeBuildsNav-CPmrkQr0.js
var import_jsx_runtime = require_jsx_runtime();
/** A segment of a nav of links, the current one raised, as a tab is. */
var NAV_TAB_CLASS = "relative inline-flex h-full min-h-11 items-center justify-center rounded-md border border-transparent px-3 text-xs font-medium whitespace-nowrap text-foreground/60 transition-colors hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-none aria-[current=page]:bg-background aria-[current=page]:text-foreground aria-[current=page]:shadow-sm dark:text-muted-foreground dark:hover:text-foreground dark:aria-[current=page]:border-input dark:aria-[current=page]:bg-input/30 dark:aria-[current=page]:text-foreground";
/**
* The two views of Native builds: the builds, and the iOS devices ad hoc
* builds install on. Links, so each view has its own URL and Back works.
*/
function NativeBuildsNav({ current }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": "Native builds views",
		className: cn(tabsListVariants(), "h-auto min-h-11 sm:h-8 sm:min-h-0 [&>a]:min-h-11 sm:[&>a]:min-h-0"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			activeOptions: {
				exact: true,
				includeSearch: false
			},
			"aria-current": current === "builds" ? "page" : void 0,
			className: NAV_TAB_CLASS,
			to: "/native-builds",
			children: "Builds"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			activeOptions: {
				exact: true,
				includeSearch: false
			},
			"aria-current": current === "devices" ? "page" : void 0,
			className: NAV_TAB_CLASS,
			to: "/native-builds/devices",
			children: "iOS devices"
		})]
	});
}
//#endregion
export { NativeBuildsNav as n, NAV_TAB_CLASS as t };
