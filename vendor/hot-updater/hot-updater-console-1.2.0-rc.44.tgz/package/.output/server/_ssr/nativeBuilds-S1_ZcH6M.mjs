import { O as nativeBuildPathKey, b as nativeBuildChannel, k as nativeBuildScope, y as nativeBuildCatalogScopeKey } from "./native-builds-lEyKQemV.mjs";
import { n as readFold, t as foldedPage } from "./foldedPage-CUjJqtlF.mjs";
import { n as projectCompiledCatalog } from "./releaseCatalogCompiler-CJ2Shida.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nativeBuilds-S1_ZcH6M.js
/**
* One page newest first, from one keyset read: newest first for the next
* page, oldest first (then reversed) for the previous one. `next` is set
* for a full page, so the last page may lead to an empty one.
*/
async function keysetPage(read, keyOf, { before, after, limit }) {
	const data = after === void 0 ? await read({
		order: "desc",
		limit,
		...before === void 0 ? {} : { after: before }
	}) : [...await read({
		order: "asc",
		after,
		limit
	})].reverse();
	const first = data[0];
	const last = data.at(-1);
	const full = data.length === limit;
	return {
		data,
		...last !== void 0 && (after !== void 0 || full) ? { next: keyOf(last) } : {},
		...first !== void 0 && (after === void 0 ? before : full) ? { previous: keyOf(first) } : {}
	};
}
/** How many patches one page of a build's patches lists. */
var NATIVE_BUILD_PATCH_PAGE_SIZE = 20;
/**
* One page of the patches from a built-in bundle, newest target first: one
* read of the patches index. The patch rows carry what the page shows, so
* no bundle is read.
*/
function listNativeBuildPatches(core, minBundleId, page) {
	return keysetPage(async (input) => (await core.listPatchesFromBase(minBundleId, input)).map(({ bundle_id, byte_size }) => ({
		bundleId: bundle_id,
		byteSize: byte_size
	})), ({ bundleId }) => bundleId, page);
}
/**
* Everything a native build's page shows, in six reads at most: the build,
* then its built-in bundle, its scope's newest build and its mark, which a
* marked build's own row answers and a sandbox build skips, its scope's
* catalog, and one page of patches from it. A sandbox iOS build reads one
* more, its other install target. Null for an unknown ID.
*/
async function getNativeBuildDetail(core, id) {
	const build = await core.getNativeBuild(id);
	if (build === null) return null;
	const catalogScopeKey = nativeBuildCatalogScopeKey(build);
	const scope = nativeBuildScope(build);
	const [builtIn, newestInScope, storeBuildInScope, catalog, patches, sibling] = await Promise.all([
		core.getBundle(build.min_bundle_id),
		build.is_sandbox ? null : core.findNativeBuild(scope),
		build.is_sandbox ? null : build.is_store_build ? build : core.findNativeBuild(scope, { storeBuild: true }),
		core.getReleaseCatalogRow(catalogScopeKey),
		listNativeBuildPatches(core, build.min_bundle_id, { limit: 20 }),
		build.is_sandbox && build.platform === "ios" ? core.findNativeBuildSibling(build) : null
	]);
	const servedNow = catalog === null || catalog.is_tombstone ? [] : projectCompiledCatalog(JSON.parse(catalog.payload), build.app_version ?? void 0).filter(({ bundleId }) => bundleId !== null && bundleId >= build.min_bundle_id);
	return {
		build,
		channel: nativeBuildChannel(build),
		catalogScopeKey,
		builtInBundle: builtIn === null ? null : { childCount: builtIn.childCount },
		newestInScope,
		storeBuildInScope,
		servedNow,
		patches,
		sibling
	};
}
var protocolOf = (storageUri) => new URL(storageUri).protocol.replace(":", "");
/** The storage that holds `storageUri`, by its protocol. */
var storageFor = (storage, storageUri) => storage.protocol === protocolOf(storageUri) ? storage : void 0;
/** A public URL no storage owns, which is its own download URL. */
var isPublicUrl = (storageUri) => ["http", "https"].includes(protocolOf(storageUri));
/**
* The URL a build's artifact downloads from without the console's sign-in: the
* storage's download URL, which may expire. Null when the storage gives none.
*/
async function nativeBuildArtifactUrl(build, storage) {
	const storageUri = build.artifact_storage_uri;
	const adapter = storageFor(storage, storageUri);
	if (adapter?.getDownloadUrl !== void 0) return (await adapter.getDownloadUrl({ storageUri })).url;
	return adapter === void 0 && isPublicUrl(storageUri) ? storageUri : null;
}
/**
* The URL a phone downloads a native build's artifact from, without the
* console's sign-in: the storage's download URL, which may expire. Null
* when the storage gives none, or the build is gone.
*/
async function resolveNativeBuildDownloadUrl(id, { core, storage }) {
	const build = await core.getNativeBuild(id);
	return build === null ? null : nativeBuildArtifactUrl(build, storage);
}
/**
* What Android's browser offers to install. An upload stores it, so a redirect
* to the storage serves it too; a streamed download sets it, for a storage
* whose `get` keeps no type.
*/
var APK_CONTENT_TYPE = "application/vnd.android.package-archive";
var noStoreRedirect = (url) => new Response(null, {
	headers: {
		"cache-control": "private, no-store",
		location: url
	},
	status: 302
});
/**
* The URL a browser or script can fetch the object from by itself, or null
* when the storage gives none, or gives one only it can read. When the
* storage can't serve the object any other way, its failure stands.
*/
var publicDownloadUrl = async (adapter, storageUri) => {
	if (adapter.getDownloadUrl === void 0) return null;
	try {
		const { url } = await adapter.getDownloadUrl({ storageUri });
		return /^https?:\/\//iu.test(url) ? url : null;
	} catch (error) {
		if (adapter.get === void 0) throw error;
		console.warn(`Streaming a native build through the console: ${adapter.name} gave no download URL.`, error);
		return null;
	}
};
/**
* Downloads a native build's artifact: a redirect to the storage's download
* URL, or, when the storage gives no URL a browser can fetch, the object
* streamed through the console, whose host then serves every byte. The
* redirect is resolved on each request, so the console's link never expires.
*/
async function downloadNativeBuild(id, { core, storage }) {
	const build = await core.getNativeBuild(id);
	if (build === null) return new Response("Build not found", { status: 404 });
	const storageUri = build.artifact_storage_uri;
	const adapter = storageFor(storage, storageUri);
	const url = adapter && await publicDownloadUrl(adapter, storageUri);
	if (url) return noStoreRedirect(url);
	if (adapter?.get !== void 0) {
		const { response } = await adapter.get({ storageUri });
		if (!response) return new Response("Storage object not found", { status: 404 });
		const fileName = decodeURIComponent(storageUri.split("/").at(-1) ?? "");
		const headers = new Headers(response.headers);
		headers.set("cache-control", "private, no-store");
		if (build.artifact_kind === "apk") headers.set("content-type", APK_CONTENT_TYPE);
		headers.set("content-disposition", `attachment; filename="${fileName.replace(/[^\w.-]/gu, "_")}"; filename*=UTF-8''${encodeURIComponent(fileName)}`);
		return new Response(response.body, {
			headers,
			status: response.status,
			statusText: response.statusText
		});
	}
	if (adapter === void 0 && isPublicUrl(storageUri)) return noStoreRedirect(storageUri);
	return new Response(`No storage adapter for protocol: ${protocolOf(storageUri)}`, { status: 503 });
}
/**
* The most rows one page or fold reads looking above its own rows for a
* newer build on a path, of its read budget, so its own rows keep the rest.
*/
var SIBLING_READ_CAP = 100;
/**
* Finds the nearest build newer than each of some builds on its
* distribution path, by each channel's own index, read upward from where
* its caller starts and kept, so each channel's rows are read once. The
* channels are read side by side. Newer is the registry's order: a greater
* ID. A path is the channel, platform, sandbox flag and distribution
* (`nativeBuildPathKey`), worked out from the row, so a build registered at
* any time is found. It spends `budget`, at most `SIBLING_READ_CAP` rows in
* all, shared out among the channels: a build it can't find a newer one for
* within that has none it knows of.
*/
var newerOnPathFinder = (core) => {
	const channels = /* @__PURE__ */ new Map();
	let spent = 0;
	const lookUp = async (build, from, share) => {
		let channel = channels.get(build.channel_id);
		if (channel === void 0 || from < channel.from) {
			channel = {
				from,
				rows: [],
				ended: false
			};
			channels.set(build.channel_id, channel);
		}
		const key = nativeBuildPathKey(build);
		for (;;) {
			const newer = channel.rows.find((row) => row.id > build.id && nativeBuildPathKey(row) === key);
			if (newer !== void 0) return newer;
			const limit = Math.min(50, share.left);
			if (channel.ended || limit <= 0) return void 0;
			const rows = await core.listNativeBuilds({
				channelId: build.channel_id,
				order: "asc",
				after: channel.last ?? channel.from,
				limit
			});
			share.left -= rows.length;
			channel.rows.push(...rows);
			channel.last = rows.at(-1)?.id ?? channel.last;
			if (rows.length < limit) channel.ended = true;
		}
	};
	return async (builds, from, budget) => {
		const byChannel = /* @__PURE__ */ new Map();
		for (const build of builds) byChannel.set(build.channel_id, [...byChannel.get(build.channel_id) ?? [], build]);
		const allowance = Math.max(0, Math.min(budget.left, SIBLING_READ_CAP - spent));
		const share = Math.floor(allowance / Math.max(byChannel.size, 1));
		const found = /* @__PURE__ */ new Map();
		const total = (await Promise.all([...byChannel.values()].map(async (channelBuilds) => {
			const left = { left: share };
			for (const build of channelBuilds) found.set(build.id, await lookUp(build, from, left));
			return share - left.left;
		}))).reduce((sum, rows) => sum + rows, 0);
		budget.left -= total;
		spent += total;
		return found;
	};
};
/**
* One page of native builds, newest first, that leads with the newest build
* of each distribution path, and the store build: every other build folds
* into the runs between them. It reads the registry's ID index, or its
* channel index, a chunk at a time, and on a later page each path's newer
* builds above the page in its channel's index, at most
* `FOLDED_PAGE_READ_BUDGET` rows in all.
*/
function listNativeBuildFolds(core, { channelId, before, after }) {
	const findNewer = newerOnPathFinder(core);
	const seen = /* @__PURE__ */ new Map();
	return foldedPage({
		read: (input) => core.listNativeBuilds({
			...input,
			...channelId === void 0 ? {} : { channelId }
		}),
		classify: async (builds, { budget, order, newerThan }) => {
			const ordinary = /* @__PURE__ */ new Set();
			if (order === "asc") {
				const newer = await findNewer(builds, builds[0].id, budget);
				for (const build of builds) if (build.is_store_build || newer.get(build.id) === void 0) ordinary.add(build.id);
				return ordinary;
			}
			const firsts = [];
			const keys = new Set(seen.keys());
			for (const build of builds) {
				const key = nativeBuildPathKey(build);
				if (!keys.has(key)) {
					keys.add(key);
					firsts.push(build);
				}
			}
			const above = newerThan === void 0 ? /* @__PURE__ */ new Map() : await findNewer(firsts, newerThan, budget);
			for (const build of builds) {
				const key = nativeBuildPathKey(build);
				const newer = seen.get(key) ?? above.get(build.id);
				if (!seen.has(key)) seen.set(key, build);
				if (build.is_store_build || newer === void 0) ordinary.add(build.id);
			}
			return ordinary;
		},
		...before === void 0 ? {} : { before },
		...after === void 0 ? {} : { after }
	});
}
/**
* One chunk of a fold's builds, as `listNativeBuildFolds` folded them: the
* builds under `from` down to `to`, and each one's nearest newer build,
* read from its channel's index upward within the read budget.
*/
async function readNativeBuildFold(core, { channelId, ...fold }) {
	const chunk = await readFold({
		read: (input) => core.listNativeBuilds({
			...input,
			...channelId === void 0 ? {} : { channelId }
		}),
		...fold
	});
	const budget = { left: 200 - chunk.rows.length };
	const oldest = chunk.rows.at(-1)?.id;
	const found = oldest === void 0 ? /* @__PURE__ */ new Map() : await newerOnPathFinder(core)(chunk.rows, oldest, budget);
	const newer = {};
	for (const [id, row] of found) if (row !== void 0) newer[id] = row;
	return {
		...chunk,
		newer
	};
}
//#endregion
export { NATIVE_BUILD_PATCH_PAGE_SIZE, downloadNativeBuild, getNativeBuildDetail, listNativeBuildFolds, listNativeBuildPatches, nativeBuildArtifactUrl, readNativeBuildFold, resolveNativeBuildDownloadUrl };
