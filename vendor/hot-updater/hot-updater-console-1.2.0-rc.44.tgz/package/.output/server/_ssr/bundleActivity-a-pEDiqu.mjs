//#region node_modules/.nitro/vite/services/ssr/assets/bundleActivity-a-pEDiqu.js
async function getBundleActivity(model, inputs) {
	if (inputs.length === 0) return {};
	const releases = inputs.map((input) => ({
		releaseId: input.releaseId,
		platform: input.platform,
		channel: input.channel
	}));
	const activity = await model.getReleaseActivity({ releases });
	return Object.fromEntries(activity.data.flatMap((item) => item.release === void 0 ? [] : [[item.release.releaseId, {
		downloads: item.metrics.downloads,
		launched: item.metrics.applies,
		failedLaunches: item.metrics.failedLaunches,
		measuredAtMs: activity.measuredAtMs
	}]]));
}
//#endregion
export { getBundleActivity };
