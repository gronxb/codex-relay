import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-keys-rpc-B71HN7wb.js
var parseName = (input) => {
	const name = typeof input === "object" && input !== null ? Reflect.get(input, "name") : void 0;
	if (typeof name !== "string") throw new TypeError("API key name must be a string.");
	return { name };
};
var parseId = (input) => {
	const id = typeof input === "object" && input !== null ? Reflect.get(input, "id") : void 0;
	if (typeof id !== "string" || !/^api-[A-Za-z0-9_-]{43}$/u.test(id)) throw new TypeError("Invalid API key id.");
	return { id };
};
/** API key management, once the console's access check and the feature guard pass. */
var apiKeyManagement = async () => {
	const [{ prepareConfig }, { requireFeature }] = await Promise.all([import("./config.server-CvAlgb8E.mjs"), import("./runtime.server-BUbb281Z.mjs")]);
	const { runtime } = await prepareConfig();
	return requireFeature(runtime, "apiKeys");
};
var listApiKeysRpc_createServerFn_handler = createServerRpc({
	id: "2c7f3cdb9bd3cab2c026a48abdc84c362db0362924a08679052a325640aec56b",
	name: "listApiKeysRpc",
	filename: "src/lib/api-keys-rpc.ts"
}, (opts) => listApiKeysRpc.__executeServer(opts));
var listApiKeysRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(listApiKeysRpc_createServerFn_handler, async () => {
	return [...await (await apiKeyManagement()).list()].sort((left, right) => right.created_at_ms - left.created_at_ms);
});
var createApiKeyRpc_createServerFn_handler = createServerRpc({
	id: "68a2d94ee016be64936401f5eba60ab08a47ff373e1cf9de48e4413336e6034b",
	name: "createApiKeyRpc",
	filename: "src/lib/api-keys-rpc.ts"
}, (opts) => createApiKeyRpc.__executeServer(opts));
var createApiKeyRpc = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator(parseName).handler(createApiKeyRpc_createServerFn_handler, async ({ data }) => {
	const created = await (await apiKeyManagement()).create({ name: data.name });
	return {
		apiKey: created.apiKey,
		record: created.record
	};
});
var revokeApiKeyRpc_createServerFn_handler = createServerRpc({
	id: "a1cb80b19ca72a64fb631ca28ebb9b6941db245983de082d5dd3203ec2eef795",
	name: "revokeApiKeyRpc",
	filename: "src/lib/api-keys-rpc.ts"
}, (opts) => revokeApiKeyRpc.__executeServer(opts));
var revokeApiKeyRpc = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator(parseId).handler(revokeApiKeyRpc_createServerFn_handler, async ({ data }) => {
	const revoked = await (await apiKeyManagement()).revoke({ id: data.id });
	if (revoked === null) throw new Error("API key not found.");
	return revoked;
});
//#endregion
export { createApiKeyRpc_createServerFn_handler, listApiKeysRpc_createServerFn_handler, revokeApiKeyRpc_createServerFn_handler };
