import { n as sameSecret } from "./local-console-Dtxlsav0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/deviceProfileToken-xzDLfE0T.js
/**
* Signed, short-lived tokens for an iPhone's profile flow, which runs where
* the Console's session isn't: Safari's profile download and the Settings app's
* answer carry no cookie. A token holds what it grants and its expiry, and the
* Console stores nothing.
*
* - The capability (`t`) lets the profile routes serve one profile and take
*   one answer for a signed-in person: `register` saves the iPhone as
*   requested, `identify` only tells the build page which iPhone it is.
* - The receipt (`r`) is what the profile's answer hands back, in the page's
*   fragment: it names the UDID the profile read and whose session asked, so
*   Request access takes the UDID from it, never from a link anyone can craft.
* - The kept receipt says the same for 30 days, in an HttpOnly cookie the
*   page trades the fragment's receipt for, so that Safari can request this
*   iPhone again without the profile, for the same person only.
*/
/** Separates these tokens' key from every other use of the Console's secret. */
var KEY_CONTEXT = "hot-updater/console/device-profile/v1";
/** How long a capability works: one profile install. */
var DEVICE_PROFILE_TOKEN_TTL_MS = 900 * 1e3;
/** How long a receipt works, from the profile's answer to Request access. */
var DEVICE_RECEIPT_TTL_MS = 3600 * 1e3;
/** How long Safari keeps the proof of this iPhone, in its cookie. */
var KEPT_DEVICE_RECEIPT_TTL_MS = 720 * 60 * 60 * 1e3;
var encoder = new TextEncoder();
var base64Url = (bytes) => btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
var fromBase64Url = (text) => Uint8Array.from(atob(text.replaceAll("-", "+").replaceAll("_", "/")), (char) => char.charCodeAt(0));
var hmac = async (key, message) => new Uint8Array(await crypto.subtle.sign("HMAC", await crypto.subtle.importKey("raw", key, {
	name: "HMAC",
	hash: "SHA-256"
}, false, ["sign"]), encoder.encode(message)));
var signatureOf = async (secret, body) => base64Url(await hmac(await hmac(encoder.encode(secret), KEY_CONTEXT), body));
var sign = async (secret, purpose, payload, expiresAtMs) => {
	const body = base64Url(encoder.encode(JSON.stringify({
		...payload,
		p: purpose,
		x: Math.floor(expiresAtMs)
	})));
	return `${body}.${await signatureOf(secret, body)}`;
};
var TOKEN = /^([A-Za-z0-9_-]{1,2048})\.([A-Za-z0-9_-]{43})$/u;
/**
* The payload of a token signed for `purpose`, `expired`, or `invalid`. The
* expiry counts only under a signature that holds.
*/
var verify = async (secret, purpose, token, now) => {
	const match = TOKEN.exec(token);
	if (match === null) return "invalid";
	const [, body, signature] = match;
	if (!sameSecret(signature, await signatureOf(secret, body))) return "invalid";
	let payload;
	try {
		payload = JSON.parse(new TextDecoder().decode(fromBase64Url(body)));
	} catch {
		return "invalid";
	}
	if (typeof payload !== "object" || payload === null || payload.p !== purpose || typeof payload.x !== "number") return "invalid";
	return now >= payload.x ? "expired" : payload;
};
var PROFILE_PURPOSE = "device-profile";
var RECEIPT_PURPOSE = "device-receipt";
var KEPT_RECEIPT_PURPOSE = "device-receipt-kept";
var createDeviceProfileToken = (secret, grant, now = Date.now()) => sign(secret, PROFILE_PURPOSE, grant, now + DEVICE_PROFILE_TOKEN_TTL_MS);
var verifyDeviceProfileToken = async (secret, token, now = Date.now()) => {
	const verified = await verify(secret, PROFILE_PURPOSE, token, now);
	if (typeof verified === "string") return verified;
	if (verified.m !== "register" && verified.m !== "identify" || typeof verified.e !== "string" || verified.n !== void 0 && typeof verified.n !== "string" || verified.b !== void 0 && typeof verified.b !== "string") return "invalid";
	return {
		m: verified.m,
		e: verified.e,
		...verified.n === void 0 ? {} : { n: verified.n },
		...verified.b === void 0 ? {} : { b: verified.b }
	};
};
var createDeviceReceipt = (secret, receipt, now = Date.now()) => sign(secret, RECEIPT_PURPOSE, receipt, now + DEVICE_RECEIPT_TTL_MS);
var verifyDeviceReceipt = async (secret, token, now = Date.now()) => {
	const verified = await verify(secret, RECEIPT_PURPOSE, token, now);
	if (typeof verified === "string") return verified;
	if (typeof verified.u !== "string" || typeof verified.e !== "string") return "invalid";
	return {
		u: verified.u,
		e: verified.e
	};
};
var createKeptDeviceReceipt = (secret, receipt, now = Date.now()) => sign(secret, KEPT_RECEIPT_PURPOSE, receipt, now + KEPT_DEVICE_RECEIPT_TTL_MS);
var verifyKeptDeviceReceipt = async (secret, token, now = Date.now()) => {
	const verified = await verify(secret, KEPT_RECEIPT_PURPOSE, token, now);
	if (typeof verified === "string") return verified;
	if (typeof verified.u !== "string" || typeof verified.e !== "string") return "invalid";
	return {
		u: verified.u,
		e: verified.e
	};
};
//#endregion
export { createKeptDeviceReceipt as a, verifyKeptDeviceReceipt as c, createDeviceReceipt as i, KEPT_DEVICE_RECEIPT_TTL_MS as n, verifyDeviceProfileToken as o, createDeviceProfileToken as r, verifyDeviceReceipt as s, DEVICE_PROFILE_TOKEN_TTL_MS as t };
