import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as requireConsoleFeature } from "./console-features-api-DbEAU6JB.mjs";
import { i as validateDistributionSearch } from "./insights-search-BZ00lACC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights_.distribution-C-cLCobe.js
var $$splitComponentImporter = () => import("./insights_.distribution-CswHCPCC.mjs");
var $$splitNotFoundComponentImporter = () => import("./insights_.distribution-e1SO9twP.mjs");
/** How a distribution row's bundle reads aloud. */
/** The bundle an app version's native build shipped, by its ID. */
var Route = createFileRoute("/insights_/distribution")({
	beforeLoad: ({ context }) => requireConsoleFeature(context.queryClient, "insightsAnalytics"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	validateSearch: validateDistributionSearch
});
//#endregion
export { Route as t };
