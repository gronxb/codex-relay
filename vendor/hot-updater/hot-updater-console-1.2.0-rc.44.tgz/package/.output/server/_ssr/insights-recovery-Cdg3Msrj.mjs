//#region node_modules/.nitro/vite/services/ssr/assets/insights-recovery-Cdg3Msrj.js
var recoveryWindows = {
	"24h": {
		durationMs: 864e5,
		intervalMs: 36e5
	},
	"7d": {
		durationMs: 7 * 864e5,
		intervalMs: 6 * 36e5
	},
	"30d": {
		durationMs: 30 * 864e5,
		intervalMs: 864e5
	}
};
/**
* Where a period ends: the end of the current UTC hour, as the server's
* reporting overview ends. The counters keep whole hours, so this is the
* latest end that still counts a report received just now; every Insights
* card ends here, so their numbers cover the same hours.
*/
var insightsPeriodEnd = (now) => Math.ceil(now / 36e5) * 36e5;
function readRecoveryInput(input) {
	if (!input || input.platform !== "ios" && input.platform !== "android" || typeof input.channel !== "string" || !input.channel.trim() || input.channel.length > 1024 || !Object.hasOwn(recoveryWindows, input.window) || input.releaseId !== void 0 && (typeof input.releaseId !== "string" || !input.releaseId.trim() || input.releaseId.length > 1024)) throw new Error("Choose a platform, channel, and time window.");
	return input;
}
//#endregion
export { readRecoveryInput as n, recoveryWindows as r, insightsPeriodEnd as t };
