import { a as decodeChannelKey, i as createReleaseCatalogScopeKey, o as encodeChannelKey, r as canonicalizeAppVersion } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-builds-lEyKQemV.js
/**
* `value` as one POSIX shell word: as it is when it holds only characters
* no shell treats specially, else in single quotes, so a file name or link
* the Console shows in a command can't run anything when it is pasted.
*/
var shellQuote = (value) => /^[\w@%+=:,./-]+$/.test(value) ? value : `'${value.replaceAll("'", `'\\''`)}'`;
/** How each artifact installs, as the Console's install dialog shows it. */
var nativeBuildArtifacts = {
	apk: {
		label: "APK",
		installs: "Android device or emulator"
	},
	aab: {
		label: "AAB",
		installs: "Google Play or bundletool"
	},
	app: {
		label: "Simulator app",
		installs: "iOS Simulator"
	},
	ipa: {
		label: "IPA",
		installs: "registered iOS devices"
	}
};
/** A build's distribution, from its row. */
var nativeBuildDistribution = (build) => build.submitted_to ?? (build.artifact_kind === "ipa" && build.export_method !== null ? `ipa-${build.export_method}` : build.artifact_kind);
/** The distribution path a build is on, as one key. */
var nativeBuildPathKey = (build) => JSON.stringify([
	build.channel_id,
	build.platform,
	build.is_sandbox,
	nativeBuildDistribution(build)
]);
/** A platform's name as the console shows it. */
var platformLabel = (platform) => platform === "ios" ? "iOS" : "Android";
/**
* A build as the CLI names it, such as `iOS 1.7.0 (66)`: the store's label
* when a store took it, else its app version, the one its artifact reports
* on a fingerprint build, and build number. Null when it reports neither,
* for the caller to name it another way.
*/
var nativeBuildLabel = (build) => {
	const label = build.submitted_version ?? [build.app_version ?? build.native_app_version ?? null, build.build_number === null ? null : `(${build.build_number})`].filter((part) => part !== null).join(" ");
	return label === "" ? null : `${platformLabel(build.platform)} ${label}`;
};
/** The console route that redirects to a build's artifact in storage. */
var nativeBuildDownloadPath = (id) => `/api/native-builds/${encodeURIComponent(id)}/download`;
/**
* A build's signed download link, under the console's path on the page's own
* address, whatever the page, so it opens where the person who copied it
* reached the console.
*/
var nativeBuildSignedDownloadUrl = (location, id, token) => {
	return `${location.origin}${consolePathOf(location, id)}${nativeBuildDownloadPath(id)}?t=${encodeURIComponent(token)}`;
};
/**
* The console's own path, from a page of build `id` under it: empty at the
* root of its host.
*/
var consolePathOf = (location, id) => {
	const page = nativeBuildDetailPath(id);
	return location.pathname.endsWith(page) ? location.pathname.slice(0, -page.length) : "";
};
/**
* The Console's own path, from where the browser is and where the router says
* it is: the prefix a host serves the Console under, or empty at its root.
*/
var consolePathFromRouter = (location, routerPathname) => {
	const path = location.pathname.replace(/\/$/u, "");
	const route = routerPathname.replace(/\/$/u, "");
	return path.endsWith(route) ? path.slice(0, path.length - route.length) : "";
};
/**
* The Console's own path, from one of its Native builds pages, where the
* profile's answer lands: empty at the root of its host.
*/
var consolePathOfNativeBuildsPage = (location) => {
	const at = location.pathname.lastIndexOf("/native-builds");
	return at < 0 ? "" : location.pathname.slice(0, at);
};
/** The console page of one native build. */
var nativeBuildDetailPath = (id) => `/native-builds/${encodeURIComponent(id)}`;
/**
* How long an Install button's link works. It sits in the `itms-services` URL,
* Safari's history and the installer's logs, and its holder can fetch the IPA
* with every UDID in its profile, so it lasts only as long as an install takes.
*/
var NATIVE_BUILD_INSTALL_LINK_TTL_MS = 3600 * 1e3;
/** This iPhone's own copy of its UDID, as its profile reported it. */
var IOS_UDID_STORAGE_KEY = "hot-updater-ios-udid";
/**
* This iPhone's receipt of its UDID: what its profile's answer signed for the
* signed-in person, which Request access takes.
*/
var IOS_DEVICE_RECEIPT_STORAGE_KEY = "hot-updater-ios-device-receipt";
/**
* The profile answer's fresh receipt, in this tab's session storage only until
* the page has traded it for the HttpOnly cookie: a reload during an outage
* can still trade it. Gone once traded, or once it has expired.
*/
var IOS_DEVICE_PENDING_RECEIPT_KEY = "hot-updater-ios-device-pending-receipt";
/** When a signed receipt expires, from its own body, or 0 when unreadable. */
var receiptExpiresAtMs = (receipt) => {
	try {
		const body = receipt.split(".")[0].replaceAll("-", "+").replaceAll("_", "/");
		const x = JSON.parse(atob(body)).x;
		return typeof x === "number" ? x : 0;
	} catch {
		return 0;
	}
};
/** The pending receipt this tab holds for `udid`, unexpired, or null. */
var readPendingReceipt = (udid) => {
	try {
		const kept = JSON.parse(window.sessionStorage.getItem("hot-updater-ios-device-pending-receipt") ?? "null");
		if (typeof kept?.receipt !== "string") return null;
		if (receiptExpiresAtMs(kept.receipt) <= Date.now()) {
			window.sessionStorage.removeItem(IOS_DEVICE_PENDING_RECEIPT_KEY);
			return null;
		}
		return udid !== null && kept.udid === udid ? kept.receipt : null;
	} catch {
		return null;
	}
};
var holdPendingReceipt = (udid, receipt) => {
	try {
		window.sessionStorage.setItem(IOS_DEVICE_PENDING_RECEIPT_KEY, JSON.stringify({
			udid,
			receipt
		}));
	} catch {}
};
/** Drops the pending receipt once it is traded, if it is this one. */
var releasePendingReceipt = (receipt) => {
	try {
		if (JSON.parse(window.sessionStorage.getItem("hot-updater-ios-device-pending-receipt") ?? "null")?.receipt === receipt) window.sessionStorage.removeItem(IOS_DEVICE_PENDING_RECEIPT_KEY);
	} catch {}
};
/** A device's UDID: 40 hex digits, or 8 and 16 joined by a hyphen. */
var IOS_UDID_PATTERN = /^(?:[0-9a-f]{40}|[0-9a-f]{8}-[0-9a-f]{16})$/iu;
/** The Console page of the iOS device registry, inside Native builds. */
var IOS_DEVICES_PATH = "/native-builds/devices";
/** The route that hands an iPhone the profile that reads its UDID. */
var IOS_DEVICE_PROFILE_PATH = "/_hot-updater/devices/device.mobileconfig";
/** Where iOS posts the profile's answer. */
var IOS_DEVICE_RESPONSE_PATH = "/_hot-updater/devices/device-response";
/** A device profile's link, under the Console's path on the page's own address. */
var iosDeviceProfileUrl = (consolePath, token) => `${consolePath}${IOS_DEVICE_PROFILE_PATH}?t=${encodeURIComponent(token)}`;
/** The command that registers requested iPhones from a terminal. */
var IOS_DEVICES_ADD_COMMAND = "npx hot-updater native-build devices add";
/** The UDID as the iOS devices page shows it: its last six characters. */
var maskIosUdid = (udid) => `…${udid.slice(-6)}`;
/** The route of a build's install manifest, as `itms-services` opens it. */
var nativeBuildManifestPath = (id) => `/_hot-updater/native-builds/${encodeURIComponent(id)}/manifest.plist`;
/**
* What an iPhone opens to install a build: the manifest's URL, signed with a
* token that also lets the installer download the IPA.
*/
var nativeBuildItmsUrl = (location, id, token) => {
	const manifest = `${location.origin}${consolePathOf(location, id)}${nativeBuildManifestPath(id)}?t=${encodeURIComponent(token)}`;
	return `itms-services://?action=download-manifest&url=${encodeURIComponent(manifest)}`;
};
var CHANNEL_ID_PREFIX = "channel:";
/** A channel row's ID, `channel:` and its channel key. */
var channelIdOf = (channel) => `${CHANNEL_ID_PREFIX}${encodeChannelKey(channel)}`;
/** The name of the channel a build embeds, decoded from its channel ID: no read. */
var nativeBuildChannel = (build) => decodeChannelKey(build.channel_id.slice(8));
/** The scope a build was registered in, as `findNativeBuild` takes it. */
var nativeBuildScope = (build) => build.fingerprint_hash === null ? {
	platform: build.platform,
	channel: nativeBuildChannel(build),
	fingerprintHash: null,
	appVersion: build.app_version ?? ""
} : {
	platform: build.platform,
	channel: nativeBuildChannel(build),
	fingerprintHash: build.fingerprint_hash,
	appVersion: null
};
/**
* The Release Catalog scope whose releases an install of the build is
* offered. A fingerprint build's scope key is that catalog's own key; an
* app-version build's adds its exact app version, which the catalog of
* every app version leaves out.
*/
var nativeBuildCatalogScopeKey = (build) => {
	const channelKey = build.channel_id.slice(8);
	return build.fingerprint_hash === null ? createReleaseCatalogScopeKey({
		channelKey,
		platform: build.platform,
		strategy: "APP_VERSION"
	}) : createReleaseCatalogScopeKey({
		channelKey,
		fingerprintHash: build.fingerprint_hash,
		platform: build.platform,
		strategy: "FINGERPRINT"
	});
};
/** What a sandbox build's page says of its built-in bundle as a patch base. */
var SANDBOX_NO_PATCH_BASE = "Deploys make no patches from a sandbox build's built-in bundle.";
/**
* The native build scope whose base new deploys of a release patch from, or
* null when it has none: a release of an app version range, rather than one
* exact version, targets many builds. The scope holds no sandbox build, which
* is no patch base.
*/
var releaseNativeBuildScope = (release) => {
	if (release.fingerprintHash !== null) return {
		platform: release.platform,
		channel: release.channel,
		fingerprintHash: release.fingerprintHash,
		appVersion: null
	};
	const target = release.targetAppVersion;
	if (target === null || canonicalizeAppVersion(target) !== target) return null;
	return {
		platform: release.platform,
		channel: release.channel,
		fingerprintHash: null,
		appVersion: target
	};
};
/**
* The artifact's file name, the last path segment of its storage URI, so a
* public URL's query or fragment stays out of it.
*/
var nativeBuildFileName = (build) => {
	const segment = (build.artifact_storage_uri.split(/[?#]/, 1)[0] ?? "").split("/").at(-1) ?? "";
	try {
		return decodeURIComponent(segment);
	} catch {
		return segment;
	}
};
var UNITS = [
	"B",
	"KB",
	"MB",
	"GB"
];
/** A byte count in the largest unit that keeps it at or above 1. */
var formatByteSize = (bytes) => {
	let value = bytes;
	let unit = 0;
	while (value >= 1024 && unit < UNITS.length - 1) {
		value /= 1024;
		unit += 1;
	}
	return `${unit === 0 ? value : value.toFixed(1)} ${UNITS[unit]}`;
};
/**
* The command that downloads a simulator build or an APK, installs it on the
* booted simulator or the connected device, and opens it, in the project with
* its `hot-updater.config.ts`.
*/
var nativeBuildInstallCommand = (build) => `npx hot-updater native-build install ${shellQuote(build.id)}`;
//#endregion
export { nativeBuildSignedDownloadUrl as A, nativeBuildFileName as C, nativeBuildManifestPath as D, nativeBuildLabel as E, shellQuote as F, readPendingReceipt as M, releaseNativeBuildScope as N, nativeBuildPathKey as O, releasePendingReceipt as P, nativeBuildDownloadPath as S, nativeBuildItmsUrl as T, maskIosUdid as _, IOS_DEVICE_RESPONSE_PATH as a, nativeBuildChannel as b, NATIVE_BUILD_INSTALL_LINK_TTL_MS as c, consolePathFromRouter as d, consolePathOf as f, iosDeviceProfileUrl as g, holdPendingReceipt as h, IOS_DEVICE_RECEIPT_STORAGE_KEY as i, platformLabel as j, nativeBuildScope as k, SANDBOX_NO_PATCH_BASE as l, formatByteSize as m, IOS_DEVICES_PATH as n, IOS_UDID_PATTERN as o, consolePathOfNativeBuildsPage as p, IOS_DEVICE_PROFILE_PATH as r, IOS_UDID_STORAGE_KEY as s, IOS_DEVICES_ADD_COMMAND as t, channelIdOf as u, nativeBuildArtifacts as v, nativeBuildInstallCommand as w, nativeBuildDetailPath as x, nativeBuildCatalogScopeKey as y };
