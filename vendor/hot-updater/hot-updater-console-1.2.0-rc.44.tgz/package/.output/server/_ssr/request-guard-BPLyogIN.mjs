import { t as guardLocalConsoleRequest } from "./local-console-Dtxlsav0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/request-guard-BPLyogIN.js
var session = process.env["HOT_UPDATER_CONSOLE_SESSION"] || void 0;
var port = process.env.NITRO_PORT || process.env.PORT || void 0;
var request_guard_default = (request) => guardLocalConsoleRequest(request, {
	session,
	port,
	checkHost: true
});
//#endregion
export { request_guard_default as default };
