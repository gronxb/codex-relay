//#region node_modules/.nitro/vite/services/ssr/assets/plistText-DkzlCfPI.js
var ESCAPES = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&apos;"
};
/**
* Text as an XML plist's `<string>` holds it. Control characters have no XML
* form at all, even escaped, so they go.
*/
var escapePlistText = (text) => [...text].filter((character) => character >= " " || "	\n\r".includes(character)).map((character) => ESCAPES[character] ?? character).join("");
//#endregion
export { escapePlistText as t };
