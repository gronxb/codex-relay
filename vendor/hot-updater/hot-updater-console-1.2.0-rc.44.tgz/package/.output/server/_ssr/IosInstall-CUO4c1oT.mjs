import { i as __toESM } from "../_runtime.mjs";
import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { D as LoaderCircle, _ as RefreshCw, i as TriangleAlert, p as Send, u as Smartphone } from "../_libs/lucide-react.mjs";
import { A as createSsrRpc, C as Skeleton, O as buttonVariants, n as Input, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { i as AlertTitle, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { a as FieldLabel, n as FieldDescription, r as FieldError, t as Field } from "./field-BVbdqLG6.mjs";
import { i as useQuery, n as useMutation, s as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { l as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as readPendingReceipt, P as releasePendingReceipt, T as nativeBuildItmsUrl, c as NATIVE_BUILD_INSTALL_LINK_TTL_MS, f as consolePathOf, g as iosDeviceProfileUrl, h as holdPendingReceipt, i as IOS_DEVICE_RECEIPT_STORAGE_KEY, o as IOS_UDID_PATTERN, p as consolePathOfNativeBuildsPage, s as IOS_UDID_STORAGE_KEY } from "./native-builds-lEyKQemV.mjs";
import { m as useNativeBuildInstallEligibilityQuery } from "./api-BISxaFip.mjs";
import { n as require_dayjs_min } from "../_libs/dayjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/IosInstall-CUO4c1oT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
var STATUSES = [
	"pending",
	"approved",
	"registered"
];
var record = (input) => {
	if (typeof input !== "object" || input === null) throw new TypeError("Invalid input.");
	return input;
};
var text = (input, field, max = 2048) => {
	const value = record(input)[field];
	if (typeof value !== "string" || value.length === 0 || value.length > max) throw new TypeError(`Invalid ${field}.`);
	return value;
};
/**
* The registry over the Console's own assembly, with the signed-in viewer's
* rights: the access check runs first, in the middleware and again here.
*/
/** The registry, or one status of it, with what the viewer may do. */
var getIosDevices = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => {
	const status = input?.status;
	if (status !== void 0 && !STATUSES.includes(status)) throw new TypeError("Invalid status.");
	return status === void 0 ? {} : { status };
}).handler(createSsrRpc("3a62744a539db57f5a29f39cec7fb03fd2817703b40d98e6da69e2f5e7ae6f3d"));
/**
* The registry's row of one UDID, or null: what an iPhone back from its
* profile reads of itself. One keyed read, whatever the list's filter. A
* POST, as the install check is, so the UDID stays out of the URL.
*/
var getIosDevice = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => ({ udid: text(input, "udid", 64) })).handler(createSsrRpc("7138a71df2ede8dd2c3db732d8d0ae10c56b85a8177dcdacf4e747b8087177c6"));
/**
* A new link to the profile that reads this iPhone's UDID: `register` saves
* it as requested under `name`, `identify` tells build `buildId`'s page which
* iPhone it is. A POST, since it signs the link.
*/
var createIosDeviceProfileLink = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => {
	const mode = record(input).mode;
	if (mode === "register") return {
		mode,
		name: text(input, "name", 100)
	};
	if (mode === "identify") return {
		mode,
		buildId: text(input, "buildId", 36)
	};
	throw new TypeError("Invalid mode.");
}).handler(createSsrRpc("4b173c2b2f5ea074a1f10862282308f11f5a043c044d64b6f63e6a29d571ec64"));
/** Approves a requested device, with its name: approvers only. */
var approveIosDevice = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => ({
	id: text(input, "id", 36),
	name: text(input, "name", 100)
})).handler(createSsrRpc("7908c24ccc2674ce07a553a645b8f4790889975a80f424a05d71a9fb8ab49787"));
/** Renames a device in the registry: approvers only. */
var renameIosDevice = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => ({
	id: text(input, "id", 36),
	name: text(input, "name", 100)
})).handler(createSsrRpc("4c92dfeae76a6fc898d6f38941eeedaec1f3d118f51a6f31ebf0bb1cea3fcea4"));
/**
* Removes a device from the registry: an approver any, the person who asked
* their own requested one. Apple keeps it.
*/
var removeIosDevice = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => ({ udid: text(input, "udid", 40) })).handler(createSsrRpc("8e37ec67413ceba554adb2d4b15e53682595a089d4b431ba7965d4347fb500fc"));
/**
* The devices an ad hoc build's IPA lists, read from its profile in storage,
* each with its registry name when the registry knows it: one row read, the
* IPA's few parts, and one page of the registry.
*/
var getNativeBuildIpaDevices = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({ id: text(input, "id", 36) })).handler(createSsrRpc("a11cb4014e6b23528f76382c43684798b0e84a6936aaba02c918e8f4e216e282"));
var iosDeviceKeys = {
	all: ["ios-devices"],
	list: (status) => ["ios-devices", status ?? "all"],
	device: (udid) => [
		"ios-devices",
		"device",
		udid
	],
	kept: (receipt) => [
		"ios-devices",
		"kept",
		receipt ?? ""
	],
	ipa: (buildId) => ["native-build-ipa-devices", buildId]
};
/**
* How long a profile link is used before the page signs a new one: its
* capability works 15 minutes, and a tester may leave the page open.
*/
var PROFILE_LINK_REFRESH_MS = 600 * 1e3;
/**
* The registry, one status or all, kept on screen while it reloads, so a
* filter change never blanks the table.
*/
function useIosDevicesQuery(status) {
	return useQuery({
		queryKey: iosDeviceKeys.list(status),
		queryFn: () => getIosDevices({ data: status === void 0 ? {} : { status } }),
		placeholderData: keepPreviousData
	});
}
/**
* This iPhone's registry row, by the UDID its profile reported, or null once
* it's gone; nothing is read without a UDID. Under `iosDeviceKeys.all`, so
* an approval or a removal reads it again.
*/
function useIosDeviceQuery(udid) {
	return useQuery({
		queryKey: iosDeviceKeys.device(udid ?? ""),
		queryFn: () => getIosDevice({ data: { udid } }),
		enabled: udid !== null
	});
}
/**
* A signed link to this iPhone's profile, signed again before it expires:
* the link stays a plain `<a href>`, so nothing waits on a request when it is
* tapped. The token signs its input, the name to register or the build to
* return to, so it has no data while another input's token loads: keeping
* the previous one would register the old name.
*/
function useIosDeviceProfileLinkQuery(input, enabled = true) {
	return useQuery({
		queryKey: ["ios-device-profile-link", input],
		queryFn: () => createIosDeviceProfileLink({ data: input }),
		enabled,
		staleTime: PROFILE_LINK_REFRESH_MS,
		refetchInterval: PROFILE_LINK_REFRESH_MS
	});
}
/** The devices an IPA lists, by registry name where it has one. */
function useNativeBuildIpaDevicesQuery(buildId) {
	return useQuery({
		queryKey: iosDeviceKeys.ipa(buildId),
		queryFn: () => getNativeBuildIpaDevices({ data: { id: buildId } })
	});
}
var useInvalidatingMutation = (mutationFn) => {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn,
		onSettled: async () => {
			await Promise.all([queryClient.invalidateQueries({ queryKey: iosDeviceKeys.all }), queryClient.invalidateQueries({ queryKey: ["native-build-install-eligibility"] })]);
		}
	});
};
var useApproveIosDeviceMutation = () => useInvalidatingMutation((input) => approveIosDevice({ data: input }));
var useRenameIosDeviceMutation = () => useInvalidatingMutation((input) => renameIosDevice({ data: input }));
var useRemoveIosDeviceMutation = () => useInvalidatingMutation((input) => removeIosDevice({ data: input }));
/** The routes this iPhone's kept proof is sent to, under the Console's path. */
var deviceRoute = (consolePath, name) => `${consolePath}/_hot-updater/devices/${name}`;
var sendDeviceRoute = async (url, init = {}) => {
	const { json, ...rest } = init;
	const response = await fetch(url, {
		credentials: "same-origin",
		...rest,
		...json === void 0 ? {} : {
			headers: { "content-type": "application/json" },
			body: JSON.stringify(json)
		}
	});
	const body = await response.json().catch(() => null);
	if (!response.ok || body === null) throw new Error(body?.error ?? `Request failed (${response.status}).`);
	return body;
};
/** Told when a trade sets the cookie, so a cached "no proof" is read again. */
var KEPT_EVENT = "hot-updater-ios-device-kept";
/**
* The same news for this Safari's other tabs, which share the cookie: a
* timestamp only, written where their `storage` event hears it.
*/
var KEPT_PING_KEY = "hot-updater-ios-device-kept";
/** Trades in flight or done, one per receipt: a failed one is forgotten. */
var trades = /* @__PURE__ */ new Map();
/**
* Trades the profile answer's fresh receipt for this Safari's HttpOnly cookie,
* wherever the answer lands: whatever the build page or the registry says, the
* proof is kept. One request per receipt while it is in flight or once it has
* succeeded; a failed one rejects and is forgotten, so the next refresh,
* refocus, or reload trades it again while it is still valid. Once traded,
* the receipt leaves this tab's session storage.
*/
var keepIosDeviceReceipt = (consolePath, receipt) => {
	let trade = trades.get(receipt);
	if (trade === void 0) {
		trade = sendDeviceRoute(deviceRoute(consolePath, "receipt"), {
			method: "POST",
			json: { receipt }
		}).then((answer) => {
			releasePendingReceipt(receipt);
			window.dispatchEvent(new Event(KEPT_EVENT));
			try {
				window.localStorage.setItem(KEPT_PING_KEY, String(Date.now()));
			} catch {}
			return answer;
		}, (error) => {
			trades.delete(receipt);
			throw error;
		});
		trades.set(receipt, trade);
	}
	return trade;
};
/**
* The UDID this Safari has proved for the signed-in person, from its HttpOnly
* cookie, or null, read after the page's fresh receipt, if any, is traded for
* it. Read on an iPhone only.
*/
function useKeptIosDeviceQuery(consolePath, receipt, enabled) {
	const queryClient = useQueryClient();
	(0, import_react.useEffect)(() => {
		const onKept = () => void queryClient.invalidateQueries({
			queryKey: iosDeviceKeys.kept(null),
			exact: true
		});
		const onStorage = (event) => {
			if (event.key === KEPT_PING_KEY) onKept();
		};
		window.addEventListener(KEPT_EVENT, onKept);
		window.addEventListener("storage", onStorage);
		return () => {
			window.removeEventListener(KEPT_EVENT, onKept);
			window.removeEventListener("storage", onStorage);
		};
	}, [queryClient]);
	return useQuery({
		queryKey: iosDeviceKeys.kept(receipt),
		queryFn: async () => {
			let failed = null;
			if (receipt !== null) await keepIosDeviceReceipt(consolePath, receipt).catch((error) => {
				failed = error;
			});
			const kept = await sendDeviceRoute(deviceRoute(consolePath, "receipt"));
			if (failed !== null && kept.udid === null) throw failed;
			return kept;
		},
		enabled,
		retry: false,
		staleTime: Number.POSITIVE_INFINITY
	});
}
/**
* Forgets this Safari's proof of its iPhone before sign-out, so the next
* person on this Safari starts from the profile. Only an iPhone or iPad holds
* one; a failure leaves the cookie, which the next email ignores anyway.
*/
var forgetKeptIosDevice = async (consolePath) => {
	await sendDeviceRoute(deviceRoute(consolePath, "receipt"), { method: "DELETE" }).catch(() => void 0);
};
/**
* Requests this iPhone for the signed-in person, under `name`: the UDID comes
* from the profile's fresh receipt when the page has one, else from the
* cookie that proved it before.
*/
var useRequestThisIphoneMutation = (consolePath) => useInvalidatingMutation((input) => sendDeviceRoute(deviceRoute(consolePath, "request"), {
	method: "POST",
	json: input.receipt === null ? { name: input.name } : {
		name: input.name,
		receipt: input.receipt
	}
}));
/** Whether the cookie's UDID is this iPhone's, whatever its case. */
var keptIsThisIphone = (kept, udid) => kept != null && udid !== null && kept.toLowerCase() === udid.toLowerCase();
/**
* What an install does to the App Store's copy of the app on this iPhone, with
* the same bundle ID. The one line to change after trying it on a real iPhone.
*/
var IOS_STORE_APP_NOTE = "With the same bundle ID, this install replaces the App Store's copy of the app on this iPhone.";
var ACTION_CLASS = "h-auto min-h-11 w-full min-w-0 py-2 whitespace-normal sm:min-h-8 sm:w-fit";
/** Whether this browser runs on an iPhone or iPad: an iPad says it is a Mac. */
var isIosBrowser = (browser) => /iPhone|iPod|iPad/u.test(browser.userAgent) || /Macintosh/u.test(browser.userAgent) && browser.maxTouchPoints > 1;
/**
* What the profile's answer passed back in the fragment: the UDID, with a
* receipt of it from a check, or `requested` from a registration.
*/
var fragmentOf = () => {
	if (typeof window === "undefined") return {
		udid: null,
		receipt: null,
		requested: false
	};
	const params = new URLSearchParams(window.location.hash.slice(1));
	const udid = params.get("udid");
	const valid = udid !== null && IOS_UDID_PATTERN.test(udid) ? udid : null;
	return {
		udid: valid,
		receipt: valid === null ? null : params.get("r"),
		requested: valid !== null && params.get("requested") === "1"
	};
};
var readKept = (key) => {
	try {
		return window.localStorage.getItem(key);
	} catch {
		return null;
	}
};
var keep = (key, value) => {
	try {
		window.localStorage.setItem(key, value);
	} catch {}
};
/**
* Whether this page is open on an iPhone, its UDID, and a receipt of it: the
* ones this phone kept, else the ones the profile's answer passed in the
* fragment, which are kept then, whether the answer opened this page or came
* back to it already open. Read after the page mounts: the server
* renders it without a browser. Null until then.
*/
/** Tells this page's `useIosDevice` that the ID it keeps was just written. */
var ADOPTED_EVENT = "hot-updater-ios-device-adopted";
/**
* Adopts the UDID this Safari's cookie names, when the page kept none: Safari
* wipes script storage after a week away while the 30-day HttpOnly cookie
* stays, and the cookie is the proof. Kept again, so every page knows it.
*/
var useAdoptKeptIosDevice = (device, kept) => {
	const adopt = device?.ios === true && device.udid === null && kept != null && IOS_UDID_PATTERN.test(kept) ? kept : null;
	(0, import_react.useEffect)(() => {
		if (adopt === null) return;
		keep(IOS_UDID_STORAGE_KEY, adopt);
		window.dispatchEvent(new Event(ADOPTED_EVENT));
	}, [adopt]);
};
var useIosDevice = () => {
	const [device, setDevice] = (0, import_react.useState)(null);
	const [passed] = (0, import_react.useState)(fragmentOf);
	(0, import_react.useEffect)(() => {
		const valid = (udid) => udid != null && IOS_UDID_PATTERN.test(udid) ? udid : null;
		let latest = passed;
		let answers = 0;
		const absorb = (fragment) => {
			const answered = fragment.receipt !== null || fragment.requested;
			if (fragment.udid !== null && answered) {
				answers += 1;
				keep(IOS_UDID_STORAGE_KEY, fragment.udid);
				if (fragment.receipt !== null) {
					holdPendingReceipt(fragment.udid, fragment.receipt);
					keepIosDeviceReceipt(consolePathOfNativeBuildsPage(window.location), fragment.receipt).catch(() => void 0);
				}
			}
			if (fragment.udid !== null && window.location.hash !== "") window.history.replaceState(window.history.state, "", `${window.location.pathname}${window.location.search}`);
		};
		absorb(passed);
		try {
			window.localStorage.removeItem(IOS_DEVICE_RECEIPT_STORAGE_KEY);
		} catch {}
		const read = () => {
			const udid = valid(readKept("hot-updater-ios-udid")) ?? latest.udid;
			const receipt = (latest.udid === udid ? latest.receipt : null) ?? readPendingReceipt(udid);
			const requested = latest.requested;
			const taken = answers;
			setDevice((current) => current !== null && current.udid === udid && current.receipt === receipt && current.requested === requested && current.answers === taken ? current : {
				ios: isIosBrowser(navigator),
				udid,
				receipt,
				requested,
				answers: taken
			});
		};
		read();
		const onStorage = (event) => {
			if (event.key === null || event.key === "hot-updater-ios-udid") read();
		};
		const onReturn = () => {
			const fragment = fragmentOf();
			if (fragment.udid !== null) {
				latest = fragment;
				absorb(fragment);
			}
			read();
		};
		window.addEventListener("storage", onStorage);
		window.addEventListener(ADOPTED_EVENT, read);
		window.addEventListener("hashchange", onReturn);
		window.addEventListener("pageshow", onReturn);
		document.addEventListener("visibilitychange", onReturn);
		return () => {
			window.removeEventListener("storage", onStorage);
			window.removeEventListener(ADOPTED_EVENT, read);
			window.removeEventListener("hashchange", onReturn);
			window.removeEventListener("pageshow", onReturn);
			document.removeEventListener("visibilitychange", onReturn);
		};
	}, [passed]);
	return device;
};
/**
* How long before its link expires the page stops offering it: the installer
* fetches the manifest, then the IPA, only after the tester confirms the prompt.
*/
var INSTALL_LINK_MARGIN_MS = 300 * 1e3;
/**
* Whether a link read at `readAtMs` is past offering, measured on this phone's
* clock from when it arrived, since the phone's clock may disagree with the
* server's. A failed refresh leaves `readAtMs` where it was. Timers stop while
* the phone sleeps, so coming back to the page checks again.
*/
var useInstallLinkExpired = (readAtMs, holdsLink) => {
	const [, check] = (0, import_react.useReducer)((count) => count + 1, 0);
	const expiresAtMs = readAtMs + NATIVE_BUILD_INSTALL_LINK_TTL_MS - INSTALL_LINK_MARGIN_MS;
	(0, import_react.useEffect)(() => {
		if (!holdsLink) return;
		const timer = setTimeout(check, Math.max(0, expiresAtMs - Date.now()));
		document.addEventListener("visibilitychange", check);
		window.addEventListener("pageshow", check);
		return () => {
			clearTimeout(timer);
			document.removeEventListener("visibilitychange", check);
			window.removeEventListener("pageshow", check);
		};
	}, [expiresAtMs, holdsLink]);
	return holdsLink && Date.now() >= expiresAtMs;
};
/** In place of Install once its link has expired: it never offers a dead link. */
function RenewInstallLink({ fetching, onRenew }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			role: "status",
			children: ["This install link has expired.", fetching ? " Getting a new one." : ""]
		}), fetching ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			className: ACTION_CLASS,
			onClick: onRenew,
			variant: "outline",
			children: "Get a new link"
		})]
	});
}
function InstallButton({ build, token }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: buttonVariants({ className: ACTION_CLASS }),
		href: nativeBuildItmsUrl(window.location, build.id, token),
		children: "Install"
	});
}
/** What a tester reads before Install opens the system's install prompt. */
function InstallNotes() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "On iOS 16 or later, the app opens only with Developer Mode on: Settings, Privacy & Security, Developer Mode."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: IOS_STORE_APP_NOTE
		})]
	});
}
/**
* The link that hands this iPhone the profile that reads its UDID, signed for
* this person, under the Console's path. A plain link, so iOS offers the
* profile; the page signs a new one before it expires. Once it's installed,
* the phone comes back to this page with the UDID and a receipt of it.
*/
function CheckThisIphone({ build, again = false }) {
	const link = useIosDeviceProfileLinkQuery({
		mode: "identify",
		buildId: build.id
	});
	if (link.data?.status === "no-secret") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-xs text-muted-foreground",
		role: "status",
		children: [
			"Set ",
			link.data.secretName,
			" on the Console to check iPhones from this page."
		]
	});
	if (link.data?.status !== "issued") return link.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "destructive",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "The check couldn't start" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Check your connection and try again." })
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
		className: ACTION_CLASS,
		disabled: link.isFetching,
		onClick: () => void link.refetch(),
		variant: "outline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Reload"]
	})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
		"aria-label": "Preparing the check",
		className: "h-11 w-full"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		className: buttonVariants({
			className: ACTION_CLASS,
			variant: again ? "secondary" : "default"
		}),
		href: iosDeviceProfileUrl(consolePathOf(window.location, build.id), link.data.token),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { "data-icon": "inline-start" }), again ? "Check this iPhone again" : "Check this iPhone"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: "Allow the download, then install it in Settings, where iOS calls it not signed. Nothing stays installed."
	})] });
}
var shortDate = (ms) => (0, import_dayjs_min.default)(ms).format("MMM D");
/**
* Apple's refusal of this iPhone, in its own words, and the one next step: the
* iOS devices page for an approver, unless this is that page, else whom to
* ask.
*/
function AppleRefusal({ device, canApprove, onDevicesPage = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Apple didn't register this iPhone" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: device.apple_error })
		] }), canApprove ? onDevicesPage ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			className: buttonVariants({
				className: ACTION_CLASS,
				variant: "outline"
			}),
			to: "/native-builds/devices",
			children: "iOS devices"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: device.status === "approved" ? "Ask a maintainer to free a device slot." : "Ask a maintainer to check it on the iOS devices page."
		})]
	});
}
/**
* What an iPhone the IPA doesn't list sees: the registry's word on it, or
* Request access, which takes the UDID from this person's receipt alone.
*/
function NotInThisBuild({ build, device, registry, newerBuild, canApprove, registryReadAt }) {
	const consolePath = consolePathOf(window.location, build.id);
	const request = useRequestThisIphoneMutation(consolePath);
	const kept = useKeptIosDeviceQuery(consolePath, device.receipt, device.ios && device.udid !== null && registry === null);
	const proved = device.receipt !== null || keptIsThisIphone(kept.data?.udid, device.udid);
	const [name, setName] = (0, import_react.useState)("");
	const [requested, setRequested] = (0, import_react.useState)(null);
	const standIn = requested !== null && registryReadAt <= requested.readBefore;
	const row = standIn ? requested.device : registry;
	const heading = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium",
			children: "Not in this build"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "This IPA was signed without this iPhone, and iOS won't install it here."
		})]
	});
	if (row !== null) {
		const newer = standIn ? null : newerBuild;
		if (row.apple_error !== null && newer === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppleRefusal, {
			canApprove,
			device: row
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-col gap-3",
			children: [
				heading,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					role: "status",
					children: row.status === "pending" ? `${row.name} was requested on ${shortDate(row.created_at_ms)}. A maintainer approves it next.` : newer !== null ? `A newer build has ${row.name}.` : `${row.name} is ${row.status}. It joins the next ad hoc build.`
				}),
				newer !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: buttonVariants({ className: ACTION_CLASS }),
					params: { buildId: newer },
					to: "/native-builds/$buildId",
					children: "Open the newer build"
				}) : null
			]
		});
	}
	if (!proved && kept.isPending && device.udid !== null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
		"aria-label": "Reading this iPhone",
		className: "h-11 w-full"
	});
	if (!proved) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-3",
		children: [
			heading,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Check this iPhone once more to request it for the next ad hoc build."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckThisIphone, {
				build,
				again: true
			})
		]
	});
	const trimmed = name.trim();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex min-w-0 flex-col gap-3",
		onSubmit: (event) => {
			event.preventDefault();
			if (trimmed === "") return;
			const readBefore = registryReadAt;
			request.mutate({
				receipt: device.receipt,
				name: trimmed
			}, { onSuccess: ({ device: saved }) => setRequested({
				device: saved,
				readBefore
			}) });
		},
		children: [
			heading,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				"data-invalid": request.isError || void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "ios-device-name",
						children: "This iPhone's name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						autoComplete: "off",
						className: "h-11 sm:h-8",
						id: "ios-device-name",
						maxLength: 100,
						onChange: (event) => setName(event.target.value),
						placeholder: "Kim's iPhone",
						value: name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "A maintainer approves it, and it joins the next ad hoc build." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: request.isError ? "The request didn't go through. Check this iPhone again, then try once more." : null })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
				className: ACTION_CLASS,
				disabled: trimmed === "" || request.isPending,
				type: "submit",
				children: [request.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					className: "animate-spin motion-reduce:animate-none",
					"data-icon": "inline-start"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { "data-icon": "inline-start" }), "Request access"]
			}),
			request.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckThisIphone, {
				again: true,
				build
			}) : null
		]
	});
}
/**
* Installing an IPA from this iPhone: the build's IPA says what it allows, read
* once when the page opens here, so a phone it doesn't list goes to Request
* access rather than a download iOS refuses at the end. App Store Connect isn't
* asked: a device registered after this IPA was signed still isn't in it.
*/
function IosInstall({ build, device }) {
	useAdoptKeptIosDevice(device, useKeptIosDeviceQuery(consolePathOf(window.location, build.id), device.receipt, device.ios && device.udid === null).data?.udid);
	const { udid } = device;
	const eligibility = useNativeBuildInstallEligibilityQuery(build.id, udid);
	const { refetch } = eligibility;
	const expired = useInstallLinkExpired(eligibility.dataUpdatedAt, eligibility.data?.status === "installable" && eligibility.data.device === "included");
	(0, import_react.useEffect)(() => {
		if (expired) refetch();
	}, [expired, refetch]);
	if (eligibility.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
		"aria-label": "Reading this IPA",
		className: "h-11 w-full"
	});
	const result = eligibility.data;
	if (result === void 0 || result.status === "unavailable") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Installation details unavailable" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "The Console couldn't read this IPA from storage in parts, which takes an HTTPS download link that answers Range requests. Other ways to install still work from a computer." })
	] });
	if (result.status === "store") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: build.is_sandbox ? "This IPA is an App Store export, which doesn't install from this page." : "This IPA is an App Store export, which installs through TestFlight, not from this page."
	});
	if (result.status === "expired") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "destructive",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "This build's profile has expired" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, { children: [
				"It expired on ",
				(0, import_dayjs_min.default)(result.expiresAt).format("YYYY-MM-DD"),
				". A maintainer rebuilds it to install again."
			] })
		]
	});
	const token = result.link.status === "issued" ? result.link.token : null;
	if (result.link.status === "no-secret") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-xs text-muted-foreground",
		role: "status",
		children: [
			"Set ",
			result.link.secretName,
			" on the Console to install from this page."
		]
	});
	if (token === null) return null;
	if (result.device === "included") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "In this build"
			}),
			expired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RenewInstallLink, {
				fetching: eligibility.isFetching,
				onRenew: () => void refetch()
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallButton, {
				build,
				token
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallNotes, {})
		]
	});
	if (result.device === "not-included") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotInThisBuild, {
		build,
		device,
		registry: result.registry,
		newerBuild: result.newerBuild,
		canApprove: result.canApprove,
		registryReadAt: eligibility.dataUpdatedAt
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-col gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Check this iPhone first"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "iOS installs this IPA only on the devices it lists. A profile reads this iPhone's ID, then Safari comes back here."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckThisIphone, { build })]
	});
}
//#endregion
export { useRequestThisIphoneMutation as _, isIosBrowser as a, useApproveIosDeviceMutation as c, useIosDeviceQuery as d, useIosDevicesQuery as f, useRenameIosDeviceMutation as g, useRemoveIosDeviceMutation as h, iosDeviceKeys as i, useIosDevice as l, useNativeBuildIpaDevicesQuery as m, IosInstall as n, keptIsThisIphone as o, useKeptIosDeviceQuery as p, forgetKeptIosDevice as r, useAdoptKeptIosDevice as s, AppleRefusal as t, useIosDeviceProfileLinkQuery as u };
