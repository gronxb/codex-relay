import { i as __toESM } from "../_runtime.mjs";
import { Et as require_react, Tt as require_jsx_runtime, i as SwitchRoot, r as SwitchThumb } from "../_libs/@base-ui/react+[...].mjs";
import { k as cn } from "./sidebar-COdOWPGC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/switch-DaBFthcN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* What a dialog opened for, kept while it animates closed. Closing clears
* the target at once, and without the kept one the dialog would empty or
* switch to another state, such as "Delete ?", during its exit animation.
*/
function useDialogTarget(target) {
	const [shown, setShown] = (0, import_react.useState)(target);
	if (target !== null && target !== shown) setShown(target);
	return target ?? shown;
}
/**
* A number that changes each time `open` turns true, to key a dialog's form
* so every opening starts from its props, even one that comes before the
* last close finished animating.
*/
function useOpenSession(open) {
	const [session, setSession] = (0, import_react.useState)(0);
	const [wasOpen, setWasOpen] = (0, import_react.useState)(open);
	if (open !== wasOpen) {
		setWasOpen(open);
		if (open) setSession(session + 1);
	}
	return session;
}
function Switch$1({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRoot, {
		"data-slot": "switch",
		className: cn("peer relative inline-flex h-5 w-9 shrink-0 after:absolute after:-inset-x-1.5 after:-inset-y-3.5 md:after:hidden cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background data-checked:bg-primary data-unchecked:bg-input data-disabled:cursor-not-allowed data-disabled:opacity-50", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, {
			"data-slot": "switch-thumb",
			className: "pointer-events-none block size-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-checked:translate-x-4 data-unchecked:translate-x-0"
		})
	});
}
//#endregion
export { useDialogTarget as n, useOpenSession as r, Switch$1 as t };
