//#region node_modules/.nitro/vite/services/ssr/assets/releaseManagement-CqIc-SDE.js
var ReleaseManagementError = class extends Error {
	code;
	name = "ReleaseManagementError";
	constructor(code, message) {
		super(message);
		this.code = code;
	}
};
//#endregion
export { ReleaseManagementError as t };
