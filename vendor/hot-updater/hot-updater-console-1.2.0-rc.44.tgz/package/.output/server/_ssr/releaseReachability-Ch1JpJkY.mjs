import { _ as isReleaseEligibleForCohort, r as NUMERIC_COHORT_SIZE } from "./dist-CiOq3ygH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/releaseReachability-Ch1JpJkY.js
var NON_TARGETED_COHORT = "release-catalog-non-targeted-cohort";
function collectReachableFromIndexes(catalog, indexes, reachableReleaseIds) {
	const descriptors = indexes.flatMap((index) => {
		const descriptor = catalog.releaseDescriptors[index];
		return descriptor === void 0 ? [] : [descriptor];
	});
	const cohorts = new Set([
		void 0,
		...Array.from({ length: NUMERIC_COHORT_SIZE }, (_, index) => String(index + 1)),
		...descriptors.flatMap(({ targetCohorts }) => targetCohorts),
		NON_TARGETED_COHORT
	]);
	for (const cohort of cohorts) {
		const selected = descriptors.find((descriptor) => descriptor.bundleId !== null && isReleaseEligibleForCohort(descriptor, cohort));
		if (selected !== void 0) reachableReleaseIds.add(selected.releaseId);
	}
}
function collectCurrentlyReachableReleaseIds(catalog) {
	const reachableReleaseIds = /* @__PURE__ */ new Set();
	const indexGroups = catalog.strategy === "APP_VERSION" ? catalog.segments.map(({ releaseIndexes }) => releaseIndexes) : [catalog.releaseIndexes];
	for (const indexes of indexGroups) collectReachableFromIndexes(catalog, indexes, reachableReleaseIds);
	return reachableReleaseIds;
}
/** Marks each release its scope's compiled catalog no longer serves: one catalog read per scope. */
async function addReleaseReachability(core, releases) {
	const scopeKeys = [...new Set(releases.map(({ scope_key }) => scope_key))];
	const reachableByScope = new Map(await Promise.all(scopeKeys.map(async (scopeKey) => {
		const row = await core.getReleaseCatalogRow(scopeKey);
		return [scopeKey, row === null ? /* @__PURE__ */ new Set() : collectCurrentlyReachableReleaseIds(JSON.parse(row.payload))];
	})));
	return releases.map((release) => ({
		...release,
		currentlyUnreachable: !reachableByScope.get(release.scope_key)?.has(release.id)
	}));
}
//#endregion
export { addReleaseReachability as t };
