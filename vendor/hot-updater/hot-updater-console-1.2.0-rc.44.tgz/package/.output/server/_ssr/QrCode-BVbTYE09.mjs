import { i as __toESM } from "../_runtime.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { k as cn } from "./sidebar-COdOWPGC.mjs";
import { t as encode } from "../_libs/uqr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/QrCode-BVbTYE09.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* A QR code of `value` as one SVG path of unit squares, with the standard
* four-module quiet zone: `size` is the side of its viewBox.
*/
var qrCodePath = (value) => {
	const { data, size } = encode(value, {
		ecc: "M",
		border: 4
	});
	let path = "";
	data.forEach((row, y) => row.forEach((dark, x) => {
		if (dark) path += `M${x} ${y}h1v1h-1z`;
	}));
	return {
		size,
		path
	};
};
/**
* A QR code of `value`, drawn as one SVG path with the standard four-module
* quiet zone. Phone cameras read dark modules on a light ground, so the code
* keeps its own two colors in both themes instead of the theme's tokens.
*/
function QrCode({ value, label, className }) {
	const { size, path } = (0, import_react.useMemo)(() => qrCodePath(value), [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		"aria-label": label,
		className: cn("aspect-square rounded-md", className),
		role: "img",
		shapeRendering: "crispEdges",
		viewBox: `0 0 ${size} ${size}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			fill: "#fff",
			height: size,
			width: size
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: path,
			fill: "#000"
		})]
	});
}
//#endregion
export { QrCode as t };
