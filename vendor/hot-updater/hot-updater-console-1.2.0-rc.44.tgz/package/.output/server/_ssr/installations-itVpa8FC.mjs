import { t as ConsoleFeatureUnavailable } from "./ConsoleFeatureUnavailable--3q0wW_8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/installations-itVpa8FC.js
var SplitNotFoundComponent = ConsoleFeatureUnavailable;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
