import { i as __toESM } from "../_runtime.mjs";
import { C as MenuItem, Et as require_react, S as MenuPopup, Tt as require_jsx_runtime, b as MenuPositioner, pt as Separator, v as MenuTrigger, x as MenuPortal, y as MenuRoot } from "../_libs/@base-ui/react+[...].mjs";
import { D as LoaderCircle, M as HardDrive, Z as Check, _ as RefreshCw, a as Trash2, i as TriangleAlert, u as Smartphone, y as Pencil, z as Ellipsis } from "../_libs/lucide-react.mjs";
import { C as Skeleton, O as buttonVariants, S as SidebarTrigger, j as useIsMobile, k as cn, n as Input, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as CardHeader, n as CardContent, o as CardTitle, t as Card } from "./card-CsUxqR3-.mjs";
import { a as Badge, i as AlertTitle, n as AlertAction, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { a as FieldLabel, i as FieldGroup, n as FieldDescription, r as FieldError, t as Field } from "./field-BVbdqLG6.mjs";
import { a as AlertDialogDescription, i as AlertDialogContent, l as AlertDialogTitle, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog$1 } from "./alert-dialog-ByY_ghMv.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog$1 } from "./dialog-CNWOO08-.mjs";
import { i as TableHead, o as TableRow, r as TableCell } from "./table-4qgdiham.mjs";
import { s as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as maskIosUdid, f as consolePathOf, g as iosDeviceProfileUrl, n as IOS_DEVICES_PATH, t as IOS_DEVICES_ADD_COMMAND } from "./native-builds-lEyKQemV.mjs";
import { r as extractTimestampFromUUIDv7 } from "./uuidv7-C0jNe2Om.mjs";
import { a as SelectTrigger, i as SelectItem, n as SelectContent, o as SelectValue, r as SelectGroup, t as Select$1 } from "./select-DYhN8vLu.mjs";
import { n as require_dayjs_min } from "../_libs/dayjs.mjs";
import { c as DataTableFullRow, d as DataTableSkeletonRows, f as RelativeTime, i as DataTable, n as DataCardSkeletons, o as DataTableEmpty, r as DataCardsEmpty, s as DataTableFrame, t as DataCard } from "./RelativeTime-jQk9a1D5.mjs";
import { n as CopyableText, r as NoValue } from "./TargetDisplay-CwHH2uJ2.mjs";
import { n as NativeBuildsNav } from "./NativeBuildsNav-CPmrkQr0.mjs";
import { _ as useRequestThisIphoneMutation, c as useApproveIosDeviceMutation, d as useIosDeviceQuery, f as useIosDevicesQuery, g as useRenameIosDeviceMutation, h as useRemoveIosDeviceMutation, i as iosDeviceKeys, l as useIosDevice, o as keptIsThisIphone, p as useKeptIosDeviceQuery, s as useAdoptKeptIosDevice, t as AppleRefusal, u as useIosDeviceProfileLinkQuery } from "./IosInstall-CUO4c1oT.mjs";
import { t as QrCode } from "./QrCode-BVbTYE09.mjs";
import { t as Route } from "./native-builds_.devices-ClVa2IkG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-builds_.devices-DJ0rI3s8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
function DropdownMenu({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRoot, {
		"data-slot": "dropdown-menu",
		...props
	});
}
function DropdownMenuTrigger({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuTrigger, {
		"data-slot": "dropdown-menu-trigger",
		...props
	});
}
function DropdownMenuContent({ align = "start", alignOffset = 0, side = "bottom", sideOffset = 4, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPositioner, {
		className: "isolate z-50 outline-none",
		align,
		alignOffset,
		side,
		sideOffset,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPopup, {
			"data-slot": "dropdown-menu-content",
			className: cn("dark z-50 max-h-(--available-height) w-(--anchor-width) min-w-32 origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-lg bg-popover p-1 text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 outline-none data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:overflow-hidden data-closed:fade-out-0 data-closed:zoom-out-95", className),
			...props
		})
	}) });
}
function DropdownMenuItem({ className, inset, variant = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
		"data-slot": "dropdown-menu-item",
		"data-inset": inset,
		"data-variant": variant,
		className: cn("group/dropdown-menu-item relative flex min-h-7 cursor-default items-center gap-2 rounded-md px-2 py-1 text-xs/relaxed outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-inset:pl-7.5 data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 data-[variant=destructive]:focus:text-destructive dark:data-[variant=destructive]:focus:bg-destructive/20 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-3.5 data-[variant=destructive]:*:[svg]:text-destructive", className),
		...props
	});
}
function DropdownMenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {
		"data-slot": "dropdown-menu-separator",
		className: cn("-mx-1 my-1 h-px bg-border/50", className),
		...props
	});
}
var STATUS_LABELS = {
	pending: "Requested",
	approved: "Approved",
	registered: "Registered"
};
/**
* Only a request waits on someone, so only it takes a status color; the
* other states are the normal course and stay neutral.
*/
var STATUS_BADGES = {
	pending: "warning",
	approved: "secondary",
	registered: "muted"
};
var ALL = "all";
var COLUMNS = 6;
/** The Console's path from this page, so links work under a base path. */
var consolePath = () => window.location.pathname.endsWith("/native-builds/devices") ? window.location.pathname.slice(0, -IOS_DEVICES_PATH.length) : consolePathOf(window.location, "");
/** Who may act on a row, decided again on the server. */
var actionsFor = (device, viewer) => ({
	approve: viewer.canApprove && device.status === "pending",
	rename: viewer.canApprove,
	remove: viewer.canApprove,
	withdraw: !viewer.canApprove && device.status === "pending" && device.requested_by === viewer.email
});
/**
* Apple's refusal of an approved device is the row an approver acts on, so it
* takes the warning in place of Approved; the other states stay neutral.
*/
var appleRefused = (device) => device.status === "approved" && device.apple_error !== null;
/** Who asked for a device: a person, or a terminal for one the CLI added. */
var requesterOf = (device) => device.requested_by ?? "Added from a terminal";
/**
* Apple's reason. In a table cell it wraps at most two lines in a narrow
* column, the full text on hover and to a screen reader, so a long reason
* never widens the table past its frame; a card shows all of it.
*/
function AppleError({ device, inTable = false }) {
	if (device.apple_error === null) return null;
	return inTable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "line-clamp-2 max-w-48 text-xs whitespace-normal text-muted-foreground",
		title: device.apple_error,
		children: device.apple_error
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "max-w-64 text-xs whitespace-normal text-muted-foreground",
		children: device.apple_error
	});
}
function DeviceStatus({ device, withError = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 shrink-0 flex-col items-start gap-1",
		children: [appleRefused(device) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "warning",
			children: "Apple refused"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: STATUS_BADGES[device.status],
			children: STATUS_LABELS[device.status]
		}), withError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppleError, {
			device,
			inTable: true
		}) : null]
	});
}
function DeviceBuild({ device }) {
	if (device.build_id === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoValue, {});
	let label = "A build";
	try {
		label = `Build of ${(0, import_dayjs_min.default)(extractTimestampFromUUIDv7(device.build_id)).format("MMM D")}`;
	} catch {}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		className: "text-xs font-medium underline-offset-4 hover:underline",
		params: { buildId: device.build_id },
		to: "/native-builds/$buildId",
		children: label
	});
}
function DeviceActions({ device, viewer, onOpen }) {
	const can = actionsFor(device, viewer);
	if (!can.approve && !can.rename && !can.remove && !can.withdraw) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-end gap-1",
		children: [
			can.approve ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
				className: "h-11 sm:h-8",
				onClick: () => onOpen({
					kind: "approve",
					device
				}),
				size: "sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { "data-icon": "inline-start" }), "Approve"]
			}) : null,
			can.withdraw ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
				className: "h-11 sm:h-8",
				onClick: () => onOpen({
					kind: "remove",
					device
				}),
				size: "sm",
				variant: "outline",
				children: "Withdraw"
			}) : null,
			can.rename || can.remove ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
					"aria-label": `More actions for ${device.name}`,
					className: "size-11 sm:size-8",
					size: "icon-sm",
					variant: "ghost"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { "aria-hidden": "true" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
				align: "end",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => onOpen({
							kind: "rename",
							device
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { "aria-hidden": "true" }), "Rename"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => onOpen({
							kind: "remove",
							device
						}),
						variant: "destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { "aria-hidden": "true" }), device.status === "pending" ? "Decline" : "Remove"]
					})
				]
			})] }) : null
		]
	});
}
/**
* "This iPhone" on the row of the iPhone this page is open on: a quiet tag,
* as "Sandbox" is on a build, so its actions are found where every row's are.
*/
function ThisIphoneTag() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		className: "shrink-0 px-1.5",
		variant: "muted",
		children: "This iPhone"
	});
}
function DeviceRow({ device, viewer, onOpen, isThisIphone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "font-medium",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1.5",
				children: [device.name, isThisIphone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThisIphoneTag, {}) : null]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs",
			title: device.udid,
			translate: "no",
			children: maskIosUdid(device.udid)
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-xs",
			children: device.requested_by ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: requesterOf(device)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceStatus, { device }) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-xs",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelativeTime, { ms: device.created_at_ms })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceBuild, { device }) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-right",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceActions, {
				device,
				onOpen,
				viewer
			})
		})
	] });
}
function DeviceCard({ device, viewer, onOpen, isThisIphone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataCard, {
		className: "cursor-default gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-col gap-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex min-w-0 items-center gap-1.5 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: device.name
						}), isThisIphone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThisIphoneTag, {}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-muted-foreground",
						translate: "no",
						children: maskIosUdid(device.udid)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceStatus, {
					device,
					withError: false
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppleError, { device }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex flex-wrap items-center gap-x-1.5 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: requesterOf(device) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelativeTime, { ms: device.created_at_ms }),
					device.build_id === null ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "·"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceBuild, { device })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceActions, {
				device,
				onOpen,
				viewer
			})
		]
	});
}
/** Name a device: approving a request, or renaming any device. */
function NameDialog({ target, onClose }) {
	const approve = useApproveIosDeviceMutation();
	const rename = useRenameIosDeviceMutation();
	const mutation = target.kind === "approve" ? approve : rename;
	const [name, setName] = (0, import_react.useState)(target.device.name);
	const trimmed = name.trim();
	const submit = (event) => {
		event.preventDefault();
		if (trimmed === "") return;
		mutation.mutate({
			id: target.device.id,
			name: trimmed
		}, { onSuccess: onClose });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		onOpenChange: (open) => open ? null : onClose(),
		open: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: target.kind === "approve" ? `Approve ${target.device.name}?` : `Rename ${target.device.name}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: target.kind === "approve" ? "The next ad hoc build registers this iPhone with your Apple account. Each new iPhone uses one of the account's 100 a year, and removing it never gives the slot back." : "The registry shows this name. The next ad hoc build doesn't rename it at Apple." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, { children: [target.kind === "approve" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-[auto_minmax(0,1fr)] gap-x-4 gap-y-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Requested by"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "truncate",
						children: target.device.requested_by ?? "Terminal (CLI)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "UDID"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-mono text-xs break-all select-all",
						translate: "no",
						children: target.device.udid
					})
				]
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				"data-invalid": mutation.isError || void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "ios-device-dialog-name",
						children: "Name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						autoComplete: "off",
						id: "ios-device-dialog-name",
						maxLength: 100,
						onChange: (event) => setName(event.target.value),
						value: name
					}),
					target.kind === "approve" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "The iPhone's ID comes from the person who asked. Approve devices you recognize." }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: mutation.isError ? `Couldn't ${target.kind === "approve" ? "approve" : "rename"} ${target.device.name}. Check your connection and try again.` : null })
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					className: "h-11 sm:h-8",
					disabled: trimmed === "" || mutation.isPending,
					type: "submit",
					children: [mutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						className: "animate-spin motion-reduce:animate-none",
						"data-icon": "inline-start"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { "data-icon": "inline-start" }), target.kind === "approve" ? "Approve" : "Rename"]
				})
			})]
		})] })
	});
}
function RemoveDialog({ device, viewer, onClose }) {
	const remove = useRemoveIosDeviceMutation();
	const withdraw = !viewer.canApprove;
	const decline = device.status === "pending";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog$1, {
		onOpenChange: (open) => open ? null : onClose(),
		open: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: withdraw ? `Withdraw ${device.name}?` : decline ? `Decline ${device.name}?` : `Remove ${device.name}?` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: decline ? "It leaves the list. Its owner can request it again." : "It leaves the list. New ad hoc builds keep it until it's disabled at Apple." })] }),
			remove.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-destructive",
				role: "alert",
				children: [
					"Couldn't ",
					withdraw ? "withdraw" : decline ? "decline" : "remove",
					" ",
					device.name,
					". Check your connection and try again."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
				disabled: remove.isPending,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogAction, {
				disabled: remove.isPending,
				onClick: (event) => {
					event.preventDefault();
					remove.mutate({ udid: device.udid }, { onSuccess: onClose });
				},
				variant: "destructive",
				children: [remove.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					className: "animate-spin motion-reduce:animate-none",
					"data-icon": "inline-start"
				}) : null, withdraw ? "Withdraw" : decline ? "Decline" : "Remove"]
			})] })
		] })
	});
}
/**
* Where this iPhone stands, once its profile has answered: its row's name,
* status, and what happens next, in place of the form that registered it.
* It has no actions: they are on its row in the list, tagged "This iPhone",
* as every row's are. Apple's refusal reads as on a build's page.
*/
function ThisIphone({ device, viewer }) {
	const canApprove = viewer?.canApprove === true;
	if (device.apple_error !== null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppleRefusal, {
		canApprove,
		device,
		onDevicesPage: true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-col gap-0.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-medium",
					children: device.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs text-muted-foreground",
					translate: "no",
					children: maskIosUdid(device.udid)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceStatus, {
				device,
				withError: false
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			role: "status",
			children: device.status === "pending" ? canApprove ? "Approve it below, and it joins the next ad hoc build." : "A maintainer approves it next." : device.status === "approved" ? "It joins the next ad hoc build." : "New ad hoc builds install on it."
		})]
	});
}
/** Why iPhones can't register through this Console. */
function RegistrationNotice({ status, secretName }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		role: "status",
		children: status === "local-console" ? "iPhones register through your hosted Console: an iPhone can't reach this computer's." : `Set ${secretName} on this Console to register iPhones.`
	});
}
/**
* Where an iPhone joins the list: on a computer, a QR code of this page; on
* the iPhone, its name and the profile that reads its UDID, signed for the
* person who is signed in.
*/
function RegisterCard({ view, phone }) {
	const [name, setName] = (0, import_react.useState)(null);
	const typed = name ?? view?.defaultName ?? "";
	const [signed, setSigned] = (0, import_react.useState)(typed);
	(0, import_react.useEffect)(() => {
		const timer = setTimeout(() => setSigned(typed.trim()), 400);
		return () => clearTimeout(timer);
	}, [typed]);
	const onPhone = phone?.ios === true;
	const link = useIosDeviceProfileLinkQuery({
		mode: "register",
		name: signed || "iPhone"
	}, onPhone && view?.registration === "ready");
	const https = phone === null || window.location.protocol === "https:";
	const udid = onPhone ? phone.udid : null;
	const mine = useIosDeviceQuery(udid);
	const answers = phone?.answers ?? 0;
	const { refetch } = mine;
	const seen = (0, import_react.useRef)({
		udid,
		answers
	});
	(0, import_react.useEffect)(() => {
		const before = seen.current;
		seen.current = {
			udid,
			answers
		};
		if (udid !== null && udid === before.udid && answers > before.answers) refetch();
	}, [
		udid,
		answers,
		refetch
	]);
	const path = phone === null ? "" : consolePath();
	const kept = useKeptIosDeviceQuery(path, phone?.receipt ?? null, onPhone && view?.registration === "ready" && (udid === null || phone.receipt !== null || mine.data === null));
	useAdoptKeptIosDevice(phone, kept.data?.udid);
	const again = useRequestThisIphoneMutation(path);
	const proved = onPhone && keptIsThisIphone(kept.data?.udid, phone.udid);
	const body = (() => {
		if (phone === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			"aria-label": "Loading",
			className: "h-36 w-full"
		});
		if (onPhone && phone.udid !== null && mine.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			"aria-label": "Loading",
			className: "h-36 w-full"
		});
		if (onPhone && mine.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThisIphone, {
			device: mine.data,
			viewer: view?.viewer
		});
		if (view !== void 0 && (view.registration === "local-console" || view.registration === "no-secret")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegistrationNotice, {
			secretName: view.secretName,
			status: view.registration
		});
		if (!onPhone) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-start gap-4 sm:flex-row sm:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {
				className: "size-36 shrink-0",
				label: "Open this page on an iPhone",
				value: `${window.location.origin}${consolePath()}${IOS_DEVICES_PATH}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-col gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Open this page on the iPhone, in Safari."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "It installs a profile that reads the iPhone's ID, then lists the iPhone here as requested. Nothing stays installed."
				})]
			})]
		});
		if (!https) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			role: "status",
			children: "iPhones need this Console on HTTPS."
		});
		if (mine.data === null && kept.isFetching && !proved) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			"aria-label": "Loading",
			className: "h-36 w-full"
		});
		if (proved) {
			const trimmed = typed.trim();
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex min-w-0 flex-col gap-3",
				onSubmit: (event) => {
					event.preventDefault();
					if (trimmed === "") return;
					again.mutate({
						name: trimmed,
						receipt: phone.receipt
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					"data-invalid": again.isError || void 0,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "ios-device-register-name",
							children: "This iPhone's name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoComplete: "off",
							className: "h-11",
							id: "ios-device-register-name",
							maxLength: 100,
							onChange: (event) => setName(event.target.value),
							value: typed
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "This Safari checked it before, so no profile is needed." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: again.isError ? "The request didn't go through. Try again." : null })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					className: "h-11 w-full",
					disabled: trimmed === "" || again.isPending,
					type: "submit",
					children: [again.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						className: "animate-spin motion-reduce:animate-none",
						"data-icon": "inline-start"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { "data-icon": "inline-start" }), "Request this iPhone"]
				})]
			});
		}
		if (link.data?.status === "local-console") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegistrationNotice, { status: "local-console" });
		if (link.data?.status === "no-secret") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegistrationNotice, {
			secretName: link.data.secretName,
			status: "no-secret"
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "ios-device-register-name",
					children: "This iPhone's name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					autoComplete: "off",
					className: "h-11",
					id: "ios-device-register-name",
					maxLength: 100,
					onChange: (event) => setName(event.target.value),
					value: typed
				})] }),
				link.data?.status === "issued" && signed === typed.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: buttonVariants({ className: "h-auto min-h-11 w-full whitespace-normal" }),
					href: iosDeviceProfileUrl(consolePath(), link.data.token),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { "data-icon": "inline-start" }), "Install profile"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
					"aria-label": "Preparing the profile",
					className: "h-11 w-full"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Safari only. Allow the download, then install it in Settings, where iOS calls it not signed. Safari comes back here, and nothing stays installed."
				})
			]
		});
	})();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
			className: "border-b px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Register an iPhone" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-4 sm:p-6",
			children: body
		})]
	});
}
/**
* The iOS device registry inside Native builds: the iPhones and iPads a team
* asked to install ad hoc builds on. Testers register from an iPhone,
* approvers approve, rename, and remove, and the next ad hoc build registers
* what was approved with Apple. Android builds need none of this.
*/
function IosDevicesPage({ search, onSearchChange }) {
	const isMobile = useIsMobile();
	const query = useIosDevicesQuery(search.status);
	const view = query.data;
	const rows = view?.devices;
	const queryClient = useQueryClient();
	const refresh = () => void queryClient.invalidateQueries({ queryKey: iosDeviceKeys.all });
	const [dialog, setDialog] = (0, import_react.useState)(null);
	const phone = useIosDevice();
	const thisUdid = phone?.ios === true ? phone.udid?.toLowerCase() ?? null : null;
	const close = () => setDialog(null);
	const empty = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableEmpty, {
		icon: Smartphone,
		title: search.status === void 0 ? "No iPhones yet" : `No ${STATUS_LABELS[search.status].toLowerCase()} iPhones`,
		children: search.status === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Open this page on an iPhone to register it." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			className: "h-11 sm:h-8",
			onClick: () => onSearchChange({}),
			size: "sm",
			variant: "outline",
			children: "Show all"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 min-w-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-10 flex shrink-0 flex-wrap items-center gap-x-3 gap-y-1 border-b bg-background px-3 py-3 sm:min-h-12 sm:flex-nowrap sm:bg-card/70 sm:px-4 sm:backdrop-blur-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1 size-11 lg:size-7" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, {
							"aria-hidden": "true",
							className: "size-3.5 text-muted-foreground"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-sm font-medium",
							children: "Native builds"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "basis-full pl-12 text-xs text-muted-foreground sm:basis-auto sm:pl-0",
						children: "The iPhones and iPads ad hoc builds install on. Android needs none."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 min-w-0 flex-1 flex-col gap-4 overflow-y-auto bg-muted/5 p-3 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeBuildsNav, { current: "devices" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegisterCard, {
						phone,
						view
					}),
					view !== void 0 && !view.viewer.approversConfigured ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-col gap-1.5 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nobody approves in this Console. Approve from a terminal:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
							label: "the approve command",
							value: IOS_DEVICES_ADD_COMMAND
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select$1, {
							items: [{
								label: "All statuses",
								value: ALL
							}, ...Object.keys(STATUS_LABELS).map((status) => ({
								label: STATUS_LABELS[status],
								value: status
							}))],
							onValueChange: (value) => onSearchChange(value === null || value === ALL ? {} : { status: value }),
							value: search.status ?? ALL,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								"aria-label": "Status",
								className: "min-w-0 flex-1 text-xs data-[size=default]:h-11 sm:w-44 sm:flex-none sm:data-[size=default]:h-8",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: ALL,
								children: "All statuses"
							}), Object.keys(STATUS_LABELS).map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: status,
								children: STATUS_LABELS[status]
							}, status))] }) })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
							"aria-label": "Refresh iOS devices",
							className: "ml-auto size-11 sm:size-7",
							disabled: query.isFetching,
							onClick: refresh,
							size: "icon-sm",
							variant: "ghost",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "aria-hidden": "true" })
						})]
					}),
					query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
						variant: "destructive",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "iOS devices couldn't be loaded" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Check your connection and try again." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
								onClick: refresh,
								size: "xs",
								variant: "outline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry"]
							}) })
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFrame, {
						className: "flex-none",
						children: isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							"aria-busy": query.isPlaceholderData,
							"aria-label": "iOS devices",
							className: "aria-busy:opacity-60",
							role: "list",
							children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataCardSkeletons, { label: "Loading iOS devices" }) : rows?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataCardsEmpty, { children: empty }) : rows?.map((device) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "border-b last:border-b-0",
								role: "listitem",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceCard, {
									device,
									isThisIphone: device.udid === thisUdid,
									onOpen: setDialog,
									viewer: view.viewer
								})
							}, device.id))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
							"aria-busy": query.isPlaceholderData,
							"aria-label": "iOS devices",
							className: "aria-busy:opacity-60",
							header: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Name" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "UDID" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Requested by" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Added" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Build" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Actions"
									})
								})
							] }),
							children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableSkeletonRows, {
								columns: COLUMNS + 1,
								label: "Loading iOS devices"
							}) : rows?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFullRow, {
								columns: COLUMNS + 1,
								children: empty
							}) : rows?.map((device) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceRow, {
								device,
								isThisIphone: device.udid === thisUdid,
								onOpen: setDialog,
								viewer: view.viewer
							}, device.id))
						})
					})
				]
			}),
			dialog !== null && dialog.kind !== "remove" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameDialog, {
				onClose: close,
				target: dialog
			}, dialog.device.id) : null,
			dialog?.kind === "remove" && view !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemoveDialog, {
				device: dialog.device,
				onClose: close,
				viewer: view.viewer
			}, dialog.device.id) : null
		]
	});
}
function IosDevicesRoute() {
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IosDevicesPage, {
		onSearchChange: (next) => void navigate({
			search: next,
			replace: true
		}),
		search
	});
}
//#endregion
export { IosDevicesRoute as component };
