import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { D as TooltipTrigger, T as TooltipContent, k as cn, w as Tooltip$1 } from "./sidebar-COdOWPGC.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/HashValueDisplay-BAS89lvP.js
var import_jsx_runtime = require_jsx_runtime();
var shortenIdentifier = (value, maxLength = 12) => value.length > maxLength ? `${value.slice(0, Math.max(1, maxLength - 4))}…${value.slice(-4)}` : value;
function HashValueDisplay({ value, display = value, maxLength = 12, className, buttonClassName }) {
	const isTruncated = display !== value || display.length > maxLength;
	const truncated = shortenIdentifier(display, maxLength);
	const copyValue = async () => {
		try {
			await navigator.clipboard.writeText(value);
			toast.success("Copied to clipboard", { description: value });
		} catch {
			toast.error("Failed to copy value");
		}
	};
	const handleClick = (event) => {
		event.preventDefault();
		event.stopPropagation();
		copyValue();
	};
	const handleKeyDown = (event) => {
		if (event.key === "Enter" || event.key === " ") {
			event.preventDefault();
			event.stopPropagation();
			copyValue();
		}
	};
	const content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		translate: "no",
		className: cn("font-mono text-xs tabular-nums whitespace-nowrap", className),
		children: truncated
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": `Copy full value: ${value}`,
			translate: "no",
			className: cn("ring-ring/30 bg-muted/40 border-border/70 relative inline-flex min-w-0 after:absolute after:inset-x-0 after:-inset-y-3 sm:after:hidden max-w-full cursor-pointer items-center rounded-md border px-1.5 py-0.5 align-top shadow-xs outline-none transition-[background-color,border-color,transform,box-shadow]", "hover:bg-muted/70 active:scale-[0.98] active:bg-muted/85 focus-visible:ring-[2px]", "touch-manipulation select-none motion-reduce:transition-none motion-reduce:active:scale-100", !isTruncated && "cursor-copy", buttonClassName),
			onClick: handleClick,
			onKeyDown: handleKeyDown
		}),
		children: content
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
		hidden: !isTruncated,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			translate: "no",
			className: "break-all font-mono text-xs tabular-nums",
			children: value
		})
	})] });
}
//#endregion
export { shortenIdentifier as n, HashValueDisplay as t };
