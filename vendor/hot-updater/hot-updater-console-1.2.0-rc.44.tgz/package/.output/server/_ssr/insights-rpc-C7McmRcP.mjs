import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-rpc-C7McmRcP.js
/** The Insights reads, once the console's access check and the feature guard pass. */
var insightsReads = async () => {
	const [{ prepareConfig }, { requireFeature }] = await Promise.all([import("./config.server-CvAlgb8E.mjs"), import("./runtime.server-BUbb281Z.mjs")]);
	const { runtime } = await prepareConfig();
	return requireFeature(runtime, "insights");
};
var readOverview = (input) => input;
var readEventsPage = (input) => input;
var readInstallationEventsPage = (input) => input;
var readInstallationPage = (input) => input;
var readInstallId = (input) => input;
var getReportingInstallationsRpc_createServerFn_handler = createServerRpc({
	id: "ff00311d412c8cdfa8ad5b0ba1eb6aa7471d0cc12170e6cc645deb91603d42dd",
	name: "getReportingInstallationsRpc",
	filename: "src/lib/insights-rpc.ts"
}, (opts) => getReportingInstallationsRpc.__executeServer(opts));
var getReportingInstallationsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readOverview).handler(getReportingInstallationsRpc_createServerFn_handler, async ({ data }) => (await insightsReads()).getReportingOverview(data));
var listInsightsEventsRpc_createServerFn_handler = createServerRpc({
	id: "d4c50f40701055145f24873dc90f3c55a5494457a6a03a743339b2ac4545eb19",
	name: "listInsightsEventsRpc",
	filename: "src/lib/insights-rpc.ts"
}, (opts) => listInsightsEventsRpc.__executeServer(opts));
var listInsightsEventsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readEventsPage).handler(listInsightsEventsRpc_createServerFn_handler, async ({ data }) => (await insightsReads()).listEvents(data));
var listInsightsInstallationEventsRpc_createServerFn_handler = createServerRpc({
	id: "3c04bc6624be6dfdd80cf96819f9c6d0455e59a7bb4c0374b6afb0162ffd15b0",
	name: "listInsightsInstallationEventsRpc",
	filename: "src/lib/insights-rpc.ts"
}, (opts) => listInsightsInstallationEventsRpc.__executeServer(opts));
var listInsightsInstallationEventsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readInstallationEventsPage).handler(listInsightsInstallationEventsRpc_createServerFn_handler, async ({ data }) => (await insightsReads()).listInstallationEvents(data));
var getInsightsInstallationRpc_createServerFn_handler = createServerRpc({
	id: "6726f1ed9eda1f0cb4c1f1ad1023faee435ddcfd0b7c55ef08ca7f2f7f577370",
	name: "getInsightsInstallationRpc",
	filename: "src/lib/insights-rpc.ts"
}, (opts) => getInsightsInstallationRpc.__executeServer(opts));
var getInsightsInstallationRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readInstallId).handler(getInsightsInstallationRpc_createServerFn_handler, async ({ data }) => (await insightsReads()).getInstallation(data));
var getInsightsRetentionRpc_createServerFn_handler = createServerRpc({
	id: "c6f18db42ac40385dbff247095197ee9f3fd3a97dc914efd368ce0ded1f098c6",
	name: "getInsightsRetentionRpc",
	filename: "src/lib/insights-rpc.ts"
}, (opts) => getInsightsRetentionRpc.__executeServer(opts));
var getInsightsRetentionRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(getInsightsRetentionRpc_createServerFn_handler, async () => (await insightsReads()).getRetention());
var findInsightsInstallationsRpc_createServerFn_handler = createServerRpc({
	id: "735c501f6d5ea81a445ff2b6b2ea6a1b589e3c6f63a465a881822c80ae71e7d1",
	name: "findInsightsInstallationsRpc",
	filename: "src/lib/insights-rpc.ts"
}, (opts) => findInsightsInstallationsRpc.__executeServer(opts));
var findInsightsInstallationsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readInstallationPage).handler(findInsightsInstallationsRpc_createServerFn_handler, async ({ data }) => {
	const insights = await insightsReads();
	const install = data.cursor ? null : await insights.getInstallation({ installId: data.identity });
	const matches = await insights.pageInstallationsByCurrentUserId({
		cursor: data.cursor,
		limit: Math.max(1, data.limit - (install === null ? 0 : 1)),
		userId: data.identity
	});
	return {
		data: install === null ? matches.data : [install, ...matches.data.filter(({ installId }) => installId !== install.installId)],
		nextCursor: matches.nextCursor
	};
});
//#endregion
export { findInsightsInstallationsRpc_createServerFn_handler, getInsightsInstallationRpc_createServerFn_handler, getInsightsRetentionRpc_createServerFn_handler, getReportingInstallationsRpc_createServerFn_handler, listInsightsEventsRpc_createServerFn_handler, listInsightsInstallationEventsRpc_createServerFn_handler };
