import { r as createDeviceProfileToken, t as DEVICE_PROFILE_TOKEN_TTL_MS } from "./deviceProfileToken-xzDLfE0T.mjs";
import { CONSOLE_SECRET_ENV, readConsoleSecret } from "./nativeBuildDownloadLink-CgZaRE6C.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/iosDevices-mJefvrvf.js
/** A registry page: past an Apple account's yearly limit of devices. */
var PAGE = 200;
/** `ios_devices.name`'s bound in core's schema. */
var NAME_MAX_LENGTH = 100;
var forbidden = (message) => new Response(message, {
	status: 403,
	headers: { "content-type": "text/plain; charset=utf-8" }
});
/** Whether this is `hot-updater console`, the local runtime, by its mode. */
var isLocalConsole = async () => {
	const { default: localConsoleGuard } = await import("./request-guard-BPLyogIN.mjs");
	return localConsoleGuard !== void 0;
};
/**
* The viewer's rights over the registry. The local Console is recognized by
* its mode, never by an email, so a hosted user named like the local one
* gains nothing. A hosted approver is an email in `deviceApprovers`.
*/
var iosDeviceViewer = async (principal, deviceApprovers) => {
	const email = principal.email.trim().toLowerCase();
	const local = await isLocalConsole();
	return {
		email,
		canApprove: local || deviceApprovers.includes(email),
		approversConfigured: local || deviceApprovers.length > 0
	};
};
/** Refuses anyone but an approver, on the server, whatever the UI sent. */
var requireDeviceApprover = (viewer) => {
	if (!viewer.canApprove) throw forbidden("Only a device approver can do this.");
};
/** Every registry row, newest first, or one status's. */
var listIosDevices = async (core, status) => {
	const rows = [];
	for (let after;;) {
		const page = await core.listIosDevices({
			order: "desc",
			limit: PAGE,
			...status === void 0 ? {} : { status },
			...after === void 0 ? {} : { after }
		});
		rows.push(...page);
		if (page.length < PAGE) return rows;
		after = page.at(-1).id;
	}
};
/** A device name as the registry stores it, or a refusal. */
var deviceName = (name) => {
	const trimmed = typeof name === "string" ? name.trim() : "";
	if (trimmed.length === 0 || trimmed.length > NAME_MAX_LENGTH) throw new TypeError(`Name the device in 1 to ${NAME_MAX_LENGTH} characters.`);
	return trimmed;
};
/** The name a device gets before anyone types one: the person's, then "iPhone". */
var defaultDeviceName = (principal) => {
	const owner = principal.name?.trim() || principal.email.split("@")[0]?.trim() || "";
	return owner === "" ? "iPhone" : `${owner}'s iPhone`.slice(0, NAME_MAX_LENGTH);
};
/**
* Whether an iPhone can register through this Console: not through the local
* one, which an iPhone can't reach, nor without the secret that signs links.
*/
var deviceRegistration = async (request) => {
	if (await isLocalConsole()) return "local-console";
	return readConsoleSecret(request) === void 0 ? "no-secret" : "ready";
};
/**
* A new capability for this person's iPhone profile: `register` saves the
* iPhone as requested under `name`, `identify` only tells build `buildId`'s
* page which iPhone it is. It reads and stores nothing.
*/
var issueDeviceProfileLink = async (request, viewer, input, now = Date.now()) => {
	if (await isLocalConsole()) return { status: "local-console" };
	const secret = readConsoleSecret(request);
	if (secret === void 0) return {
		status: "no-secret",
		secretName: CONSOLE_SECRET_ENV
	};
	return {
		status: "issued",
		token: await createDeviceProfileToken(secret, input.mode === "register" ? {
			m: "register",
			e: viewer.email,
			n: deviceName(input.name)
		} : {
			m: "identify",
			e: viewer.email,
			b: input.buildId
		}, now),
		expiresAt: new Date(now + DEVICE_PROFILE_TOKEN_TTL_MS).toISOString()
	};
};
/**
* Removes a device from the registry, as read now: an approver removes any,
* and the person who asked withdraws their own while it is still requested.
* Null when it is gone already.
*/
var removeIosDevice = async (core, viewer, udid) => {
	const device = await core.findIosDevice(udid);
	if (device === null) return null;
	if (viewer.canApprove) return core.deleteIosDevice(device.id);
	if (device.status !== "pending" || device.requested_by !== viewer.email) throw forbidden("Only a device approver can remove this device.");
	const withdrawn = await core.deleteIosDevice(device.id, {
		status: "pending",
		requestedBy: viewer.email
	});
	if (withdrawn === null && await core.findIosDevice(udid) !== null) throw forbidden("It was approved meanwhile. A device approver removes it.");
	return withdrawn;
};
//#endregion
export { defaultDeviceName, deviceName, deviceRegistration, iosDeviceViewer, issueDeviceProfileLink, listIosDevices, removeIosDevice, requireDeviceApprover };
