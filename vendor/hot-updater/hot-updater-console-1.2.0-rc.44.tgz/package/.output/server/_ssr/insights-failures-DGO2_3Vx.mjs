import { r as recoveryWindows } from "./insights-recovery-Cdg3Msrj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-failures-DGO2_3Vx.js
function readUpdateFailuresInput(input) {
	if (!input || input.platform !== "all" && input.platform !== "ios" && input.platform !== "android" || typeof input.channel !== "string" || !input.channel.trim() || input.channel.length > 1024 || input.releaseId !== void 0 && (typeof input.releaseId !== "string" || !input.releaseId.trim() || input.releaseId.length > 36) || (input.window === void 0 ? input.releaseId === void 0 : !Object.hasOwn(recoveryWindows, input.window))) throw new Error("Choose a platform, channel, and time window.");
	return input;
}
/**
* The failure rate of update attempts: failed download and install reports,
* over those plus download reports. Null without either.
*/
var failureRate = ({ failedUpdates, downloads }) => failedUpdates + downloads === 0 ? null : failedUpdates / (failedUpdates + downloads);
/** Installations whose update check failed, over the active ones; estimates, so at most 100%. */
var checkFailureRate = ({ failedInstallations, activeInstallations }) => activeInstallations === 0 ? null : Math.min(1, failedInstallations / activeInstallations);
var formatRate = (rate) => rate === null ? "—" : `${(rate * 100).toFixed(2)}%`;
var STAGES = {
	check: "Update check",
	download: "Download",
	install: "Install"
};
var REASONS = {
	network: "Network",
	http: "HTTP error",
	invalid_response: "Invalid response",
	hash_mismatch: "Hash mismatch",
	signature: "Signature",
	patch: "Patch",
	extract: "Extract",
	storage: "Storage",
	unknown: "No reason reported"
};
var failureStageLabel = (stage) => STAGES[stage] ?? "Unknown stage";
var failureReasonLabel = (reason) => REASONS[reason] ?? "Unknown reason";
/** What else the client knew: its resource, HTTP status, origin code, and transport. */
var failureDetailParts = (detail) => [
	...detail.httpStatus == null ? [] : [`HTTP ${detail.httpStatus}`],
	...detail.originCode == null ? [] : [detail.originCode],
	...detail.transport == null ? [] : [detail.transport],
	...detail.resource == null ? [] : [detail.resource]
];
/** An update failure as one line: where, why, and what else the client knew. */
var describeFailure = (failure) => {
	const message = failure.errorMessage || (failure.reason === "unknown" ? "The client did not report a detailed cause" : failureReasonLabel(failure.reason));
	return [`${failureStageLabel(failure.stage)} failed: ${message}`, ...failureDetailParts(failure)].join(" · ");
};
//#endregion
export { failureReasonLabel as a, readUpdateFailuresInput as c, failureRate as i, describeFailure as n, failureStageLabel as o, failureDetailParts as r, formatRate as s, checkFailureRate as t };
