//#region node_modules/.nitro/vite/services/ssr/assets/uuid-kZvLA0Ly-DNL0qBSj.js
var LETTER_DASH_NUMBER = "[a-zA-Z0-9-]";
var NUMERIC_IDENTIFIER = String.raw`0|[1-9]\d*`;
var NUMERIC_IDENTIFIER_LOOSE = String.raw`\d+`;
var NON_NUMERIC_IDENTIFIER = String.raw`\d*[a-zA-Z-]${LETTER_DASH_NUMBER}*`;
var MAIN_VERSION = String.raw`(${NUMERIC_IDENTIFIER})\.(${NUMERIC_IDENTIFIER})\.(${NUMERIC_IDENTIFIER})`;
var MAIN_VERSION_LOOSE = String.raw`(${NUMERIC_IDENTIFIER_LOOSE})\.(${NUMERIC_IDENTIFIER_LOOSE})\.(${NUMERIC_IDENTIFIER_LOOSE})`;
var PRERELEASE_IDENTIFIER = `(?:${NON_NUMERIC_IDENTIFIER}|${NUMERIC_IDENTIFIER})`;
var PRERELEASE_IDENTIFIER_LOOSE = `(?:${NON_NUMERIC_IDENTIFIER}|${NUMERIC_IDENTIFIER_LOOSE})`;
var PRERELEASE = String.raw`(?:-(${PRERELEASE_IDENTIFIER}(?:\.${PRERELEASE_IDENTIFIER})*))`;
var PRERELEASE_LOOSE = String.raw`(?:-?(${PRERELEASE_IDENTIFIER_LOOSE}(?:\.${PRERELEASE_IDENTIFIER_LOOSE})*))`;
var BUILD_IDENTIFIER = `${LETTER_DASH_NUMBER}+`;
var BUILD = String.raw`(?:\+(${BUILD_IDENTIFIER}(?:\.${BUILD_IDENTIFIER})*))`;
var FULL_PLAIN = `v?${MAIN_VERSION}${PRERELEASE}?${BUILD}?`;
var LOOSE_PLAIN = String.raw`[v=\s]*${MAIN_VERSION_LOOSE}${PRERELEASE_LOOSE}?${BUILD}?`;
var XRANGE_IDENTIFIER = String.raw`${NUMERIC_IDENTIFIER}|x|X|\*`;
var XRANGE_IDENTIFIER_LOOSE = String.raw`${NUMERIC_IDENTIFIER_LOOSE}|x|X|\*`;
String.raw`[v=\s]*(${XRANGE_IDENTIFIER})(?:\.(${XRANGE_IDENTIFIER})(?:\.(${XRANGE_IDENTIFIER})(?:${PRERELEASE})?${BUILD}?)?)?`;
String.raw`[v=\s]*(${XRANGE_IDENTIFIER_LOOSE})(?:\.(${XRANGE_IDENTIFIER_LOOSE})(?:\.(${XRANGE_IDENTIFIER_LOOSE})(?:${PRERELEASE_LOOSE})?${BUILD}?)?)?`;
String.raw`(?:\^)`;
var COERCE_PLAIN = String.raw`(^|[^\d])(\d{1,${16}})(?:\.(\d{1,${16}}))?(?:\.(\d{1,${16}}))?`;
var COERCE = String.raw`${COERCE_PLAIN}(?:$|[^\d])`;
var COERCE_FULL = String.raw`${COERCE_PLAIN}(?:${PRERELEASE})?(?:${BUILD})?(?:$|[^\d])`;
function makeSafeRegexSource(source) {
	const replacements = [
		[String.raw`\s`, 1],
		[String.raw`\d`, 256],
		[LETTER_DASH_NUMBER, 250]
	];
	for (const [token, maximum] of replacements) source = source.split(`${token}*`).join(`${token}{0,${maximum}}`).split(`${token}+`).join(`${token}{1,${maximum}}`);
	return source;
}
function safeRegex(source, flags) {
	return new RegExp(makeSafeRegexSource(source), flags);
}
var FULL = safeRegex(`^${FULL_PLAIN}$`);
var LOOSE = safeRegex(`^${LOOSE_PLAIN}$`);
var NUMERIC$1 = /^\d+$/;
function formatComparableVersion(version) {
	const base = `${version.major}.${version.minor}.${version.patch}`;
	return version.prerelease?.length ? `${base}-${version.prerelease.join(".")}` : base;
}
function formatFullVersion(version) {
	const comparable = formatComparableVersion(version);
	return version.build?.length ? `${comparable}+${version.build.join(".")}` : comparable;
}
function parse(version, options = {}) {
	if (typeof version !== "string") return version;
	if (version.length > 256) throw new TypeError(`Version exceeds the maximum length of 256 characters`);
	const match = version.trim().match(options.loose ? LOOSE : FULL);
	if (!match) throw new TypeError(`Invalid version syntax: ${version}`);
	const major = Number(match[1]);
	const minor = Number(match[2]);
	const patch = Number(match[3]);
	if (major > Number.MAX_SAFE_INTEGER || major < 0) throw new TypeError(`Invalid major version: ${match[1]}`);
	if (minor > Number.MAX_SAFE_INTEGER || minor < 0) throw new TypeError(`Invalid minor version: ${match[2]}`);
	if (patch > Number.MAX_SAFE_INTEGER || patch < 0) throw new TypeError(`Invalid patch version: ${match[3]}`);
	const prerelease = match[4] ? match[4].split(".").map((identifier) => {
		if (NUMERIC$1.test(identifier)) {
			const numeric = Number(identifier);
			if (numeric >= 0 && numeric < Number.MAX_SAFE_INTEGER) return numeric;
		}
		return identifier;
	}) : void 0;
	return {
		build: match[5]?.split("."),
		major,
		minor,
		patch,
		prerelease
	};
}
function tryParse(version, options = {}) {
	try {
		return parse(version, options);
	} catch {
		return null;
	}
}
var COERCE_EXACT = safeRegex(COERCE);
var COERCE_FULL_EXACT = safeRegex(COERCE_FULL);
safeRegex(`^${PRERELEASE}$`);
safeRegex(`^${PRERELEASE_LOOSE}$`);
function normalizeFull(version, options = {}) {
	const parsed = tryParse(version, options);
	return parsed ? formatFullVersion(parsed) : null;
}
function coerce(value, options = {}) {
	if (typeof value === "object") return value;
	const input = typeof value === "number" ? String(value) : value;
	let match = null;
	if (options.rtl) {
		const expression = safeRegex(options.includePrerelease ? COERCE_FULL : COERCE, "g");
		let next;
		while ((next = expression.exec(input)) && (!match || match.index + match[0].length !== input.length)) {
			if (!match || next.index + next[0].length !== match.index + match[0].length) match = next;
			expression.lastIndex = next.index + next[1].length + next[2].length;
		}
	} else match = (options.includePrerelease ? COERCE_FULL_EXACT : COERCE_EXACT).exec(input);
	if (!match) return null;
	const major = match[2];
	return tryParse(`${major}.${match[3] || "0"}.${match[4] || "0"}${options.includePrerelease && match[5] ? `-${match[5]}` : ""}${options.includePrerelease && match[6] ? `+${match[6]}` : ""}`, options);
}
/**
* The form of an app version that the device and the server compare:
* `major.minor.patch` of the first version in `appVersion`, such as `1.4.0`
* for `v1.4`, or null when it holds none. Prerelease and build parts are
* dropped.
*/
function canonicalizeAppVersion(appVersion) {
	const version = coerce(appVersion);
	return version ? normalizeFull(version) : null;
}
var BASE64URL_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
var MAX_CATALOG_SEGMENT_LENGTH = 255;
function assertCatalogSegment(value, name) {
	if (value.length === 0 || value.length > MAX_CATALOG_SEGMENT_LENGTH || !/^[A-Za-z0-9._~-]+$/.test(value)) throw new Error(`${name} must be 1-${MAX_CATALOG_SEGMENT_LENGTH} URL-safe ASCII characters`);
}
function encodeUtf8(value) {
	const bytes = [];
	for (const codePointText of value) {
		const codePoint = codePointText.codePointAt(0);
		if (codePoint <= 127) bytes.push(codePoint);
		else if (codePoint <= 2047) bytes.push(192 | codePoint >> 6, 128 | codePoint & 63);
		else if (codePoint <= 65535) bytes.push(224 | codePoint >> 12, 128 | codePoint >> 6 & 63, 128 | codePoint & 63);
		else bytes.push(240 | codePoint >> 18, 128 | codePoint >> 12 & 63, 128 | codePoint >> 6 & 63, 128 | codePoint & 63);
	}
	return bytes;
}
function decodeUtf8(bytes) {
	let result = "";
	for (let index = 0; index < bytes.length;) {
		const first = bytes[index++];
		let codePoint;
		let continuationCount;
		if (first <= 127) {
			codePoint = first;
			continuationCount = 0;
		} else if ((first & 224) === 192) {
			codePoint = first & 31;
			continuationCount = 1;
		} else if ((first & 240) === 224) {
			codePoint = first & 15;
			continuationCount = 2;
		} else if ((first & 248) === 240) {
			codePoint = first & 7;
			continuationCount = 3;
		} else throw new Error("Invalid UTF-8 channel key");
		for (let offset = 0; offset < continuationCount; offset += 1) {
			const continuation = bytes[index++];
			if (continuation === void 0 || (continuation & 192) !== 128) throw new Error("Invalid UTF-8 channel key");
			codePoint = codePoint << 6 | continuation & 63;
		}
		if (codePoint > 1114111 || codePoint >= 55296 && codePoint <= 57343 || continuationCount === 1 && codePoint < 128 || continuationCount === 2 && codePoint < 2048 || continuationCount === 3 && codePoint < 65536) throw new Error("Invalid UTF-8 channel key");
		result += String.fromCodePoint(codePoint);
	}
	return result;
}
function base64UrlEncode(bytes) {
	let result = "";
	for (let index = 0; index < bytes.length; index += 3) {
		const first = bytes[index];
		const second = bytes[index + 1];
		const third = bytes[index + 2];
		const value = first << 16 | (second ?? 0) << 8 | (third ?? 0);
		result += BASE64URL_ALPHABET[value >> 18 & 63];
		result += BASE64URL_ALPHABET[value >> 12 & 63];
		if (second !== void 0) result += BASE64URL_ALPHABET[value >> 6 & 63];
		if (third !== void 0) result += BASE64URL_ALPHABET[value & 63];
	}
	return result;
}
function base64UrlDecode(value) {
	if (!/^[A-Za-z0-9_-]*$/.test(value) || value.length % 4 === 1) throw new Error("Invalid channel key");
	const bytes = [];
	for (let index = 0; index < value.length; index += 4) {
		const chunk = value.slice(index, index + 4);
		const encoded = [...chunk].map((character) => BASE64URL_ALPHABET.indexOf(character));
		if (encoded.some((part) => part < 0)) throw new Error("Invalid channel key");
		const bits = encoded[0] << 18 | encoded[1] << 12 | (encoded[2] ?? 0) << 6 | (encoded[3] ?? 0);
		bytes.push(bits >> 16 & 255);
		if (chunk.length >= 3) bytes.push(bits >> 8 & 255);
		if (chunk.length === 4) bytes.push(bits & 255);
	}
	return bytes;
}
function normalizeChannelName(channel) {
	return channel.trim().normalize("NFC");
}
function assertCanonicalChannelName(channel) {
	const normalized = normalizeChannelName(channel);
	if (normalized.length === 0 || normalized !== channel) throw new Error("Channel name must be non-empty, trimmed, and NFC-normalized");
	let codePointCount = 0;
	for (const _codePoint of normalized) {
		codePointCount += 1;
		if (codePointCount > 255) throw new Error("Channel name must not exceed 255 characters");
	}
}
function encodeChannelKey(channel) {
	assertCanonicalChannelName(channel);
	return base64UrlEncode(encodeUtf8(channel));
}
function decodeChannelKey(channelKey) {
	const channel = decodeUtf8(base64UrlDecode(channelKey));
	assertCanonicalChannelName(channel);
	if (encodeChannelKey(channel) !== channelKey) throw new Error("Channel key is not canonically encoded");
	return channel;
}
function createReleaseCatalogScopeKey(input) {
	decodeChannelKey(input.channelKey);
	if (input.strategy === "APP_VERSION") return `v1:app-version:${input.platform}:${input.channelKey}`;
	assertCatalogSegment(input.fingerprintHash, "Fingerprint hash");
	return `v1:fingerprint:${input.platform}:${input.channelKey}:${input.fingerprintHash}`;
}
function parseReleaseCatalogScopeKey(scopeKey) {
	const segments = scopeKey.split(":");
	const [version, strategy, platform, channelKey] = segments;
	if (version !== "v1" || platform !== "ios" && platform !== "android" || channelKey === void 0) throw new Error("Invalid release catalog scope key");
	const input = strategy === "app-version" && segments.length === 4 ? {
		channelKey,
		platform,
		strategy: "APP_VERSION"
	} : strategy === "fingerprint" && segments.length === 5 && segments[4] !== void 0 ? {
		channelKey,
		fingerprintHash: segments[4],
		platform,
		strategy: "FINGERPRINT"
	} : (() => {
		throw new Error("Invalid release catalog scope key");
	})();
	if (createReleaseCatalogScopeKey(input) !== scopeKey) throw new Error("Release catalog scope key is not canonical");
	return input;
}
var NIL_UUID = "00000000-0000-0000-0000-000000000000";
var UUID_V7_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
var isUUIDv7 = (value) => typeof value === "string" && UUID_V7_PATTERN.test(value);
//#endregion
export { decodeChannelKey as a, parseReleaseCatalogScopeKey as c, createReleaseCatalogScopeKey as i, assertCanonicalChannelName as n, encodeChannelKey as o, canonicalizeAppVersion as r, isUUIDv7 as s, NIL_UUID as t };
