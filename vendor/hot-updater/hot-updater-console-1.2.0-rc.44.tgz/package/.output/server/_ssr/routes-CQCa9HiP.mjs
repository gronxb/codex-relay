import { i as __toESM } from "../_runtime.mjs";
import { Et as require_react, Tt as require_jsx_runtime, a as SliderIndicator, c as SliderControl, l as SliderRoot, o as SliderThumb, s as SliderTrack } from "../_libs/@base-ui/react+[...].mjs";
import { B as Download, D as LoaderCircle, J as ChevronRight, O as List, P as Funnel, R as ExternalLink, T as Minus, W as CircleOff, X as ChevronDown, Z as Check, _ as RefreshCw, a as Trash2, g as RotateCcw, i as TriangleAlert, nt as ArrowUpRight, o as Tags, rt as ArrowRight, s as Tag, t as X, v as Plus, x as Package } from "../_libs/lucide-react.mjs";
import { C as Skeleton, O as buttonVariants, S as SidebarTrigger, a as SheetContent, c as SheetTitle, i as Sheet, j as useIsMobile, k as cn, n as Input, o as SheetDescription, r as Separator$1, s as SheetHeader, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as CardHeader, n as CardContent, o as CardTitle, r as CardDescription, t as Card } from "./card-CsUxqR3-.mjs";
import { a as Badge, i as AlertTitle, n as AlertAction, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { a as FieldLabel, c as Label, i as FieldGroup, n as FieldDescription, r as FieldError, t as Field } from "./field-BVbdqLG6.mjs";
import { a as AlertDialogDescription, i as AlertDialogContent, l as AlertDialogTitle, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog$1 } from "./alert-dialog-ByY_ghMv.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as DialogTrigger, t as Dialog$1 } from "./dialog-CNWOO08-.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-4qgdiham.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as normalizeRolloutCohortCount, f as getPatchBaseBundleId, m as getPatchFileHash, p as getPatchBaseFileHash, r as NUMERIC_COHORT_SIZE, t as INVALID_COHORT_ERROR_MESSAGE, u as getNumericCohortRolloutPosition, v as isValidCohort, y as normalizeCohortValue } from "./dist-CiOq3ygH.mjs";
import { N as releaseNativeBuildScope, j as platformLabel, v as nativeBuildArtifacts } from "./native-builds-lEyKQemV.mjs";
import { n as normalizeRange } from "../_libs/verkit.mjs";
import { t as InfoTooltip } from "./insights-search-BZ00lACC.mjs";
import { C as useReleasesQuery, S as useReleaseQuery, _ as usePreflightReleaseMutation, a as useConfigQuery, b as useReleaseFoldQuery, c as useDeleteReleaseMutation, i as useChannelsQuery, n as useBundleChildrenQuery, o as useCreateChannelMutation, r as useBundleQuery, s as useDeleteChannelMutation, t as useBundleChildCountsQuery, v as usePromoteReleaseMutation, w as useUpdateReleaseMutation, x as useReleaseNativeBuildQuery, y as useReleaseCatalogDiagnosticsQuery } from "./api-BISxaFip.mjs";
import { n as PlatformLabel, t as PlatformIcon } from "./PlatformIcon-C22qEcwo.mjs";
import { a as SelectTrigger, i as SelectItem, n as SelectContent, o as SelectValue, r as SelectGroup, t as Select$1 } from "./select-DYhN8vLu.mjs";
import { t as BundleIdDisplay } from "./BundleIdDisplay-LgsZ_E0k.mjs";
import { a as InputGroupText, i as InputGroupInput, n as InputGroupAddon, o as Textarea, t as InputGroup } from "./input-group-DpNq5b5O.mjs";
import { t as ChannelPicker } from "./ChannelPicker-DNX6PX8b.mjs";
import { t as HashValueDisplay } from "./HashValueDisplay-BAS89lvP.mjs";
import { t as ChannelBadge } from "./ChannelBadge-DsA4srwK.mjs";
import { a as DataTableBody, c as DataTableFullRow, d as DataTableSkeletonRows, f as RelativeTime, i as DataTable, l as DataTablePagination, n as DataCardSkeletons, o as DataTableEmpty, p as openOutsideControls, r as DataCardsEmpty, s as DataTableFrame, t as DataCard, u as DataTableRow } from "./RelativeTime-jQk9a1D5.mjs";
import { i as TargetDisplay, n as CopyableText } from "./TargetDisplay-CwHH2uJ2.mjs";
import { a as foldKey, c as groupsOf, i as RowReason, l as useOpenFolds, n as DataTableFold, o as foldLabel, r as FoldStatus, s as foldedTotal, t as DataCardFold } from "./RowReason-DJegqY99.mjs";
import { n as TimestampDisplay, r as getCommitUrl, t as RolloutPercentageBadge } from "./RolloutPercentageBadge-XfgBi8FV.mjs";
import { n as useDialogTarget, t as Switch$1 } from "./switch-DaBFthcN.mjs";
import { a as resolveReleaseSearch, i as releaseFilterOf, l as useReleaseColumns, n as Route, o as showsDefaultReleases, r as hasReleaseFilters, s as updateReleaseFilters, t as ReleaseSections } from "./routes-CdByvccx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CQCa9HiP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EnabledStatusIcon({ enabled, className, falseIcon = "x", colorMode = "semantic" }) {
	const iconColorClassName = colorMode === "inherit" ? "text-current" : void 0;
	if (enabled) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: cn("h-4 w-4", iconColorClassName ?? "text-green-600 dark:text-green-400", className) });
	if (falseIcon === "minus") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: cn("h-4 w-4", iconColorClassName ?? "text-muted-foreground", className) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: cn("h-4 w-4", iconColorClassName ?? "text-red-600 dark:text-red-400", className) });
}
function BundleChildrenPanel({ panelId, bundle, bundles, loading, onDetailClick }) {
	const isMobile = useIsMobile();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-live": "polite",
		className: "border-t bg-muted/10 p-3 sm:p-4",
		id: panelId,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: "Advanced artifact diagnostics"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-start gap-2 text-sm sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Base artifact ID"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
							bundleId: bundle.id,
							fullOnMobile: true,
							maxLength: 18
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						children: [
							bundles.length,
							" ",
							bundles.length === 1 ? "patch" : "patches"
						]
					})]
				}),
				loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })]
				}) : bundles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-semibold uppercase text-muted-foreground/70",
						children: "Patch artifacts from this base"
					}), isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-2",
						children: bundles.map((childBundle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-md border bg-background p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] font-medium uppercase text-muted-foreground/70",
											children: "Target artifact ID"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
											bundleId: childBundle.id,
											fullOnMobile: true,
											maxLength: 18
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] font-medium uppercase text-muted-foreground/70",
											children: "Relation"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col items-start gap-1 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
													bundleId: bundle.id,
													fullOnMobile: true,
													maxLength: 12
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 rotate-90 text-muted-foreground" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
													bundleId: childBundle.id,
													fullOnMobile: true,
													maxLength: 12
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] font-medium uppercase text-muted-foreground/70",
												children: "Artifact"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "secondary",
												children: "bsdiff"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1 text-right",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] font-medium uppercase text-muted-foreground/70",
												children: "Created"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs tabular-nums text-foreground",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimestampDisplay, { uuid: childBundle.id })
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
										className: "w-full",
										onClick: () => onDetailClick(childBundle),
										size: "sm",
										type: "button",
										variant: "outline",
										children: "Detail"
									})
								]
							})
						}, childBundle.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-md border bg-background",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							className: "min-w-max",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
								className: "hover:bg-transparent",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Target artifact ID" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Relation" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Artifact" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Created" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "w-24 text-right",
										children: "Detail"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: bundles.map((childBundle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
									bundleId: childBundle.id,
									fullOnMobile: true,
									maxLength: 18
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex min-w-[280px] flex-col items-start gap-1 sm:flex-row sm:items-center sm:gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
											bundleId: bundle.id,
											fullOnMobile: true,
											maxLength: 12
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 shrink-0 rotate-90 text-muted-foreground sm:rotate-0" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
											bundleId: childBundle.id,
											fullOnMobile: true,
											maxLength: 12
										})
									]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "secondary",
									children: "bsdiff"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "tabular-nums",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimestampDisplay, { uuid: childBundle.id })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
										onClick: () => onDetailClick(childBundle),
										size: "sm",
										type: "button",
										variant: "outline",
										children: "Detail"
									})
								})
							] }, childBundle.id)) })]
						})
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-semibold uppercase text-muted-foreground/70",
						children: "Patch artifacts from this base"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-md border bg-background p-3 text-sm text-muted-foreground",
						children: "No direct patch artifacts."
					})]
				})
			]
		})
	});
}
function ChannelManagementDialog({ open, onOpenChange }) {
	const [channelName, setChannelName] = (0, import_react.useState)("");
	const [channelToDelete, setChannelToDelete] = (0, import_react.useState)(null);
	const shownChannelToDelete = useDialogTarget(channelToDelete);
	const { data: channels = [], isPending: isLoadingChannels } = useChannelsQuery();
	const createChannel = useCreateChannelMutation();
	const deleteChannel = useDeleteChannelMutation();
	const normalizedName = channelName.trim();
	const handleCreate = async (event) => {
		event.preventDefault();
		if (!normalizedName || createChannel.isPending) return;
		try {
			const result = await createChannel.mutateAsync({ name: normalizedName });
			setChannelName("");
			if (result.inserted) toast.success(`Channel ${result.row.name} created`);
			else toast.info(`Channel ${result.row.name} already exists`);
		} catch (error) {
			toast.error("Failed to create channel");
			console.error(error);
		}
	};
	const handleDelete = async () => {
		if (!channelToDelete || deleteChannel.isPending) return;
		try {
			const result = await deleteChannel.mutateAsync({ id: channelToDelete.id });
			if (result.deleted) toast.success(`Channel ${channelToDelete.name} deleted`);
			else if (result.reason === "not_empty") toast.error(`Channel ${channelToDelete.name} is still in use and cannot be deleted`);
			else toast.error(`Channel ${channelToDelete.name} no longer exists`);
			setChannelToDelete(null);
		} catch (error) {
			toast.error("Failed to delete channel");
			console.error(error);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "size-4 text-muted-foreground" }), "Channels"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Create deployment channels and remove them when no bundle uses them. Empty channels remain available until you delete them." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					onSubmit: handleCreate,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldGroup, {
						className: "gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
							orientation: "horizontal",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
									htmlFor: "channel-name",
									className: "sr-only",
									children: "Channel name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "channel-name",
									value: channelName,
									onChange: (event) => setChannelName(event.target.value),
									placeholder: "Channel name",
									autoComplete: "off",
									disabled: createChannel.isPending
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
									className: "max-md:h-11",
									type: "submit",
									disabled: !normalizedName || createChannel.isPending,
									children: [createChannel.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
										"data-icon": "inline-start",
										className: "animate-spin motion-reduce:animate-none"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), "Create"]
								})
							]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-72 overflow-y-auto rounded-lg border",
					children: isLoadingChannels ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-20 items-center justify-center text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-3.5 animate-spin motion-reduce:animate-none" }), "Loading channels"]
					}) : channels.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-20 items-center justify-center text-muted-foreground",
						children: "No channels yet"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y",
						children: channels.map((channel) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex min-h-12 items-center gap-3 px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "min-w-0 flex-1 truncate text-xs font-medium",
								title: channel.name,
								children: channel.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
								type: "button",
								variant: "ghost",
								size: "icon-sm",
								"aria-label": `Delete ${channel.name}`,
								title: `Delete ${channel.name}`,
								disabled: deleteChannel.isPending,
								onClick: () => setChannelToDelete(channel),
								className: "text-muted-foreground hover:text-destructive max-md:size-11",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { "data-icon": "inline-start" })
							})]
						}, channel.id))
					})
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog$1, {
		open: channelToDelete !== null,
		onOpenChange: (nextOpen) => {
			if (!nextOpen && !deleteChannel.isPending) setChannelToDelete(null);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, { children: [
			"Delete ",
			shownChannelToDelete?.name,
			"?"
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "Only empty channels can be removed. The server checks this when you delete it, and the channel can be created again later with a new ID." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
			disabled: deleteChannel.isPending,
			children: "Cancel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
			variant: "destructive",
			disabled: deleteChannel.isPending,
			onClick: (event) => {
				event.preventDefault();
				handleDelete();
			},
			children: deleteChannel.isPending ? "Deleting..." : "Delete channel"
		})] })] })
	})] });
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1.5 sm:flex-row sm:items-start sm:justify-between sm:gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "min-w-0 text-left text-sm sm:text-right",
			children: value
		})]
	});
}
function BundleMetadata({ bundle, release }) {
	const { data: configData, isFetched } = useConfigQuery();
	const hbcPatchFileHash = bundle ? getPatchFileHash(bundle) : null;
	const hbcPatchBaseFileHash = bundle ? getPatchBaseFileHash(bundle) : null;
	const gitCommitUrl = bundle?.gitCommitHash && isFetched ? getCommitUrl(configData?.console.gitUrl, bundle.gitCommitHash) : null;
	const target = release.strategy === "APP_VERSION" ? release.target_app_version : release.fingerprint_hash;
	if (!(target || bundle?.gitCommitHash || bundle?.manifestFileHash || hbcPatchBaseFileHash || hbcPatchFileHash)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
		className: "p-4 pb-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
			className: "text-sm font-medium",
			children: "Metadata"
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
		className: "px-4 pb-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "flex flex-col gap-3 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: release.strategy === "APP_VERSION" ? "Target app version" : "Fingerprint target",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "break-all font-mono text-xs",
						translate: "no",
						children: target ?? "—"
					})
				}),
				bundle?.gitCommitHash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Git commit",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-start gap-1 sm:justify-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
							className: gitCommitUrl ? "text-primary" : void 0,
							maxLength: 12,
							value: bundle.gitCommitHash
						}), gitCommitUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							"aria-label": "Open git commit",
							className: "relative shrink-0 text-primary after:absolute after:-inset-2.5 hover:underline md:after:hidden",
							href: gitCommitUrl,
							rel: "noopener noreferrer",
							target: "_blank",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { "aria-hidden": "true" })
						}) : null]
					})
				}) : null,
				bundle?.manifestFileHash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Manifest hash",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
						maxLength: 16,
						value: bundle.manifestFileHash
					})
				}) : null,
				hbcPatchBaseFileHash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Base hash",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
						maxLength: 16,
						value: hbcPatchBaseFileHash
					})
				}) : null,
				hbcPatchFileHash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Patch hash",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
						maxLength: 16,
						value: hbcPatchFileHash
					})
				}) : null
			]
		})
	})] });
}
var ALL_NUMERIC_COHORTS = Array.from({ length: NUMERIC_COHORT_SIZE }, (_, index) => index + 1);
function RolloutCohortsDialog({ releaseId, rolloutCohortCount, targetCohorts }) {
	const normalizedRolloutCount = normalizeRolloutCohortCount(rolloutCohortCount);
	const normalizedTargetCohorts = targetCohorts ?? [];
	const hasTargetCohorts = normalizedTargetCohorts.length > 0;
	const isPartialRollout = normalizedRolloutCount > 0 && normalizedRolloutCount < 1e3;
	const isFullRollout = normalizedRolloutCount === NUMERIC_COHORT_SIZE;
	const isMobile = useIsMobile();
	const rolloutCohorts = isFullRollout ? ALL_NUMERIC_COHORTS : isPartialRollout ? ALL_NUMERIC_COHORTS.filter((cohortValue) => getNumericCohortRolloutPosition(releaseId, cohortValue) < normalizedRolloutCount) : [];
	const rolloutPercentage = (normalizedRolloutCount / 10).toFixed(1);
	const selectedCount = isFullRollout ? NUMERIC_COHORT_SIZE : rolloutCohorts.length;
	const excludedCount = NUMERIC_COHORT_SIZE - selectedCount;
	const dialogBody = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Selected cohorts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "font-mono text-2xl tabular-nums",
						children: selectedCount
					})]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Excluded cohorts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "font-mono text-2xl tabular-nums",
						children: excludedCount
					})]
				}) })]
			}),
			hasTargetCohorts ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "p-4 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-sm",
					children: "Additional cohorts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Always included in addition to the percentage rollout." })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-4 pt-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2 rounded-lg border bg-muted/20 p-3",
					children: normalizedTargetCohorts.map((cohort) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						className: "max-w-full font-mono",
						variant: "secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: cohort
						})
					}, cohort))
				})
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
				className: "p-4 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-sm",
					children: "Numeric cohorts"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-4 pt-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[50vh] overflow-y-auto overscroll-contain rounded-lg border bg-muted/20 p-3 sm:max-h-[45vh]",
					children: rolloutCohorts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-label": "Included numeric cohorts",
						className: "grid grid-cols-3 gap-2 sm:grid-cols-6 lg:grid-cols-8",
						role: "list",
						children: rolloutCohorts.map((cohortValue) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "justify-center font-mono tabular-nums",
							role: "listitem",
							variant: "outline",
							children: cohortValue
						}, cohortValue))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No numeric cohorts are included."
					})
				})
			})] })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			className: "max-md:h-11",
			size: "sm",
			type: "button",
			variant: "outline"
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { "data-icon": "inline-start" }), "Preview cohorts"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
		className: isMobile ? "top-0 left-0 h-dvh max-w-none translate-x-0 translate-y-0 rounded-none border-0 p-0" : "sm:max-w-3xl",
		children: isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-full flex-col overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "shrink-0 border-b border-border/70 px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Rolled out cohorts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						rolloutPercentage,
						"% includes ",
						selectedCount,
						" of",
						" ",
						NUMERIC_COHORT_SIZE,
						" numeric cohorts.",
						hasTargetCohorts ? " Additional cohorts are always included." : ""
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto overscroll-contain px-4 py-4",
					children: dialogBody
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, {
					className: "shrink-0 border-t border-border/70 px-4 py-3",
					showCloseButton: true
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Rolled out cohorts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				rolloutPercentage,
				"% includes ",
				selectedCount,
				" of",
				" ",
				NUMERIC_COHORT_SIZE,
				" numeric cohorts.",
				hasTargetCohorts ? " Additional cohorts are always included." : ""
			] })] }),
			dialogBody,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { showCloseButton: true })
		] })
	})] });
}
/**
* The native build new deploys to a release's scope patch from, and whether
* this bundle has a patch from its built-in bundle: the scope's store build,
* or with none its newest, in two reads at most. A release of an app version
* range targets many builds, so it shows none and reads nothing.
*/
function ReleaseNativeBuildLink({ release, channel, bundle }) {
	const input = release.bundle_id === null ? null : {
		platform: release.platform,
		channel,
		fingerprintHash: release.fingerprint_hash,
		targetAppVersion: release.target_app_version
	};
	const scoped = input !== null && releaseNativeBuildScope(input) !== null;
	const query = useReleaseNativeBuildQuery(scoped ? input : null);
	if (!scoped) return null;
	const build = query.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium text-muted-foreground",
			children: "Native build"
		}), query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40" }) : build ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			className: "inline-flex flex-wrap items-center gap-x-1 gap-y-0.5 text-xs text-foreground underline-offset-4 hover:underline",
			params: { buildId: build.id },
			to: "/native-builds/$buildId",
			children: [
				platformLabel(build.platform),
				" ",
				nativeBuildArtifacts[build.artifact_kind].label,
				" ·",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono",
					translate: "no",
					children: build.min_bundle_id
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
					"aria-hidden": "true",
					className: "size-3"
				})
			]
		}), bundle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "secondary",
			children: (bundle.patches ?? []).some(({ baseBundleId }) => baseBundleId === build.min_bundle_id) ? "Patches from it" : "No patch from it"
		}) : null] }) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted-foreground",
			children: [
				"Couldn't load the scope's native build.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "underline underline-offset-4",
					onClick: () => void query.refetch(),
					type: "button",
					children: "Retry"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted-foreground",
			children: [
				"None tracked for this scope ·",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: "relative underline-offset-4 after:absolute after:-inset-x-2 after:-inset-y-4 hover:text-foreground hover:underline md:after:hidden",
					search: { channel },
					to: "/native-builds",
					children: "This channel's builds"
				})
			]
		})]
	});
}
function Slider$1({ className, defaultValue, value, min = 0, max = 100, ...props }) {
	const _values = Array.isArray(value) ? value : value !== void 0 ? [value] : Array.isArray(defaultValue) ? defaultValue : defaultValue !== void 0 ? [defaultValue] : [min];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRoot, {
		className: cn("data-horizontal:w-full data-vertical:h-full", className),
		"data-slot": "slider",
		defaultValue,
		value,
		min,
		max,
		thumbAlignment: "edge",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SliderControl, {
			className: "relative flex w-full touch-none items-center select-none data-disabled:opacity-50 data-vertical:h-full data-vertical:min-h-40 data-vertical:w-auto data-vertical:flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
				"data-slot": "slider-track",
				className: "relative grow overflow-hidden rounded-full bg-primary/20 select-none data-horizontal:h-1.5 data-horizontal:w-full data-vertical:h-full data-vertical:w-1.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderIndicator, {
					"data-slot": "slider-range",
					className: "bg-primary select-none data-horizontal:h-full data-vertical:w-full"
				})
			}), Array.from({ length: _values.length }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, {
				"data-slot": "slider-thumb",
				className: "relative block size-4 shrink-0 rounded-full border border-primary/50 bg-background shadow transition-colors select-none after:absolute after:-inset-2 max-md:after:-inset-3.5 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring data-disabled:pointer-events-none data-disabled:opacity-50"
			}, index))]
		})
	});
}
var promoteActionItems = [{
	label: "Move bundle",
	value: "move"
}, {
	label: "Copy bundle",
	value: "copy"
}];
var draftFromRelease = (release) => ({
	enabled: release.enabled,
	message: release.message ?? "",
	rolloutCohortCount: release.rollout_cohort_count,
	shouldForceUpdate: release.should_force_update,
	targetAppVersion: release.target_app_version ?? "",
	targetCohorts: [...release.target_cohorts]
});
var patchFromDraft = (release, draft) => ({
	enabled: draft.enabled,
	message: draft.message.trim() || null,
	rolloutCohortCount: draft.rolloutCohortCount,
	shouldForceUpdate: draft.shouldForceUpdate,
	...release.strategy === "APP_VERSION" ? { targetAppVersion: draft.targetAppVersion.trim() } : {},
	targetCohorts: draft.targetCohorts
});
var formatRolloutPercentage = (count) => (count / 10).toFixed(1);
var formatRolloutInput = (value) => {
	const normalized = value.replace(",", ".");
	const [integer = "", ...decimals] = normalized.split(".");
	const integerDigits = integer.replace(/\D/g, "").slice(0, 3);
	const decimalDigit = decimals.join("").replace(/\D/g, "").slice(0, 1);
	return normalized.includes(".") ? `${integerDigits}.${decimalDigit}` : integerDigits;
};
var parseRolloutInput = (value) => {
	const percentage = Number.parseFloat(value);
	if (!Number.isFinite(percentage)) return null;
	return Math.min(1e3, Math.max(0, Math.trunc(percentage * 10)));
};
function RolloutPercentageInput({ value, onChange }) {
	const [inputValue, setInputValue] = (0, import_react.useState)(formatRolloutPercentage(value));
	const [focused, setFocused] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!focused) setInputValue(formatRolloutPercentage(value));
	}, [focused, value]);
	const commitInput = () => {
		const nextValue = parseRolloutInput(inputValue) ?? value;
		setFocused(false);
		setInputValue(formatRolloutPercentage(nextValue));
		onChange(nextValue);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider$1, {
			"aria-label": "Rollout percentage",
			max: 1e3,
			min: 0,
			onValueChange: (nextValue) => onChange(Array.isArray(nextValue) ? nextValue[0] ?? value : nextValue),
			step: 1,
			value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputGroup, {
			className: "w-24 shrink-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupInput, {
				"aria-label": "Rollout percentage",
				autoComplete: "off",
				className: "text-right tabular-nums",
				id: "release-rollout-percentage",
				inputMode: "decimal",
				name: "rolloutPercentage",
				onBlur: commitInput,
				onChange: (event) => {
					const nextInput = formatRolloutInput(event.target.value);
					setInputValue(nextInput);
					const parsed = parseRolloutInput(nextInput);
					if (parsed !== null) onChange(parsed);
				},
				onFocus: () => setFocused(true),
				value: inputValue
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, {
				align: "inline-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupText, { children: "%" })
			})]
		})]
	});
}
function ReleaseEditorSheet({ channels, onOpenChange, onShowScope, open, releaseId }) {
	const releaseQuery = useReleaseQuery(releaseId);
	const release = releaseQuery.data;
	const bundleQuery = useBundleQuery(release?.bundle_id ?? "");
	const bundle = bundleQuery.data;
	const patchBaseBundleId = bundle ? getPatchBaseBundleId(bundle) : null;
	const diagnostics = useReleaseCatalogDiagnosticsQuery(release?.scope_key ?? "");
	const update = useUpdateReleaseMutation();
	const preflight = usePreflightReleaseMutation();
	const remove = useDeleteReleaseMutation();
	const promote = usePromoteReleaseMutation();
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [newCohort, setNewCohort] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [confirmDiscard, setConfirmDiscard] = (0, import_react.useState)(false);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [showPromote, setShowPromote] = (0, import_react.useState)(false);
	const [targetChannel, setTargetChannel] = (0, import_react.useState)("");
	const [promoteAction, setPromoteAction] = (0, import_react.useState)("move");
	(0, import_react.useEffect)(() => {
		setDraft(release ? draftFromRelease(release) : null);
		setError("");
	}, [release]);
	const initialDraft = release ? draftFromRelease(release) : null;
	const dirty = draft !== null && initialDraft !== null && JSON.stringify(draft) !== JSON.stringify(initialDraft);
	const busy = preflight.isPending || update.isPending || remove.isPending || promote.isPending;
	const requestClose = () => {
		if (busy) return;
		if (dirty) {
			setConfirmDiscard(true);
			return;
		}
		onOpenChange(false);
	};
	const addCohort = () => {
		if (!draft) return;
		const cohort = normalizeCohortValue(newCohort);
		if (!isValidCohort(cohort)) {
			setError(INVALID_COHORT_ERROR_MESSAGE);
			return;
		}
		setDraft({
			...draft,
			targetCohorts: Array.from(new Set([...draft.targetCohorts, cohort]))
		});
		setNewCohort("");
		setError("");
	};
	const save = async () => {
		if (!release || !draft) return;
		const cohorts = draft.targetCohorts.map(normalizeCohortValue);
		if (cohorts.some((cohort) => !isValidCohort(cohort))) {
			setError(INVALID_COHORT_ERROR_MESSAGE);
			return;
		}
		if (release.strategy === "APP_VERSION" && !normalizeRange(draft.targetAppVersion.trim())) {
			setError("Enter a valid target app version range.");
			return;
		}
		const input = {
			expectedRevision: release.revision,
			patch: patchFromDraft(release, {
				...draft,
				targetCohorts: cohorts
			}),
			releaseId: release.id
		};
		setError("");
		try {
			await preflight.mutateAsync(input);
			await update.mutateAsync(input);
			toast.success("Bundle settings saved");
			onOpenChange(false);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Bundle settings could not be saved.");
		}
	};
	const channelName = channels.find((channel) => channel.id === release?.channel_id)?.name ?? release?.channel_id;
	const availableChannels = channels.filter((channel) => channel.id !== release?.channel_id);
	const availableChannelItems = availableChannels.map((channel) => ({
		label: channel.name,
		value: channel.name
	}));
	const normalizedTargetChannel = targetChannel.trim();
	const isCopyPromotion = promoteAction === "copy";
	const normalizedTargetAppVersion = draft ? normalizeRange(draft.targetAppVersion.trim()) : null;
	const resetPromoteDialog = () => {
		setTargetChannel("");
		setPromoteAction("move");
	};
	const handlePromoteOpenChange = (nextOpen) => {
		if (!nextOpen && promote.isPending) return;
		setShowPromote(nextOpen);
		if (!nextOpen) resetPromoteDialog();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			onOpenChange: (nextOpen) => nextOpen ? void 0 : requestClose(),
			open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
				className: "min-w-0 overflow-hidden data-[side=right]:w-full sm:max-w-[600px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
					className: "shrink-0 pr-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Bundle Detail" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, {
							className: "sr-only",
							children: "Edit bundle delivery settings."
						}),
						release ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex min-w-0 flex-col gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
											className: "size-4",
											platform: release.platform
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: release.platform === "ios" ? "iOS" : "Android"
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-start gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-muted-foreground",
										children: "ID"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 basis-full sm:basis-auto",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
											bundleId: release.id,
											fullOnMobile: true,
											maxLength: 18
										}), !release.bundle_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-foreground",
											children: "Built-in bundle"
										}) : null]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-muted-foreground",
										children: "Channel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-foreground",
										translate: "no",
										children: channelName
									})]
								}),
								channelName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseNativeBuildLink, {
									bundle,
									channel: channelName,
									release
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-muted-foreground",
										children: "Platform"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-foreground",
										children: release.platform === "ios" ? "iOS" : "Android"
									})]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 overflow-y-auto overscroll-contain",
					children: [releaseQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
						className: "m-4 sm:m-6",
						variant: "destructive",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Bundle details could not be loaded" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: releaseQuery.error.message })
						]
					}) : null, release && draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-6 px-4 pb-4 sm:px-6 sm:pb-6",
						children: [
							channelName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseSections, { release: {
								platform: release.platform,
								channel: channelName,
								releaseId: release.id,
								builtIn: !release.bundle_id
							} }) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								"aria-labelledby": "delivery-settings-heading",
								className: "flex flex-col gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-sm font-medium",
										id: "delivery-settings-heading",
										children: "Delivery settings"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, {
										className: "gap-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
												htmlFor: "release-message",
												children: "Message"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
												autoComplete: "off",
												id: "release-message",
												name: "message",
												onChange: (event) => setDraft({
													...draft,
													message: event.target.value
												}),
												rows: 3,
												value: draft.message
											})] }),
											release.strategy === "APP_VERSION" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
													htmlFor: "release-target",
													children: "Target app version"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													autoComplete: "off",
													id: "release-target",
													name: "targetAppVersion",
													onChange: (event) => setDraft({
														...draft,
														targetAppVersion: event.target.value
													}),
													value: draft.targetAppVersion
												}),
												normalizedTargetAppVersion ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: normalizedTargetAppVersion }) : null
											] }) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
														htmlFor: "release-enabled",
														children: "Enabled"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTooltip, {
														label: "About Enabled",
														children: "Disabling rolls devices back to the previous enabled bundle on their next check, or to the built-in app when none remains."
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
													"aria-label": "Enabled",
													checked: draft.enabled,
													id: "release-enabled",
													name: "enabled",
													onCheckedChange: (enabled) => setDraft({
														...draft,
														enabled
													})
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
														htmlFor: "release-force-update",
														children: "Force update"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTooltip, {
														label: "About Force update",
														children: "Devices apply this bundle right away, and so do devices that skip it to update straight to a newer bundle."
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
													"aria-label": "Force update",
													checked: draft.shouldForceUpdate,
													id: "release-force-update",
													name: "shouldForceUpdate",
													onCheckedChange: (shouldForceUpdate) => setDraft({
														...draft,
														shouldForceUpdate
													})
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
												htmlFor: "release-rollout-percentage",
												children: "Rollout percentage"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolloutPercentageInput, {
												onChange: (rolloutCohortCount) => setDraft({
													...draft,
													rolloutCohortCount
												}),
												value: draft.rolloutCohortCount
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center justify-between gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
														htmlFor: "release-cohort",
														children: "Additional cohorts (optional)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolloutCohortsDialog, {
														releaseId: release.id,
														rolloutCohortCount: draft.rolloutCohortCount,
														targetCohorts: draft.targetCohorts
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														autoComplete: "off",
														id: "release-cohort",
														name: "targetCohort",
														onChange: (event) => setNewCohort(event.target.value),
														onKeyDown: (event) => {
															if (event.key === "Enter") {
																event.preventDefault();
																addCohort();
															}
														},
														placeholder: "e.g. qa-team…",
														value: newCohort
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
														"aria-label": "Add cohort",
														className: "max-md:size-11",
														disabled: !newCohort.trim(),
														onClick: addCohort,
														size: "icon",
														type: "button",
														variant: "outline",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
													})]
												}),
												draft.targetCohorts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex flex-wrap gap-2",
													children: draft.targetCohorts.map((cohort) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
														className: "gap-1 font-mono",
														variant: "secondary",
														children: [cohort, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															"aria-label": `Remove cohort ${cohort}`,
															className: "rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
															onClick: () => setDraft({
																...draft,
																targetCohorts: draft.targetCohorts.filter((value) => value !== cohort)
															}),
															type: "button",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
														})]
													}, cohort))
												}) : null,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "Public names—no IDs or secrets." })
											] })
										]
									}),
									error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: error }) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
										className: "w-full max-md:h-11",
										disabled: !dirty || busy,
										onClick: save,
										size: "lg",
										children: preflight.isPending || update.isPending ? "Saving…" : "Save changes"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator$1, { className: "my-2" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "flex flex-col gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-sm font-medium",
										children: "Actions"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
										className: "w-full max-md:h-11",
										disabled: !release.bundle_id || busy,
										onClick: () => setShowPromote(true),
										size: "sm",
										variant: "outline",
										children: "Promote to channel"
									}),
									release.bundle_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
										className: "w-full max-md:h-11",
										disabled: busy,
										onClick: () => {
											window.open(`/api/bundles/${encodeURIComponent(release.bundle_id)}/download`, "_blank", "noopener,noreferrer");
											toast.success("Bundle download started");
										},
										size: "sm",
										variant: "outline",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { "data-icon": "inline-start" }), "Download manifest"]
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
										className: "w-full max-md:h-11",
										disabled: release.enabled || busy,
										onClick: () => setConfirmDelete(true),
										size: "sm",
										variant: "destructive",
										children: "Remove from channel"
									})
								]
							}),
							release.bundle_id && bundleQuery.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 w-full" }) : null,
							release.bundle_id && bundleQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
								variant: "destructive",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Build details are unavailable" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Delivery settings are unaffected." })
								]
							}) : null,
							!release.bundle_id || !bundleQuery.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleMetadata, {
								bundle,
								release
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "rounded-lg border bg-muted/10 p-4 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
										className: "cursor-pointer font-medium",
										children: "Advanced diagnostics"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
										className: "mt-4 grid gap-3 text-muted-foreground sm:grid-cols-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "sm:col-span-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Artifact ID" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
													className: "mt-1 break-all font-mono text-foreground",
													children: release.bundle_id ?? "Built-in bundle"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Revision" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-1 font-mono text-foreground",
												children: release.revision
											})] }),
											patchBaseBundleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "sm:col-span-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Patch base artifact ID" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
													className: "mt-1 break-all font-mono text-foreground",
													children: patchBaseBundleId
												})]
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Catalog generation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-1 font-mono text-foreground",
												children: diagnostics.data?.generation ?? "—"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Catalog size" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-1 font-mono text-foreground",
												children: diagnostics.data ? `${diagnostics.data.byte_size} bytes` : "—"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "sm:col-span-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Scope key" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
														className: "mt-1 break-all font-mono text-foreground",
														children: release.scope_key
													}),
													onShowScope ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
														className: "mt-1 h-auto px-0 text-xs max-md:min-h-11",
														onClick: () => onShowScope(release.scope_key),
														size: "sm",
														variant: "link",
														children: "Show bundles for this target"
													}) : null
												]
											})
										]
									}),
									diagnostics.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-destructive",
										children: "Diagnostics are unavailable. Bundle settings are unaffected."
									}) : null
								]
							})
						]
					}) : null]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog$1, {
			onOpenChange: setConfirmDiscard,
			open: confirmDiscard,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Discard unsaved changes?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "Your Bundle changes will be lost." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Keep editing" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
				onClick: () => {
					setConfirmDiscard(false);
					onOpenChange(false);
				},
				variant: "destructive",
				children: "Discard changes"
			})] })] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog$1, {
			onOpenChange: setConfirmDelete,
			open: confirmDelete,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, { children: [
				"Remove this Bundle from ",
				channelName ?? "the channel",
				"?"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "The uploaded artifact stays available. This only removes the Bundle from the channel." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
				onClick: async () => {
					if (!release) return;
					try {
						await remove.mutateAsync({
							expectedRevision: release.revision,
							releaseId: release.id
						});
						toast.success(`Bundle removed from ${channelName ?? "the channel"}`);
						setConfirmDelete(false);
						onOpenChange(false);
					} catch (caught) {
						setError(caught instanceof Error ? caught.message : "Bundle could not be removed from the channel.");
					}
				},
				variant: "destructive",
				children: "Remove from channel"
			})] })] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
			onOpenChange: handlePromoteOpenChange,
			open: showPromote,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				showCloseButton: !promote.isPending,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Promote to Channel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Choose how to promote this Bundle, then select the target channel." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "promote-action",
									children: "Action"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select$1, {
									disabled: promote.isPending,
									items: promoteActionItems,
									onValueChange: (value) => setPromoteAction(value),
									value: promoteAction,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "w-full",
										id: "promote-action",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select an action" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "move",
										children: "Move bundle"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "copy",
										children: "Copy bundle"
									})] }) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: isCopyPromotion ? "Make this Bundle available in the target channel and keep it in the current channel." : "Move this Bundle to the target channel. Devices in the current channel may fall back to an earlier Bundle."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "target-channel",
								children: "Target Channel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select$1, {
								disabled: promote.isPending,
								items: availableChannelItems,
								onValueChange: (value) => setTargetChannel(value ?? ""),
								value: targetChannel || null,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-full",
									id: "target-channel",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a channel" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
									className: "md:max-h-64",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectGroup, { children: availableChannels.map((channel) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: channel.name,
										children: channel.name
									}, channel.id)) })
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
						disabled: promote.isPending,
						onClick: () => handlePromoteOpenChange(false),
						variant: "outline",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
						disabled: !normalizedTargetChannel || promote.isPending,
						onClick: async () => {
							if (!release) return;
							try {
								await promote.mutateAsync({
									action: promoteAction,
									expectedRevision: release.revision,
									releaseId: release.id,
									targetChannel: normalizedTargetChannel
								});
								handlePromoteOpenChange(false);
								toast.success(isCopyPromotion ? `Bundle copied to ${normalizedTargetChannel}` : `Bundle moved to ${normalizedTargetChannel}`);
							} catch (caught) {
								toast.error(caught instanceof Error ? caught.message : "Bundle could not be promoted.");
							}
						},
						children: promote.isPending ? isCopyPromotion ? "Copying…" : "Moving…" : isCopyPromotion ? "Copy" : "Move"
					})] })
				]
			})
		})
	] });
}
function ReleaseStateBadge({ release }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
		className: "gap-1 font-normal text-muted-foreground",
		variant: release.enabled ? "outline" : "secondary",
		children: [release.enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleOff, { className: "size-3" }), release.enabled ? "Enabled" : "Disabled"]
	});
}
/** The list while its channel is unknown: loading, whatever the cache holds. */
var PENDING_RELEASES = {
	data: void 0,
	error: null,
	isError: false,
	isPending: true,
	isPlaceholderData: false
};
/** A fold of unreachable bundles: "1 unreachable bundle", "2 …". */
var UNREACHABLE_BUNDLES = {
	one: "unreachable bundle",
	other: "unreachable bundles"
};
var platformFilterItems = [{
	label: "iOS",
	value: "ios"
}, {
	label: "Android",
	value: "android"
}];
var statusFilterItems = [
	{
		label: "Any Status",
		value: "all"
	},
	{
		label: "Enabled",
		value: "enabled"
	},
	{
		label: "Disabled",
		value: "disabled"
	}
];
function BundleFilterToolbar({ channels, clearable, onChange, onClear, onManageChannels, pending, search }) {
	const channelSelected = search.channelId !== void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-10 flex shrink-0 flex-wrap items-center gap-2 border-b bg-background px-3 py-3 sm:h-12 sm:flex-nowrap sm:bg-card/70 sm:px-4 sm:py-0 sm:backdrop-blur-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1 size-11 lg:size-7" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "sr-only",
				children: "Bundles"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-1 flex items-center gap-1.5 text-muted-foreground sm:ml-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium",
					children: "Filters"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelPicker, {
				allChannels: true,
				className: "max-sm:order-1 max-sm:min-w-0 max-sm:basis-full",
				onValueChange: (name) => onChange(name === void 0 ? {
					channelId: void 0,
					channels: "all"
				} : { channelId: channels.find((channel) => channel.name === name)?.id ?? name }),
				pending,
				value: search.channelId === void 0 ? void 0 : channels.find(({ id }) => id === search.channelId)?.name ?? search.channelId
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select$1, {
				disabled: !channelSelected,
				items: platformFilterItems,
				onValueChange: (value) => onChange({ platform: value === "android" ? "android" : "ios" }),
				value: search.platform ?? "ios",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					"aria-label": "Platform",
					className: "w-[calc(50%-0.25rem)] min-w-[132px] text-sm data-[size=default]:h-11 max-sm:order-2 sm:w-[140px] sm:text-xs sm:data-[size=default]:h-8",
					title: channelSelected ? void 0 : "Choose a channel first",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "ios",
					children: "iOS"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "android",
					children: "Android"
				})] }) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select$1, {
				disabled: !channelSelected && search.scopeKey === void 0,
				items: statusFilterItems,
				onValueChange: (value) => onChange({ enabled: value === "enabled" ? true : value === "disabled" ? false : void 0 }),
				value: search.enabled === void 0 ? "all" : search.enabled ? "enabled" : "disabled",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					"aria-label": "Status",
					className: "w-[calc(50%-0.25rem)] min-w-[132px] text-sm data-[size=default]:h-11 max-sm:order-2 sm:w-[140px] sm:text-xs sm:data-[size=default]:h-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "all",
						children: "Any Status"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "enabled",
						children: "Enabled"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "disabled",
						children: "Disabled"
					})
				] }) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
				"aria-label": "Manage channels",
				className: "size-11 max-sm:ml-auto sm:size-7",
				onClick: onManageChannels,
				size: "icon-sm",
				title: "Manage channels",
				variant: "outline",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, {})
			}),
			search.bundleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
				className: "max-w-48 gap-1 max-sm:order-3",
				variant: "secondary",
				children: ["Artifact filter", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Clear artifact filter",
					className: "relative rounded-sm after:absolute after:-inset-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:after:hidden",
					onClick: () => onChange({ bundleId: void 0 }),
					type: "button",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
				})]
			}) : null,
			search.scopeKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
				className: "max-w-48 gap-1 max-sm:order-3",
				variant: "secondary",
				children: ["Target filter", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Clear target filter",
					className: "relative rounded-sm after:absolute after:-inset-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:after:hidden",
					onClick: () => onChange({ scopeKey: void 0 }),
					type: "button",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
				})]
			}) : null,
			clearable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
				className: "h-11 px-2 text-xs text-muted-foreground hover:text-foreground max-sm:order-3 sm:ml-auto sm:h-8",
				onClick: onClear,
				size: "sm",
				variant: "ghost",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "data-icon": "inline-start" }), "Clear"]
			}) : null
		]
	});
}
function BundleEntry({ expanded, onOpen, onToggleExpand, release }) {
	const operationLabel = release.operation === "PROMOTE" ? "Promoted" : release.operation === "ROLLBACK" ? "Rollback" : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-[240px] items-center gap-3",
		children: [
			release.bundle_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
				"aria-controls": `bundle-lineage-panel-${release.id}`,
				"aria-expanded": expanded,
				"aria-label": expanded ? "Hide advanced artifact diagnostics" : "Show advanced artifact diagnostics",
				title: "Advanced artifact diagnostics",
				className: "size-11 shrink-0 touch-manipulation sm:size-8",
				onClick: onToggleExpand,
				size: "icon",
				type: "button",
				variant: "ghost",
				children: expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				className: "size-11 shrink-0 sm:size-8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				"aria-label": `Open details for ID ${release.id}`,
				className: "min-w-0 rounded-sm text-left text-foreground transition-colors underline-offset-4 hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
				onClick: onOpen,
				title: release.id,
				type: "button",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, {
					bundleId: release.id,
					fullOnMobile: true
				}), !release.bundle_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), " Built-in bundle"]
				}) : null]
			}),
			operationLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "shrink-0 font-normal",
				variant: "secondary",
				children: operationLabel
			}) : null,
			release.currentlyUnreachable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowReason, {
				icon: CircleOff,
				label: "Unreachable: no device gets this bundle with the current delivery settings.",
				reason: "No device gets this bundle with the current delivery settings.",
				children: "Unreachable"
			}) : null
		]
	});
}
function ReleaseBundleChildrenPanel({ onDetailClick, panelId, release }) {
	const bundleId = release.bundle_id ?? "";
	const bundleQuery = useBundleQuery(bundleId);
	const childrenQuery = useBundleChildrenQuery(bundleId);
	if (bundleQuery.isError || childrenQuery.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-live": "polite",
		className: "border-t bg-muted/10 p-4 text-sm text-muted-foreground",
		id: panelId,
		children: "Patch lineage could not be loaded."
	});
	if (bundleQuery.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-live": "polite",
		className: "flex flex-col gap-2 border-t bg-muted/10 p-4",
		id: panelId,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })]
	});
	if (!bundleQuery.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-live": "polite",
		className: "border-t bg-muted/10 p-4 text-sm text-muted-foreground",
		id: panelId,
		children: "Bundle details are unavailable."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleChildrenPanel, {
		bundle: bundleQuery.data,
		bundles: childrenQuery.data ?? [],
		loading: childrenQuery.isPending,
		onDetailClick,
		panelId
	});
}
/**
* The patch counts and feature slots of a group of releases: the page's
* reachable ones, or one fold's, so opening a fold reads its own rows'
* and changes no other query.
*/
function useRowContext(releases, channels) {
	return {
		patchCounts: useBundleChildCountsQuery(Array.from(new Set(releases.flatMap((release) => release.bundle_id ? [release.bundle_id] : [])))).data ?? {},
		slotReleases: releases.flatMap((release) => {
			const channel = channels.find((item) => item.id === release.channel_id)?.name;
			return channel ? [{
				releaseId: release.id,
				platform: release.platform,
				channel,
				builtIn: !release.bundle_id
			}] : [];
		})
	};
}
/** Whether a fold of the page holds `releaseId`: IDs order the list. */
var foldHolds = (fold, releaseId) => releaseId >= fold.to && (fold.from === void 0 || releaseId < fold.from);
/**
* A fold of unreachable bundles, where they sit in the list: closed, the
* number it holds; open, those bundles in order, subdued, read a chunk at a
* time once it opens.
*/
function UnreachableBundlesFold({ fold, filter, channels, columns, isMobile, open, onOpenChange, render }) {
	const query = useReleaseFoldQuery(filter, {
		...fold.from === void 0 ? {} : { from: fold.from },
		to: fold.to
	}, open);
	const rows = query.data?.pages.flatMap((page) => page.rows) ?? [];
	const ctx = useRowContext(rows, channels);
	const statusColumns = isMobile ? void 0 : columns;
	const status = query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldStatus, {
		columns: statusColumns,
		label: "Unreachable bundles",
		onRetry: () => void query.refetch(),
		state: "error"
	}) : query.isPending || query.isFetchingNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldStatus, {
		columns: statusColumns,
		label: "Loading unreachable bundles",
		state: "loading"
	}) : query.hasNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldStatus, {
		columns: statusColumns,
		label: "Unreachable bundles",
		onMore: () => void query.fetchNextPage(),
		state: "more"
	}) : null;
	const props = {
		label: foldLabel(fold, UNREACHABLE_BUNDLES),
		open,
		onOpenChange,
		panelId: `bundle-fold-${fold.to}`
	};
	return isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataCardFold, {
		...props,
		children: [rows.map((release) => render(release, ctx)), status]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTableFold, {
		...props,
		columns,
		children: [rows.map((release) => render(release, ctx)), status]
	});
}
function BundlesPage() {
	const urlSearch = Route.useSearch();
	const navigate = Route.useNavigate();
	const isMobile = useIsMobile();
	const [channelsOpen, setChannelsOpen] = (0, import_react.useState)(false);
	const [expandedReleaseId, setExpandedReleaseId] = (0, import_react.useState)();
	const folds = useOpenFolds();
	const channelsQuery = useChannelsQuery();
	const channels = channelsQuery.data ?? [];
	const channelRows = channelsQuery.data;
	const resolved = resolveReleaseSearch(urlSearch, channelRows);
	const channelsFailed = resolved === void 0 && channelsQuery.isError;
	const search = resolved ?? urlSearch;
	const filter = releaseFilterOf(search);
	const releasesQuery = useReleasesQuery({
		afterReleaseId: search.afterReleaseId,
		beforeReleaseId: search.beforeReleaseId,
		filter,
		releaseId: search.releaseId
	}, { enabled: resolved !== void 0 });
	const clearable = !showsDefaultReleases(urlSearch, channelRows);
	const list = resolved === void 0 ? PENDING_RELEASES : releasesQuery;
	const entries = list.data?.entries ?? [];
	const releases = entries.flatMap((entry) => entry.kind === "row" ? [entry.row] : []);
	const pageContext = useRowContext(releases, channels);
	const nextCursor = list.data?.next;
	const previousCursor = list.data?.previous;
	const featureColumns = useReleaseColumns();
	const columnCount = 10 + featureColumns.length;
	const channelNames = new Map(channels.map((channel) => [channel.id, channel.name]));
	const visible = (releaseId) => releases.some((release) => release.id === releaseId) || entries.some((entry) => entry.kind === "fold" && folds.isOpen(foldKey(entry)) && foldHolds(entry, releaseId));
	const lineageVisible = expandedReleaseId !== void 0 && visible(expandedReleaseId);
	(0, import_react.useEffect)(() => {
		if (expandedReleaseId !== void 0 && !lineageVisible) setExpandedReleaseId(void 0);
	}, [expandedReleaseId, lineageVisible]);
	const go = (nextSearch, resetScroll = true) => void navigate({
		resetScroll,
		search: nextSearch,
		to: "/"
	});
	const changeFilters = (filters) => go(updateReleaseFilters(search, filters));
	const select = (release) => {
		if (!releases.some(({ id }) => id === release.id)) folds.set(release.id, true);
		go({
			...search,
			releaseId: release.id
		}, false);
	};
	const openChildBundle = (bundle) => {
		const childRelease = releases.find((release) => release.bundle_id === bundle.id);
		setExpandedReleaseId(void 0);
		if (childRelease) {
			go({
				...search,
				releaseId: childRelease.id
			}, false);
			return;
		}
		changeFilters({ bundleId: bundle.id });
	};
	const onLaterPage = search.afterReleaseId !== void 0 || search.beforeReleaseId !== void 0;
	const previousSearch = previousCursor ? {
		...search,
		afterReleaseId: "after" in previousCursor ? previousCursor.after : void 0,
		beforeReleaseId: "before" in previousCursor ? previousCursor.before : void 0,
		releaseId: void 0
	} : null;
	const nextSearch = nextCursor ? {
		...search,
		afterReleaseId: void 0,
		beforeReleaseId: nextCursor,
		releaseId: void 0
	} : null;
	const newestSearch = {
		...search,
		afterReleaseId: void 0,
		beforeReleaseId: void 0,
		releaseId: void 0
	};
	const renderCard = (release, ctx) => {
		const channelName = channelNames.get(release.channel_id) ?? release.channel_id;
		const patchCount = release.bundle_id ? ctx.patchCounts[release.bundle_id] : 0;
		const isExpanded = lineageVisible && expandedReleaseId === release.id;
		const panelId = `bundle-lineage-panel-${release.id}`;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataCard, {
			"aria-label": `Bundle ${release.id}`,
			className: cn("gap-3", release.currentlyUnreachable && "bg-muted/60 saturate-50 hover:bg-muted/60 hover:saturate-100 focus-within:saturate-100", isExpanded && "border-b-0 bg-primary/5"),
			"data-state": search.releaseId === release.id ? "selected" : void 0,
			onClick: openOutsideControls(() => select(release)),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleEntry, {
						expanded: isExpanded,
						onOpen: () => select(release),
						onToggleExpand: () => setExpandedReleaseId(isExpanded ? void 0 : release.id),
						release
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelBadge, {
						channel: channelName,
						className: "shrink-0"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex flex-wrap items-center gap-x-1.5 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
								className: "size-4",
								platform: release.platform
							}), release.platform === "ios" ? "iOS" : "Android"]
						}),
						patchCount === void 0 || patchCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "·"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: patchCount === void 0 ? "Checking patches" : `${patchCount} ${patchCount === 1 ? "patch" : "patches"}` })] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "·"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelativeTime, { ms: release.created_at_ms })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-x-3 gap-y-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolloutPercentageBadge, { percentage: release.rollout_cohort_count / 10 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseStateBadge, { release }),
						release.should_force_update ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "secondary",
							children: "Force update"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Target "
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetDisplay, {
								appVersion: release.target_app_version,
								fingerprintHash: release.fingerprint_hash
							})]
						})
					]
				}),
				featureColumns.map(({ Cell, feature, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						releaseId: release.id,
						releases: ctx.slotReleases
					})]
				}, feature)),
				release.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "line-clamp-2 text-xs text-muted-foreground",
					children: release.message
				}) : null
			]
		}), isExpanded && release.bundle_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseBundleChildrenPanel, {
			onDetailClick: openChildBundle,
			panelId,
			release
		}) : null] }, release.id);
	};
	const renderRow = (release, ctx) => {
		const isExpanded = lineageVisible && expandedReleaseId === release.id;
		const panelId = `bundle-lineage-panel-${release.id}`;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTableRow, {
			"aria-label": `Open bundle ${release.id}`,
			className: cn(release.currentlyUnreachable && "bg-muted/60 saturate-50 hover:bg-muted/60 hover:saturate-100 focus-within:saturate-100", isExpanded && "bg-primary/5"),
			"data-state": search.releaseId === release.id ? "selected" : void 0,
			onOpen: () => select(release),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleEntry, {
					expanded: isExpanded,
					onOpen: () => select(release),
					onToggleExpand: () => setExpandedReleaseId(isExpanded ? void 0 : release.id),
					release
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelBadge, { channel: channelNames.get(release.channel_id) ?? release.channel_id }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "whitespace-nowrap",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformLabel, { platform: release.platform })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: release.bundle_id && ctx.patchCounts[release.bundle_id] === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted-foreground",
					children: "Checking"
				}) : release.bundle_id && ctx.patchCounts[release.bundle_id] > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					variant: "secondary",
					children: [
						ctx.patchCounts[release.bundle_id],
						" ",
						ctx.patchCounts[release.bundle_id] === 1 ? "patch" : "patches"
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "-"
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetDisplay, {
					appVersion: release.target_app_version,
					fingerprintHash: release.fingerprint_hash
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnabledStatusIcon, { enabled: release.enabled }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: release.enabled ? "Enabled" : "Disabled"
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnabledStatusIcon, {
						enabled: release.should_force_update,
						falseIcon: "minus"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: release.should_force_update ? "Required" : "Optional"
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolloutPercentageBadge, { percentage: release.rollout_cohort_count / 10 }) }),
				featureColumns.map(({ Cell, feature }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
					releaseId: release.id,
					releases: ctx.slotReleases
				}) }, feature)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-sm text-muted-foreground",
					title: release.message ?? void 0,
					children: release.message || "-"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelativeTime, { ms: release.created_at_ms })
				})
			]
		}), isExpanded && release.bundle_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
			className: "hover:bg-transparent",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "border-t-0 p-0",
				colSpan: columnCount,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseBundleChildrenPanel, {
					onDetailClick: openChildBundle,
					panelId,
					release
				})
			})
		}) : null] }, release.id);
	};
	const fold = (entry, render) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnreachableBundlesFold, {
		channels,
		columns: columnCount,
		filter,
		fold: entry,
		isMobile,
		onOpenChange: (open) => folds.set(foldKey(entry), open),
		open: folds.isOpen(foldKey(entry)),
		render
	}, `fold-${entry.to}`);
	const openingTitle = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		"No ",
		search.platform === "android" ? "Android" : "iOS",
		" bundles in",
		" ",
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			translate: "no",
			children: channelNames.get(search.channelId ?? "") ?? search.channelId
		})
	] });
	const empty = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableEmpty, {
		icon: Package,
		title: releases.length === 0 && entries.length > 0 ? "No device gets the bundles here" : onLaterPage ? "No more bundles" : !hasReleaseFilters(search) ? "No bundles yet" : clearable ? "No bundles match these filters" : openingTitle,
		children: onLaterPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			className: buttonVariants({
				className: "mt-1 min-h-11 sm:min-h-8",
				variant: "outline"
			}),
			search: newestSearch,
			to: "/",
			children: "Show the newest bundles"
		}) : clearable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			className: "mt-1 min-h-11 sm:min-h-8",
			onClick: () => go({}),
			variant: "outline",
			children: "Clear filters"
		}) : hasReleaseFilters(search) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			className: "mt-1 min-h-11 sm:min-h-8",
			onClick: () => changeFilters({
				channelId: void 0,
				channels: "all"
			}),
			variant: "outline",
			children: "Show all channels"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Deploy one from your app's project:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full text-left",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
				label: "the deploy command",
				value: "npx hot-updater deploy",
				wrap: true
			})
		})] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 min-w-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleFilterToolbar, {
				channels,
				clearable,
				onChange: changeFilters,
				onClear: () => go({}),
				onManageChannels: () => setChannelsOpen(true),
				pending: resolved === void 0,
				search
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 min-w-0 flex-1 flex-col gap-6 bg-muted/5 p-3 sm:p-6",
				children: [channelsFailed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Channels couldn't be loaded" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Bundles show once the channels load." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							className: "min-h-11 sm:min-h-7",
							onClick: () => void channelsQuery.refetch(),
							size: "xs",
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry"]
						}) })
					]
				}) : list.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Bundles could not be loaded" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: list.error?.message })
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFrame, { children: isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full overflow-y-auto",
					children: list.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataCardSkeletons, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [releases.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataCardsEmpty, { children: empty }) : null, entries.map((entry) => entry.kind === "row" ? renderCard(entry.row, pageContext) : fold(entry, renderCard))] })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					rowGroups: true,
					header: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "ID" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Channel" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Platform" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Patches" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Target" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Enabled" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Force update" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Rollout" }),
						featureColumns.map(({ feature, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: label }, feature)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Message" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Created" })
					] }),
					children: list.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableBody, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableSkeletonRows, { columns: columnCount }) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [releases.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableBody, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFullRow, {
						columns: columnCount,
						children: empty
					}) }) : null, groupsOf(entries).map((group) => group.kind === "fold" ? fold(group.fold, renderRow) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableBody, { children: group.rows.map((release) => renderRow(release, pageContext)) }, `rows-${group.rows[0].id}`))] })
				}) }), !channelsFailed && !list.isError && !list.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTablePagination, {
					count: releases.length,
					folded: {
						...foldedTotal(entries),
						label: "unreachable"
					},
					label: "Bundle pagination",
					noun: ["bundle", "bundles"],
					pending: list.isPlaceholderData,
					newest: onLaterPage ? {
						search: newestSearch,
						to: "/"
					} : void 0,
					next: nextSearch ? {
						search: nextSearch,
						to: "/"
					} : void 0,
					previous: previousSearch ? {
						search: previousSearch,
						to: "/"
					} : void 0
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseEditorSheet, {
				channels,
				onOpenChange: (open) => !open && go({
					...search,
					releaseId: void 0
				}, false),
				onShowScope: (scopeKey) => changeFilters({ scopeKey }),
				open: Boolean(search.releaseId),
				releaseId: search.releaseId ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelManagementDialog, {
				onOpenChange: setChannelsOpen,
				open: channelsOpen
			})
		]
	});
}
//#endregion
export { BundlesPage as component };
