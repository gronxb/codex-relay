import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
import { i as rowToBundle } from "./databaseRows-BZMFl5QV.mjs";
import { n as assertCanonicalChannelName } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
import { t as ReleaseManagementError } from "./releaseManagement-CqIc-SDE.mjs";
import { N as releaseNativeBuildScope, u as channelIdOf } from "./native-builds-lEyKQemV.mjs";
import { n as readReleaseFilter, r as readReleaseFold, t as listReleaseFolds } from "./listReleases-QF91GLE7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-rpc-C1CJ-QWs.js
var withPublicBundleMutationErrors = async (action) => {
	try {
		return await action();
	} catch (error) {
		if (error instanceof ReleaseManagementError) throw new Error(error.message.replace(/\bRelease\b/g, "Bundle").replace("Bundle Bundle", "deployed Bundle"), { cause: error });
		throw error;
	}
};
/** The bounds of a fold, checked: IDs as text. */
var readFoldInput = (input) => {
	const text = (value) => typeof value === "string" && value !== "";
	if (!text(input.to) || input.from !== void 0 && !text(input.from) || input.after !== void 0 && !text(input.after)) throw new Error("A fold is its to, and optionally from and after.");
	return {
		to: input.to,
		...input.from === void 0 ? {} : { from: input.from },
		...input.after === void 0 ? {} : { after: input.after }
	};
};
var prepare = async () => {
	const { prepareConfig } = await import("./config.server-CvAlgb8E.mjs");
	return prepareConfig();
};
var getReleases_createServerFn_handler = createServerRpc({
	id: "206547cb1526f961070a989818ca7b9e34f6b2b0e4ab851698c3807fe9fb5e0c",
	name: "getReleases",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getReleases.__executeServer(opts));
var getReleases = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	filter: readReleaseFilter(input?.filter),
	...input?.afterReleaseId === void 0 ? {} : { afterReleaseId: input.afterReleaseId },
	...input?.beforeReleaseId === void 0 ? {} : { beforeReleaseId: input.beforeReleaseId },
	...input?.releaseId === void 0 ? {} : { releaseId: input.releaseId }
})).handler(getReleases_createServerFn_handler, async ({ data }) => listReleaseFolds((await prepare()).core, data));
var getReleaseFold_createServerFn_handler = createServerRpc({
	id: "b30a0e32e3e84050037368e4405bfc34507fda8891a64faefe1a7acd019e9f3c",
	name: "getReleaseFold",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getReleaseFold.__executeServer(opts));
var getReleaseFold = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	filter: readReleaseFilter(input.filter),
	...readFoldInput(input)
})).handler(getReleaseFold_createServerFn_handler, async ({ data }) => readReleaseFold((await prepare()).core, data));
var getRelease_createServerFn_handler = createServerRpc({
	id: "a6f23116eeaf76166d405e28a95213123025613c6603030894e519015bf48032",
	name: "getRelease",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getRelease.__executeServer(opts));
var getRelease = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(getRelease_createServerFn_handler, async ({ data }) => (await prepare()).core.getRelease(data.releaseId));
var updateRelease_createServerFn_handler = createServerRpc({
	id: "7ea0186f19f9f2bc2ca4b26e3c59636891cf046957f84287b6783f8d88bd8cb7",
	name: "updateRelease",
	filename: "src/lib/api-rpc.ts"
}, (opts) => updateRelease.__executeServer(opts));
var updateRelease = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(updateRelease_createServerFn_handler, async ({ data }) => {
	const { core } = await prepare();
	return withPublicBundleMutationErrors(() => core.updateReleasePolicy(data));
});
var preflightRelease_createServerFn_handler = createServerRpc({
	id: "b46c95dba95a6a3e8fa5c9d100e3622fa5ae7af4f38e10fb1ed2fa48289a3a8f",
	name: "preflightRelease",
	filename: "src/lib/api-rpc.ts"
}, (opts) => preflightRelease.__executeServer(opts));
var preflightRelease = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(preflightRelease_createServerFn_handler, async ({ data }) => {
	const { core } = await prepare();
	return withPublicBundleMutationErrors(() => core.preflightReleasePolicy(data));
});
var deleteRelease_createServerFn_handler = createServerRpc({
	id: "d5b58722ce514e3b63a377f736b4823c2011782495442ae4870ed547e392c70b",
	name: "deleteRelease",
	filename: "src/lib/api-rpc.ts"
}, (opts) => deleteRelease.__executeServer(opts));
var deleteRelease = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(deleteRelease_createServerFn_handler, async ({ data }) => {
	const { core } = await prepare();
	return withPublicBundleMutationErrors(() => core.deleteRelease(data));
});
var promoteRelease_createServerFn_handler = createServerRpc({
	id: "956539a300d79a7efa191c1cc2d529d62fc4bfd940442548fdbc1404e0d53078",
	name: "promoteRelease",
	filename: "src/lib/api-rpc.ts"
}, (opts) => promoteRelease.__executeServer(opts));
var promoteRelease = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(promoteRelease_createServerFn_handler, async ({ data }) => {
	const { core } = await prepare();
	return withPublicBundleMutationErrors(() => core.promoteRelease(data));
});
var getReleaseCatalogDiagnostics_createServerFn_handler = createServerRpc({
	id: "e8c24b7247936f045a145ffd5c177fd0e3df3b52769d67dfbd8d1de491d66396",
	name: "getReleaseCatalogDiagnostics",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getReleaseCatalogDiagnostics.__executeServer(opts));
var getReleaseCatalogDiagnostics = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(getReleaseCatalogDiagnostics_createServerFn_handler, async ({ data }) => (await prepare()).core.getReleaseCatalogRow(data.scopeKey));
var getConfig_createServerFn_handler = createServerRpc({
	id: "51a34c05479a893c7d320bd4cd1604427289d667698c48b9f30a01aabf8a5e68",
	name: "getConfig",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getConfig.__executeServer(opts));
var getConfig = createServerFn().middleware([consoleAccess]).handler(getConfig_createServerFn_handler, async () => {
	try {
		const { config } = await prepare();
		return { console: { gitUrl: config.gitUrl } };
	} catch (error) {
		console.error("Error during config retrieval:", error);
		throw error;
	}
});
var getChannels_createServerFn_handler = createServerRpc({
	id: "79ada05964de8f2123bfcd62b10097d59bf8fd689ef5c7161031e5871d8396c5",
	name: "getChannels",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getChannels.__executeServer(opts));
var getChannels = createServerFn().middleware([consoleAccess]).handler(getChannels_createServerFn_handler, async () => {
	try {
		return await (await prepare()).core.listChannels();
	} catch (error) {
		console.error("Error during channel retrieval:", error);
		throw error;
	}
});
var createChannel_createServerFn_handler = createServerRpc({
	id: "2b9b8d1f49f79a511589617d8d4bfc6094a3acf5264f33651b9569ba66d3f321",
	name: "createChannel",
	filename: "src/lib/api-rpc.ts"
}, (opts) => createChannel.__executeServer(opts));
var createChannel = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => {
	const name = typeof input?.name === "string" ? input.name.trim() : "";
	if (name.length === 0) throw new Error("Channel name is required.");
	return { name };
}).handler(createChannel_createServerFn_handler, async ({ data }) => {
	try {
		const { core } = await prepare();
		const existing = await core.findChannelByName(data.name);
		if (existing !== null) return { data: {
			row: existing,
			inserted: false
		} };
		return { data: {
			row: await core.ensureChannel(data.name),
			inserted: true
		} };
	} catch (error) {
		console.error("Error during channel creation:", error);
		throw error;
	}
});
var deleteChannel_createServerFn_handler = createServerRpc({
	id: "52756dde414919a906bfe83d1ab6d29910c63bcafdb47653d6f1df562d958920",
	name: "deleteChannel",
	filename: "src/lib/api-rpc.ts"
}, (opts) => deleteChannel.__executeServer(opts));
var deleteChannel = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(deleteChannel_createServerFn_handler, async ({ data }) => {
	try {
		return { data: await (await prepare()).core.deleteChannel(data.id) };
	} catch (error) {
		console.error("Error during channel deletion:", error);
		throw error;
	}
});
var getBundle_createServerFn_handler = createServerRpc({
	id: "1bd85c2a50e24785cb6abb023a247a9f048f37ddfa85cbb1c57e579563bad013",
	name: "getBundle",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getBundle.__executeServer(opts));
var getBundle = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(getBundle_createServerFn_handler, async ({ data }) => {
	try {
		const detail = await (await prepare()).core.getBundle(data.bundleId);
		return detail === null ? null : rowToBundle(detail.bundle, detail.patches);
	} catch (error) {
		console.error("Error during bundle retrieval:", error);
		throw error;
	}
});
var getBundleChildren_createServerFn_handler = createServerRpc({
	id: "4370f1bf70b91f1168d85379d3008449a1bedb915e9878ca4ef89d5f3a80fa7f",
	name: "getBundleChildren",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getBundleChildren.__executeServer(opts));
var getBundleChildren = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(getBundleChildren_createServerFn_handler, async ({ data }) => {
	try {
		const [{ core }, { getBundleChildren: readBundleChildren }] = await Promise.all([prepare(), import("./getBundleChildren-CnOf4Frp.mjs")]);
		return await readBundleChildren(core, data.baseBundleId);
	} catch (error) {
		console.error("Error during bundle children retrieval:", error);
		throw error;
	}
});
var getBundleChildCounts_createServerFn_handler = createServerRpc({
	id: "4ca367070b00f58179a572f0bb8196a4ccdd3881e9b1dbfe33deee0cb6e1f549",
	name: "getBundleChildCounts",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getBundleChildCounts.__executeServer(opts));
var getBundleChildCounts = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => {
	if (!Array.isArray(input?.bundleIds) || input.bundleIds.length > 100) throw new Error("Choose up to 100 bundles.");
	return input;
}).handler(getBundleChildCounts_createServerFn_handler, async ({ data }) => {
	try {
		const [{ core }, { getBundleChildCounts: readBundleChildCounts }] = await Promise.all([prepare(), import("./getBundleChildren-CnOf4Frp.mjs")]);
		return await readBundleChildCounts(core, data.bundleIds);
	} catch (error) {
		console.error("Error during bundle child count retrieval:", error);
		throw error;
	}
});
/** A channel name the list filters by, as its channel ID. */
var channelIdFilter = (channel) => {
	if (channel === void 0) return {};
	if (typeof channel !== "string") throw new Error("channel must be a name.");
	assertCanonicalChannelName(channel);
	return { channelId: channelIdOf(channel) };
};
var getNativeBuilds_createServerFn_handler = createServerRpc({
	id: "17a54fe7c5ad6ca53457914b1d02b3d6887811aa6b5fa6598a1ee107796ce8f0",
	name: "getNativeBuilds",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getNativeBuilds.__executeServer(opts));
var getNativeBuilds = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	...input?.before === void 0 ? {} : { before: input.before },
	...input?.after === void 0 ? {} : { after: input.after },
	...channelIdFilter(input?.channel)
})).handler(getNativeBuilds_createServerFn_handler, async ({ data }) => {
	const [{ core }, { listNativeBuildFolds }] = await Promise.all([prepare(), import("./nativeBuilds-S1_ZcH6M.mjs")]);
	return listNativeBuildFolds(core, data);
});
var getNativeBuildFold_createServerFn_handler = createServerRpc({
	id: "1fc98b1499df6f62eeb3e84712ff4bd12e428d2ddd08880d541463d24ccd0233",
	name: "getNativeBuildFold",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getNativeBuildFold.__executeServer(opts));
var getNativeBuildFold = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	...channelIdFilter(input.channel),
	...readFoldInput(input)
})).handler(getNativeBuildFold_createServerFn_handler, async ({ data }) => {
	const [{ core }, { readNativeBuildFold }] = await Promise.all([prepare(), import("./nativeBuilds-S1_ZcH6M.mjs")]);
	return readNativeBuildFold(core, data);
});
var getNativeBuildDetail_createServerFn_handler = createServerRpc({
	id: "c101ad0315790cf226f182906274176b64a93b9bf5b410cacec5067208c70a04",
	name: "getNativeBuildDetail",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getNativeBuildDetail.__executeServer(opts));
var getNativeBuildDetail = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(getNativeBuildDetail_createServerFn_handler, async ({ data }) => {
	const [{ core }, { getNativeBuildDetail: readNativeBuildDetail }] = await Promise.all([prepare(), import("./nativeBuilds-S1_ZcH6M.mjs")]);
	return readNativeBuildDetail(core, data.id);
});
var getNativeBuildPatches_createServerFn_handler = createServerRpc({
	id: "2e3fab89483b2e4fea0c2f996071b2dbb15b8bc072e7dae78c75a9a9d854d5b9",
	name: "getNativeBuildPatches",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getNativeBuildPatches.__executeServer(opts));
var getNativeBuildPatches = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({
	minBundleId: input.minBundleId,
	...input.before === void 0 ? {} : { before: input.before },
	...input.after === void 0 ? {} : { after: input.after }
})).handler(getNativeBuildPatches_createServerFn_handler, async ({ data: { minBundleId, ...page } }) => {
	const [{ core }, { listNativeBuildPatches, NATIVE_BUILD_PATCH_PAGE_SIZE }] = await Promise.all([prepare(), import("./nativeBuilds-S1_ZcH6M.mjs")]);
	return listNativeBuildPatches(core, minBundleId, {
		...page,
		limit: NATIVE_BUILD_PATCH_PAGE_SIZE
	});
});
var getReleaseNativeBuild_createServerFn_handler = createServerRpc({
	id: "868ce85f0b63ad138a1f82a573d1d6b12f80c7ca44aefec3dadf01b5fa7db86c",
	name: "getReleaseNativeBuild",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getReleaseNativeBuild.__executeServer(opts));
var getReleaseNativeBuild = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(getReleaseNativeBuild_createServerFn_handler, async ({ data }) => {
	const scope = releaseNativeBuildScope(data);
	if (scope === null) return null;
	const { core } = await prepare();
	return await core.findNativeBuild(scope, { storeBuild: true }) ?? core.findNativeBuild(scope);
});
var markNativeBuild_createServerFn_handler = createServerRpc({
	id: "a6c8cfa907e2f75bf69aa90044bd52a3ee684d1a0462d23781161a1a3531aa33",
	name: "markNativeBuild",
	filename: "src/lib/api-rpc.ts"
}, (opts) => markNativeBuild.__executeServer(opts));
var markNativeBuild = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(markNativeBuild_createServerFn_handler, async ({ data }) => (await prepare()).core.markNativeBuild(data.id, { storeBuild: data.storeBuild }));
var getNativeBuildDownloadUrl_createServerFn_handler = createServerRpc({
	id: "936ef8582ff49d97077d1d80e8403d0b4106831c955591c5c471a88f96007fe9",
	name: "getNativeBuildDownloadUrl",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getNativeBuildDownloadUrl.__executeServer(opts));
var getNativeBuildDownloadUrl = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => input).handler(getNativeBuildDownloadUrl_createServerFn_handler, async ({ data }) => {
	const [deps, { resolveNativeBuildDownloadUrl }] = await Promise.all([prepare(), import("./nativeBuilds-S1_ZcH6M.mjs")]);
	return { url: await resolveNativeBuildDownloadUrl(data.id, deps) };
});
var createNativeBuildDownloadLink_createServerFn_handler = createServerRpc({
	id: "c6ff40bd8faad0b2d7aba3e94179c18e02a918a76bff25849d771ff31f688208",
	name: "createNativeBuildDownloadLink",
	filename: "src/lib/api-rpc.ts"
}, (opts) => createNativeBuildDownloadLink.__executeServer(opts));
var createNativeBuildDownloadLink = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(createNativeBuildDownloadLink_createServerFn_handler, async ({ data }) => {
	const { issueNativeBuildDownloadLink } = await import("./nativeBuildDownloadLink-CgZaRE6C.mjs");
	return issueNativeBuildDownloadLink(data.id);
});
var getNativeBuildInstallEligibility_createServerFn_handler = createServerRpc({
	id: "67cea9f69773d83e69e68e20b81116a2bee9ee4ab3e378698ff74149f1d59ad0",
	name: "getNativeBuildInstallEligibility",
	filename: "src/lib/api-rpc.ts"
}, (opts) => getNativeBuildInstallEligibility.__executeServer(opts));
var getNativeBuildInstallEligibility = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => input).handler(getNativeBuildInstallEligibility_createServerFn_handler, async ({ data }) => {
	const [deps, { checkNativeBuildInstall }] = await Promise.all([prepare(), import("./nativeBuildInstall-KCHXNr-F.mjs")]);
	return checkNativeBuildInstall(data.id, data.udid, deps, { canApprove: async () => {
		const [{ getRequest }, { requireConsoleAccess }, { iosDeviceViewer }] = await Promise.all([
			import("../_libs/_.mjs").then((n) => n.t),
			import("./auth.server-BtwE9LLM.mjs"),
			import("./iosDevices-mJefvrvf.mjs")
		]);
		return (await iosDeviceViewer(await requireConsoleAccess(getRequest()), deps.config.deviceApprovers)).canApprove;
	} });
});
//#endregion
export { createChannel_createServerFn_handler, createNativeBuildDownloadLink_createServerFn_handler, deleteChannel_createServerFn_handler, deleteRelease_createServerFn_handler, getBundleChildCounts_createServerFn_handler, getBundleChildren_createServerFn_handler, getBundle_createServerFn_handler, getChannels_createServerFn_handler, getConfig_createServerFn_handler, getNativeBuildDetail_createServerFn_handler, getNativeBuildDownloadUrl_createServerFn_handler, getNativeBuildFold_createServerFn_handler, getNativeBuildInstallEligibility_createServerFn_handler, getNativeBuildPatches_createServerFn_handler, getNativeBuilds_createServerFn_handler, getReleaseCatalogDiagnostics_createServerFn_handler, getReleaseFold_createServerFn_handler, getReleaseNativeBuild_createServerFn_handler, getRelease_createServerFn_handler, getReleases_createServerFn_handler, markNativeBuild_createServerFn_handler, preflightRelease_createServerFn_handler, promoteRelease_createServerFn_handler, updateRelease_createServerFn_handler };
