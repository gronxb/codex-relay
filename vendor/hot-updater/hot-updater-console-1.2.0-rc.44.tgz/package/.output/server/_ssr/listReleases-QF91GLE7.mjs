import { n as readFold, t as foldedPage } from "./foldedPage-CUjJqtlF.mjs";
import { t as addReleaseReachability } from "./releaseReachability-Ch1JpJkY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/listReleases-QF91GLE7.js
var isRecord = (value) => typeof value === "object" && value !== null;
var text = (value, name) => {
	if (typeof value !== "string" || value.length === 0) throw new Error(`Release filter ${name} is required.`);
	return value;
};
var enabledOf = (value) => {
	if (value === void 0) return {};
	if (typeof value !== "boolean") throw new Error("Release filter enabled must be true or false.");
	return { enabled: value };
};
/**
* A release list's filter: none, a channel with its platform (and enabled),
* a bundle, or a scope (and enabled). Those are the sets the release indexes
* serve, so any other combination is refused.
*/
var readReleaseFilter = (value) => {
	if (value === void 0) return { kind: "all" };
	if (!isRecord(value)) throw new Error("Invalid release filter.");
	switch (value.kind) {
		case "all": return { kind: "all" };
		case "channelPlatform":
			if (value.platform !== "ios" && value.platform !== "android") throw new Error("Release filter platform must be ios or android.");
			return {
				kind: "channelPlatform",
				channelId: text(value.channelId, "channelId"),
				platform: value.platform,
				...enabledOf(value.enabled)
			};
		case "bundle": return {
			kind: "bundle",
			bundleId: text(value.bundleId, "bundleId")
		};
		case "scope": return {
			kind: "scope",
			scopeKey: text(value.scopeKey, "scopeKey"),
			...enabledOf(value.enabled)
		};
		default: throw new Error("Invalid release filter.");
	}
};
/**
* Whether a filter asks for unreachable releases: Disabled, whose every
* release no catalog serves, or one bundle. Its releases fold none.
*/
var asksForUnreachable = (filter) => filter.kind === "bundle" || (filter.kind === "scope" || filter.kind === "channelPlatform") && filter.enabled === false;
/** The core reads a page makes, with each scope's catalog read once. */
var readingCatalogsOnce = (core) => {
	const catalogs = /* @__PURE__ */ new Map();
	return {
		listReleases: core.listReleases.bind(core),
		getReleaseCatalogRow: (scopeKey) => {
			if (!catalogs.has(scopeKey)) catalogs.set(scopeKey, core.getReleaseCatalogRow(scopeKey));
			return catalogs.get(scopeKey);
		}
	};
};
/**
* One page of releases, newest first, that leads with the reachable ones:
* each run of unreachable releases between them folds, split around the
* selected release, which shows where it sits and counts toward no page.
* It reads the filter's index a chunk at a time (at most
* `FOLDED_PAGE_READ_BUDGET` rows), and each scope's catalog once. A filter
* that asks for unreachable releases folds none.
*/
function listReleaseFolds(core, { filter, beforeReleaseId, afterReleaseId, releaseId }) {
	const reads = readingCatalogsOnce(core);
	const foldsNone = asksForUnreachable(filter);
	return foldedPage({
		read: async (input) => addReleaseReachability(reads, await reads.listReleases({
			filter,
			...input
		})),
		classify: async (releases) => new Set(releases.filter((release) => foldsNone || !release.currentlyUnreachable).map(({ id }) => id)),
		...beforeReleaseId === void 0 ? {} : { before: beforeReleaseId },
		...afterReleaseId === void 0 ? {} : { after: afterReleaseId },
		...releaseId === void 0 ? {} : { pinned: releaseId }
	});
}
/** One chunk of a fold's releases, as `listReleaseFolds` folded them. */
function readReleaseFold(core, { filter, ...fold }) {
	const reads = readingCatalogsOnce(core);
	return readFold({
		read: async (input) => addReleaseReachability(reads, await reads.listReleases({
			filter,
			...input
		})),
		...fold
	});
}
//#endregion
export { readReleaseFilter as n, readReleaseFold as r, listReleaseFolds as t };
