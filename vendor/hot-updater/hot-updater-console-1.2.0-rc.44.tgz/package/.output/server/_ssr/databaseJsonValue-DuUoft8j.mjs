//#region node_modules/.nitro/vite/services/ssr/assets/databaseJsonValue-DuUoft8j.js
/** A bundle an operation names is not stored. */
var DatabaseBundleNotFoundError = class extends Error {
	bundleId;
	name = "DatabaseBundleNotFoundError";
	constructor(bundleId) {
		super(`Bundle "${bundleId}" was not found.`);
		this.bundleId = bundleId;
	}
};
/** A row a delete names is still referenced, such as a bundle a release uses. */
var DatabaseRowReferencedError = class extends Error {
	name = "DatabaseRowReferencedError";
	constructor() {
		super("The database row is still referenced.");
	}
};
/** Input a database operation refuses before touching storage. */
var DatabaseAdapterInputError = class extends Error {
	code;
	name = "DatabaseAdapterInputError";
	constructor(code) {
		super(`Invalid database adapter input: ${code}`);
		this.code = code;
	}
};
var isDatabaseJsonValue = (value) => {
	const ancestors = /* @__PURE__ */ new WeakSet();
	const validate = (input) => {
		if (input === null || typeof input === "string" || typeof input === "boolean") return true;
		if (typeof input === "number") return Number.isFinite(input);
		if (typeof input !== "object") return false;
		if (ancestors.has(input)) return false;
		ancestors.add(input);
		try {
			if (Array.isArray(input)) {
				if (Object.getPrototypeOf(input) !== Array.prototype) return false;
				if (Reflect.ownKeys(input).length !== input.length + 1) return false;
				for (let index = 0; index < input.length; index += 1) {
					const descriptor = Object.getOwnPropertyDescriptor(input, String(index));
					if (descriptor === void 0 || !descriptor.enumerable || !("value" in descriptor) || !validate(descriptor.value)) return false;
				}
				return true;
			}
			const prototype = Object.getPrototypeOf(input);
			if (prototype !== Object.prototype && prototype !== null) return false;
			for (const key of Reflect.ownKeys(input)) {
				if (typeof key !== "string" || key === "__proto__") return false;
				const descriptor = Object.getOwnPropertyDescriptor(input, key);
				if (descriptor === void 0 || !descriptor.enumerable || !("value" in descriptor) || !validate(descriptor.value)) return false;
			}
			return true;
		} finally {
			ancestors.delete(input);
		}
	};
	return validate(value);
};
/**
* Whether `value` is a plain object of JSON values a store keeps as they
* are: no cycles, accessors, non-finite numbers, or class instances. A
* plugin checks a `json` field's value with it before it writes, as
* Insights does for an event's metadata.
*/
var isDatabaseJsonObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value) && isDatabaseJsonValue(value);
var isDatabaseMetadataObject = (value) => isDatabaseJsonObject(value) && (!Object.hasOwn(value, "app_version") || typeof value["app_version"] === "string");
//#endregion
export { isDatabaseMetadataObject as a, isDatabaseJsonObject as i, DatabaseBundleNotFoundError as n, DatabaseRowReferencedError as r, DatabaseAdapterInputError as t };
