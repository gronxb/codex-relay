import { i as getRequest } from "./server-CUH0Oy00.mjs";
import { n as sameSecret } from "./local-console-Dtxlsav0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nativeBuildDownloadLink-CgZaRE6C.js
/**
* How long a signed download link works. A link holds its own expiry and the
* Console stores nothing, so a new one never ends an older one.
*/
var NATIVE_BUILD_DOWNLOAD_LINK_TTL_MS = 720 * 60 * 60 * 1e3;
/**
* The Console's secret, which a hosted Console already has for its sessions:
* a host's guide lists it. Links sign with a key derived from it, so a link
* is never a signature the sessions could take, and rotating it ends both.
*/
var CONSOLE_SECRET_ENV = "BETTER_AUTH_SECRET";
/** The length the Console's deployment guide asks of the secret. */
var MIN_SECRET_LENGTH = 32;
/** Separates the links' key from every other use of the Console's secret. */
var KEY_CONTEXT = "hot-updater/console/signed-links/v1";
/** What a link grants, so a token for anything else never verifies as one. */
var DOWNLOAD_PURPOSE = "native-build-download";
/** `<expiry in Unix seconds>.<HMAC-SHA256, base64url>`. */
var TOKEN_PATTERN = /^(\d{1,12})\.([A-Za-z0-9_-]{43})$/u;
var encoder = new TextEncoder();
var hmac = async (key, message) => new Uint8Array(await crypto.subtle.sign("HMAC", await crypto.subtle.importKey("raw", key, {
	name: "HMAC",
	hash: "SHA-256"
}, false, ["sign"]), encoder.encode(message)));
var base64Url = (bytes) => btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
var signatureOf = async (secret, buildId, expiresAtSeconds) => base64Url(await hmac(await hmac(encoder.encode(secret), KEY_CONTEXT), `${DOWNLOAD_PURPOSE}\n${buildId}\n${expiresAtSeconds}`));
/**
* The Console's secret from the host's environment, or undefined without one
* long enough to sign with. A Worker's secrets come with the request.
*/
var readConsoleSecret = (request) => {
	const { runtime } = request;
	const value = runtime?.cloudflare?.env?.["BETTER_AUTH_SECRET"] ?? (typeof process === "undefined" ? void 0 : process.env["BETTER_AUTH_SECRET"]);
	const secret = typeof value === "string" ? value.trim() : "";
	return secret.length >= MIN_SECRET_LENGTH ? secret : void 0;
};
/** A token that lets its bearer download one build until `expiresAtMs`. */
var createNativeBuildDownloadToken = async (secret, buildId, expiresAtMs) => {
	const expiresAtSeconds = String(Math.floor(expiresAtMs / 1e3));
	return `${expiresAtSeconds}.${await signatureOf(secret, buildId, expiresAtSeconds)}`;
};
/**
* Whether a token lets its bearer download `buildId` now. The expiry counts
* only under a signature that holds, so `expired` says nothing to a forger.
*/
var verifyNativeBuildDownloadToken = async (secret, buildId, token, now = Date.now()) => {
	const match = TOKEN_PATTERN.exec(token);
	if (match === null) return "invalid";
	const [, expiresAtSeconds, signature] = match;
	if (!sameSecret(signature, await signatureOf(secret, buildId, expiresAtSeconds))) return "invalid";
	return now >= Number(expiresAtSeconds) * 1e3 ? "expired" : "valid";
};
var refusal = (message) => new Response(message, {
	status: 403,
	headers: {
		"cache-control": "no-store",
		"content-type": "text/plain; charset=utf-8"
	}
});
/**
* The 403 for a download link's token, or undefined when it lets its bearer
* download `buildId`. The answer never repeats the token.
*/
var refuseNativeBuildDownloadToken = async (request, buildId, token) => {
	const secret = readConsoleSecret(request);
	if (secret === void 0) return refusal(`This Console can't check download links. Set ${CONSOLE_SECRET_ENV} on it.`);
	switch (await verifyNativeBuildDownloadToken(secret, buildId, token)) {
		case "valid": return;
		case "expired": return refusal("This download link has expired. Open the build's Console page for a new one.");
		case "invalid": return refusal("This download link isn't valid. Open the build's Console page for a new one.");
	}
};
/**
* A new signed download link's token, for a caller the Console already let
* in. It reads nothing and stores nothing.
*/
var issueNativeBuildDownloadLink = async (buildId, request = getRequest(), now = Date.now(), ttlMs = NATIVE_BUILD_DOWNLOAD_LINK_TTL_MS) => {
	const { default: localConsoleGuard } = await import("./request-guard-BPLyogIN.mjs");
	if (localConsoleGuard !== void 0) return { status: "local-console" };
	const secret = readConsoleSecret(request);
	if (secret === void 0) return {
		status: "no-secret",
		secretName: CONSOLE_SECRET_ENV
	};
	const expiresAt = now + ttlMs;
	return {
		status: "issued",
		token: await createNativeBuildDownloadToken(secret, buildId, expiresAt),
		expiresAt: new Date(expiresAt).toISOString()
	};
};
//#endregion
export { CONSOLE_SECRET_ENV, NATIVE_BUILD_DOWNLOAD_LINK_TTL_MS, createNativeBuildDownloadToken, issueNativeBuildDownloadLink, readConsoleSecret, refuseNativeBuildDownloadToken, verifyNativeBuildDownloadToken };
