import { t as ConsoleFeatureUnavailable } from "./ConsoleFeatureUnavailable--3q0wW_8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-keys-SwwUDM4p.js
var SplitNotFoundComponent = ConsoleFeatureUnavailable;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
