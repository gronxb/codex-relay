import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { k as cn } from "./sidebar-COdOWPGC.mjs";
import { a as Badge } from "./badge-o8QNRxtw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ChannelBadge-DsA4srwK.js
var import_jsx_runtime = require_jsx_runtime();
/** The channels with their own color; any other channel is neutral. */
var COLORED_CHANNELS = new Set([
	"production",
	"staging",
	"dev"
]);
function ChannelBadge({ channel, className }) {
	const name = channel.toLowerCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "outline",
		translate: "no",
		"data-channel": COLORED_CHANNELS.has(name) ? name : void 0,
		className: cn("border-channel-other/20 bg-channel-other/10 text-channel-other", "data-[channel=production]:border-channel-production/20 data-[channel=production]:bg-channel-production/10 data-[channel=production]:text-channel-production", "data-[channel=staging]:border-channel-staging/20 data-[channel=staging]:bg-channel-staging/10 data-[channel=staging]:text-channel-staging", "data-[channel=dev]:border-channel-dev/20 data-[channel=dev]:bg-channel-dev/10 data-[channel=dev]:text-channel-dev", className),
		children: channel
	});
}
//#endregion
export { ChannelBadge as t };
