//#region node_modules/.nitro/vite/services/ssr/assets/publicConsoleBase-wTKw3_iB.js
/**
* The console's address and path as a phone reached it, without a trailing
* slash, from a request to `routePath` under it. A proxy that ends TLS says so
* in `x-forwarded-proto`, which only upgrades the scheme: the answer goes back
* to whoever sent the header, and is never cached.
*/
var publicConsoleBase = (request, routePath) => {
	const url = new URL(request.url);
	const forwarded = request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim();
	const base = url.pathname.endsWith(routePath) ? url.pathname.slice(0, -routePath.length) : "";
	return `${forwarded === "https" ? "https:" : url.protocol}//${url.host}${base}`;
};
//#endregion
export { publicConsoleBase as t };
