import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as validateNativeBuildsSearch } from "./-native-builds-search-Bwt8tQzp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-builds-BN0EyqQH.js
var $$splitComponentImporter = () => import("./native-builds-1M1S1lhY.mjs");
var Route = createFileRoute("/native-builds")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	validateSearch: validateNativeBuildsSearch
});
//#endregion
export { Route as t };
