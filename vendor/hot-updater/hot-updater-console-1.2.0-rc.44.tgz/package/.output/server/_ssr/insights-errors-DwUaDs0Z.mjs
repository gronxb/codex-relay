import { c as readUpdateFailuresInput } from "./insights-failures-DGO2_3Vx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-errors-DwUaDs0Z.js
function readFailureReportsInput(input) {
	readUpdateFailuresInput(input);
	if (!Number.isSafeInteger(input.beforeReceivedAtMs) || input.beforeReceivedAtMs < 0 || input.cursor !== void 0 && (typeof input.cursor !== "string" || !input.cursor.length || input.cursor.length > 8192)) throw new Error("Invalid failure report range or cursor.");
	return input;
}
/** Exact text and reported context only; never guess a cause from the message. */
function groupFailureReports(events) {
	const groups = /* @__PURE__ */ new Map();
	for (const event of events) {
		if (event.type !== "UPDATE_FAILED" || !event.failure) continue;
		const f = event.failure;
		const key = JSON.stringify([
			f.stage,
			f.reason,
			f.errorMessage ?? null,
			f.resource ?? null,
			f.httpStatus ?? null,
			f.originCode ?? null,
			f.transport ?? null
		]);
		const group = groups.get(key) ?? [];
		group.push(event);
		groups.set(key, group);
	}
	return [...groups].map(([key, reports]) => ({
		key,
		reports: reports.sort((a, b) => b.receivedAtMs - a.receivedAtMs),
		installations: new Set(reports.map((event) => event.installId)).size
	})).sort((a, b) => b.reports.length - a.reports.length || b.reports[0].receivedAtMs - a.reports[0].receivedAtMs);
}
//#endregion
export { readFailureReportsInput as n, groupFailureReports as t };
