import { i as __toESM } from "../_runtime.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { A as Info } from "../_libs/lucide-react.mjs";
import { D as TooltipTrigger, T as TooltipContent, t as Button$1, w as Tooltip$1 } from "./sidebar-COdOWPGC.mjs";
import { s as isUUIDv7 } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
import { r as extractTimestampFromUUIDv7 } from "./uuidv7-C0jNe2Om.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-search-BZ00lACC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InfoTooltip({ label, children }) {
	const id = (0, import_react.useId)();
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip$1, {
		open,
		onOpenChange: setOpen,
		triggerId: id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
			id,
			"aria-describedby": open ? `${id}-description` : void 0,
			closeOnClick: false,
			onClick: () => setOpen((value) => !value),
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
				"aria-label": label,
				className: "size-11 sm:size-7",
				size: "icon",
				variant: "ghost"
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
			id: `${id}-description`,
			role: "tooltip",
			className: "max-w-64",
			side: "bottom",
			children
		})]
	});
}
var readText = (value) => typeof value === "string" && value.trim().length > 0 && value.length <= 1024 ? value : void 0;
var readWindow = (value) => value === "24h" || value === "7d" || value === "30d" ? value : void 0;
var readHealthChart = (value) => value === "adoption" || value === "crashes" ? value : void 0;
var readUsageWindow = (value) => value === "12m" ? value : readWindow(value);
var readPlatform = (value) => value === "all" || value === "ios" || value === "android" ? value : void 0;
function validateInsightsSearch(search) {
	return {
		platform: readPlatform(search.platform),
		channel: readText(search.channel),
		appVersion: readText(search.appVersion),
		window: readUsageWindow(search.window),
		bundleWindow: readWindow(search.bundleWindow),
		releaseId: readText(search.releaseId),
		healthChart: readHealthChart(search.healthChart),
		bundles: readText(search.bundles)
	};
}
function validateDistributionSearch(search) {
	return {
		...validateInsightsSearch(search),
		version: readText(search.version),
		page: typeof search.page === "number" && Number.isSafeInteger(search.page) && search.page > 0 ? search.page : void 0
	};
}
/**
* The shortest Release health period that still covers a release's first
* hours: 24h within a day of its deployment, 7d within a week, else 30d.
*/
function adoptionWindow(releaseId, now = Date.now()) {
	if (!isUUIDv7(releaseId)) return "7d";
	const age = now - extractTimestampFromUUIDv7(releaseId);
	return age <= 864e5 ? "24h" : age <= 7 * 864e5 ? "7d" : "30d";
}
/** Release health's compared bundles from the `bundles` search value. */
var comparedBundleIds = (value) => value === void 0 ? void 0 : [...new Set(value.split(",").filter((id) => id.length > 0))];
//#endregion
export { validateInsightsSearch as a, validateDistributionSearch as i, adoptionWindow as n, comparedBundleIds as r, InfoTooltip as t };
