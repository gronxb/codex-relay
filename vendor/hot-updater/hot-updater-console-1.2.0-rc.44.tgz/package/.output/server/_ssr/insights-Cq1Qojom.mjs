import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as requireConsoleFeature } from "./console-features-api-DbEAU6JB.mjs";
import { a as validateInsightsSearch } from "./insights-search-BZ00lACC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-Cq1Qojom.js
var $$splitComponentImporter = () => import("./insights-D4PYR8oS.mjs");
var $$splitNotFoundComponentImporter = () => import("./insights-BRkURfOE.mjs");
var Route = createFileRoute("/insights")({
	beforeLoad: ({ context }) => requireConsoleFeature(context.queryClient, "insightsAnalytics"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	validateSearch: validateInsightsSearch
});
//#endregion
export { Route as t };
