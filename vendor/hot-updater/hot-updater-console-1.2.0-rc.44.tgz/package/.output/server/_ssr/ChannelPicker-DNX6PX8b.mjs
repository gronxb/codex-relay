import { i as __toESM } from "../_runtime.mjs";
import { A as ComboboxPopup, D as ComboboxItem$1, E as ComboboxEmpty$1, Et as require_react, F as ComboboxClear$1, I as ComboboxInput$1, L as ComboboxTrigger$1, M as ComboboxPortal, N as ComboboxList$1, O as ComboboxGroupLabel, P as ComboboxCollection$1, T as ComboboxRoot, Tt as require_jsx_runtime, j as ComboboxPositioner, k as ComboboxGroup$1, w as ComboboxItemIndicator } from "../_libs/@base-ui/react+[...].mjs";
import { X as ChevronDown, Z as Check, _ as RefreshCw, t as X } from "../_libs/lucide-react.mjs";
import { C as Skeleton, k as cn, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { i as useChannelsQuery } from "./api-BISxaFip.mjs";
import { t as ALL_CHANNELS_LABEL } from "./constants-BjsJZqaU.mjs";
import { i as InputGroupInput, n as InputGroupAddon, r as InputGroupButton, t as InputGroup } from "./input-group-DpNq5b5O.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ChannelPicker-DNX6PX8b.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Combobox$1 = ComboboxRoot;
function ComboboxTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxTrigger$1, {
		"data-slot": "combobox-trigger",
		className: cn("[&_svg:not([class*='size-'])]:size-3.5", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "text-muted-foreground size-3.5 pointer-events-none" })]
	});
}
function ComboboxClear({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxClear$1, {
		"aria-label": "Clear selection",
		"data-slot": "combobox-clear",
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupButton, {
			variant: "ghost",
			size: "icon-xs"
		}),
		className: cn(className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "pointer-events-none" })
	});
}
function ComboboxInput({ className, children, disabled = false, showTrigger = true, showClear = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputGroup, {
		className: cn("w-auto", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput$1, {
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupInput, { disabled }),
				...props
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputGroupAddon, {
				align: "inline-end",
				children: [showTrigger && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxTrigger, { render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupButton, {
					size: "icon-xs",
					variant: "ghost",
					"data-slot": "input-group-button",
					className: "group-has-data-[slot=combobox-clear]/input-group:hidden data-pressed:bg-transparent",
					disabled
				}) }), showClear && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxClear, { disabled })]
			}),
			children
		]
	});
}
function ComboboxContent({ className, side = "bottom", sideOffset = 6, align = "start", alignOffset = 0, anchor, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxPositioner, {
		side,
		sideOffset,
		align,
		alignOffset,
		anchor,
		className: "isolate z-50",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxPopup, {
			"data-slot": "combobox-content",
			"data-chips": !!anchor,
			className: cn("bg-popover text-popover-foreground data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 *:data-[slot=input-group]:bg-input/20 dark:bg-popover max-h-72 min-w-32 overflow-hidden rounded-lg shadow-md ring-1 duration-100 *:data-[slot=input-group]:m-1 *:data-[slot=input-group]:mb-0 *:data-[slot=input-group]:h-7 max-md:*:data-[slot=input-group]:h-11 *:data-[slot=input-group]:border-none *:data-[slot=input-group]:shadow-none dark group/combobox-content relative max-h-(--available-height) w-(--anchor-width) max-w-(--available-width) min-w-[calc(var(--anchor-width)+--spacing(7))] origin-(--transform-origin) data-[chips=true]:min-w-(--anchor-width)", className),
			...props
		})
	}) });
}
function ComboboxList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList$1, {
		"data-slot": "combobox-list",
		className: cn("no-scrollbar max-h-[min(calc(--spacing(72)---spacing(9)),calc(var(--available-height)---spacing(9)))] scroll-py-1 overflow-y-auto p-1 data-empty:p-0 overflow-y-auto overscroll-contain", className),
		...props
	});
}
function ComboboxItem({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxItem$1, {
		"data-slot": "combobox-item",
		className: cn("data-highlighted:bg-accent data-highlighted:text-accent-foreground not-data-[variant=destructive]:data-highlighted:**:text-accent-foreground min-h-7 gap-2 rounded-md py-1 pr-8 pl-2 text-xs/relaxed max-md:min-h-11 [&_svg:not([class*='size-'])]:size-3.5 relative flex w-full cursor-default items-center outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxItemIndicator, {
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute right-2 flex items-center justify-center" }),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "pointer-events-none" })
		})]
	});
}
function ComboboxGroup({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxGroup$1, {
		"data-slot": "combobox-group",
		className: cn(className),
		...props
	});
}
function ComboboxLabel({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxGroupLabel, {
		"data-slot": "combobox-label",
		className: cn("text-muted-foreground px-2 py-1.5 text-xs", className),
		...props
	});
}
function ComboboxCollection({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxCollection$1, {
		"data-slot": "combobox-collection",
		...props
	});
}
function ComboboxEmpty({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty$1, {
		"data-slot": "combobox-empty",
		className: cn("text-muted-foreground hidden w-full justify-center py-2 text-center text-xs/relaxed group-data-empty/combobox-content:flex", className),
		...props
	});
}
/**
* One look for every filter button: 44 px on a phone, compact from sm, and
* filled when the filter is narrower than its default.
*/
function FilterChip({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
		className: cn("h-11 shrink-0 gap-1.5 px-3 text-sm data-[active=true]:border-primary/60 data-[active=true]:bg-primary/10 sm:h-8 sm:text-xs", className),
		variant: "outline",
		...props
	});
}
var EVERY_CHANNEL = {
	name: void 0,
	label: ALL_CHANNELS_LABEL
};
/**
* The channel filter Insights, Bundles, and Native builds share: a button
* that reads "Channel <name>" and opens a searchable list of the project's
* channels. Typing narrows the list, and Enter picks the first match.
*
* Every channel is one more choice where a page offers it. It is no name,
* so a channel named `all` stays a channel of its own.
*/
function ChannelPicker({ value, onValueChange, allChannels = false, pending = false, active, className }) {
	const channels = useChannelsQuery();
	const [query, setQuery] = (0, import_react.useState)("");
	const list = (0, import_react.useRef)(null);
	const opening = (0, import_react.useRef)(false);
	const names = channels.data?.map(({ name }) => name) ?? [];
	const shown = value === void 0 || names.includes(value) ? names : [value, ...names];
	const choices = [...allChannels ? [EVERY_CHANNEL] : [], ...shown.map((name) => ({
		name,
		label: name
	}))];
	const typed = query.trim().toLowerCase();
	const matches = choices.filter((choice) => choice.label.toLowerCase().includes(typed));
	const selected = choices.find((choice) => choice.name === value) ?? (value === void 0 ? EVERY_CHANNEL : {
		name: value,
		label: value
	});
	const label = pending ? void 0 : selected.label;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox$1, {
		autoHighlight: true,
		disabled: pending,
		filter: null,
		inputValue: query,
		isItemEqualToValue: (item, current) => item.name === current.name,
		itemToStringLabel: (choice) => choice.label,
		items: matches,
		onInputValueChange: setQuery,
		onItemHighlighted: (_, details) => {
			if (!opening.current || details.reason !== "none") return;
			opening.current = false;
			queueMicrotask(() => requestAnimationFrame(() => {
				if (list.current) list.current.scrollTop = 0;
			}));
		},
		onOpenChange: (next) => {
			opening.current = next;
			if (!next) {
				setQuery("");
				return;
			}
			if (channels.data !== void 0 && !channels.isFetching && Date.now() - channels.dataUpdatedAt > 3e4) channels.refetch();
		},
		onValueChange: (choice) => {
			if (choice !== null && choice.name !== value) onValueChange(choice.name);
		},
		value: pending ? null : selected,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxTrigger, {
			"aria-label": label === void 0 ? "Channel" : `Channel: ${label}`,
			"data-active": active,
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, { className }),
			title: label,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "Channel"
			}), label === void 0 ? channels.isError ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-16" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 truncate text-left sm:max-w-48",
				translate: value === void 0 ? void 0 : "no",
				children: label
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, {
			className: "w-72 min-w-(--anchor-width)",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
					"aria-label": "Search channels",
					maxLength: 1024,
					placeholder: "Search channels…",
					showTrigger: false
				}),
				channels.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 pt-2 text-xs text-muted-foreground",
					children: "Loading channels…"
				}) : channels.isError && channels.data === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 px-3 pt-2 text-xs text-muted-foreground",
					children: ["Couldn't load channels.", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
						className: "max-md:min-h-11",
						onClick: () => void channels.refetch(),
						size: "sm",
						variant: "outline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry channels"]
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, {
					className: "flex-col items-center gap-2 px-3",
					children: typed === "" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"No channel matches “",
						query.trim(),
						"”.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
							className: "max-md:min-h-11",
							onClick: () => setQuery(""),
							size: "sm",
							variant: "outline",
							children: "Clear search"
						})
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList, {
					ref: list,
					children: (choice) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxItem, {
						value: choice,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 [overflow-wrap:anywhere]",
							translate: choice.name === void 0 ? void 0 : "no",
							children: choice.label
						})
					}, choice.name ?? "")
				})
			]
		})]
	});
}
//#endregion
export { ComboboxEmpty as a, ComboboxItem as c, ComboboxTrigger as d, FilterChip as f, ComboboxContent as i, ComboboxLabel as l, Combobox$1 as n, ComboboxGroup as o, ComboboxCollection as r, ComboboxInput as s, ChannelPicker as t, ComboboxList as u };
