import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { Tt as require_jsx_runtime, _ as ProgressRoot, g as ProgressTrack$1, h as ProgressIndicator$1 } from "../_libs/@base-ui/react+[...].mjs";
import { A as createSsrRpc, k as cn } from "./sidebar-COdOWPGC.mjs";
import { t as readAppUsageInput } from "./insights-usage-BVm7CDw9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-usage-rpc-CUpYkwHr.js
var import_jsx_runtime = require_jsx_runtime();
function Progress$1({ className, children, value, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ProgressRoot, {
		value,
		"data-slot": "progress",
		className: cn("w-full", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressTrack, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressIndicator, {}) })]
	});
}
function ProgressTrack({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressTrack$1, {
		className: cn("relative flex h-1 w-full items-center overflow-x-hidden rounded-md bg-muted", className),
		"data-slot": "progress-track",
		...props
	});
}
function ProgressIndicator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressIndicator$1, {
		"data-slot": "progress-indicator",
		className: cn("h-full bg-primary transition-transform motion-reduce:transition-none", className),
		...props
	});
}
var getAppUsageReportRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => {
	readAppUsageInput(input);
	return {
		platform: input.platform,
		channel: input.channel,
		appVersion: input.appVersion,
		window: input.window
	};
}).handler(createSsrRpc("8a98cd9c178e4a54185d62c25a95f09d3d59850c43d3f5baa1563e1614ad942e"));
//#endregion
export { getAppUsageReportRpc as n, Progress$1 as t };
