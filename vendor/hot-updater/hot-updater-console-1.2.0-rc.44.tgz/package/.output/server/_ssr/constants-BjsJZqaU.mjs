//#region node_modules/.nitro/vite/services/ssr/assets/constants-BjsJZqaU.js
/**
* The channel the SDK and the CLI use when none is chosen. Insights, Bundles,
* and Native builds open on it when the URL names no channel.
*/
var DEFAULT_CHANNEL = "production";
/** The channel filter's choice that lists every channel, on every page. */
var ALL_CHANNELS_LABEL = "All channels";
//#endregion
export { DEFAULT_CHANNEL as n, ALL_CHANNELS_LABEL as t };
