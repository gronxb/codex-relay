import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { A as createSsrRpc } from "./sidebar-COdOWPGC.mjs";
import { i as useQuery, r as queryOptions } from "../_libs/tanstack__react-query.mjs";
import { n as consoleFeatures } from "./console-features-DTYyXrWO.mjs";
import { v as notFound } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/console-features-api-DbEAU6JB.js
/** The features this console serves, for navigation and route guards. */
var getConsoleFeaturesRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(createSsrRpc("82ec3500e57f9e81dac6d3f3a7bd9e34915da3121429beec87b7ad153dc6eafe"));
var consoleFeaturesQueryKey = ["console", "features"];
var consoleFeaturesQueryOptions = () => queryOptions({
	queryKey: consoleFeaturesQueryKey,
	queryFn: () => getConsoleFeaturesRpc(),
	staleTime: Infinity
});
/** The features the console serves; the authorized layout loads them first. */
var useConsoleFeatures = () => useQuery(consoleFeaturesQueryOptions());
/** Whether `feature` is on; false until the features load. */
var useConsoleFeature = (feature) => useConsoleFeatures().data?.features[feature] === true;
/** The feature in a route's not-found data, when a feature guard threw it. */
var notFoundFeature = (data) => {
	const feature = typeof data === "object" && data !== null ? Reflect.get(data, "feature") : void 0;
	return typeof feature === "string" && Object.hasOwn(consoleFeatures, feature) ? feature : void 0;
};
/**
* A feature route's `beforeLoad`: not found, naming the feature, when the
* console does not serve it. A failed features read lets the route load: the
* root layout answers a visitor it does not authorize, and the route's own
* reads report any other failure. The failure leaves the cache, which a
* server render sends to the browser: a refused visitor's failure is the 401
* or 403 Response, which the render cannot serialize.
*/
var requireConsoleFeature = async (queryClient, feature) => {
	const featureSet = await queryClient.ensureQueryData(consoleFeaturesQueryOptions()).catch(() => {
		queryClient.removeQueries({
			queryKey: consoleFeaturesQueryKey,
			exact: true
		});
	});
	if (featureSet !== void 0 && !featureSet.features[feature]) throw notFound({ data: { feature } });
};
//#endregion
export { useConsoleFeatures as a, useConsoleFeature as i, notFoundFeature as n, requireConsoleFeature as r, consoleFeaturesQueryOptions as t };
