import { i as isDatabaseJsonObject, t as DatabaseAdapterInputError } from "./databaseJsonValue-DuUoft8j.mjs";
import { d as getNumericCohortValue, u as getNumericCohortRolloutPosition, v as isValidCohort, y as normalizeCohortValue } from "./dist-CiOq3ygH.mjs";
import { s as isUUIDv7 } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
import { t as __exportAll } from "./rolldown-runtime-rSIU-vHC.mjs";
import { t as createUUIDv7 } from "./uuidv7-C0jNe2Om.mjs";
import { o as satisfies, t as coerce } from "./version-CQ98ZBpL-zW2fpHOZ.mjs";
import { n as defineTable, t as defineAggregate } from "./schema-CaIuQCXb.mjs";
import { t as isValidRange } from "../_libs/verkit.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plugins-D9CCkDjn.js
var semverSatisfies = (targetAppVersion, currentVersion) => {
	const currentCoerce = coerce(currentVersion);
	if (!currentCoerce) return false;
	return satisfies(currentCoerce, targetAppVersion);
};
defineTable({
	id: {
		type: "string",
		maxLength: 255
	},
	hash: {
		type: "string",
		maxLength: 64,
		unique: true
	},
	name: {
		type: "string",
		maxLength: 64
	},
	prefix: {
		type: "string",
		maxLength: 16
	},
	role: {
		type: "string",
		maxLength: 16
	},
	created_at_ms: { type: "integer" },
	revoked_at_ms: {
		type: "integer",
		required: false
	}
}, {
	key: ["id"],
	indexes: { byCreated: {
		eq: [],
		sort: ["created_at_ms"]
	} }
});
var DAY_MS$1 = 864e5;
var DEFAULT_INSIGHTS_RETENTION = {
	rawDays: 90,
	dailyDays: 400
};
var bucketRetention = (days) => ({
	field: "bucket_start_ms",
	days
});
/** Every kind of row the table keeps belongs in installation history. */
var MOVEMENTS = /* @__PURE__ */ new Set([
	"UPDATE_DOWNLOADED",
	"UPDATE_APPLIED",
	"RECOVERED",
	"UPDATE_FAILED",
	"UNCHANGED"
]);
/** A failed update check: it names no target bundle, so no bundle list shows it. */
var isFailedCheck = (row) => row.type === "UPDATE_FAILED" && row.metadata?.failure?.stage === "check";
var metadataOf = (row) => row.metadata ?? {};
/** A download or apply that arrived after its target ran: it counts nothing. */
var isLateEvent = (row) => metadataOf(row).late === true;
/**
* Whether a stored row launched its installation into a bundle release: an
* apply, or a kept UNCHANGED row that moved the installation to another
* bundle of a release, as when the apply report never arrived or a rollback
* to the built-in bundle took it there. A first report, a release change of
* the bundle already running, and a late row launch nothing.
*/
var isLaunch = (row) => {
	if (isLateEvent(row)) return false;
	if (row.type === "UPDATE_APPLIED") return true;
	if (row.type !== "UNCHANGED") return false;
	const kinds = metadataOf(row).change?.kinds ?? [];
	return kinds.includes("bundle") && !kinds.includes("first_seen") && row.to_release_id !== null;
};
/**
* The bundle a stored row's bundle filter matches: `from:<bundle>` for a
* recovery; `to:<bundle>` for a download, an apply, and an update failure;
* `on:<bundle>` for an UNCHANGED row that launched a bundle (`isLaunch`), a
* key no other row uses. None for a failed check, which targets no bundle, a
* late row, or any other UNCHANGED row.
*/
var bundleRefsOf = (row) => {
	if (isFailedCheck(row) || isLateEvent(row)) return [];
	if (row.type === "RECOVERED") return [`from:${row.from_bundle_id}`];
	if (row.type === "UNCHANGED") return isLaunch(row) ? [`on:${row.to_bundle_id}`] : [];
	return [`to:${row.to_bundle_id}`];
};
/** The key a bundle filter reads, as `bundleRefsOf` writes it. */
var bundleRefOfFilter = (filter) => filter.type === "RECOVERED" ? `from:${filter.fromBundleId}` : filter.type === "UNCHANGED" ? `on:${filter.toBundleId}` : `to:${filter.toBundleId}`;
/**
* Downloads, applies, recoveries, update failures, and the UNCHANGED
* reports that changed what their installation runs, whole. An UNCHANGED
* report that changes nothing counts as a launch and moves its
* installation's head, but no row keeps it.
*/
var bundleEvents = (days) => defineTable({
	id: {
		type: "string",
		maxLength: 36
	},
	type: {
		type: "string",
		maxLength: 32
	},
	install_id: {
		type: "string",
		maxLength: 255
	},
	user_id: {
		type: "string",
		maxLength: 255,
		required: false
	},
	from_release_id: {
		type: "string",
		maxLength: 36,
		required: false
	},
	from_bundle_id: {
		type: "string",
		maxLength: 36,
		required: false
	},
	to_release_id: {
		type: "string",
		maxLength: 36,
		required: false
	},
	to_bundle_id: {
		type: "string",
		maxLength: 36
	},
	platform: {
		type: "string",
		maxLength: 16
	},
	app_version: { type: "string" },
	channel: { type: "string" },
	metadata: { type: "json" },
	received_at_ms: { type: "integer" }
}, {
	key: ["id"],
	derived: {
		day: {
			type: "integer",
			compute: (row) => row.received_at_ms - row.received_at_ms % DAY_MS$1
		},
		movement_install_id: {
			type: "string",
			compute: (row) => MOVEMENTS.has(row.type) ? row.install_id : null
		},
		bundle_ref: {
			type: "string",
			multi: true,
			compute: (row) => bundleRefsOf(row)
		}
	},
	indexes: {
		movementsByInstall: {
			eq: ["movement_install_id"],
			sort: ["received_at_ms"]
		},
		byBundle: {
			eq: [
				"platform",
				"channel",
				"type",
				"bundle_ref",
				"day"
			],
			sort: ["received_at_ms"]
		},
		byDay: {
			eq: ["day"],
			sort: ["received_at_ms"]
		}
	},
	retention: {
		field: "day",
		days
	}
});
/**
* Each installation's latest event, whole, so reading it is one point read.
* Its gauges count it in the UTC day of that event. An update failure moves
* nothing, so no head holds one.
*/
var bundleEventHeads = (days) => defineTable({
	install_id: {
		type: "string",
		maxLength: 255
	},
	id: {
		type: "string",
		maxLength: 36
	},
	type: {
		type: "string",
		maxLength: 32
	},
	user_id: {
		type: "string",
		maxLength: 255,
		required: false
	},
	from_release_id: {
		type: "string",
		maxLength: 36,
		required: false
	},
	from_bundle_id: {
		type: "string",
		maxLength: 36,
		required: false
	},
	to_release_id: {
		type: "string",
		maxLength: 36,
		required: false
	},
	to_bundle_id: {
		type: "string",
		maxLength: 36
	},
	platform: {
		type: "string",
		maxLength: 16
	},
	app_version: { type: "string" },
	channel: { type: "string" },
	metadata: { type: "json" },
	received_at_ms: { type: "integer" }
}, {
	key: ["install_id"],
	indexes: { byUser: {
		eq: ["user_id"],
		sort: ["install_id"]
	} },
	retention: {
		field: "received_at_ms",
		days
	}
});
/**
* Shards are keyed by install id. Counters are blind increments and never
* conflict, so they keep 8. Gauges and sketches are read, merged, and written
* back. B3's rollout gate on PostgreSQL retried 2.4% of transactions at 8
* shards and 1.3% at 16. DynamoDB's transactions take longer, so D8's gate
* on DynamoDB Local retried 2–24% at 16, almost all on gauge rows, and 1–5%
* with gauges at 32. Sketches stay at 16: each shard row carries 2 KB of
* registers that every read merges.
*
* Every Insights aggregate is `batched`: on DynamoDB and Firestore, which
* bill each write, an event's changes apply after it commits, merged with
* other events' into one write per row, on one shard per writer.
*/
var COUNTER_SHARDS = 8;
var GAUGE_SHARDS = 32;
var SKETCH_SHARDS = 16;
/** Rows keyed by a hashed identity (scope and period) and a bucket. */
var identityFields = {
	identity: {
		type: "string",
		maxLength: 32
	},
	bucket_start_ms: { type: "integer" }
};
var window = {
	eq: ["identity"],
	sort: ["bucket_start_ms"]
};
/** What a release or channel row counts in every period kind. */
var WINDOW_COUNTERS = [
	"downloads",
	"failed_launches",
	"patch_downloads",
	"patch_fallbacks"
];
/**
* Hourly or daily counters: a release or channel row counts downloads,
* launches that crashed and recovered (`failed_launches`), and downloads a
* patch delivered and those that fell back from one.
*/
var counters = (retention) => defineAggregate(identityFields, {
	key: ["identity", "bucket_start_ms"],
	counters: WINDOW_COUNTERS,
	shards: COUNTER_SHARDS,
	batched: true,
	indexes: { window },
	retention
});
/**
* A release's counters since its first report, at bucket 0: the windowed
* counters, its applies, which the bundle list reads, and its failed updates
* (`failed_updates`), since no breakdown row outlives the raw period; windowed
* reads sum `insights_failures` instead.
*/
var lifetimeCounters = () => defineAggregate(identityFields, {
	key: ["identity", "bucket_start_ms"],
	counters: [
		...WINDOW_COUNTERS,
		"applies",
		"failed_updates"
	],
	shards: COUNTER_SHARDS,
	batched: true,
	indexes: { window }
});
/**
* Unique-installation sketches of one period kind: a usage row's active
* installations (`activity_users`), and a `failure` or `check` row's
* installations whose update or update check failed (`failed_users`).
*/
var sketches = (retention) => defineAggregate(identityFields, {
	key: ["identity", "bucket_start_ms"],
	distinct: ["activity_users", "failed_users"],
	shards: SKETCH_SHARDS,
	batched: true,
	indexes: { window },
	retention
});
/** Installations whose update to a release failed, since its first failure: kept, at bucket 0. */
var lifetimeSketches = () => defineAggregate(identityFields, {
	key: ["identity", "bucket_start_ms"],
	distinct: ["failed_users"],
	shards: SKETCH_SHARDS,
	batched: true,
	indexes: { window }
});
/**
* Update failures by what failed, a row an hour. `release_id` is the failed
* update's target release, or empty for a failed check or an unknown target.
* `stage` and `reason` say where and why it failed, and `detail` what else
* the client knew, as the JSON array `[resource, httpStatus, originCode,
* transport]`. Every index is in key order, so its counters stay blind
* increments.
*/
var insightsFailures = (retention) => defineAggregate({
	platform: {
		type: "string",
		maxLength: 16
	},
	channel: { type: "string" },
	bucket_start_ms: { type: "integer" },
	release_id: {
		type: "string",
		maxLength: 36
	},
	stage: {
		type: "string",
		maxLength: 16
	},
	reason: {
		type: "string",
		maxLength: 64
	},
	detail: {
		type: "string",
		maxLength: 160
	}
}, {
	key: [
		"platform",
		"channel",
		"bucket_start_ms",
		"release_id",
		"stage",
		"reason",
		"detail"
	],
	counters: ["events"],
	shards: COUNTER_SHARDS,
	batched: true,
	indexes: { byScope: {
		eq: ["platform", "channel"],
		sort: ["bucket_start_ms"]
	} },
	retention
});
/** Installations counted in the UTC day of their latest event, so reads sum whole UTC days. */
var insightsDistribution = (retention) => defineAggregate({
	channel: { type: "string" },
	platform: {
		type: "string",
		maxLength: 16
	},
	app_version: { type: "string" },
	release_id: {
		type: "string",
		maxLength: 36
	},
	bucket_start_ms: { type: "integer" }
}, {
	key: [
		"channel",
		"platform",
		"app_version",
		"release_id",
		"bucket_start_ms"
	],
	gauges: ["latest_installations"],
	shards: GAUGE_SHARDS,
	batched: true,
	indexes: {
		byScope: {
			eq: ["channel", "platform"],
			sort: ["bucket_start_ms"]
		},
		byVersion: {
			eq: [
				"channel",
				"platform",
				"app_version"
			],
			sort: ["bucket_start_ms"]
		}
	},
	retention
});
/**
* The installations of `insights_distribution` that run their native build's
* built-in bundle, by its ID (`builtin_bundle_id`), within the same rows:
* reads move them out of the row of their release, or of no release.
*/
var insightsBuiltinDistribution = (retention) => defineAggregate({
	channel: { type: "string" },
	platform: {
		type: "string",
		maxLength: 16
	},
	app_version: { type: "string" },
	release_id: {
		type: "string",
		maxLength: 36
	},
	builtin_bundle_id: {
		type: "string",
		maxLength: 36
	},
	bucket_start_ms: { type: "integer" }
}, {
	key: [
		"channel",
		"platform",
		"app_version",
		"release_id",
		"builtin_bundle_id",
		"bucket_start_ms"
	],
	gauges: ["latest_installations"],
	shards: GAUGE_SHARDS,
	batched: true,
	indexes: {
		byScope: {
			eq: ["channel", "platform"],
			sort: ["bucket_start_ms"]
		},
		byVersion: {
			eq: [
				"channel",
				"platform",
				"app_version"
			],
			sort: ["bucket_start_ms"]
		}
	},
	retention
});
/** Latest events by the bundle they came from or went to, bucketed like the distribution. */
var insightsLatestByBundle = (retention) => defineAggregate({
	platform: {
		type: "string",
		maxLength: 16
	},
	channel: { type: "string" },
	bundle_field: {
		type: "string",
		maxLength: 16
	},
	bundle_id: {
		type: "string",
		maxLength: 36
	},
	type: {
		type: "string",
		maxLength: 32
	},
	bucket_start_ms: { type: "integer" }
}, {
	key: [
		"platform",
		"channel",
		"bundle_field",
		"bundle_id",
		"type",
		"bucket_start_ms"
	],
	gauges: ["installations"],
	shards: GAUGE_SHARDS,
	batched: true,
	indexes: { byBundle: {
		eq: [
			"platform",
			"channel",
			"bundle_field",
			"bundle_id",
			"type"
		],
		sort: ["bucket_start_ms"]
	} },
	retention
});
/**
* Stored events by outcome and the bundle a bundle filter matches, a row an
* hour, which a failed check has none of; and every stored event, a row a UTC
* day (`DAILY_EVENTS`). Bundle counts sum the hourly rows, and event lists
* read either to skip days without events.
*/
var insightsOutcomes = (retention) => defineAggregate({
	platform: {
		type: "string",
		maxLength: 16
	},
	channel: { type: "string" },
	type: {
		type: "string",
		maxLength: 32
	},
	bundle_ref: {
		type: "string",
		maxLength: 41
	},
	bucket_start_ms: { type: "integer" }
}, {
	key: [
		"platform",
		"channel",
		"type",
		"bundle_ref",
		"bucket_start_ms"
	],
	counters: ["events"],
	shards: COUNTER_SHARDS,
	batched: true,
	indexes: { byRef: {
		eq: [
			"platform",
			"channel",
			"type",
			"bundle_ref"
		],
		sort: ["bucket_start_ms"]
	} },
	retention
});
/**
* Insights' tables, each expiring after its period. The periods are values
* the engine applies at runtime; the tables and indexes are the same for
* any periods.
*/
var createInsightsSchema = ({ rawDays, dailyDays } = DEFAULT_INSIGHTS_RETENTION) => {
	const hourly = bucketRetention(rawDays);
	const daily = bucketRetention(dailyDays);
	return {
		bundle_events: bundleEvents(rawDays),
		bundle_event_heads: bundleEventHeads(dailyDays),
		insights_overview: counters(hourly),
		insights_sketches: sketches(hourly),
		insights_overview_daily: counters(daily),
		insights_sketches_daily: sketches(daily),
		insights_overview_lifetime: lifetimeCounters(),
		insights_sketches_lifetime: lifetimeSketches(),
		insights_distribution: insightsDistribution(daily),
		insights_builtin_distribution: insightsBuiltinDistribution(daily),
		insights_latest_by_bundle: insightsLatestByBundle(daily),
		insights_outcomes: insightsOutcomes(hourly),
		insights_failures: insightsFailures(hourly)
	};
};
createInsightsSchema();
var CHANGE_KINDS = /* @__PURE__ */ new Set([
	"first_seen",
	"bundle",
	"release",
	"app_version",
	"channel",
	"native_build"
]);
var isBundleEventChange = (value) => isDatabaseJsonObject(value) && Array.isArray(value.kinds) && value.kinds.length > 0 && value.kinds.every((kind) => CHANGE_KINDS.has(kind)) && (value.previous === null || isDatabaseJsonObject(value.previous) && typeof value.previous.bundle_id === "string" && (value.previous.release_id === null || typeof value.previous.release_id === "string") && typeof value.previous.app_version === "string" && typeof value.previous.channel === "string" && isOptional(value.previous, "min_bundle_id", isString));
var isOptional = (value, key, valid) => !Object.hasOwn(value, key) || valid(value[key]);
var isString = (value) => typeof value === "string";
var isDatabaseHttpResponse = (value) => isDatabaseJsonObject(value) && (value.resource === "catalog" || value.resource === "artifact") && isString(value.path) && Number.isSafeInteger(value.status) && (value.body === null || isString(value.body)) && typeof value.body_truncated === "boolean" && Number.isSafeInteger(value.received_at_ms);
/** An `UPDATE_FAILED` report's stored failure: a stage and a reason, and what else the client knew. */
var isDatabaseBundleEventFailure = (value) => isDatabaseJsonObject(value) && isString(value.stage) && isString(value.reason) && isOptional(value, "resource", isString) && isOptional(value, "http_status", (status) => Number.isSafeInteger(status)) && isOptional(value, "transport", isString) && isOptional(value, "origin_code", isString) && isOptional(value, "error_message", isString) && isOptional(value, "error_stack", isString);
var isDatabaseBundleEventMetadata = (value) => isDatabaseJsonObject(value) && typeof value.cohort === "string" && (value.update_strategy === null || value.update_strategy === "fingerprint" || value.update_strategy === "appVersion") && (value.fingerprint_hash === null || typeof value.fingerprint_hash === "string") && (value.sdk_version === null || typeof value.sdk_version === "string") && isOptional(value, "min_bundle_id", isString) && isOptional(value, "failure", isDatabaseBundleEventFailure) && isOptional(value, "http_response", isDatabaseHttpResponse) && isOptional(value, "delivery", isString) && isOptional(value, "patch_fallback", (flag) => typeof flag === "boolean") && isOptional(value, "change", isBundleEventChange) && isOptional(value, "late", (flag) => flag === true) && isOptional(value, "implied_download", (flag) => flag === true);
var isRecord$3 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var isIdentity$1 = (value) => typeof value === "string" && value.length > 0 && value.length <= 255;
var isTextOrNull = (value) => value === null || typeof value === "string";
/** Each bundle event field and what it holds. */
var BUNDLE_EVENT_FIELDS = {
	id: (value) => typeof value === "string",
	type: (value) => value === "UPDATE_DOWNLOADED" || value === "UPDATE_APPLIED" || value === "RECOVERED" || value === "UPDATE_FAILED" || value === "UNCHANGED",
	install_id: isIdentity$1,
	user_id: (value) => value === null || isIdentity$1(value),
	from_bundle_id: isTextOrNull,
	from_release_id: isTextOrNull,
	to_release_id: isTextOrNull,
	to_bundle_id: (value) => typeof value === "string",
	platform: (value) => value === "ios" || value === "android",
	app_version: (value) => typeof value === "string",
	channel: (value) => typeof value === "string",
	metadata: isDatabaseBundleEventMetadata,
	received_at_ms: (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0
};
var hasMetadata = (row, key) => isRecord$3(row.metadata) && Object.hasOwn(row.metadata, key);
var updateStrategyOf = (row) => isRecord$3(row.metadata) ? row.metadata.update_strategy : void 0;
/**
* A movement, or a failed update, names the bundle it left and how the
* device updates, and a failed update says what failed; an unchanged report
* names neither.
*/
var hasEventInvariants = (row) => (row.type === "UPDATE_DOWNLOADED" || row.type === "UPDATE_APPLIED" || row.type === "RECOVERED" || row.type === "UPDATE_FAILED") && typeof row.from_bundle_id === "string" && (updateStrategyOf(row) === "fingerprint" || updateStrategyOf(row) === "appVersion") && (row.type !== "UPDATE_FAILED" || isRecord$3(row.metadata) && isRecord$3(row.metadata.failure)) && !hasMetadata(row, "change") && (!hasMetadata(row, "late") || row.type === "UPDATE_DOWNLOADED" || row.type === "UPDATE_APPLIED") && (!hasMetadata(row, "implied_download") || row.type === "UPDATE_APPLIED" || row.type === "RECOVERED") || row.type === "UNCHANGED" && !hasMetadata(row, "late") && row.from_bundle_id === null && updateStrategyOf(row) === null;
/**
* Throws unless `row` has exactly the bundle event fields, each of its type,
* and the invariants of its event type: `invalid-field` for an unknown field,
* `invalid-data` for anything else.
*/
var validateBundleEventFields = (row) => {
	if (!isRecord$3(row)) throw new DatabaseAdapterInputError("invalid-data");
	for (const field of Object.keys(row)) if (!Object.hasOwn(BUNDLE_EVENT_FIELDS, field)) throw new DatabaseAdapterInputError("invalid-field");
	for (const [field, valid] of Object.entries(BUNDLE_EVENT_FIELDS)) if (!Object.hasOwn(row, field) || !valid(row[field])) throw new DatabaseAdapterInputError("invalid-data");
	if (!hasEventInvariants(row)) throw new DatabaseAdapterInputError("invalid-data");
};
var encoder = new TextEncoder();
/** Exact UTF-8 byte ordering, without case folding or Unicode normalization. */
var compareInsightsText = (left, right) => {
	const a = encoder.encode(left);
	const b = encoder.encode(right);
	for (let index = 0; index < Math.min(a.length, b.length); index += 1) if (a[index] !== b[index]) return a[index] - b[index];
	return a.length - b.length;
};
var isWellFormedText = (value) => {
	for (const character of value) {
		const point = character.codePointAt(0);
		if (point >= 55296 && point <= 57343) return false;
	}
	return true;
};
var isIdentity = (value) => typeof value === "string" && value.length > 0 && value.length <= 255 && isWellFormedText(value);
var isText = (value) => typeof value === "string" && value.length > 0 && isWellFormedText(value);
var isTimestamp = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
var isLimit = (value) => isTimestamp(value) && value >= 1 && value <= 101;
var hasOnlyKeys = (value, keys) => Object.keys(value).every((key) => keys.includes(key));
var hasScope = (value) => (value.platform === "ios" || value.platform === "android") && isText(value.channel);
var isBundleFilter = (value, withKind = false) => {
	if (!isRecord$3(value) || !hasScope(value)) return false;
	const keys = [
		"platform",
		"channel",
		"type",
		...withKind ? ["kind"] : []
	];
	return value.type === "RECOVERED" ? isText(value.fromBundleId) && hasOnlyKeys(value, [...keys, "fromBundleId"]) : (value.type === "UPDATE_DOWNLOADED" || value.type === "UPDATE_APPLIED" || value.type === "UPDATE_FAILED" || value.type === "UNCHANGED") && isText(value.toBundleId) && hasOnlyKeys(value, [...keys, "toBundleId"]);
};
var isEventFilter = (value) => {
	if (!isRecord$3(value)) return false;
	if (value.kind === "all") return hasOnlyKeys(value, ["kind"]);
	if (value.kind === "installationMovement") return isIdentity(value.installId) && hasOnlyKeys(value, ["kind", "installId"]);
	return value.kind === "bundle" && isBundleFilter(value, true);
};
var validateRow = (model, row, result = false) => {
	try {
		validateBundleEventFields(row);
		if (!isRecord$3(row) || typeof row.id !== "string" || !isUUIDv7(row.id) || [...Object.values(row), ...isRecord$3(row.metadata) ? Object.values(row.metadata) : []].some((value) => typeof value === "string" && !isWellFormedText(value))) throw new DatabaseAdapterInputError("invalid-data");
	} catch (error) {
		if (result) throw new DatabaseAdapterInputError("invalid-result");
		throw error;
	}
};
/**
* Downloads, applies, recoveries, failed updates, and the UNCHANGED rows
* kept for a change belong in installation history.
*/
var isInsightsMovementEvent = (event) => event.type === "UPDATE_DOWNLOADED" || event.type === "UPDATE_APPLIED" || event.type === "RECOVERED" || event.type === "UPDATE_FAILED" || event.type === "UNCHANGED";
var matchesInsightsEventFilter = (event, filter) => {
	if (filter.kind === "all") return true;
	if (filter.kind === "installationMovement") return event.install_id === filter.installId && isInsightsMovementEvent(event);
	return event.type === filter.type && event.platform === filter.platform && event.channel === filter.channel && bundleRefsOf(event).includes(bundleRefOfFilter(filter));
};
var invalidQuery = () => {
	throw new DatabaseAdapterInputError("invalid-query");
};
var invalidResult = () => {
	throw new DatabaseAdapterInputError("invalid-result");
};
var validateCount = (count) => isTimestamp(count) ? count : invalidResult();
var isTimeRange = (value) => isRecord$3(value) && hasOnlyKeys(value, ["start", "end"]) && isTimestamp(value.start) && isTimestamp(value.end) && value.start < value.end;
var isReleaseReference = (value) => isRecord$3(value) && hasOnlyKeys(value, [
	"releaseId",
	"platform",
	"channel"
]) && isIdentity(value.releaseId) && hasScope(value);
var validateAggregateResult = (value) => {
	const result = isRecord$3(value) ? value : invalidResult();
	if (!isTimestamp(result.measuredAtMs)) invalidResult();
	const coverage = result.coverage;
	if (!isRecord$3(coverage) || coverage.kind !== "complete" && coverage.kind !== "partial" || coverage.sinceMs !== null && !isTimestamp(coverage.sinceMs)) invalidResult();
};
/** Validate custom and bundled providers at the same public boundary. */
var createValidatedInsightsModel = (model) => ({
	async recordEvent(input) {
		if (!isRecord$3(input) || !hasOnlyKeys(input, ["event"])) throw new DatabaseAdapterInputError("invalid-data");
		validateRow("bundle_events", input.event);
		await model.recordEvent(input);
	},
	async listEvents(input) {
		if (!isRecord$3(input) || !hasOnlyKeys(input, [
			"filter",
			"sinceMs",
			"beforeReceivedAtMs",
			"after",
			"limit"
		]) || !isEventFilter(input.filter) || !isLimit(input.limit) || !isTimestamp(input.beforeReceivedAtMs) || input.sinceMs !== void 0 && !isTimestamp(input.sinceMs)) invalidQuery();
		const sinceMs = input.sinceMs ?? 0;
		if (sinceMs > input.beforeReceivedAtMs || input.after !== void 0 && (!isRecord$3(input.after) || !hasOnlyKeys(input.after, ["receivedAtMs", "id"]) || !isTimestamp(input.after.receivedAtMs) || typeof input.after.id !== "string" || !isUUIDv7(input.after.id) || input.after.receivedAtMs < sinceMs || input.after.receivedAtMs >= input.beforeReceivedAtMs)) invalidQuery();
		const rows = await model.listEvents(input);
		if (!Array.isArray(rows) || rows.length > input.limit) invalidResult();
		let previous = input.after;
		for (const row of rows) {
			validateRow("bundle_events", row, true);
			if (row.received_at_ms < sinceMs || row.received_at_ms >= input.beforeReceivedAtMs || !matchesInsightsEventFilter(row, input.filter) || previous !== void 0 && (row.received_at_ms > previous.receivedAtMs || row.received_at_ms === previous.receivedAtMs && row.id >= previous.id)) invalidResult();
			previous = {
				receivedAtMs: row.received_at_ms,
				id: row.id
			};
		}
		return rows;
	},
	async findLatestEvents(input) {
		if (!isRecord$3(input)) invalidQuery();
		if ("installId" in input) {
			if (!hasOnlyKeys(input, ["installId"]) || !isIdentity(input.installId)) invalidQuery();
		} else if (!hasOnlyKeys(input, [
			"userId",
			"afterInstallId",
			"limit"
		]) || !isIdentity(input.userId) || !isLimit(input.limit) || input.afterInstallId !== void 0 && !isIdentity(input.afterInstallId)) invalidQuery();
		const rows = await model.findLatestEvents(input);
		if (!Array.isArray(rows) || rows.length > ("installId" in input ? 1 : input.limit)) invalidResult();
		let previous = "installId" in input ? void 0 : input.afterInstallId;
		for (const row of rows) {
			validateRow("bundle_events", row, true);
			if ("installId" in input ? row.install_id !== input.installId : row.user_id !== input.userId || previous !== void 0 && compareInsightsText(row.install_id, previous) <= 0) invalidResult();
			previous = row.install_id;
		}
		return rows;
	},
	async countLatestEvents(input) {
		if (!isRecord$3(input) || !hasOnlyKeys(input, [
			"platform",
			"channel",
			"sinceMs",
			"bundle"
		]) || !hasScope(input) || !isTimestamp(input.sinceMs) || input.bundle !== void 0 && (!Array.isArray(input.bundle) || input.bundle.length < 1 || input.bundle.length > 2 || input.bundle.some((bundle) => !isRecord$3(bundle) || !hasOnlyKeys(bundle, [
			"field",
			"value",
			"types"
		]) || bundle.field !== "from_bundle_id" && bundle.field !== "to_bundle_id" || !isText(bundle.value) || !Array.isArray(bundle.types) || bundle.types.length === 0 || bundle.types.some((type) => ![
			"UNCHANGED",
			"UPDATE_DOWNLOADED",
			"UPDATE_APPLIED",
			"RECOVERED"
		].includes(type))))) invalidQuery();
		return validateCount(await model.countLatestEvents(input));
	},
	async countEvents(input) {
		if (!isRecord$3(input) || !hasOnlyKeys(input, [
			"filter",
			"sinceMs",
			"beforeReceivedAtMs"
		]) || !isBundleFilter(input.filter) || !isTimestamp(input.sinceMs) || !isTimestamp(input.beforeReceivedAtMs) || input.sinceMs > input.beforeReceivedAtMs) invalidQuery();
		return validateCount(await model.countEvents(input));
	},
	async countEventSeries(input) {
		if (!isRecord$3(input) || !hasOnlyKeys(input, [
			"filter",
			"timeRange",
			"intervalMs"
		]) || !isBundleFilter(input.filter) || !isTimeRange(input.timeRange) || !isTimestamp(input.intervalMs)) invalidQuery();
		const { start, end } = input.timeRange;
		const { intervalMs } = input;
		if (intervalMs === 0 || intervalMs % 36e5 !== 0 || start % 36e5 !== 0 || (end - start) % intervalMs !== 0 || end - start > 7776e6) invalidQuery();
		const points = await model.countEventSeries(input);
		if (!Array.isArray(points) || points.length !== (end - start) / intervalMs || points.some((point, index) => !isRecord$3(point) || !hasOnlyKeys(point, ["startMs", "events"]) || point.startMs !== start + index * intervalMs || !isTimestamp(point.events))) invalidResult();
		return points;
	},
	async getReleaseActivity(input) {
		if (!isRecord$3(input) || !hasOnlyKeys(input, ["releases"]) || !Array.isArray(input.releases) || input.releases.length < 1 || input.releases.length > 100 || !input.releases.every(isReleaseReference)) invalidQuery();
		const result = await model.getReleaseActivity(input);
		if (!isRecord$3(result) || !isTimestamp(result.measuredAtMs) || !Array.isArray(result.data) || result.data.some((item) => !isRecord$3(item) || !isReleaseReference(item.release) || !isRecord$3(item.metrics) || !isTimestamp(item.metrics.downloads) || !isTimestamp(item.metrics.applies) || !isTimestamp(item.metrics.failedLaunches))) invalidResult();
		return result;
	},
	async getAppUsage(input) {
		if (!isRecord$3(input) || !hasOnlyKeys(input, [
			"channel",
			"platform",
			"appVersion",
			"timeRange",
			"intervalMs"
		]) || !isText(input.channel) || ![
			"all",
			"ios",
			"android"
		].includes(input.platform) || input.appVersion !== void 0 && !isText(input.appVersion) || !isTimeRange(input.timeRange) || !isTimestamp(input.intervalMs) || input.intervalMs < 36e5) invalidQuery();
		const result = await model.getAppUsage(input);
		validateAggregateResult(result);
		if (!isTimestamp(result.activeInstallations) || !Array.isArray(result.points) || !Array.isArray(result.appVersions) || !Array.isArray(result.versions) || !Array.isArray(result.platforms) || !Array.isArray(result.bundleDistribution)) invalidResult();
		return result;
	}
});
/**
* The plugin's API as `InsightsModel`, validated at its boundary: what the
* Insights routes, the console, and the e2e harness read through.
*/
var createInsightsModel = (api) => createValidatedInsightsModel({
	recordEvent: ({ event }) => api.recordEvent(event),
	listEvents: api.listEvents,
	findLatestEvents: api.findLatestEvents,
	countLatestEvents: api.countLatestEvents,
	countEvents: api.countEvents,
	countEventSeries: api.countEventSeries,
	getReleaseActivity: api.getReleaseActivity,
	getAppUsage: api.getAppUsage
});
/**
* What Insights' API throws for an input it refuses, such as an unknown
* event field or a malformed cursor; its routes answer 400 for it.
*/
var InsightsBadRequestError = class extends Error {
	name = "InsightsBadRequestError";
};
var MAX_EVENT_STRING_LENGTH = 1024;
var MAX_IDENTITY_LENGTH$1 = 255;
function isRecord$2(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function requireStringField(payload, key) {
	const value = payload[key];
	if (typeof value !== "string" || value.length === 0 || value.length > MAX_EVENT_STRING_LENGTH || new TextDecoder("utf-8", { ignoreBOM: true }).decode(new TextEncoder().encode(value)) !== value) throw new InsightsBadRequestError(`Invalid event field: ${key}`);
	return value;
}
function requireNullableStringField(payload, key) {
	if (payload[key] === null) return null;
	return requireStringField(payload, key);
}
function requireIdentityField(payload, key) {
	const value = requireStringField(payload, key);
	if (value.length > MAX_IDENTITY_LENGTH$1) throw new InsightsBadRequestError(`Invalid event field: ${key}`);
	return value;
}
/**
* The report's idempotency key, when the client sends one: it creates the
* UUIDv7 once and repeats it on every retry of that report.
*/
function readEventId(payload) {
	const value = payload.eventId;
	if (value === void 0) return void 0;
	if (!isUUIDv7(value)) throw new InsightsBadRequestError("Invalid event field: eventId");
	return value;
}
/**
* The native build's built-in bundle ID: a bundle ID's length at most, and
* left out when it is missing or malformed, so the report still records.
*/
var readMinBundleId = (value) => typeof value === "string" && value.length > 0 && value.length <= 36 ? value : null;
/** One value of an open set: any other value reads as `unknown`. */
var oneOf = (values, value) => values.includes(value) ? value : "unknown";
var STAGES = [
	"check",
	"download",
	"install"
];
var REASONS = [
	"network",
	"http",
	"invalid_response",
	"hash_mismatch",
	"signature",
	"patch",
	"extract",
	"storage"
];
var RESOURCES = [
	"catalog",
	"artifact",
	"manifest",
	"file",
	"patch",
	"archive"
];
var TRANSPORTS = [
	"timeout",
	"dns",
	"tls",
	"connection",
	"offline",
	"cancelled"
];
var DELIVERIES = [
	"patch",
	"manifest",
	"archive"
];
/** A storage error code: letters, digits, and `._-`. */
var CODE = /^[A-Za-z0-9._-]{1,64}$/;
var readCode = (value) => typeof value === "string" && CODE.test(value) ? value : void 0;
var readMetadata = (payload) => isRecord$2(payload.metadata) ? payload.metadata : {};
/**
* What an UPDATE_FAILED report says failed. It never refuses the report: an
* unknown value of a set reads as `unknown`, a missing or malformed failure
* as an unknown stage and reason, and a malformed optional field is left out,
* as is a null one.
*/
function readFailure(value) {
	const failure = isRecord$2(value) ? value : {};
	const httpStatus = failure.httpStatus;
	const originCode = readCode(failure.originCode);
	const errorMessage = typeof failure.errorMessage === "string" && failure.errorMessage.length <= 2048 ? failure.errorMessage : void 0;
	const errorStack = typeof failure.errorStack === "string" && failure.errorStack.length <= 4096 ? failure.errorStack : void 0;
	return {
		stage: oneOf(STAGES, failure.stage),
		reason: oneOf(REASONS, failure.reason),
		...failure.resource == null ? {} : { resource: oneOf(RESOURCES, failure.resource) },
		...Number.isSafeInteger(httpStatus) && httpStatus >= 100 && httpStatus <= 599 ? { httpStatus } : {},
		...failure.transport == null ? {} : { transport: oneOf(TRANSPORTS, failure.transport) },
		...originCode === void 0 ? {} : { originCode },
		...errorMessage === void 0 ? {} : { errorMessage },
		...errorStack === void 0 ? {} : { errorStack }
	};
}
function readHttpResponse(value) {
	if (!isRecord$2(value) || value.resource !== "catalog" && value.resource !== "artifact" || typeof value.path !== "string" || value.path.length > 1024 || !Number.isSafeInteger(value.status) || value.status < 100 || value.status > 599 || value.body !== null && (typeof value.body !== "string" || new TextEncoder().encode(JSON.stringify(value.body)).byteLength > 4096) || typeof value.bodyTruncated !== "boolean" || !Number.isSafeInteger(value.receivedAtMs) || value.receivedAtMs < 0) throw new InsightsBadRequestError("Invalid HTTP response details");
	return {
		resource: value.resource,
		path: value.path,
		status: value.status,
		body: value.body,
		bodyTruncated: value.bodyTruncated,
		receivedAtMs: value.receivedAtMs
	};
}
function requireEvent(payload) {
	if (!isRecord$2(payload)) throw new InsightsBadRequestError("Invalid event payload");
	const platform = requireStringField(payload, "platform");
	if (platform !== "ios" && platform !== "android") throw new InsightsBadRequestError("Invalid event field: platform");
	const eventId = readEventId(payload);
	const metadata = readMetadata(payload);
	const httpMetadata = metadata.httpResponse === void 0 ? {} : { httpResponse: readHttpResponse(metadata.httpResponse) };
	const base = {
		...metadata.httpResponse === void 0 ? {} : { metadata: httpMetadata },
		...eventId === void 0 ? {} : { eventId },
		installId: requireIdentityField(payload, "installId"),
		toBundleId: requireStringField(payload, "toBundleId"),
		...payload.userId === void 0 ? {} : { userId: requireIdentityField(payload, "userId") },
		platform,
		appVersion: requireStringField(payload, "appVersion"),
		channel: requireStringField(payload, "channel"),
		cohort: requireStringField(payload, "cohort"),
		fingerprintHash: requireNullableStringField(payload, "fingerprintHash"),
		sdkVersion: payload.sdkVersion === void 0 ? null : requireNullableStringField(payload, "sdkVersion"),
		minBundleId: readMinBundleId(payload.minBundleId),
		fromReleaseId: requireNullableStringField(payload, "fromReleaseId"),
		toReleaseId: requireNullableStringField(payload, "toReleaseId")
	};
	const type = requireStringField(payload, "type");
	const movement = () => {
		const updateStrategy = requireStringField(payload, "updateStrategy");
		if (updateStrategy !== "fingerprint" && updateStrategy !== "appVersion") throw new InsightsBadRequestError("Invalid event field: updateStrategy");
		return {
			...base,
			fromBundleId: requireStringField(payload, "fromBundleId"),
			updateStrategy
		};
	};
	switch (type) {
		case "UPDATE_DOWNLOADED": {
			const delivery = metadata.delivery;
			const read = {
				...httpMetadata,
				...delivery == null ? {} : { delivery: oneOf(DELIVERIES, delivery) },
				...metadata.patchFallback === true ? { patchFallback: true } : {}
			};
			return {
				...movement(),
				type,
				...Object.keys(read).length === 0 ? {} : { metadata: read }
			};
		}
		case "UPDATE_APPLIED":
		case "RECOVERED": return {
			...movement(),
			type
		};
		case "UPDATE_FAILED": return {
			...movement(),
			type,
			metadata: {
				...httpMetadata,
				failure: readFailure(metadata.failure)
			}
		};
		case "UNCHANGED":
			if (payload.fromBundleId !== null || payload.updateStrategy !== null) throw new InsightsBadRequestError("Invalid unchanged event shape");
			return {
				...base,
				type,
				fromBundleId: null,
				updateStrategy: null
			};
		default: throw new InsightsBadRequestError("Invalid event field: type");
	}
}
function createBundleEventRow(input) {
	input = requireEvent(input);
	const base = {
		app_version: input.appVersion,
		channel: input.channel,
		from_release_id: input.fromReleaseId,
		id: input.eventId ?? createUUIDv7(),
		install_id: input.installId,
		platform: input.platform,
		received_at_ms: Date.now(),
		to_bundle_id: input.toBundleId,
		to_release_id: input.toReleaseId,
		user_id: input.userId ?? null
	};
	const response = input.metadata?.httpResponse;
	const metadata = {
		...response ? { http_response: {
			resource: response.resource,
			path: response.path,
			status: response.status,
			body: response.body,
			body_truncated: response.bodyTruncated,
			received_at_ms: response.receivedAtMs
		} } : {},
		cohort: input.cohort,
		fingerprint_hash: input.fingerprintHash,
		sdk_version: input.sdkVersion ?? null,
		...input.minBundleId ? { min_bundle_id: input.minBundleId } : {},
		update_strategy: input.updateStrategy
	};
	switch (input.type) {
		case "UPDATE_DOWNLOADED": {
			const { delivery, patchFallback } = input.metadata ?? {};
			return {
				...base,
				from_bundle_id: input.fromBundleId,
				type: input.type,
				metadata: {
					...metadata,
					...delivery === void 0 ? {} : { delivery },
					...patchFallback ? { patch_fallback: true } : {}
				}
			};
		}
		case "UPDATE_APPLIED":
		case "RECOVERED": return {
			...base,
			from_bundle_id: input.fromBundleId,
			type: input.type,
			metadata
		};
		case "UPDATE_FAILED": {
			const { failure } = input.metadata;
			return {
				...base,
				from_bundle_id: input.fromBundleId,
				type: input.type,
				metadata: {
					...metadata,
					failure: {
						stage: failure.stage,
						reason: failure.reason,
						...failure.errorMessage === void 0 ? {} : { error_message: failure.errorMessage },
						...failure.errorStack === void 0 ? {} : { error_stack: failure.errorStack },
						...failure.resource === void 0 ? {} : { resource: failure.resource },
						...failure.httpStatus === void 0 ? {} : { http_status: failure.httpStatus },
						...failure.transport === void 0 ? {} : { transport: failure.transport },
						...failure.originCode === void 0 ? {} : { origin_code: failure.originCode }
					}
				}
			};
		}
		case "UNCHANGED": return {
			...base,
			from_bundle_id: null,
			type: input.type,
			metadata
		};
	}
}
var DEFAULT_PAGE_LIMIT = 50;
var MAX_PAGE_LIMIT = 100;
var MAX_EVENT_ID_LENGTH = 1024;
var MAX_IDENTITY_LENGTH = 255;
var MAX_CURSOR_LENGTH = 8192;
var HOUR_MS = 36e5;
var DAY_MS = 24 * HOUR_MS;
var WINDOW_MS = {
	"24h": 864e5,
	"7d": 6048e5,
	"30d": 2592e6
};
/**
* The longest receipt range, `[sinceMs, beforeReceivedAtMs)`, of a global or
* bundle event list, and the range one covers without `sinceMs`: raw events
* are listed inside a time range, as analytics products list them. It is a
* duration, so a range that ends mid-day touches 91 UTC days. Installation
* history is one index range and reads back to `sinceMs`.
*/
var EVENT_LIST_RANGE_MS = 2160 * HOUR_MS;
var isRecord$1 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var requireString = (value, label, maximumLength) => {
	if (typeof value !== "string" || value.length === 0 || value.length > maximumLength || new TextDecoder("utf-8", { ignoreBOM: true }).decode(new TextEncoder().encode(value)) !== value) throw new InsightsBadRequestError(`Invalid ${label}.`);
	return value;
};
var requireTimestamp = (value, label) => {
	if (!Number.isSafeInteger(value) || Number(value) < 0) throw new InsightsBadRequestError(`Invalid ${label}.`);
	return Number(value);
};
var readLimit = (value) => {
	const limit = value ?? DEFAULT_PAGE_LIMIT;
	if (!Number.isSafeInteger(limit) || limit < 1 || limit > MAX_PAGE_LIMIT) throw new InsightsBadRequestError("Invalid page limit.");
	return limit;
};
var encodeBase64Url = (value) => {
	const bytes = new TextEncoder().encode(value);
	let binary = "";
	for (const byte of bytes) binary += String.fromCharCode(byte);
	return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
};
var decodeBase64Url = (value) => {
	if (value.length === 0 || value.length > MAX_CURSOR_LENGTH) throw new InsightsBadRequestError("Invalid Insights cursor.");
	try {
		const base64 = value.replaceAll("-", "+").replaceAll("_", "/");
		const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, "=");
		const binary = atob(padded);
		const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
		return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
	} catch {
		throw new InsightsBadRequestError("Invalid Insights cursor.");
	}
};
var encodeCursor = (value) => encodeBase64Url(JSON.stringify(value));
var decodeCursor = (value) => {
	try {
		return JSON.parse(decodeBase64Url(value));
	} catch (error) {
		if (error instanceof InsightsBadRequestError) throw error;
		throw new InsightsBadRequestError("Invalid Insights cursor.");
	}
};
var readScope = (input) => {
	if (input.platform !== "ios" && input.platform !== "android") throw new InsightsBadRequestError("Invalid Insights platform.");
	return {
		platform: input.platform,
		channel: requireString(input.channel, "channel", MAX_EVENT_ID_LENGTH)
	};
};
var bundleFilter = (input) => {
	const scope = readScope(input);
	const bundleId = requireString(input.bundleId, "bundle ID", MAX_EVENT_ID_LENGTH);
	switch (input.outcome) {
		case "downloaded": return {
			...scope,
			type: "UPDATE_DOWNLOADED",
			toBundleId: bundleId
		};
		case "applied": return {
			...scope,
			type: "UPDATE_APPLIED",
			toBundleId: bundleId
		};
		case "recovered": return {
			...scope,
			type: "RECOVERED",
			fromBundleId: bundleId
		};
		case "failed": return {
			...scope,
			type: "UPDATE_FAILED",
			toBundleId: bundleId
		};
		default: throw new InsightsBadRequestError("Invalid Insights outcome.");
	}
};
var sameFilter = (left, right) => {
	if (!isRecord$1(left) || left.kind !== right.kind) return false;
	switch (right.kind) {
		case "all": return true;
		case "installationMovement": return left.installId === right.installId;
		case "bundle": return left.platform === right.platform && left.channel === right.channel && left.type === right.type && (right.type === "RECOVERED" ? left.fromBundleId === right.fromBundleId : left.toBundleId === right.toBundleId);
	}
};
var readEventCursor = (value, filter) => {
	const cursor = decodeCursor(value);
	if (!isRecord$1(cursor) || cursor.version !== 2 || cursor.kind !== "events" || !isRecord$1(cursor.filter) || !isRecord$1(cursor.after)) throw new InsightsBadRequestError("Invalid Insights cursor.");
	if (!sameFilter(cursor.filter, filter)) throw new InsightsBadRequestError("Insights cursor does not match the requested events.");
	if (typeof cursor.after.id !== "string" || !isUUIDv7(cursor.after.id)) throw new InsightsBadRequestError("Invalid Insights event cursor ID.");
	return {
		after: {
			id: cursor.after.id,
			receivedAtMs: requireTimestamp(cursor.after.receivedAtMs, "event cursor")
		},
		beforeReceivedAtMs: requireTimestamp(cursor.beforeReceivedAtMs, "event cutoff"),
		kind: "events",
		sinceMs: requireTimestamp(cursor.sinceMs, "event start"),
		filter,
		version: 2
	};
};
var readUserInstallationCursor = (value, userId) => {
	const cursor = decodeCursor(value);
	if (!isRecord$1(cursor) || cursor.version !== 1 || cursor.kind !== "user-installations" || cursor.userId !== userId) throw new InsightsBadRequestError("Insights cursor does not match the requested user ID.");
	return {
		afterInstallId: requireString(cursor.afterInstallId, "installation cursor", MAX_IDENTITY_LENGTH),
		kind: "user-installations",
		userId,
		version: 1
	};
};
var compareEventNewest = (left, right) => right.received_at_ms - left.received_at_ms || compareInsightsText(right.id, left.id);
var isAfterEventCursor = (row, after) => row.received_at_ms < after.receivedAtMs || row.received_at_ms === after.receivedAtMs && compareInsightsText(row.id, after.id) < 0;
var assertEventRows = (rows, input) => {
	if (rows.length > input.limit) throw new Error("Insights database returned too many event rows.");
	for (let index = 0; index < rows.length; index += 1) {
		const row = rows[index];
		const previous = rows[index - 1];
		if (!row || typeof row.id !== "string" || !isUUIDv7(row.id) || !Number.isSafeInteger(row.received_at_ms) || row.received_at_ms >= input.beforeReceivedAtMs || row.received_at_ms < input.sinceMs || previous !== void 0 && compareEventNewest(previous, row) >= 0 || input.after !== void 0 && !isAfterEventCursor(row, input.after) || input.filter.kind === "installationMovement" && (row.install_id !== input.filter.installId || !isInsightsMovementEvent(row)) || input.filter.kind === "bundle" && (row.platform !== input.filter.platform || row.channel !== input.filter.channel || row.type !== input.filter.type || (input.filter.type === "RECOVERED" ? row.from_bundle_id !== input.filter.fromBundleId : row.to_bundle_id !== input.filter.toBundleId))) throw new Error("Insights database returned invalid event rows.");
	}
};
/** An `UPDATE_FAILED` row's failure, as the event lists show it. */
var toFailure = (failure) => ({
	stage: failure.stage,
	reason: failure.reason,
	...failure.error_message === void 0 ? {} : { errorMessage: failure.error_message },
	...failure.error_stack === void 0 ? {} : { errorStack: failure.error_stack },
	...failure.resource === void 0 ? {} : { resource: failure.resource },
	...failure.http_status === void 0 ? {} : { httpStatus: failure.http_status },
	...failure.transport === void 0 ? {} : { transport: failure.transport },
	...failure.origin_code === void 0 ? {} : { originCode: failure.origin_code }
});
/** What a row's metadata adds for its type: a failure or a delivery. */
var eventDetails = ({ type, metadata }) => ({
	...metadata.http_response !== void 0 ? { httpResponse: {
		resource: metadata.http_response.resource,
		path: metadata.http_response.path,
		status: metadata.http_response.status,
		body: metadata.http_response.body,
		bodyTruncated: metadata.http_response.body_truncated,
		receivedAtMs: metadata.http_response.received_at_ms
	} } : {},
	...type === "UPDATE_FAILED" && metadata.failure !== void 0 ? { failure: toFailure(metadata.failure) } : {},
	...type === "UPDATE_DOWNLOADED" && metadata.delivery !== void 0 ? { delivery: metadata.delivery } : {},
	...type === "UPDATE_DOWNLOADED" && metadata.patch_fallback === true ? { patchFallback: true } : {},
	...type === "UNCHANGED" && metadata.change !== void 0 ? { change: {
		kinds: metadata.change.kinds,
		...metadata.change.previous === null ? {} : { previous: {
			bundleId: metadata.change.previous.bundle_id,
			releaseId: metadata.change.previous.release_id,
			appVersion: metadata.change.previous.app_version,
			channel: metadata.change.previous.channel,
			...metadata.change.previous.min_bundle_id === void 0 ? {} : { minBundleId: metadata.change.previous.min_bundle_id }
		} }
	} } : {},
	...metadata.late === true ? { late: true } : {},
	...metadata.implied_download === true ? { impliedDownload: true } : {}
});
var toEventHistoryRow = (row) => ({
	...row.to_release_id == null ? {} : { toReleaseId: row.to_release_id },
	...row.metadata.sdk_version == null ? {} : { sdkVersion: row.metadata.sdk_version },
	...row.metadata.min_bundle_id === void 0 ? {} : { minBundleId: row.metadata.min_bundle_id },
	appVersion: row.app_version,
	channel: row.channel,
	cohort: row.metadata.cohort,
	fromBundleId: row.from_bundle_id,
	id: row.id,
	installId: row.install_id,
	platform: row.platform,
	receivedAtMs: row.received_at_ms,
	toBundleId: row.to_bundle_id,
	type: row.type,
	userId: row.user_id,
	...eventDetails(row)
});
var toInstallationRow = (row) => ({
	...eventDetails(row).httpResponse ? { httpResponse: eventDetails(row).httpResponse } : {},
	...row.metadata.min_bundle_id === void 0 ? {} : { minBundleId: row.metadata.min_bundle_id },
	appVersion: row.app_version,
	channel: row.channel,
	cohort: row.metadata.cohort,
	installId: row.install_id,
	lastKnownBundleId: row.type === "UPDATE_DOWNLOADED" ? row.from_bundle_id : row.to_bundle_id,
	pendingBundleId: row.type === "UPDATE_DOWNLOADED" ? row.to_bundle_id : null,
	pendingReleaseId: row.type === "UPDATE_DOWNLOADED" ? row.to_release_id : null,
	latestStatus: row.type,
	platform: row.platform,
	receivedAtMs: row.received_at_ms,
	userId: row.user_id
});
/**
* Where a list without `sinceMs` starts: 90 days before its cutoff for the
* global and bundle lists, at the first event for installation history.
*/
var defaultEventStart = (filter, beforeReceivedAtMs) => filter.kind === "installationMovement" ? 0 : Math.max(0, beforeReceivedAtMs - EVENT_LIST_RANGE_MS);
/** Whether a cursor's row lies inside the list's range. */
var isInsideBounds = ({ after }, bounds) => after.receivedAtMs >= bounds.sinceMs && after.receivedAtMs < bounds.beforeReceivedAtMs;
/** A page's range: its cursor's, which the request may repeat but not change. */
var readEventBounds = (input, cursor, filter) => {
	const beforeReceivedAtMs = cursor?.beforeReceivedAtMs ?? (input.beforeReceivedAtMs === void 0 ? Date.now() : requireTimestamp(input.beforeReceivedAtMs, "event cutoff"));
	if (cursor !== void 0 && input.beforeReceivedAtMs !== void 0 && input.beforeReceivedAtMs !== beforeReceivedAtMs) throw new InsightsBadRequestError("Insights cursor does not match the requested event cutoff.");
	const sinceMs = cursor?.sinceMs ?? (input.sinceMs === void 0 ? defaultEventStart(filter, beforeReceivedAtMs) : requireTimestamp(input.sinceMs, "event start"));
	const bounds = {
		beforeReceivedAtMs,
		sinceMs
	};
	if (sinceMs > beforeReceivedAtMs || input.sinceMs !== void 0 && input.sinceMs !== sinceMs || cursor !== void 0 && !isInsideBounds(cursor, bounds)) throw new InsightsBadRequestError("Insights cursor or range does not match the requested event start.");
	if (filter.kind !== "installationMovement" && beforeReceivedAtMs - sinceMs > 7776e6) throw new InsightsBadRequestError("Insights event lists cover at most 90 days: send a sinceMs no more than 90 days before beforeReceivedAtMs.");
	return bounds;
};
var pageEventRows = async (model, input, filter, map) => {
	const limit = readLimit(input.limit);
	const cursor = input.cursor === void 0 ? void 0 : readEventCursor(input.cursor, filter);
	const bounds = readEventBounds(input, cursor, filter);
	const query = {
		filter,
		...bounds,
		...cursor === void 0 ? {} : { after: cursor.after },
		limit
	};
	const rows = await model.listEvents(query);
	assertEventRows(rows, query);
	const last = rows.at(-1);
	return {
		beforeReceivedAtMs: bounds.beforeReceivedAtMs,
		data: rows.map(map),
		nextCursor: rows.length === limit && last ? encodeCursor({
			after: {
				id: last.id,
				receivedAtMs: last.received_at_ms
			},
			...bounds,
			kind: "events",
			filter,
			version: 2
		}) : null
	};
};
var assertInstallationRows = (rows, input) => {
	if (rows.length > input.limit) throw new Error("Insights database returned too many installation rows.");
	for (let index = 0; index < rows.length; index += 1) {
		const row = rows[index];
		const previous = rows[index - 1];
		if (!row || row.user_id !== input.userId || input.afterInstallId !== void 0 && compareInsightsText(row.install_id, input.afterInstallId) <= 0 || previous !== void 0 && compareInsightsText(previous.install_id, row.install_id) >= 0) throw new Error("Insights database returned invalid installation rows.");
	}
};
var createInsightsProvider = (model) => Object.freeze({
	async appendBundleEvent(input) {
		const event = createBundleEventRow(input);
		await model.recordEvent({ event });
	},
	listEvents(input) {
		return pageEventRows(model, input, input.bundle === void 0 ? { kind: "all" } : {
			kind: "bundle",
			...bundleFilter(input.bundle)
		}, toEventHistoryRow);
	},
	async listInstallationEvents(input) {
		if ("bundle" in input && input.bundle !== void 0) throw new InsightsBadRequestError("Installation movement queries cannot include a bundle filter.");
		return pageEventRows(model, input, {
			kind: "installationMovement",
			installId: requireString(input.installId, "install ID", MAX_IDENTITY_LENGTH)
		}, (row) => toEventHistoryRow(row));
	},
	async getInstallation({ installId }) {
		const normalizedInstallId = requireString(installId, "install ID", MAX_IDENTITY_LENGTH);
		const rows = await model.findLatestEvents({ installId: normalizedInstallId });
		const row = rows[0] ?? null;
		if (rows.length > 1 || row !== null && row.install_id !== normalizedInstallId) throw new Error("Insights database returned an invalid installation.");
		return row === null ? null : toInstallationRow(row);
	},
	async pageInstallationsByCurrentUserId(input) {
		const userId = requireString(input.userId, "user ID", MAX_IDENTITY_LENGTH);
		const limit = readLimit(input.limit);
		const cursor = input.cursor === void 0 ? void 0 : readUserInstallationCursor(input.cursor, userId);
		const databaseInput = {
			userId,
			...cursor === void 0 ? {} : { afterInstallId: cursor.afterInstallId },
			limit
		};
		const rows = await model.findLatestEvents(databaseInput);
		assertInstallationRows(rows, databaseInput);
		const last = rows.at(-1);
		return {
			data: rows.map(toInstallationRow),
			nextCursor: rows.length === limit && last ? encodeCursor({
				afterInstallId: last.install_id,
				kind: "user-installations",
				userId,
				version: 1
			}) : null
		};
	},
	async getReportingOverview(input) {
		const scope = readScope(input);
		const { window } = input;
		if (!Object.hasOwn(WINDOW_MS, window)) throw new InsightsBadRequestError("Invalid reporting installation window.");
		const now = Date.now();
		const beforeReceivedAtMs = now - now % HOUR_MS + (now % HOUR_MS === 0 ? 0 : HOUR_MS);
		const reach = Math.max(0, beforeReceivedAtMs - WINDOW_MS[window]);
		const sinceMs = reach - reach % DAY_MS;
		const measure = async (count) => {
			const value = await count;
			if (!Number.isSafeInteger(value) || value < 0) throw new Error("Insights database returned an invalid count.");
			return {
				count: value,
				measuredAtMs: Date.now()
			};
		};
		const bundleId = input.bundleId === void 0 ? void 0 : requireString(input.bundleId, "bundle ID", MAX_EVENT_ID_LENGTH);
		const reporting = measure(model.countLatestEvents({
			...scope,
			sinceMs
		}));
		if (bundleId === void 0) return {
			...scope,
			window,
			sinceMs,
			beforeReceivedAtMs,
			reportingInstallations: await reporting
		};
		const countOutcome = (outcome) => measure(model.countEvents({
			filter: bundleFilter({
				...scope,
				bundleId,
				outcome
			}),
			sinceMs,
			beforeReceivedAtMs
		}));
		const [reportingInstallations, bundleInstallations, downloadedReports, appliedReports, recoveredReports, failedReports] = await Promise.all([
			reporting,
			measure(model.countLatestEvents({
				...scope,
				sinceMs,
				bundle: [{
					field: "from_bundle_id",
					value: bundleId,
					types: ["UPDATE_DOWNLOADED"]
				}, {
					field: "to_bundle_id",
					value: bundleId,
					types: [
						"UNCHANGED",
						"UPDATE_APPLIED",
						"RECOVERED"
					]
				}]
			})),
			countOutcome("downloaded"),
			countOutcome("applied"),
			countOutcome("recovered"),
			countOutcome("failed")
		]);
		return {
			...scope,
			window,
			sinceMs,
			beforeReceivedAtMs,
			reportingInstallations,
			bundle: {
				bundleId,
				reportingInstallations: bundleInstallations,
				downloadedReports,
				appliedReports,
				recoveredReports,
				failedReports
			}
		};
	}
});
30 * DAY_MS$1;
/** The reads over the `insights()` API tooling assembled on the server's database. */
var createInsightsReads = (api) => ({
	...createInsightsProvider(createInsightsModel(api)),
	getRetention: async () => api.retention,
	getUpdateFailures: api.getUpdateFailures
});
/** The `error` a failed admin route answered with, or a message naming its status. */
var errorOf = async (response, path) => {
	const body = await response.json().catch(() => null);
	return new Error(typeof body === "object" && body !== null && typeof Reflect.get(body, "error") === "string" ? String(Reflect.get(body, "error")) : `The server answered ${path.split("?")[0]} with ${response.status}.`);
};
var withQuery = (path, input) => {
	const query = new URLSearchParams();
	for (const [key, value] of Object.entries(input)) if (value !== void 0) query.set(key, String(value));
	const value = query.toString();
	return value.length === 0 ? path : `${path}?${value}`;
};
var eventQuery = ({ beforeReceivedAtMs, sinceMs, cursor, limit }) => ({
	beforeReceivedAtMs,
	sinceMs,
	cursor,
	limit
});
/**
* The reads over a self-hosted server's admin routes, which its `insights()`
* serves, for tooling that reaches it through `standaloneRepository`.
*/
var createInsightsAdminReads = (fetchAdmin, { unavailable = () => /* @__PURE__ */ new Error("The server runs without insights(): its admin API serves no Insights routes.") } = {}) => {
	const read = async (path) => {
		const response = await fetchAdmin(path);
		if (response.status === 404) return null;
		if (!response.ok) throw await errorOf(response, path);
		return await response.json();
	};
	const required = async (path) => {
		const value = await read(path);
		if (value === null) throw unavailable();
		return value;
	};
	return {
		getReportingOverview: ({ platform, channel, window, bundleId }) => required(withQuery("/overview", {
			platform,
			channel,
			window,
			bundleId
		})),
		listEvents: ({ bundle, ...input }) => required(withQuery("/events", {
			...eventQuery(input),
			...bundle === void 0 ? {} : {
				platform: bundle.platform,
				channel: bundle.channel,
				bundleId: bundle.bundleId,
				outcome: bundle.outcome
			}
		})),
		listInstallationEvents: ({ installId, ...input }) => required(withQuery(`/installations/${encodeURIComponent(installId)}/events`, eventQuery(input))),
		getInstallation: ({ installId }) => read(`/installations/${encodeURIComponent(installId)}`),
		pageInstallationsByCurrentUserId: ({ userId, cursor, limit }) => required(withQuery("/installations", {
			userId,
			cursor,
			limit
		})),
		getUpdateFailures: ({ platform, channel, releaseId, timeRange }) => required(withQuery("/failures", {
			platform,
			channel,
			releaseId,
			start: timeRange?.start,
			end: timeRange?.end
		})),
		getRetention: () => required("/retention")
	};
};
/**
* A record's own entry. Parameter keys and condition names come from users,
* so `constructor` or `__proto__` must name theirs, never Object.prototype's.
*/
var ownEntry = (record, key) => record !== void 0 && Object.prototype.hasOwnProperty.call(record, key) ? record[key] : void 0;
Object.freeze({
	conditions: Object.freeze([]),
	parameters: Object.freeze({})
});
/**
* A template's JSON stays under this many characters, so a device's values
* always fit the 64 KB a client plugin may store under one key.
*/
var REMOTE_CONFIG_MAX_TEMPLATE_LENGTH = 6e4;
var REMOTE_CONFIG_MAX_PARAMETERS = 2e3;
var MAX_RULE_VALUES = 100;
var MAX_DESCRIPTION_LENGTH = 256;
var MAX_CONDITION_NAME_LENGTH = 100;
var MAX_RULE_TEXT_LENGTH = 128;
var PARAMETER_KEY_PATTERN = /^[A-Za-z_][A-Za-z0-9_]{0,255}$/u;
var SEED_PATTERN = /^[A-Za-z0-9_-]{1,64}$/u;
/** A date-time with its time zone, so it names one instant. */
var DATE_TIME_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/u;
var VALUE_TYPES = /* @__PURE__ */ new Set([
	"STRING",
	"NUMBER",
	"BOOLEAN",
	"JSON"
]);
var PLATFORMS = /* @__PURE__ */ new Set(["ios", "android"]);
/** A template that cannot be published; `issues` lists every problem found. */
var RemoteConfigValidationError = class extends Error {
	issues;
	name = "RemoteConfigValidationError";
	constructor(issues) {
		super(`The Remote Config template is invalid: ${issues.slice(0, 3).map(({ path, message }) => path ? `${path}: ${message}` : message).join("; ")}${issues.length > 3 ? ` (and ${issues.length - 3} more)` : ""}`);
		this.issues = issues;
	}
};
var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var visibleText = (value, max) => typeof value === "string" && value.trim().length > 0 && value.length <= max && !/[\p{Cc}]/u.test(value);
/** Whether a value's text suits its type; the problem otherwise. */
var checkValueText = (valueType, text) => {
	switch (valueType) {
		case "NUMBER": return text.trim().length > 0 && Number.isFinite(Number(text)) ? null : "must be a number.";
		case "BOOLEAN": return text === "true" || text === "false" ? null : "must be \"true\" or \"false\".";
		case "JSON": try {
			JSON.parse(text);
			return null;
		} catch {
			return "must be valid JSON.";
		}
		default: return null;
	}
};
/**
* Checks a template and returns it with only its declared fields, or throws
* `RemoteConfigValidationError` with every problem it finds.
*/
var validateRemoteConfigTemplate = (input) => {
	const issues = [];
	const issue = (path, message) => {
		issues.push({
			path,
			message
		});
	};
	const unknownKeys = (value, allowed, path) => {
		for (const key of Object.keys(value)) if (!allowed.includes(key)) issue(path ? `${path}.${key}` : key, "is not a template field.");
	};
	if (!isRecord(input)) throw new RemoteConfigValidationError([{
		path: "",
		message: "A template is an object."
	}]);
	unknownKeys(input, ["conditions", "parameters"], "");
	const conditions = [];
	const conditionNames = /* @__PURE__ */ new Set();
	const rawConditions = input.conditions ?? [];
	if (!Array.isArray(rawConditions)) issue("conditions", "must be a list.");
	else {
		if (rawConditions.length > 500) issue("conditions", `holds at most 500 conditions.`);
		rawConditions.forEach((raw, index) => {
			const path = `conditions[${index}]`;
			if (!isRecord(raw)) {
				issue(path, "must be an object.");
				return;
			}
			unknownKeys(raw, ["name", "rules"], path);
			const { name } = raw;
			if (!visibleText(name, MAX_CONDITION_NAME_LENGTH)) issue(`${path}.name`, `must be 1-${MAX_CONDITION_NAME_LENGTH} visible characters.`);
			else if (conditionNames.has(name)) issue(`${path}.name`, `"${name}" names another condition too.`);
			else conditionNames.add(name);
			const rules = validateRules(raw.rules, `${path}.rules`, issue);
			if (typeof name === "string") conditions.push({
				name,
				rules
			});
		});
	}
	const parameters = [];
	const rawParameters = input.parameters ?? {};
	if (!isRecord(rawParameters)) issue("parameters", "must be an object keyed by parameter.");
	else {
		const keys = Object.keys(rawParameters);
		if (keys.length > 2e3) issue("parameters", `holds at most ${REMOTE_CONFIG_MAX_PARAMETERS} parameters.`);
		for (const key of keys) {
			const path = `parameters.${key}`;
			if (!PARAMETER_KEY_PATTERN.test(key)) issue(path, "Parameter keys start with a letter or _, and hold up to 256 letters, digits, and _.");
			const raw = rawParameters[key];
			if (!isRecord(raw)) {
				issue(path, "must be an object.");
				continue;
			}
			unknownKeys(raw, [
				"valueType",
				"defaultValue",
				"conditionalValues",
				"description"
			], path);
			const valueType = raw.valueType;
			if (typeof valueType !== "string" || !VALUE_TYPES.has(valueType)) {
				issue(`${path}.valueType`, "must be STRING, NUMBER, BOOLEAN, or JSON.");
				continue;
			}
			const type = valueType;
			const readValue = (value, valuePath) => {
				if (!isRecord(value)) {
					issue(valuePath, "must be { value } or { useInAppDefault: true }.");
					return null;
				}
				if ("useInAppDefault" in value) {
					unknownKeys(value, ["useInAppDefault"], valuePath);
					if (value.useInAppDefault !== true) {
						issue(`${valuePath}.useInAppDefault`, "must be true.");
						return null;
					}
					return { useInAppDefault: true };
				}
				unknownKeys(value, ["value"], valuePath);
				if (typeof value.value !== "string") {
					issue(`${valuePath}.value`, "must be text.");
					return null;
				}
				const problem = checkValueText(type, value.value);
				if (problem !== null) {
					issue(`${valuePath}.value`, problem);
					return null;
				}
				return { value: value.value };
			};
			const defaultValue = readValue(raw.defaultValue, `${path}.defaultValue`);
			const conditionalValues = [];
			if (raw.conditionalValues !== void 0) if (!isRecord(raw.conditionalValues)) issue(`${path}.conditionalValues`, "must be an object keyed by condition.");
			else for (const [conditionName, value] of Object.entries(raw.conditionalValues)) {
				const valuePath = `${path}.conditionalValues.${conditionName}`;
				if (!conditionNames.has(conditionName)) {
					issue(valuePath, `No condition is named "${conditionName}".`);
					continue;
				}
				const read = readValue(value, valuePath);
				if (read !== null) conditionalValues.push([conditionName, read]);
			}
			let description;
			if (raw.description !== void 0) {
				const text = typeof raw.description === "string" ? raw.description.trim() : null;
				if (text === null || text.length > MAX_DESCRIPTION_LENGTH) issue(`${path}.description`, `must be text of up to ${MAX_DESCRIPTION_LENGTH} characters.`);
				else if (text.length > 0) description = text;
			}
			if (defaultValue !== null) parameters.push([key, {
				valueType: type,
				defaultValue,
				...conditionalValues.length === 0 ? {} : { conditionalValues: Object.fromEntries(conditionalValues) },
				...description === void 0 ? {} : { description }
			}]);
		}
	}
	if (issues.length > 0) throw new RemoteConfigValidationError(issues);
	const template = {
		conditions,
		parameters: Object.fromEntries(parameters)
	};
	const length = JSON.stringify(template).length;
	if (length > 6e4) throw new RemoteConfigValidationError([{
		path: "",
		message: `The template takes ${length.toLocaleString("en-US")} characters of JSON; the limit is ${REMOTE_CONFIG_MAX_TEMPLATE_LENGTH.toLocaleString("en-US")}.`
	}]);
	return template;
};
var textList = (value, path, issue, check, describe) => {
	if (!Array.isArray(value) || value.length === 0 || value.length > MAX_RULE_VALUES) {
		issue(path, `must list 1-${MAX_RULE_VALUES} values.`);
		return [];
	}
	const list = [];
	value.forEach((entry, index) => {
		if (typeof entry !== "string" || !check(entry)) issue(`${path}[${index}]`, describe);
		else if (!list.includes(entry)) list.push(entry);
	});
	return list;
};
var RULE_FIELDS = {
	platform: ["type", "platforms"],
	channel: ["type", "channels"],
	appVersion: ["type", "range"],
	cohort: ["type", "cohorts"],
	percent: [
		"type",
		"seed",
		"from",
		"to"
	],
	fingerprint: ["type", "hashes"],
	dateTime: [
		"type",
		"from",
		"to"
	]
};
var validateRules = (value, path, issue) => {
	if (!Array.isArray(value) || value.length === 0) {
		issue(path, "must list at least one rule.");
		return [];
	}
	const rules = [];
	value.forEach((raw, index) => {
		const rulePath = `${path}[${index}]`;
		if (!isRecord(raw) || typeof raw.type !== "string") {
			issue(rulePath, "must be a rule object with a type.");
			return;
		}
		const type = raw.type;
		const fields = ownEntry(RULE_FIELDS, type);
		if (fields === void 0) {
			issue(`${rulePath}.type`, "must be platform, channel, appVersion, cohort, percent, fingerprint, or dateTime.");
			return;
		}
		for (const key of Object.keys(raw)) if (!fields.includes(key)) issue(`${rulePath}.${key}`, `is not a field of a ${type} rule.`);
		switch (type) {
			case "platform": {
				const platforms = textList(raw.platforms, `${rulePath}.platforms`, issue, (text) => PLATFORMS.has(text), "must be \"ios\" or \"android\".");
				rules.push({
					type,
					platforms
				});
				return;
			}
			case "channel": {
				const channels = textList(raw.channels, `${rulePath}.channels`, issue, (text) => visibleText(text, MAX_RULE_TEXT_LENGTH), `must be a channel name of 1-${MAX_RULE_TEXT_LENGTH} characters.`);
				rules.push({
					type,
					channels
				});
				return;
			}
			case "appVersion": {
				const range = raw.range;
				if (!visibleText(range, MAX_RULE_TEXT_LENGTH) || !isValidRange(range.trim())) {
					issue(`${rulePath}.range`, "must be a semver range, such as >=1.4.0 or 2.x.");
					return;
				}
				rules.push({
					type,
					range: range.trim()
				});
				return;
			}
			case "cohort": {
				const cohorts = textList(raw.cohorts, `${rulePath}.cohorts`, issue, isValidCohort, "must be a cohort from 1 to 1000, or a lowercase slug.").map(normalizeCohortValue);
				rules.push({
					type,
					cohorts: [...new Set(cohorts)]
				});
				return;
			}
			case "percent": {
				const { seed, from, to } = raw;
				if (typeof seed !== "string" || !SEED_PATTERN.test(seed)) {
					issue(`${rulePath}.seed`, "must be 1-64 letters, digits, _, and -.");
					return;
				}
				const isPercent = (value) => typeof value === "number" && value >= 0 && value <= 100 && Math.abs(value * 10 - Math.round(value * 10)) < 1e-9;
				if (!isPercent(from) || !isPercent(to) || from >= to) {
					issue(rulePath, "takes from < to, each a percentage from 0 to 100 in steps of 0.1.");
					return;
				}
				rules.push({
					type,
					seed,
					from,
					to
				});
				return;
			}
			case "fingerprint": {
				const hashes = textList(raw.hashes, `${rulePath}.hashes`, issue, (text) => visibleText(text, MAX_RULE_TEXT_LENGTH), `must be a fingerprint of 1-${MAX_RULE_TEXT_LENGTH} characters.`);
				rules.push({
					type,
					hashes
				});
				return;
			}
			case "dateTime": {
				const instant = (field) => {
					const value = raw[field];
					if (value === void 0) return void 0;
					const ms = typeof value === "string" ? Date.parse(value) : NaN;
					if (typeof value !== "string" || !DATE_TIME_PATTERN.test(value) || !Number.isFinite(ms)) {
						issue(`${rulePath}.${field}`, "must be an ISO 8601 date-time with a time zone, such as 2026-10-08T10:00:00Z.");
						return null;
					}
					return new Date(ms).toISOString();
				};
				const from = instant("from");
				const to = instant("to");
				if (from === null || to === null) return;
				if (from === void 0 && to === void 0) {
					issue(rulePath, "takes from, to, or both.");
					return;
				}
				if (from !== void 0 && to !== void 0 && from >= to) {
					issue(rulePath, "takes a from before its to.");
					return;
				}
				rules.push({
					type,
					...from === void 0 ? {} : { from },
					...to === void 0 ? {} : { to }
				});
				return;
			}
		}
	});
	return rules;
};
/** Whether one rule matches a device. */
var matchesRemoteConfigRule = (rule, context) => {
	switch (rule.type) {
		case "platform": return context.platform !== void 0 && context.platform !== null && rule.platforms.includes(context.platform);
		case "channel": return typeof context.channel === "string" && rule.channels.includes(context.channel);
		case "appVersion": return typeof context.appVersion === "string" && semverSatisfies(rule.range, context.appVersion);
		case "cohort": return typeof context.cohort === "string" && rule.cohorts.includes(normalizeCohortValue(context.cohort));
		case "percent": {
			if (typeof context.cohort !== "string") return false;
			const cohort = getNumericCohortValue(context.cohort);
			if (cohort === null) return false;
			const position = getNumericCohortRolloutPosition(rule.seed, cohort);
			return position >= Math.round(rule.from * 10) && position < Math.round(rule.to * 10);
		}
		case "fingerprint": return typeof context.fingerprintHash === "string" && rule.hashes.includes(context.fingerprintHash);
		case "dateTime": return typeof context.now === "number" && (rule.from === void 0 || context.now >= Date.parse(rule.from)) && (rule.to === void 0 || context.now < Date.parse(rule.to));
	}
};
/** Whether every rule of a condition matches a device. */
var matchesRemoteConfigCondition = (condition, context) => condition.rules.every((rule) => matchesRemoteConfigRule(rule, context));
/**
* Every parameter's value for one device: the value of the first condition,
* in the template's order, that matches and that the parameter has a value
* for; otherwise its default value.
*/
var evaluateRemoteConfig = (template, context) => {
	const matched = template.conditions.filter((condition) => matchesRemoteConfigCondition(condition, context)).map(({ name }) => name);
	return Object.fromEntries(Object.entries(template.parameters).map(([key, parameter]) => {
		let condition = null;
		let chosen = parameter.defaultValue;
		for (const name of matched) {
			const value = ownEntry(parameter.conditionalValues, name);
			if (value !== void 0) {
				condition = name;
				chosen = value;
				break;
			}
		}
		return [key, {
			value: "value" in chosen ? chosen.value : null,
			condition
		}];
	}));
};
defineTable({
	id: {
		type: "string",
		maxLength: 16
	},
	version: { type: "integer" },
	template: { type: "json" },
	updated_at_ms: { type: "integer" }
}, { key: ["id"] }), defineTable({
	version: { type: "integer" },
	template: { type: "json" },
	description: {
		type: "string",
		maxLength: 256,
		required: false
	},
	update_type: {
		type: "string",
		maxLength: 16
	},
	rollback_source: {
		type: "integer",
		required: false
	},
	created_at_ms: { type: "integer" }
}, {
	key: ["version"],
	indexes: { byVersion: {
		eq: [],
		sort: ["version"]
	} }
});
var readBody = async (response) => response.json().catch(() => null);
var field = (body, name) => typeof body === "object" && body !== null ? Reflect.get(body, name) : void 0;
/** A published version's record, as a publish or a rollback answers it. */
var isPublishedVersion = (body) => {
	const version = field(body, "version");
	const updateType = field(body, "updateType");
	return typeof version === "number" && Number.isSafeInteger(version) && version > 0 && (updateType === "PUBLISH" || updateType === "ROLLBACK") && typeof field(body, "createdAtMs") === "number";
};
var errorText = (body) => {
	const error = field(body, "error");
	return typeof error === "string" ? error : void 0;
};
/**
* Remote Config over a self-hosted server's admin routes, for tooling that
* reaches it through `standaloneRepository`. It answers as the API does: an
* invalid template throws `RemoteConfigValidationError` with the server's
* issues.
*/
var createRemoteConfigAdminApi = (fetchAdmin, { unavailable = () => /* @__PURE__ */ new Error("The server runs without remoteConfig(): its admin API serves no Remote Config routes.") } = {}) => {
	const request = async (path, init) => {
		const response = await fetchAdmin(path, init === void 0 ? void 0 : {
			method: init.method,
			headers: { "content-type": "application/json" },
			body: JSON.stringify(init.body)
		});
		const body = await readBody(response);
		if (response.status === 404 && errorText(body) === "Not found") throw unavailable();
		return {
			status: response.status,
			body
		};
	};
	const expectOk = (path, { status, body }) => {
		if (status >= 200 && status < 300) return body;
		throw new Error(errorText(body) ?? `The server answered ${path.split("?")[0]} with ${status}.`);
	};
	const published = (path, result) => {
		const currentVersion = field(result.body, "currentVersion");
		if (result.status === 409 && typeof currentVersion === "number" && Number.isSafeInteger(currentVersion)) return {
			status: "conflict",
			currentVersion
		};
		const issues = field(result.body, "issues");
		if (result.status === 400 && Array.isArray(issues)) throw new RemoteConfigValidationError(issues);
		const version = expectOk(path, result);
		if (!isPublishedVersion(version)) throw new Error(`The server answered ${path} without the version it published.`);
		return {
			status: "published",
			version
		};
	};
	return {
		getActive: async () => {
			const path = "/remote-config/template";
			return expectOk(path, await request(path));
		},
		listVersions: async ({ limit, cursor } = {}) => {
			const query = new URLSearchParams();
			if (limit !== void 0) query.set("limit", String(limit));
			if (cursor !== void 0) query.set("cursor", cursor);
			const path = `/remote-config/versions${query.size === 0 ? "" : `?${query}`}`;
			return expectOk(path, await request(path));
		},
		getVersion: async (version) => {
			const path = `/remote-config/versions/${version}`;
			const result = await request(path);
			return result.status === 404 ? null : expectOk(path, result);
		},
		publish: async ({ template, baseVersion, description }) => {
			const path = "/remote-config/template";
			return published(path, await request(path, {
				method: "PUT",
				body: {
					template,
					baseVersion,
					description
				}
			}));
		},
		rollback: async ({ version, baseVersion, description }) => {
			const path = `/remote-config/versions/${version}/rollback`;
			const result = await request(path, {
				method: "POST",
				body: {
					baseVersion,
					description
				}
			});
			return result.status === 404 ? { status: "not_found" } : published(path, result);
		}
	};
};
var plugins_exports = /* @__PURE__ */ __exportAll({
	API_KEY_HEADER_NAME: () => API_KEY_HEADER_NAME,
	REMOTE_CONFIG_MAX_CONDITIONS: () => 500,
	REMOTE_CONFIG_MAX_PARAMETERS: () => REMOTE_CONFIG_MAX_PARAMETERS,
	REMOTE_CONFIG_MAX_TEMPLATE_LENGTH: () => REMOTE_CONFIG_MAX_TEMPLATE_LENGTH,
	RemoteConfigValidationError: () => RemoteConfigValidationError,
	evaluateRemoteConfig: () => evaluateRemoteConfig,
	validateRemoteConfigTemplate: () => validateRemoteConfigTemplate
});
//#endregion
export { createInsightsReads as a, createInsightsAdminReads as i, createRemoteConfigAdminApi as n, createInsightsModel as o, RemoteConfigValidationError as r, plugins_exports as t };
