import { r as recoveryWindows } from "./insights-recovery-Cdg3Msrj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/release-adoption-gfhE5tz5.js
/** A crash rate at which Release health recommends rolling a bundle back. */
var CRASH_RATE_THRESHOLD = .05;
var HOUR_MS = 36e5;
var isText = (value) => typeof value === "string" && value.trim().length > 0 && value.length <= 1024;
var invalid = () => {
	throw new Error("Choose a platform, channel, period, and bundle.");
};
function readAdoptionReleasesInput(input) {
	if (!input || input.platform !== "all" && input.platform !== "ios" && input.platform !== "android" || !isText(input.channel)) invalid();
	return {
		platform: input.platform,
		channel: input.channel
	};
}
function readAdoptionReleaseInput(input) {
	const scope = readAdoptionReleasesInput(input);
	if (!isText(input.releaseId) || input.withPrevious !== void 0 && typeof input.withPrevious !== "boolean") invalid();
	return {
		...scope,
		releaseId: input.releaseId,
		...input.withPrevious ? { withPrevious: true } : {}
	};
}
function readBundleEventsInput(input) {
	const { platform, channel } = readAdoptionReleasesInput(input);
	if (platform === "all" || !Object.hasOwn(recoveryWindows, input.window) || typeof input.endMs !== "number" || !Number.isSafeInteger(input.endMs) || input.endMs <= 0 || input.endMs % HOUR_MS !== 0 || !isText(input.bundleId) || input.type !== "DOWNLOADED" && input.type !== "LAUNCHED" && input.type !== "RECOVERED") invalid();
	return {
		platform,
		channel,
		window: input.window,
		endMs: input.endMs,
		bundleId: input.bundleId,
		type: input.type
	};
}
/**
* Of the installations that tried a bundle, the share whose launch crashed
* and rolled back: one that crashes never reports a launch, so attempts
* count both.
*/
var crashRateOf = (launched, recovered) => {
	const attempts = launched + recovered;
	return {
		attempts,
		rate: attempts === 0 ? 0 : recovered / attempts
	};
};
/**
* The bundles Release health compares when none are chosen, from the
* candidates newest first: the two newest live bundles of one platform, or
* the newest live one of each; without any live one, the newest two.
*/
var defaultAdoptionReleases = (candidates, platform) => {
	const live = (platform === "all" ? ["ios", "android"] : [platform]).flatMap((each) => candidates.filter((release) => release.platform === each && release.live).slice(0, platform === "all" ? 1 : 2));
	return (live.length > 0 ? live : candidates).slice(0, 2).map((release) => release.releaseId);
};
/** Whether a bundle's crashes call for rolling it back. */
var recommendsRollback = (release, launched, recovered) => {
	const { attempts, rate } = crashRateOf(launched, recovered);
	return release.enabled && attempts >= 20 && rate >= .05;
};
//#endregion
export { readAdoptionReleasesInput as a, readAdoptionReleaseInput as i, crashRateOf as n, readBundleEventsInput as o, defaultAdoptionReleases as r, recommendsRollback as s, CRASH_RATE_THRESHOLD as t };
