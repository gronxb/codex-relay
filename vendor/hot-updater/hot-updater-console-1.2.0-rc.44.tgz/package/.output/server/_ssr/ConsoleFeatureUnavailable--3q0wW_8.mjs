import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { nt as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { O as buttonVariants, S as SidebarTrigger } from "./sidebar-COdOWPGC.mjs";
import { a as unavailableReason, n as consoleFeatures } from "./console-features-DTYyXrWO.mjs";
import { a as useConsoleFeatures, n as notFoundFeature } from "./console-features-api-DbEAU6JB.mjs";
import { t as NotFoundPage } from "./NotFoundPage-BZK0yis5.mjs";
import { i as EmptyHeader, n as EmptyContent, o as EmptyTitle, r as EmptyDescription, t as Empty } from "./empty-qtSrrSOA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ConsoleFeatureUnavailable--3q0wW_8.js
var import_jsx_runtime = require_jsx_runtime();
var CONSOLE_DEPLOYMENT_GUIDE_URL = "https://hot-updater.dev/docs/guides/console-deployment";
/**
* A feature route's not-found state: the plugin to add, or, for a feature a
* self-hosted server does not serve, the database config it needs.
*/
function ConsoleFeatureUnavailable({ data }) {
	const feature = notFoundFeature(data);
	const remote = useConsoleFeatures().data?.remote === true;
	if (feature === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotFoundPage, {});
	const { label, plugin } = consoleFeatures[feature];
	const pluginCall = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
		className: "font-mono",
		children: `${plugin}()`
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-10 flex shrink-0 items-center gap-3 border-b bg-background px-3 py-3 sm:min-h-12 sm:bg-card/70 sm:px-4 sm:backdrop-blur-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-sm font-medium",
				children: label
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-h-0 min-w-0 flex-1 overflow-y-auto bg-muted/5 p-3 sm:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyHeader, { children: unavailableReason(feature, { remote }) === "remote" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "Needs the server's database" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: "This console reaches a self-hosted server through its admin API, which does not serve this page. Configure the console with the database the server uses." })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyTitle, { children: [label, " not installed"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyDescription, { children: [
				"Add ",
				pluginCall,
				" to ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
					className: "font-mono",
					children: "plugins"
				}),
				" ",
				"where you create the server and in the console config."
			] })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: buttonVariants({ variant: "outline" }),
				href: CONSOLE_DEPLOYMENT_GUIDE_URL,
				rel: "noreferrer",
				target: "_blank",
				children: ["Console setup guide", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
					"aria-hidden": "true",
					"data-icon": "inline-end"
				})]
			}) })] })
		})]
	});
}
//#endregion
export { ConsoleFeatureUnavailable as t };
