import { i as __toESM } from "../_runtime.mjs";
import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { i as TriangleAlert } from "../_libs/lucide-react.mjs";
import { k as cn } from "./sidebar-COdOWPGC.mjs";
import { a as Badge } from "./badge-o8QNRxtw.mjs";
import { r as extractTimestampFromUUIDv7 } from "./uuidv7-C0jNe2Om.mjs";
import { n as require_dayjs_min, t as require_relativeTime } from "../_libs/dayjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RolloutPercentageBadge-XfgBi8FV.js
var import_jsx_runtime = require_jsx_runtime();
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
var import_relativeTime = /* @__PURE__ */ __toESM(require_relativeTime());
import_dayjs_min.default.extend(import_relativeTime.default);
function TimestampDisplay({ uuid, format = "relative" }) {
	const date = (0, import_dayjs_min.default)(extractTimestampFromUUIDv7(uuid));
	if (format === "relative") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-sm text-muted-foreground",
		children: date.fromNow()
	});
	if (format === "absolute") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-sm text-muted-foreground",
		children: date.format("YYYY-MM-DD HH:mm:ss")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm",
			children: date.fromNow()
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground",
			children: date.format("YYYY-MM-DD HH:mm:ss")
		})]
	});
}
var normalizeGitUrl = (gitUrl) => {
	const trimmedGitUrl = gitUrl.trim();
	if (trimmedGitUrl.startsWith("git@")) {
		const sshMatch = trimmedGitUrl.match(/^git@([^:]+):(.+?)(?:\.git)?$/);
		if (sshMatch) return `https://${sshMatch[1]}/${sshMatch[2]}`;
	}
	if (trimmedGitUrl.startsWith("ssh://")) try {
		const url = new URL(trimmedGitUrl);
		return `https://${url.hostname}${url.pathname}`.replace(/\/+$/, "").replace(/\.git$/, "");
	} catch {
		return trimmedGitUrl.replace(/\/+$/, "").replace(/\.git$/, "");
	}
	return trimmedGitUrl.replace(/\/+$/, "").replace(/\.git$/, "");
};
var getCommitUrl = (gitUrl, commitHash) => {
	if (!gitUrl?.trim()) return null;
	const normalizedGitUrl = normalizeGitUrl(gitUrl);
	try {
		const { hostname } = new URL(normalizedGitUrl);
		if (hostname.includes("gitlab")) return `${normalizedGitUrl}/-/commit/${commitHash}`;
		if (hostname.includes("bitbucket")) return `${normalizedGitUrl}/commits/${commitHash}`;
	} catch {}
	return `${normalizedGitUrl}/commit/${commitHash}`;
};
function RolloutPercentageBadge({ percentage, className }) {
	const isPartialRollout = percentage < 100;
	const formattedPercentage = percentage.toFixed(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
		className: cn("gap-1", className),
		variant: isPartialRollout ? "secondary" : "default",
		children: [
			isPartialRollout ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-3 w-3" }) : null,
			formattedPercentage,
			"%"
		]
	});
}
//#endregion
export { TimestampDisplay as n, getCommitUrl as r, RolloutPercentageBadge as t };
