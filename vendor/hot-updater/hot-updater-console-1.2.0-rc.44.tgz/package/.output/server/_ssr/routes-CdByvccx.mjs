import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { $ as ChartLine, Q as ChartNoAxesCombined, d as SlidersHorizontal, k as KeyRound } from "../_libs/lucide-react.mjs";
import { A as createSsrRpc, C as Skeleton, O as buttonVariants, k as cn, r as Separator$1 } from "./sidebar-COdOWPGC.mjs";
import { a as CardHeader, i as CardFooter, n as CardContent, o as CardTitle, t as Card } from "./card-CsUxqR3-.mjs";
import { i as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as consoleFeatures } from "./console-features-DTYyXrWO.mjs";
import { f as lazyRouteComponent, h as Link, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useConsoleFeatures, i as useConsoleFeature } from "./console-features-api-DbEAU6JB.mjs";
import { n as readRecoveryInput } from "./insights-recovery-Cdg3Msrj.mjs";
import { i as failureRate, s as formatRate } from "./insights-failures-DGO2_3Vx.mjs";
import { n as adoptionWindow, t as InfoTooltip } from "./insights-search-BZ00lACC.mjs";
import { u as useUpdateFailuresQuery } from "./insights-api-DGzoZoEY.mjs";
import { n as DEFAULT_CHANNEL } from "./constants-BjsJZqaU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CdByvccx.js
var import_jsx_runtime = require_jsx_runtime();
/** What API key management adds: its navigation item. */
var apiKeysFeatureUi = { apiKeys: { navigation: {
	icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {}),
	paths: ["/api-keys"],
	link: ({ onClick }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/api-keys",
		onClick
	})
} } };
function readBundleActivityInput(inputs) {
	if (!Array.isArray(inputs) || inputs.length > 20) throw new Error("Choose up to 20 bundles.");
	return inputs.map((input) => {
		readRecoveryInput({
			...input,
			window: "30d"
		});
		if (!input.releaseId) throw new Error("Choose a bundle ID.");
		return input;
	});
}
var getBundleActivityRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readBundleActivityInput).handler(createSsrRpc("b4bf4c461903edcdc44eea52468c737b5b600a586f542138ff022dcbbe86c45c"));
/** Release activity for bundle rows; mounted only where the console reads it. */
function useBundleActivityQuery(inputs) {
	const sorted = inputs.map(({ releaseId, platform, channel }) => ({
		releaseId,
		platform,
		channel
	})).sort((a, b) => a.releaseId.localeCompare(b.releaseId));
	return useQuery({
		queryKey: ["bundle-activity", sorted],
		queryFn: () => getBundleActivityRpc({ data: sorted }),
		enabled: sorted.length > 0,
		staleTime: 3e4
	});
}
var activityStats = [
	{
		label: "Downloaded",
		field: "downloads",
		color: "text-primary/85"
	},
	{
		label: "Launched",
		field: "launched",
		color: "text-success/85"
	},
	{
		label: "Crashed",
		field: "failedLaunches",
		color: "text-warning/85"
	}
];
var crashRate = (report) => {
	const attempts = report.launched + report.failedLaunches;
	return attempts === 0 ? "—" : `${(report.failedLaunches / attempts * 100).toFixed(2)}%`;
};
/** Downloads that neither launched nor crashed yet: waiting for a restart, or passed over for a newer bundle. */
var notLaunched = (report) => Math.max(0, report.downloads - report.launched - report.failedLaunches);
function ReleaseMetricsInfo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTooltip, {
		label: "About release insight metrics",
		children: "Downloaded: got this bundle. Launched: ran it. Crashed: crashed on it and rolled back. Once every installation restarts, Downloaded = Launched + Crashed."
	});
}
function BundleMovementSummary({ report, loading = false, input, variant = "inline" }) {
	if (!report) return loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
		"aria-label": "Loading release insights",
		className: variant === "card" ? "h-16 w-full" : "h-4 w-40"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"aria-label": "Release insights unavailable",
		className: "text-sm text-muted-foreground",
		children: "—"
	});
	const builtIn = input?.builtIn === true;
	const waiting = builtIn ? 0 : notLaunched(report);
	const metrics = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
		className: cn(variant === "card" ? "grid grid-cols-[1fr_1fr_auto] gap-4" : "flex min-w-[220px] flex-wrap items-baseline gap-x-3 gap-y-1"),
		children: activityStats.map(({ label, field, color }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("flex", variant === "card" ? "min-w-0 flex-col gap-1" : "items-baseline gap-1.5 whitespace-nowrap"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-xs text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
				className: cn("flex flex-wrap items-baseline gap-x-1.5 tabular-nums", variant === "card" ? "text-xl font-semibold" : "text-sm font-medium", report[field] > 0 && !(field === "downloads" && builtIn) ? color : "text-muted-foreground"),
				children: [field === "downloads" && builtIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					title: "The built-in bundle is never downloaded",
					children: "—"
				}) : report[field].toLocaleString(), field === "failedLaunches" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs font-normal text-muted-foreground",
					children: [
						"(",
						crashRate(report),
						")"
					]
				}) : null]
			})]
		}, field))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex", variant === "card" ? "flex-col gap-2" : "items-center gap-1"),
		children: [
			input ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				className: "relative min-w-0 rounded-sm after:absolute after:inset-x-0 after:-inset-y-3 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:after:hidden",
				to: "/insights",
				search: {
					platform: input.platform,
					channel: input.channel,
					releaseId: input.releaseId,
					bundleWindow: adoptionWindow(input.releaseId)
				},
				children: metrics
			}) : metrics,
			variant === "card" && waiting > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [waiting.toLocaleString(), " downloaded but not launched yet: waiting for a restart, or passed over for a newer bundle."]
			}) : null,
			variant === "inline" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseMetricsInfo, {}) : null
		]
	});
}
/** The release's failed downloads and installs since its first report, and their rate. */
function BundleDownloadFailures({ input }) {
	const query = useUpdateFailuresQuery({
		platform: input.platform,
		channel: input.channel,
		releaseId: input.releaseId
	});
	const report = query.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-1",
		children: [report ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-baseline gap-x-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-xs text-muted-foreground",
				children: "Download failures"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
				className: cn("flex items-baseline gap-1.5 text-sm font-medium tabular-nums", report.failedUpdates > 0 ? "text-warning/85" : "text-muted-foreground"),
				children: [report.failedUpdates.toLocaleString(), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs font-normal text-muted-foreground",
					children: [
						"(",
						formatRate(failureRate(report)),
						")"
					]
				})]
			})]
		}) }) : query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			"aria-label": "Loading download failures",
			className: "h-4 w-40"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-label": "Download failures unavailable",
			className: "text-sm text-muted-foreground",
			children: "—"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTooltip, {
			label: "About download failures",
			children: "Failed downloads or installs of this bundle, at most one per installation a day. Rate = failures ÷ (failures + downloads)."
		})]
	});
}
/** The bundle detail's Insights card, a section of the release editor: activity and download failures. */
function BundleInsightsSummary({ input }) {
	const query = useBundleActivityQuery([input]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
			className: "flex-row items-center justify-between px-4 pt-4 pb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-sm font-medium",
				children: "Insights"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseMetricsInfo, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "flex flex-col gap-3 px-4 pb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleMovementSummary, {
					variant: "card",
					input,
					loading: query.isFetching,
					report: query.data?.[input.releaseId]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator$1, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleDownloadFailures, { input })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFooter, {
			className: "px-4 pb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				className: buttonVariants({
					className: "max-md:h-11",
					variant: "outline",
					size: "sm"
				}),
				to: "/insights",
				search: {
					platform: input.platform,
					channel: input.channel,
					releaseId: input.releaseId,
					bundleWindow: adoptionWindow(input.releaseId),
					healthChart: "adoption"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartLine, {
					"aria-hidden": "true",
					"data-icon": "inline-start"
				}), "View adoption"]
			})
		})
	] });
}
/**
* The release editor's Insights card where the console reads no release
* activity, as through a self-hosted server's admin API: download failures
* alone. With release activity, its card shows them.
*/
function ReleaseFailuresSection({ input }) {
	if (useConsoleFeature("insightsAnalytics")) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
		className: "px-4 pt-4 pb-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
			className: "text-sm font-medium",
			children: "Insights"
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
		className: "px-4 pb-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleDownloadFailures, { input })
	})] });
}
/**
* One release's activity in the Bundles page's Insights column. Every cell
* asks for the page's releases under one query key, so the page makes one
* request.
*/
function ReleaseActivityCell({ releaseId, releases }) {
	const query = useBundleActivityQuery(releases);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleMovementSummary, {
		input: releases.find((release) => release.releaseId === releaseId),
		loading: query.isFetching,
		report: query.data?.[releaseId]
	});
}
/**
* What the Insights features add: their navigation item, release activity on
* the Bundles page and in the release editor, and a release's download
* failures in the release editor, which a self-hosted server serves too.
*/
var insightsFeatureUi = {
	insights: {
		navigation: {
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartNoAxesCombined, {}),
			paths: [
				"/insights",
				"/insights/distribution",
				"/installations"
			],
			link: ({ features, onClick }) => features.insightsAnalytics ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/insights",
				onClick
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/installations",
				onClick
			})
		},
		releaseSection: ({ release }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReleaseFailuresSection, { input: release })
	},
	insightsAnalytics: {
		releaseColumn: { Cell: ReleaseActivityCell },
		releaseSection: ({ release }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleInsightsSummary, { input: release })
	}
};
/** What Remote Config adds: its navigation item. */
var remoteConfigFeatureUi = { remoteConfig: { navigation: {
	icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {}),
	paths: ["/remote-config"],
	link: ({ onClick }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/remote-config",
		onClick
	})
} } };
var consoleFeatureUi = {
	...insightsFeatureUi,
	...apiKeysFeatureUi,
	...remoteConfigFeatureUi
};
var featureIds = Object.keys(consoleFeatures);
/**
* What the features that are on add, in the registry's order, with each
* feature's label; nothing until the features load.
*/
var useFeatureUi = () => {
	const features = useConsoleFeatures().data?.features;
	if (features === void 0) return [];
	return featureIds.flatMap((feature) => {
		const ui = consoleFeatureUi[feature];
		return ui !== void 0 && features[feature] ? [{
			...ui,
			feature,
			label: consoleFeatures[feature].label,
			features
		}] : [];
	});
};
/** The release list's feature columns, with their headers. */
var useReleaseColumns = () => useFeatureUi().flatMap(({ feature, label, releaseColumn }) => releaseColumn === void 0 ? [] : [{
	...releaseColumn,
	feature,
	label
}]);
/** The release editor's feature sections, for one release. */
function ReleaseSections({ release }) {
	return useFeatureUi().map(({ feature, releaseSection: Section }) => Section === void 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { release }, feature));
}
var optionalString = (value) => typeof value === "string" && value.trim().length > 0 ? value.trim() : void 0;
/**
* The search a URL holds, reduced to one of the filter sets the release
* indexes serve: a bundle, a scope (with enabled), or a channel with its
* platform (with enabled). A channel without a platform lists iOS.
*/
function validateReleaseSearch(search) {
	const beforeReleaseId = optionalString(search.beforeReleaseId);
	const afterReleaseId = beforeReleaseId ? void 0 : optionalString(search.afterReleaseId);
	const enabled = search.enabled === true || search.enabled === "true" ? true : search.enabled === false || search.enabled === "false" ? false : void 0;
	const bundleId = optionalString(search.bundleId);
	const scopeKey = bundleId ? void 0 : optionalString(search.scopeKey);
	const channelId = bundleId || scopeKey ? void 0 : optionalString(search.channelId);
	const platform = channelId === void 0 ? void 0 : search.platform === "android" ? "android" : "ios";
	return {
		afterReleaseId,
		beforeReleaseId,
		bundleId,
		channelId,
		channels: !bundleId && !scopeKey && !channelId && search.channels === "all" ? "all" : void 0,
		enabled: scopeKey || channelId ? enabled : void 0,
		platform,
		releaseId: optionalString(search.releaseId),
		scopeKey
	};
}
function releaseFilterOf(search) {
	const enabled = search.enabled === void 0 ? {} : { enabled: search.enabled };
	if (search.bundleId) return {
		kind: "bundle",
		bundleId: search.bundleId
	};
	if (search.scopeKey) return {
		kind: "scope",
		scopeKey: search.scopeKey,
		...enabled
	};
	if (search.channelId && search.platform) return {
		kind: "channelPlatform",
		channelId: search.channelId,
		platform: search.platform,
		...enabled
	};
	return { kind: "all" };
}
function hasReleaseFilters(search) {
	return releaseFilterOf(search).kind !== "all";
}
/**
* The search the list shows. A URL that names no channel, bundle, or scope
* opens on the default channel's iOS releases, or on every channel when the
* project has no such channel; undefined until the channel list, which the
* page reads anyway, arrives. A link to one release that names no channel
* shows every channel, so its row shows wherever it is.
*/
function resolveReleaseSearch(search, channels) {
	if (search.bundleId || search.scopeKey || search.channelId || search.channels === "all") return search;
	if (search.releaseId) return {
		...search,
		channels: "all"
	};
	if (channels === void 0) return void 0;
	const defaultChannel = channels.find(({ name }) => name === DEFAULT_CHANNEL);
	return defaultChannel ? validateReleaseSearch({
		...search,
		channelId: defaultChannel.id
	}) : search;
}
/**
* A new filter starts from the first page. A bundle or scope filter replaces
* the others, and choosing a channel or platform clears them.
*/
function updateReleaseFilters(current, filters) {
	const next = {
		...current,
		...filters
	};
	if (filters.bundleId) return validateReleaseSearch({ bundleId: next.bundleId });
	if (filters.scopeKey) return validateReleaseSearch({
		scopeKey: next.scopeKey,
		enabled: next.enabled
	});
	if ("channelId" in filters || "platform" in filters) return validateReleaseSearch({
		channelId: next.channelId,
		channels: next.channels,
		enabled: next.enabled,
		platform: next.platform
	});
	return validateReleaseSearch({
		bundleId: next.bundleId,
		channelId: next.channelId,
		channels: next.channels,
		enabled: next.enabled,
		platform: next.platform,
		scopeKey: next.scopeKey
	});
}
/**
* Whether the list shows what it opens on, so Clear has nothing to clear;
* true until the channel list arrives.
*/
function showsDefaultReleases(search, channels) {
	const view = resolveReleaseSearch(search, channels);
	const opening = resolveReleaseSearch({}, channels);
	return view === void 0 || opening === void 0 || JSON.stringify(releaseFilterOf(view)) === JSON.stringify(releaseFilterOf(opening));
}
var $$splitComponentImporter = () => import("./routes-CQCa9HiP.mjs");
/** The list while its channel is unknown: loading, whatever the cache holds. */
/** A fold of unreachable bundles: "1 unreachable bundle", "2 …". */
var Route = createFileRoute("/")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	validateSearch: validateReleaseSearch
});
//#endregion
export { resolveReleaseSearch as a, useFeatureUi as c, releaseFilterOf as i, useReleaseColumns as l, Route as n, showsDefaultReleases as o, hasReleaseFilters as r, updateReleaseFilters as s, ReleaseSections as t };
