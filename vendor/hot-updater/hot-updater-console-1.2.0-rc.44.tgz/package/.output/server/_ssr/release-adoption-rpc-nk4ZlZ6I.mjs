import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
import { a as readAdoptionReleasesInput, i as readAdoptionReleaseInput, o as readBundleEventsInput } from "./release-adoption-gfhE5tz5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/release-adoption-rpc-nk4ZlZ6I.js
var listAdoptionReleasesRpc_createServerFn_handler = createServerRpc({
	id: "d11a48f7251928b7819e2376aed4902fa66277bf6d30312d87ca53468332f256",
	name: "listAdoptionReleasesRpc",
	filename: "src/lib/release-adoption-rpc.ts"
}, (opts) => listAdoptionReleasesRpc.__executeServer(opts));
var listAdoptionReleasesRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readAdoptionReleasesInput).handler(listAdoptionReleasesRpc_createServerFn_handler, async ({ data }) => {
	const [{ prepareConfig }, { listAdoptionReleases }] = await Promise.all([import("./config.server-CvAlgb8E.mjs"), import("./releaseAdoption-DfEYq7I4.mjs")]);
	const { core } = await prepareConfig();
	return listAdoptionReleases(core, data);
});
var getAdoptionReleaseRpc_createServerFn_handler = createServerRpc({
	id: "16e3be74610cddd54e5e894419dca16817a7b63c09a4eed15042cdac9c39e1e0",
	name: "getAdoptionReleaseRpc",
	filename: "src/lib/release-adoption-rpc.ts"
}, (opts) => getAdoptionReleaseRpc.__executeServer(opts));
var getAdoptionReleaseRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readAdoptionReleaseInput).handler(getAdoptionReleaseRpc_createServerFn_handler, async ({ data }) => {
	const [{ prepareConfig }, { getAdoptionRelease }] = await Promise.all([import("./config.server-CvAlgb8E.mjs"), import("./releaseAdoption-DfEYq7I4.mjs")]);
	const { core } = await prepareConfig();
	return getAdoptionRelease(core, data);
});
var getBundleEventsRpc_createServerFn_handler = createServerRpc({
	id: "bfcca2365dfef4d071bdcddf97538a2637482c77bb747969dbdcd6769ca98416",
	name: "getBundleEventsRpc",
	filename: "src/lib/release-adoption-rpc.ts"
}, (opts) => getBundleEventsRpc.__executeServer(opts));
var getBundleEventsRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator(readBundleEventsInput).handler(getBundleEventsRpc_createServerFn_handler, async ({ data }) => {
	const [{ prepareConfig }, { getBundleEvents }, { requireFeature }] = await Promise.all([
		import("./config.server-CvAlgb8E.mjs"),
		import("./releaseAdoption-DfEYq7I4.mjs"),
		import("./runtime.server-BUbb281Z.mjs")
	]);
	const { runtime } = await prepareConfig();
	return getBundleEvents(await requireFeature(runtime, "insightsAnalytics"), data);
});
//#endregion
export { getAdoptionReleaseRpc_createServerFn_handler, getBundleEventsRpc_createServerFn_handler, listAdoptionReleasesRpc_createServerFn_handler };
