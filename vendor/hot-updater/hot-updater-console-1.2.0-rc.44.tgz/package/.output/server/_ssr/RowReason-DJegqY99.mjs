import { i as __toESM } from "../_runtime.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { J as ChevronRight } from "../_libs/lucide-react.mjs";
import { C as Skeleton, D as TooltipTrigger, T as TooltipContent, t as Button$1, w as Tooltip$1 } from "./sidebar-COdOWPGC.mjs";
import { o as TableRow, r as TableCell } from "./table-4qgdiham.mjs";
import { a as DataTableBody } from "./RelativeTime-jQk9a1D5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RowReason-DJegqY99.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** A fold's key on its page: the row above it, which no other fold shares. */
var foldKey = (fold) => fold.from ?? "";
/** "1 older build", "12 older builds", "100+ older builds". */
var foldLabel = (fold, noun) => `${fold.count}${fold.more ? "+" : ""} ${fold.count === 1 && !fold.more ? noun.one : noun.other}`;
/** A page's entries as table row groups: each run of rows, and each fold. */
var groupsOf = (entries) => {
	const groups = [];
	for (const entry of entries) {
		const last = groups.at(-1);
		if (entry.kind === "fold") groups.push({
			kind: "fold",
			fold: entry
		});
		else if (last?.kind === "rows") last.rows.push(entry.row);
		else groups.push({
			kind: "rows",
			rows: [entry.row]
		});
	}
	return groups;
};
/** Which folds of a page are open, by `foldKey`. */
function useOpenFolds() {
	const [open, setOpen] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	return {
		isOpen: (key) => open.has(key),
		set: (key, value) => setOpen((previous) => {
			if (previous.has(key) === value) return previous;
			const next = new Set(previous);
			if (value) next.add(key);
			else next.delete(key);
			return next;
		})
	};
}
/**
* The fold's button: a chevron and "12 older builds", as tall as a touch
* needs on a phone and as a row's text on a wide screen.
*/
function FoldButton({ label, open, onOpenChange, panelId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		"aria-controls": panelId,
		"aria-expanded": open,
		className: "group/fold flex min-h-11 w-full items-center gap-2 px-4 text-left text-xs font-medium text-muted-foreground transition-colors hover:bg-muted/30 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none focus-visible:ring-inset motion-reduce:transition-none sm:min-h-9 sm:px-3",
		onClick: () => onOpenChange(!open),
		type: "button",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
			"aria-hidden": "true",
			className: "size-3.5 shrink-0 transition-transform group-aria-expanded/fold:rotate-90 motion-reduce:transition-none"
		}), label]
	});
}
/** A fold in a `rowGroups` table: its row, then the group of its rows. */
function DataTableFold({ columns, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableBody, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
		className: "bg-muted/20 hover:bg-muted/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "p-0",
			colSpan: columns,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldButton, { ...props })
		})
	}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableBody, {
		hidden: !props.open,
		id: props.panelId,
		children: props.open ? children : null
	})] });
}
/**
* A fold in a list of cards on a narrow screen; `inList` when the cards are
* a list's items, so its row is one too.
*/
function DataCardFold({ children, inList = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b bg-muted/20",
		role: inList ? "listitem" : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldButton, { ...props })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		hidden: !props.open,
		id: props.panelId,
		children: props.open ? children : null
	})] });
}
/**
* What an open fold shows past its rows: that they load, that more of them
* load on request, or that they couldn't be read.
*/
function FoldStatus({ state, label, onMore, onRetry, columns }) {
	const body = state === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-live": "polite",
		className: "flex flex-col gap-2 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" })
		]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-4 py-2 sm:px-3",
		children: [state === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted-foreground",
			role: "status",
			children: [label, " couldn't be loaded."]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			className: "h-11 px-3 text-xs sm:h-8",
			onClick: state === "error" ? onRetry : onMore,
			size: "sm",
			variant: "ghost",
			children: state === "error" ? "Retry" : "Show more"
		})]
	});
	return columns === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b",
		children: body
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
		className: "hover:bg-transparent",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "p-0",
			colSpan: columns,
			children: body
		})
	});
}
/**
* What a page's folds hold: their counts summed, and whether any holds more
* than it says (past its cap, or past the page), so the total is a floor.
*/
var foldedTotal = (entries) => {
	let count = 0;
	let more = false;
	for (const entry of entries) {
		if (entry.kind !== "fold") continue;
		count += entry.count;
		more ||= entry.more;
	}
	return {
		count,
		more
	};
};
/**
* A quiet word on a row a list shades, such as "Older" or "Unreachable",
* that says why on a tap, a click, or focus: a touch or a keyboard reaches
* the reason, not only a pointer's hover. A control of its own, so it opens
* no row.
*/
function RowReason({ icon: Icon, children, label, reason }) {
	const id = (0, import_react.useId)();
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip$1, {
		onOpenChange: setOpen,
		open,
		triggerId: id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipTrigger, {
			"aria-describedby": open ? `${id}-reason` : void 0,
			"aria-label": label,
			className: "relative inline-flex shrink-0 items-center gap-1 rounded-sm text-xs text-muted-foreground transition-colors after:absolute after:-inset-x-2 after:-inset-y-3.5 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none motion-reduce:transition-none sm:after:hidden",
			closeOnClick: false,
			id,
			onClick: () => setOpen((value) => !value),
			type: "button",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				"aria-hidden": "true",
				className: "size-3.5"
			}), children]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
			className: "max-w-64",
			id: `${id}-reason`,
			role: "tooltip",
			side: "bottom",
			children: reason
		})]
	});
}
//#endregion
export { foldKey as a, groupsOf as c, RowReason as i, useOpenFolds as l, DataTableFold as n, foldLabel as o, FoldStatus as r, foldedTotal as s, DataCardFold as t };
