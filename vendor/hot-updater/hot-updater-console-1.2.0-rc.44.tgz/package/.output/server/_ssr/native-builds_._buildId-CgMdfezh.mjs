import { i as __toESM } from "../_runtime.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { B as Download, G as CircleCheck, J as ChevronRight, M as HardDrive, N as GitBranch, S as PackageOpen, U as CircleSlash, Y as ChevronLeft, _ as RefreshCw, i as TriangleAlert, j as History, nt as ArrowUpRight, u as Smartphone } from "../_libs/lucide-react.mjs";
import { C as Skeleton, O as buttonVariants, S as SidebarTrigger, k as cn, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as CardHeader, n as CardContent, o as CardTitle, t as Card } from "./card-CsUxqR3-.mjs";
import { a as Badge, i as AlertTitle, n as AlertAction, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-4qgdiham.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as EmptyMedia, i as EmptyHeader, n as EmptyContent, o as EmptyTitle, r as EmptyDescription, t as Empty } from "./empty-qtSrrSOA.mjs";
import { r as NUMERIC_COHORT_SIZE } from "./dist-CiOq3ygH.mjs";
import { A as nativeBuildSignedDownloadUrl, C as nativeBuildFileName, E as nativeBuildLabel, F as shellQuote, S as nativeBuildDownloadPath, _ as maskIosUdid, j as platformLabel, l as SANDBOX_NO_PATCH_BASE, m as formatByteSize, v as nativeBuildArtifacts, w as nativeBuildInstallCommand } from "./native-builds-lEyKQemV.mjs";
import { a as useConfigQuery, d as useNativeBuildDownloadLinkQuery, f as useNativeBuildDownloadUrlQuery, h as useNativeBuildPatchesQuery, l as useMarkNativeBuildMutation, u as useNativeBuildDetailQuery } from "./api-BISxaFip.mjs";
import { a as tabsListVariants } from "./tabs-Bw-XniPE.mjs";
import { t as PlatformIcon } from "./PlatformIcon-C22qEcwo.mjs";
import { t as BundleIdDisplay } from "./BundleIdDisplay-LgsZ_E0k.mjs";
import { t as ChannelBadge } from "./ChannelBadge-DsA4srwK.mjs";
import { n as require_dayjs_min } from "../_libs/dayjs.mjs";
import { i as TargetDisplay, n as CopyableText, r as NoValue, t as BuildKeyDisplay } from "./TargetDisplay-CwHH2uJ2.mjs";
import { t as NAV_TAB_CLASS } from "./NativeBuildsNav-CPmrkQr0.mjs";
import { n as StoreSubmissionBadge, r as isSubmitted, t as SandboxBadge } from "./SandboxBadge-C-Yh0M84.mjs";
import { l as useIosDevice, m as useNativeBuildIpaDevicesQuery, n as IosInstall } from "./IosInstall-CUO4c1oT.mjs";
import { t as Route } from "./native-builds_._buildId-C_VAJYD2.mjs";
import { n as TimestampDisplay, r as getCommitUrl, t as RolloutPercentageBadge } from "./RolloutPercentageBadge-XfgBi8FV.mjs";
import { t as QrCode } from "./QrCode-BVbTYE09.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-builds_._buildId-CgMdfezh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
/**
* A hash shortened to its prefix, as git shows a commit: never cut in the
* middle, the full value on hover, and copied on click.
*/
function ShortHash({ value, length, shown = value.slice(0, length), label }) {
	const copy = async () => {
		try {
			await navigator.clipboard.writeText(value);
			toast.success("Copied to clipboard", { description: value });
		} catch {
			toast.error(`Could not copy the ${label}`);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		"aria-label": `Copy the ${label} ${value}`,
		className: "relative cursor-copy rounded-sm font-mono after:absolute after:-inset-x-2 after:-inset-y-4 sm:after:hidden text-xs whitespace-nowrap tabular-nums underline-offset-4 hover:underline focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none",
		onClick: (event) => {
			event.stopPropagation();
			copy();
		},
		title: value,
		translate: "no",
		type: "button",
		children: shown
	});
}
/**
* A build's commit as git shows it, its first 7 characters: a link to the
* commit when `console.gitUrl` is set, else a button that copies the full
* SHA. The full SHA shows on hover either way.
*/
function CommitLink({ hash }) {
	const config = useConfigQuery();
	if (hash === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoValue, {});
	const url = getCommitUrl(config.data?.console.gitUrl, hash);
	return url === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortHash, {
		label: "commit",
		length: 7,
		value: hash
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: "relative font-mono text-xs whitespace-nowrap underline-offset-4 after:absolute after:-inset-x-2 after:-inset-y-4 hover:underline sm:after:hidden",
		href: url,
		onClick: (event) => event.stopPropagation(),
		rel: "noreferrer",
		target: "_blank",
		title: hash,
		translate: "no",
		children: hash.slice(0, 7)
	});
}
function Row({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1 sm:grid-cols-[10rem_minmax(0,1fr)] sm:gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs font-medium text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "min-w-0 text-sm",
			children
		})]
	});
}
/** Marks or clears the build where the card says what the mark does. */
function StoreBuildAction({ detail }) {
	const { build } = detail;
	const mark = useMarkNativeBuildMutation();
	if (build.is_sandbox) return null;
	const storeBuild = !build.is_store_build;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
		className: "min-h-11 shrink-0 sm:min-h-8",
		disabled: mark.isPending,
		onClick: () => mark.mutate({
			id: build.id,
			storeBuild
		}, {
			onSuccess: () => {
				toast.success(storeBuild ? "Marked as the store build" : "Mark cleared");
			},
			onError: (error) => {
				toast.error("Could not change the mark", { description: error.message });
			}
		}),
		size: "sm",
		type: "button",
		variant: "outline",
		children: storeBuild ? "Mark as store build" : "Clear mark"
	});
}
/**
* Which build new deploys patch from: this one, as the store build or as the
* newest with no mark, or another, which it links to. A sandbox build is never
* one, whatever its scope holds.
*/
function BaselineStatus({ detail }) {
	const { build, newestInScope, storeBuildInScope } = detail;
	if (build.is_sandbox) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-2 rounded-md border bg-muted/40 p-3 text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleSlash, {
			"aria-hidden": "true",
			className: "mt-0.5 size-3.5 shrink-0 text-muted-foreground"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: "No patch base."
			}),
			" ",
			SANDBOX_NO_PATCH_BASE
		] })]
	});
	const base = storeBuildInScope ?? newestInScope;
	if (base === null) return null;
	const isBase = base.id === build.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 rounded-md border bg-muted/40 p-3 text-xs sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(isBase ? CircleCheck : History, {
				"aria-hidden": "true",
				className: "mt-0.5 size-3.5 shrink-0 text-muted-foreground"
			}), storeBuildInScope?.id === build.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: "Store build."
			}), " New deploys to this scope patch from this build."] }) : isBase ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: "Current baseline."
			}), " The newest build, and no store build is marked. New deploys to this scope patch from this build."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "Not the base."
				}),
				" New deploys patch from",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					className: "inline-flex items-center gap-0.5 font-medium underline underline-offset-4",
					params: { buildId: base.id },
					to: "/native-builds/$buildId",
					children: [nativeBuildLabel(base) ?? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						platformLabel(base.platform),
						" ",
						nativeBuildArtifacts[base.artifact_kind].label,
						" ·",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimestampDisplay, { uuid: base.id })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
						"aria-hidden": "true",
						className: "size-3"
					})]
				}),
				", so this one gets no new patches."
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreBuildAction, { detail })]
	});
}
/**
* The build's built-in bundle: the bundle every install runs until its
* first OTA, and the base that OTA's patch starts from.
*/
function BuiltInBundleCard({ detail }) {
	const { build, builtInBundle, channel } = detail;
	const childCount = builtInBundle?.childCount ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
			className: "border-b px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Built-in bundle" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "flex flex-col gap-4 p-4 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Bundle ID",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleIdDisplay, { bundleId: build.min_bundle_id })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "OTAs patching from it",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: childCount === 1 ? "1 bundle" : `${childCount} bundles`
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Scope",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex flex-wrap items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									"aria-label": `Show the builds that embed ${channel}`,
									className: "relative rounded-md after:absolute after:-inset-x-1 after:-inset-y-[11px] sm:after:hidden",
									search: { channel },
									to: "/native-builds",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelBadge, { channel })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs",
									children: platformLabel(build.platform)
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Target",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetDisplay, {
									appVersion: build.app_version,
									fingerprintHash: build.fingerprint_hash,
									nativeAppVersion: build.native_app_version
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Build key",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildKeyDisplay, { value: build.build_key })
							})
						}),
						!build.build_number ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Build",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs tabular-nums",
								translate: "no",
								children: build.build_number
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Commit",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommitLink, { hash: build.git_commit_hash })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Created",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimestampDisplay, {
								format: "both",
								uuid: build.id
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BaselineStatus, { detail }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: build.is_sandbox ? "An install of this build runs this bundle until it opens an OTA." : "A store or test install of this build runs this bundle until its first OTA. That OTA downloads as a patch from this bundle when one exists, and as the full bundle otherwise."
				})
			]
		})]
	});
}
var IPA_LIMIT = "The .ipa installs only on devices its signing profile allows (development or ad hoc)";
/**
* What an artifact installs on, where the file alone isn't enough: the card
* says it once, under the QR code, or without one, in its place. A sandbox
* build gets no TestFlight advice.
*/
var installLimit = (build) => {
	switch (build.artifact_kind) {
		case "ipa": return build.is_sandbox ? `${IPA_LIMIT}.` : `${IPA_LIMIT}; an App Store export reaches testers through TestFlight.`;
		case "aab": return "The .aab installs through Google Play or bundletool, not from the file.";
		default: return;
	}
};
/**
* What scanning a build's QR code gets, by its artifact. The install steps
* beside it add only what this doesn't say, so the card says each thing once.
*/
var qrCaption = (build) => {
	switch (build.artifact_kind) {
		case "apk": return "Scan with an Android phone's camera, then open the APK to install it.";
		case "app": return "Scan to download the .app.zip on a Mac.";
		default: return `Scan to download. ${installLimit(build)}`;
	}
};
/**
* An IPA's QR code holds this page rather than a file: the iPhone that scans it
* checks whether the IPA lists it before anything downloads, and installs here.
*/
function ScannablePage() {
	const { origin, pathname } = window.location;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {
			className: "size-48",
			label: "Open this page on an iPhone",
			value: `${origin}${pathname}`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-56 text-center text-xs text-muted-foreground",
			children: "Scan with an iPhone to install this build from here. The phone signs in to the Console first."
		})]
	});
}
/** A QR code of the build's download URL, with what scanning it gets. */
function ScannableUrl({ build, url, note }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {
				className: "size-48",
				label: `Download ${nativeBuildFileName(build)}`,
				value: url
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-56 text-center text-xs text-muted-foreground",
				children: qrCaption(build)
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-56 text-center text-xs text-muted-foreground",
				children: note
			}) : null
		]
	});
}
function QrProblem({ message }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "destructive",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "The download link couldn't be created" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: message })
		]
	});
}
/**
* The QR code when the Console can't sign a link: the storage's URL, which a
* phone opens without the Console's sign-in, but only until it expires.
*/
function StorageQrCode({ build }) {
	const downloadUrl = useNativeBuildDownloadUrlQuery(build.id);
	const url = downloadUrl.data?.url;
	if (url === null) {
		const limits = installLimit(build);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-2 text-xs text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This storage gives no download link a phone can open without signing in, so there is no QR code. Download the build here, or open this page on the phone signed in to the console." }), limits ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: limits }) : null]
		});
	}
	if (url !== void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScannableUrl, {
		build,
		note: "This link expires. If the download fails, reload this page.",
		url
	});
	return downloadUrl.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrProblem, { message: downloadUrl.error.message }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-48" });
}
/**
* The file's download, as an outline button where people use the file itself.
* An IPA's is a ghost button in the same place: a computer's browser installs
* nothing from it, so it never competes with the card's install path.
*/
function DownloadButton({ build, href }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		className: buttonVariants({
			className: "h-auto min-h-11 w-full min-w-0 py-2 whitespace-normal sm:min-h-8 sm:w-fit",
			variant: build.artifact_kind === "ipa" ? "ghost" : "outline"
		}),
		download: true,
		href,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { "data-icon": "inline-start" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-left [overflow-wrap:anywhere]",
			children: ["Download ", nativeBuildFileName(build)]
		})]
	});
}
/**
* A build a store took installs from the store, so the card leads with the
* store's badge, says how testers get it, and keeps the file's download, with
* no QR code or signed link to ask for.
*/
function StoreInstallCard({ build }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
			className: "border-b px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Install" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "flex min-w-0 flex-col gap-4 p-4 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreSubmissionBadge, {
					build,
					withTime: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallSteps, { build }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
					build,
					href: nativeBuildDownloadPath(build.id)
				})
			]
		})]
	});
}
/**
* How else the artifact installs, beside its QR code's caption and its
* download: none of it repeats the caption.
*/
function InstallSteps({ build }) {
	switch (build.artifact_kind) {
		case "apk": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Your browser needs the \"Install unknown apps\" permission."
				}),
				build.is_sandbox ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Its .sandbox ID installs it beside a Play copy."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "If this package is already installed with another signing key, such as a Play copy, the install fails. Uninstall that copy first, or build with sandbox: true, whose .sandbox ID installs beside it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "On an emulator or a phone over USB, install and open it from your project:"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
					label: "the install command",
					value: nativeBuildInstallCommand(build)
				})
			]
		});
		case "app": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "It runs only in the iOS Simulator. In your project, install and open it on the booted one:"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
				label: "the install command",
				value: nativeBuildInstallCommand(build)
			})]
		});
		case "aab": return isSubmitted(build) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [build.submitted_to === "play-production" ? "Users" : "Testers", " get it once its release is rolled out; on an app Play Console hasn't published, the release is a draft you roll out in Play Console."]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "For testers, build and release to internal testing:"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
				label: "the Google Play command",
				value: "npx hot-updater google-play upload"
			})]
		});
		case "ipa": return isSubmitted(build) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "Internal testers install it from the TestFlight app once App Store Connect has processed it."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "Over USB, Xcode or Apple Configurator installs it."
		});
	}
}
/**
* The signed link to copy, which a script or a teammate uses without signing
* in. A local Console has none, and says nothing about it on every build.
*/
function SignedLink({ link, url }) {
	if (link?.status === "no-secret") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-xs text-muted-foreground",
		role: "status",
		children: [
			"Set ",
			link.secretName,
			" on the Console to create links."
		]
	});
	if (link?.status !== "issued" || url === null) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
			label: "the download link",
			value: url
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				"Anyone with this link can download this build until",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "whitespace-nowrap",
					children: [(0, import_dayjs_min.default)(link.expiresAt).format("YYYY-MM-DD"), "."]
				})
			]
		})]
	});
}
/**
* Installs one native build: an IPA or AAB a store took, from the store, which
* its badge names, with the file's download; an IPA
* on the iPhone that opens this page, whose QR code on any other screen holds
* this page; every other artifact by a QR code of its signed link, which a phone
* without a session scans, and by download here or the link itself; an APK or a
* simulator app also with `native-build install`, and an IPA's or an AAB's
* testers through its store. Where the Console can't sign, the QR code holds the
* storage's URL and the download asks for the session.
*/
function InstallCard({ build, sibling = null }) {
	return isSubmitted(build) && (build.artifact_kind === "ipa" || build.artifact_kind === "aab") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreInstallCard, { build }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileInstallCard, {
		build,
		sibling
	});
}
/** What each install target is called where a person picks one. */
var TARGET_LABELS = {
	ipa: "iPhone",
	app: "Simulator"
};
/**
* The two install targets of one native code, iPhone then Simulator, as links
* to each build's own page: everything else on the page is of that build.
*/
function InstallTargetSwitch({ build, sibling }) {
	const targets = build.artifact_kind === "ipa" ? [build, sibling] : [sibling, build];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": "Install target",
		className: cn(tabsListVariants(), "h-auto min-h-11 shrink-0 sm:h-8 sm:min-h-0 [&>a]:min-h-11 sm:[&>a]:min-h-0"),
		children: targets.map((target) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			"aria-current": target.id === build.id ? "page" : void 0,
			className: NAV_TAB_CLASS,
			params: { buildId: target.id },
			to: "/native-builds/$buildId",
			children: TARGET_LABELS[target.artifact_kind]
		}, target.id))
	});
}
/**
* On the iPhone, what installs the IPA from a computer, closed under the one
* action this phone takes: over USB, the download, and its link.
*/
function OtherWaysToInstall({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const id = (0, import_react.useId)();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-3 border-t pt-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			"aria-controls": id,
			"aria-expanded": open,
			className: "group/other -mx-1 flex min-h-11 items-center gap-1.5 self-start rounded-md px-1 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none motion-reduce:transition-none sm:min-h-8",
			onClick: () => setOpen((value) => !value),
			type: "button",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
				"aria-hidden": "true",
				className: "size-3.5 shrink-0 transition-transform group-aria-expanded/other:rotate-90 motion-reduce:transition-none"
			}), "Other ways to install"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			hidden: !open,
			id,
			children
		})]
	});
}
function FileInstallCard({ build, sibling }) {
	const link = useNativeBuildDownloadLinkQuery(build.id);
	const signedUrl = link.data?.status === "issued" ? nativeBuildSignedDownloadUrl(window.location, build.id, link.data.token) : null;
	const device = useIosDevice();
	const ipa = build.artifact_kind === "ipa";
	const onPhone = ipa && device?.ios === true;
	const otherWays = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallSteps, { build }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
				build,
				href: signedUrl ?? nativeBuildDownloadPath(build.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedLink, {
				link: link.data,
				url: signedUrl
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
			className: "flex flex-row items-center justify-between gap-3 border-b px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Install" })
			}), sibling === null ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallTargetSwitch, {
				build,
				sibling
			})]
		}), onPhone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "flex min-w-0 flex-col gap-4 p-4 sm:p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IosInstall, {
				build,
				device
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OtherWaysToInstall, { children: otherWays })]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "grid gap-6 p-4 sm:grid-cols-[12rem_minmax(0,1fr)] sm:p-6",
			children: [ipa && signedUrl !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScannablePage, {}) : signedUrl !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScannableUrl, {
				build,
				url: signedUrl
			}) : link.data !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StorageQrCode, { build }) : link.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrProblem, { message: link.error.message }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-48" }), otherWays]
		})]
	});
}
/**
* The devices an ad hoc IPA installs on, read from its signing profile: each
* by the registry's name when the registry knows it, else as an unknown
* device, over its UDID's last characters, which copy the whole UDID. Read
* only: the IPA decides, and a new build is what adds a device.
*/
function IpaDevicesCard({ build }) {
	const query = useNativeBuildIpaDevicesQuery(build.id);
	const result = query.data;
	if (result?.status === "store" || result?.status === "enterprise") return null;
	const devices = result?.status === "listed" ? result.devices : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
			className: "flex flex-row items-center gap-2 border-b px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Devices in this build" })
				}),
				devices === null ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tabular-nums text-muted-foreground",
					children: devices.length
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: buttonVariants({
						className: "ml-auto h-11 sm:h-7",
						size: "sm",
						variant: "ghost"
					}),
					to: "/native-builds/devices",
					children: "iOS devices"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Reading this IPA's devices"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" })
				]
			}) : query.isError || result?.status === "unavailable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 p-4 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-0 flex-1",
					children: "The Console couldn't read this IPA's devices from storage."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					className: "h-11 sm:h-7",
					onClick: () => void query.refetch(),
					size: "sm",
					variant: "outline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry"]
				})]
			}) : devices?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-4 text-xs text-muted-foreground",
				children: "This IPA lists no devices."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				"aria-label": "Devices in this build",
				className: "divide-y",
				children: devices?.map((device) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex min-h-11 min-w-0 items-center gap-3 px-4 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
						"aria-hidden": "true",
						className: "size-4 shrink-0 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex min-w-0 flex-col items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: device.name === null ? "truncate text-muted-foreground" : "truncate",
							children: device.name ?? "Unknown device"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortHash, {
								label: "UDID",
								shown: maskIosUdid(device.udid),
								value: device.udid
							})
						})]
					})]
				}, device.udid))
			})
		})]
	});
}
var BUNDLE_DIFFING_GUIDE_URL = "https://hot-updater.dev/docs/guides/bundle-diffing#first-ota-update";
/**
* The bundles that patch from the build's built-in bundle, newest first, a
* page at a time: the newest page comes with the build's page, and others
* are read as they are asked for.
*/
function PatchesCard({ detail, page, onPage }) {
	const paged = page.before !== void 0 || page.after !== void 0;
	const query = useNativeBuildPatchesQuery(detail.build.min_bundle_id, page, paged);
	const patches = paged ? query.data : detail.patches;
	const { next, previous } = patches ?? {};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden shadow-sm",
		id: "patches",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
			className: "border-b px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Patches from this build" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "p-0",
			children: [paged && query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Patches couldn't be loaded" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: query.error.message }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							onClick: () => void query.refetch(),
							size: "xs",
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry"]
						}) })
					]
				})
			}) : patches === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Loading patches"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-2/3" })
				]
			}) : patches.data.length === 0 ? paged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, {
				className: "py-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "No more patches" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
					className: "min-h-11 sm:min-h-8",
					onClick: () => onPage({}),
					variant: "outline",
					children: "Show the newest patches"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, {
				className: "py-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyMedia, {
						variant: "icon",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GitBranch, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "No patches from this build" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: detail.build.is_sandbox ? SANDBOX_NO_PATCH_BASE : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"A deploy adds a patch from this build's bundle while it is its scope's store build, or its newest build with none marked, and the deploy config turns patches on, with",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "font-mono",
							children: "patch"
						}),
						" in",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "font-mono",
							children: "hot-updater.config.ts"
						}),
						"."
					] }) })
				] }), detail.build.is_sandbox ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: buttonVariants({
						className: "min-h-11 sm:min-h-8",
						variant: "outline"
					}),
					href: BUNDLE_DIFFING_GUIDE_URL,
					rel: "noreferrer",
					target: "_blank",
					children: ["Bundle diffing guide", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { "data-icon": "inline-end" })]
				}) })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				"aria-busy": paged && query.isPlaceholderData,
				"aria-label": "Patches from this build",
				className: "table-fixed",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Target bundle" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "w-28",
						children: "Patch size"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "hidden w-32 sm:table-cell",
						children: "Created"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: patches.data.map((patch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "py-3 whitespace-normal",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "block font-mono text-xs [overflow-wrap:anywhere] underline-offset-4 hover:underline",
							search: { bundleId: patch.bundleId },
							title: patch.bundleId,
							to: "/",
							translate: "no",
							children: patch.bundleId
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-xs tabular-nums",
						children: formatByteSize(patch.byteSize)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "hidden sm:table-cell",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimestampDisplay, { uuid: patch.bundleId })
					})
				] }, patch.bundleId)) })]
			}), next !== void 0 || previous !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Patch pages",
				className: "flex items-center justify-end gap-2 border-t px-4 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					className: "min-h-11 sm:min-h-7",
					disabled: previous === void 0 || paged && query.isPlaceholderData,
					onClick: () => onPage({ after: previous }),
					size: "sm",
					variant: "ghost",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { "data-icon": "inline-start" }), "Newer"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					className: "min-h-11 sm:min-h-7",
					disabled: next === void 0 || paged && query.isPlaceholderData,
					onClick: () => onPage({ before: next }),
					size: "sm",
					variant: "ghost",
					children: ["Older", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { "data-icon": "inline-end" })]
				})]
			}) : null]
		})]
	});
}
/**
* How an install of the build downloads `bundleId` as its first OTA: as the
* patch from the built-in bundle when one exists, else the full bundle. The
* newest page of patches decides it for every bundle down to the page's
* oldest; an older bundle is unknown only when the page is full.
*/
var firstDownloadOf = (patches, bundleId) => {
	const patch = patches.data.find((row) => row.bundleId === bundleId);
	if (patch !== void 0) return {
		kind: "patch",
		byteSize: patch.byteSize
	};
	const oldest = patches.data.at(-1)?.bundleId;
	return patches.next !== void 0 && oldest !== void 0 && bundleId < oldest ? { kind: "unknown" } : { kind: "full" };
};
function FirstDownloadCell({ download }) {
	switch (download.kind) {
		case "patch": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs",
			children: [
				"Patch",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted-foreground tabular-nums",
					children: [
						"(",
						formatByteSize(download.byteSize),
						")"
					]
				})
			]
		});
		case "full": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground",
			children: "Full bundle"
		});
		case "unknown": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "text-xs underline-offset-4 hover:underline",
			href: "#patches",
			children: "See patches"
		});
	}
}
/**
* What the update check offers an install of the build now: its scope's
* catalog at the build's app version, down to the built-in bundle, newest
* first. It is the catalog of now, not the history.
*/
function ServedNowCard({ detail }) {
	const { build, channel, servedNow, patches, catalogScopeKey } = detail;
	const firstOta = servedNow.find(({ rolloutCohortCount, targetCohorts }) => rolloutCohortCount > 0 || targetCohorts.length > 0)?.bundleId;
	const missingPatch = build.is_store_build && firstOta !== void 0 && firstOta !== null && firstDownloadOf(patches, firstOta).kind === "full" ? [
		"npx hot-updater patch",
		`-p ${build.platform}`,
		`-c ${shellQuote(channel)}`,
		`-b ${shellQuote(firstOta)}`,
		`--base-artifact-id ${shellQuote(build.min_bundle_id)}`
	].join(" ") : null;
	const scopeLink = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		className: "inline-flex items-center gap-0.5 underline-offset-4 hover:underline",
		search: { scopeKey: catalogScopeKey },
		to: "/",
		children: ["All releases in this scope", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
			"aria-hidden": "true",
			className: "size-3"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
			className: "border-b px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Served now" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: servedNow.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, {
				className: "py-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyMedia, {
						variant: "icon",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageOpen, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "No OTA for this build yet" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyDescription, { children: [
						"No release in this build's scope is newer than its built-in bundle. Deploy one with",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "font-mono",
							children: "hot-updater deploy"
						}),
						", and it shows here."
					] })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: buttonVariants({
						className: "min-h-11 sm:min-h-8",
						variant: "outline"
					}),
					search: { scopeKey: catalogScopeKey },
					to: "/",
					children: "All releases in this scope"
				}) })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					"aria-label": "Served now",
					className: "table-fixed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Bundle" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "hidden w-40 md:table-cell",
							children: "Rollout"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "hidden w-32 sm:table-cell",
							children: "Created"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "w-32",
							children: "First OTA download"
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: servedNow.map((release) => {
						const bundleId = release.bundleId;
						const percentage = release.rolloutCohortCount / NUMERIC_COHORT_SIZE * 100;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "py-3 whitespace-normal",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex min-w-0 flex-col gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										className: "font-mono text-xs [overflow-wrap:anywhere] underline-offset-4 hover:underline",
										search: { releaseId: release.releaseId },
										title: bundleId,
										to: "/",
										translate: "no",
										children: bundleId
									}), release.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: release.message
									}) : null]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "hidden md:table-cell",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-1",
									children: [release.targetCohorts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: release.targetCohorts.length === 1 ? "1 cohort" : `${release.targetCohorts.length} cohorts`
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolloutPercentageBadge, { percentage }), release.shouldForceUpdate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										children: "Forced"
									}) : null]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "hidden sm:table-cell",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimestampDisplay, { uuid: bundleId })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FirstDownloadCell, { download: firstDownloadOf(patches, bundleId) }) })
						] }, release.releaseId);
					}) })]
				}),
				missingPatch === null ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 border-t px-4 py-3 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The OTA fresh installs get first has no patch from this store build, so they download all of it. Add one from your project:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
						label: "the patch command",
						value: missingPatch
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "border-t px-4 py-3 text-xs text-muted-foreground",
					children: ["What the update check serves an install of this build now, newest first: not the history. ", scopeLink]
				})
			] })
		})]
	});
}
/**
* One native build: how to install it, its built-in bundle as the base its
* OTAs patch from, what an install is served now, and the patches from it.
* The patch page is in the URL, so a link opens it.
*/
function NativeBuildDetailPage({ buildId, search, onSearchChange }) {
	const query = useNativeBuildDetailQuery(buildId);
	const detail = query.data;
	const page = {
		...search.patchesBefore === void 0 ? {} : { before: search.patchesBefore },
		...search.patchesAfter === void 0 ? {} : { after: search.patchesAfter }
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-10 flex shrink-0 items-center gap-x-2 border-b bg-background px-3 py-3 sm:min-h-12 sm:bg-card/70 sm:px-4 sm:backdrop-blur-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1 size-11 lg:size-7" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					className: buttonVariants({
						className: "min-h-11 sm:min-h-7",
						size: "sm",
						variant: "ghost"
					}),
					search: detail ? { channel: detail.channel } : { channels: "all" },
					to: "/native-builds",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { "data-icon": "inline-start" }), "Native builds"]
				}),
				detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "flex min-w-0 items-center gap-1.5 text-sm font-medium",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
							className: "size-3.5 shrink-0 text-muted-foreground",
							platform: detail.build.platform
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex min-w-0 flex-wrap items-center gap-x-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5 whitespace-nowrap",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "sr-only",
										children: [platformLabel(detail.build.platform), " "]
									}),
									nativeBuildArtifacts[detail.build.artifact_kind].label,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SandboxBadge, { build: detail.build })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 [overflow-wrap:anywhere]",
								children: ["· ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									translate: "no",
									children: detail.channel
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-xs font-normal text-muted-foreground tabular-nums sm:inline",
							children: formatByteSize(detail.build.byte_size)
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "sr-only",
					children: "Native build"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 min-w-0 flex-1 overflow-y-auto bg-muted/5 p-3 sm:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto flex w-full max-w-5xl flex-col gap-4 sm:gap-6",
				children: query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "The native build couldn't be loaded" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: query.error.message }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							onClick: () => void query.refetch(),
							size: "xs",
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry"]
						}) })
					]
				}) : detail === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Loading the native build"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-56 w-full rounded-xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full rounded-xl" })
				] }) : detail === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, {
					className: "border py-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyMedia, {
							variant: "icon",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: "Native build not found" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: "No native build has this ID. It may have been deleted, or be from another console." })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						className: buttonVariants({
							className: "min-h-11 sm:min-h-8",
							variant: "outline"
						}),
						search: { channels: "all" },
						to: "/native-builds",
						children: "Show all native builds"
					}) })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallCard, {
						build: detail.build,
						sibling: detail.sibling
					}),
					detail.build.artifact_kind === "ipa" && !isSubmitted(detail.build) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IpaDevicesCard, { build: detail.build }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuiltInBundleCard, { detail }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServedNowCard, { detail }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatchesCard, {
						detail,
						onPage: (next) => onSearchChange({
							...next.before === void 0 ? {} : { patchesBefore: next.before },
							...next.after === void 0 ? {} : { patchesAfter: next.after }
						}),
						page
					})
				] }, detail.build.id)
			})
		})]
	});
}
function NativeBuildDetailRoute() {
	const { buildId } = Route.useParams();
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeBuildDetailPage, {
		buildId,
		onSearchChange: (next) => void navigate({
			search: next,
			replace: true
		}),
		search
	});
}
//#endregion
export { NativeBuildDetailRoute as component };
