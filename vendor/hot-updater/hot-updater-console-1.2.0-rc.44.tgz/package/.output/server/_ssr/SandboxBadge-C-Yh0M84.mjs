import { i as __toESM } from "../_runtime.mjs";
import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { p as Send } from "../_libs/lucide-react.mjs";
import { a as Badge } from "./badge-o8QNRxtw.mjs";
import { n as require_dayjs_min, t as require_relativeTime } from "../_libs/dayjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SandboxBadge-C-Yh0M84.js
var import_jsx_runtime = require_jsx_runtime();
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min());
var import_relativeTime = /* @__PURE__ */ __toESM(require_relativeTime());
/** Google Play destination display labels. */
var PLAY_TRACKS = {
	"play-internal": { label: "Play internal" },
	"play-closed": { label: "Play closed" },
	"play-open": { label: "Play open" },
	"play-production": { label: "Play production" }
};
import_dayjs_min.default.extend(import_relativeTime.default);
/** Each store track's name as the stores call it. */
var storeTrackLabels = {
	testflight: "TestFlight",
	...Object.fromEntries(Object.entries(PLAY_TRACKS).map(([key, value]) => [key, value.label]))
};
/** Whether a store took the build, as its row records. */
var isSubmitted = (build) => build.submitted_to !== null && build.submitted_to !== void 0;
/** When the submission was recorded: relative, with the exact time on hover. */
function SubmittedAt({ ms }) {
	if (ms === null) return null;
	const date = (0, import_dayjs_min.default)(ms);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
		className: "text-xs text-muted-foreground",
		dateTime: date.toISOString(),
		title: date.format("YYYY-MM-DD HH:mm:ss"),
		children: date.fromNow()
	});
}
/** When the submission was recorded, as a tooltip says it. */
var submittedTitle = (build) => {
	const destination = `Submitted to ${storeTrackLabels[build.submitted_to]}`;
	if (build.submitted_at_ms === null) return destination;
	const date = (0, import_dayjs_min.default)(build.submitted_at_ms);
	return `${destination} ${date.fromNow()}, ${date.format("YYYY-MM-DD HH:mm:ss")}`;
};
/**
* The store track a build went to, with the store's label of it, such as
* "TestFlight 1.7.0 (66)": none for a build no store took. Its tooltip says
* when it was submitted.
*/
function StoreSubmissionBadge({ build, withTime = false }) {
	if (!isSubmitted(build)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex flex-wrap items-center gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
			className: "gap-1",
			title: submittedTitle(build),
			variant: "muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
					"aria-hidden": "true",
					className: "size-3"
				}),
				storeTrackLabels[build.submitted_to],
				build.submitted_version ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono tabular-nums",
					translate: "no",
					children: build.submitted_version
				}) : null
			]
		}), withTime ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubmittedAt, { ms: build.submitted_at_ms }) : null]
	});
}
/**
* "Sandbox" on a sandbox build, as the registry records it, whatever its
* channel; nothing on any other. A qualifier of the artifact kind beside it,
* so a quiet tag: tinted and muted like a neutral channel, the row's chip
* height, and narrow, as "Store build" is.
*/
function SandboxBadge({ build }) {
	return build.is_sandbox ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		className: "px-1.5",
		variant: "muted",
		children: "Sandbox"
	}) : null;
}
//#endregion
export { storeTrackLabels as i, StoreSubmissionBadge as n, isSubmitted as r, SandboxBadge as t };
