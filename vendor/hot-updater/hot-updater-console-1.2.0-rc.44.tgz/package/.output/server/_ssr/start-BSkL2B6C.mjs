import { t as createMiddleware } from "./createMiddleware-C3ACsfuG.mjs";
import { i as isPromise, t as createCsrfMiddleware } from "./createCsrfMiddleware-BwHbC8n-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/start-BSkL2B6C.js
function dedupeSerializationAdapters(deduped, serializationAdapters) {
	for (let i = 0, len = serializationAdapters.length; i < len; i++) {
		const current = serializationAdapters[i];
		if (!deduped.has(current)) {
			deduped.add(current);
			if (current.extends) dedupeSerializationAdapters(deduped, current.extends);
		}
	}
}
function dedupeOptions(options) {
	if (options.serializationAdapters) {
		const deduped = /* @__PURE__ */ new Set();
		dedupeSerializationAdapters(deduped, options.serializationAdapters);
		options.serializationAdapters = Array.from(deduped);
	}
	return options;
}
var createStart = (getOptions) => {
	return {
		getOptions: () => {
			const options = getOptions();
			return isPromise(options) ? Promise.resolve(options).then(dedupeOptions) : dedupeOptions(options);
		},
		createMiddleware
	};
};
/**
* Server functions answer only their own console's pages: a request
* another site sends, such as a form that posts to one, gets 403. TanStack
* Start adds this check itself only while no `start.ts` exists, so it is
* listed here, and `start.spec.ts` keeps it listed.
*/
var sameOriginServerFunctions = createCsrfMiddleware({ filter: (context) => context.handlerType === "serverFn" });
/**
* The local console's lock, before any page, server function, or route:
* this machine's `Host` only, changes from its own pages only, and the
* run's session for every page, server function, and route. A hosted
* console has none: its sign-in guards it.
*/
var localConsoleGuard = createMiddleware().server(async ({ request, next }) => {
	const { default: guard } = await import("./request-guard-BPLyogIN.mjs");
	return await guard?.(request) ?? next();
});
var startInstance = createStart(() => ({ requestMiddleware: [sameOriginServerFunctions, localConsoleGuard] }));
//#endregion
export { startInstance };
