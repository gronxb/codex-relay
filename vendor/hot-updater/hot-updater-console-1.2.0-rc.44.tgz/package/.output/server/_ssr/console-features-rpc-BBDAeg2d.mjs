import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/console-features-rpc-BBDAeg2d.js
var getConsoleFeaturesRpc_createServerFn_handler = createServerRpc({
	id: "82ec3500e57f9e81dac6d3f3a7bd9e34915da3121429beec87b7ad153dc6eafe",
	name: "getConsoleFeaturesRpc",
	filename: "src/lib/console-features-rpc.ts"
}, (opts) => getConsoleFeaturesRpc.__executeServer(opts));
var getConsoleFeaturesRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(getConsoleFeaturesRpc_createServerFn_handler, async () => {
	const { prepareConfig } = await import("./config.server-CvAlgb8E.mjs");
	const { runtime } = await prepareConfig();
	return {
		features: await runtime.features(),
		remote: runtime.remote
	};
});
//#endregion
export { getConsoleFeaturesRpc_createServerFn_handler };
