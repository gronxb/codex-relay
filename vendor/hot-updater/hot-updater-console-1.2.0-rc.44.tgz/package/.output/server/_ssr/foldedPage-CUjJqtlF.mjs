//#region node_modules/.nitro/vite/services/ssr/assets/foldedPage-CUjJqtlF.js
var SEPARATOR = ".";
var ID = /^[0-9A-Za-z-]+$/u;
var parseCursor = (token) => {
	const [mark, ...ids] = token.split(SEPARATOR);
	if ((mark === "s" || mark === "t") && ids.length > 0) {
		if (!ids.every((id) => ID.test(id))) throw new Error("Invalid page cursor.");
		return {
			id: ids[0],
			history: ids.slice(1),
			complete: mark === "s"
		};
	}
	if (!ID.test(token)) throw new Error("Invalid page cursor.");
	return {
		id: token,
		history: [],
		complete: false
	};
};
var cursorToken = (ids, complete) => {
	const kept = ids.slice(0, 21);
	return [complete && kept.length === ids.length ? "s" : "t", ...kept].join(SEPARATOR);
};
/**
* Reads from `after` in `order`, a chunk at a time, while the budget lasts,
* until it finds the ordinary row past `size` of them: the first of the page
* beyond, which is left out (`beyond`). `ended` when the index ran out.
*/
async function scan(read, classify, order, after, size, budget, pinned) {
	const rows = [];
	let ordinary = 0;
	let cursor = after;
	let pageTop;
	while (budget.left > 0) {
		const limit = Math.min(50, budget.left);
		const chunk = await read({
			order,
			limit,
			...cursor === void 0 ? {} : { after: cursor }
		});
		budget.left -= chunk.length;
		pageTop ??= chunk[0]?.id;
		const ordinaryIds = chunk.length === 0 ? /* @__PURE__ */ new Set() : await classify(chunk, {
			budget,
			order,
			...order === "desc" && after !== void 0 && pageTop !== void 0 ? { newerThan: pageTop } : {}
		});
		for (const row of chunk) {
			const isOrdinary = ordinaryIds.has(row.id);
			if (isOrdinary && ordinary === size) return {
				rows,
				ended: false,
				beyond: true
			};
			if (isOrdinary) ordinary += 1;
			rows.push({
				row,
				ordinary: isOrdinary,
				shown: isOrdinary || row.id === pinned
			});
		}
		if (chunk.length < limit) return {
			rows,
			ended: true,
			beyond: false
		};
		cursor = chunk.at(-1).id;
	}
	return {
		rows,
		ended: false,
		beyond: false
	};
}
/**
* Rows newest first as entries: each run of folded rows one fold. `above`
* is the row over the first one; `topContinues` and `bottomContinues` say a
* run at either edge goes on past the page.
*/
var entriesOf = (rows, above, { topContinues = false, bottomContinues = false } = {}) => {
	const entries = [];
	let run = [];
	let from = above;
	const close = (continues) => {
		if (run.length === 0) return;
		entries.push({
			kind: "fold",
			count: Math.min(run.length, 100),
			more: run.length > 100 || continues,
			...from === void 0 ? {} : { from },
			to: run.at(-1).id
		});
		run = [];
	};
	for (const { row, shown } of rows) if (shown) {
		close(entries.length === 0 && topContinues);
		entries.push({
			kind: "row",
			row
		});
		from = row.id;
	} else run.push(row);
	close(bottomContinues || entries.length === 0 && topContinues);
	return entries;
};
/**
* One page newest first. `before` is a cursor from `next` or `previous`;
* `after` reads the page above a row, when no cursor remembers it; neither
* is the newest page. A page holds `size` ordinary rows and the folds
* between them, and the run of folded rows under its last ordinary row, so
* the next page starts with an ordinary row. It reads at most `budget` rows:
* a page that runs out first ends in a fold that goes on, and the next page
* continues it.
*/
async function foldedPage({ read, classify, before, after, pinned, size = 20, budget = 200 }) {
	const left = { left: budget };
	if (after === void 0) {
		const cursor = before === void 0 ? void 0 : parseCursor(before);
		const { rows, ended } = await scan(read, classify, "desc", cursor?.id, size, left, pinned);
		const last = rows.at(-1)?.row.id;
		const outOfBudget = !ended && left.left === 0;
		const pages = cursor === void 0 ? [] : [cursor.id, ...cursor.history];
		const complete = cursor === void 0 || cursor.complete;
		const previous = () => {
			if (cursor === void 0) return void 0;
			if (cursor.history.length > 0) return { before: cursorToken(cursor.history, cursor.complete) };
			if (cursor.complete) return {};
			return { after: rows[0]?.row.id ?? cursor.id };
		};
		const previousPage = previous();
		return {
			entries: entriesOf(rows, cursor?.id, { bottomContinues: outOfBudget }),
			...!ended && last !== void 0 ? { next: cursorToken([last, ...pages], complete) } : {},
			...previousPage === void 0 ? {} : { previous: previousPage }
		};
	}
	const { rows, ended, beyond } = await scan(read, classify, "asc", after, size, left, pinned);
	let top = rows.length;
	let above;
	if (beyond) {
		while (top > 0 && !rows[top - 1].ordinary) top -= 1;
		above = rows[top]?.row.id;
	} else if (!ended && rows.length > 0) {
		top -= 1;
		above = rows[top].row.id;
	}
	const page = rows.slice(0, top).reverse();
	const first = page[0]?.row.id;
	return {
		entries: entriesOf(page, ended ? void 0 : above, { topContinues: !ended && !beyond }),
		...page.length > 0 ? { next: cursorToken([page.at(-1).row.id], false) } : {},
		...!ended && first !== void 0 ? { previous: { after: first } } : {}
	};
}
/**
* One chunk of a fold's rows, newest first: the rows under `from` (or under
* `after`, the last row of the chunk before) down to `to`. `next` is the
* `after` of the next chunk, while the fold goes on.
*/
async function readFold({ read, from, to, after, limit = 50 }) {
	const cursor = after ?? from;
	const rows = await read({
		order: "desc",
		limit,
		through: to,
		...cursor === void 0 ? {} : { after: cursor }
	});
	const last = rows.at(-1)?.id;
	return {
		rows,
		...rows.length < limit || last === to || last === void 0 ? {} : { next: last }
	};
}
//#endregion
export { readFold as n, foldedPage as t };
