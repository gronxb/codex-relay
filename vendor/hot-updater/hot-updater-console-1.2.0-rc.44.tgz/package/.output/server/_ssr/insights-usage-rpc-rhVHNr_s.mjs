import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
import { t as readAppUsageInput } from "./insights-usage-BVm7CDw9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-usage-rpc-rhVHNr_s.js
var getAppUsageReportRpc_createServerFn_handler = createServerRpc({
	id: "8a98cd9c178e4a54185d62c25a95f09d3d59850c43d3f5baa1563e1614ad942e",
	name: "getAppUsageReportRpc",
	filename: "src/lib/insights-usage-rpc.ts"
}, (opts) => getAppUsageReportRpc.__executeServer(opts));
var getAppUsageReportRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => {
	readAppUsageInput(input);
	return {
		platform: input.platform,
		channel: input.channel,
		appVersion: input.appVersion,
		window: input.window
	};
}).handler(getAppUsageReportRpc_createServerFn_handler, async ({ data }) => {
	const [{ prepareConfig }, { getAppUsageReport }, { requireFeature }] = await Promise.all([
		import("./config.server-CvAlgb8E.mjs"),
		import("./insightsUsage-lPKyRC2o.mjs"),
		import("./runtime.server-BUbb281Z.mjs")
	]);
	const { runtime } = await prepareConfig();
	return getAppUsageReport(await requireFeature(runtime, "insightsAnalytics"), data);
});
//#endregion
export { getAppUsageReportRpc_createServerFn_handler };
