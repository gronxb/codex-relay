import { i as __toESM } from "../_runtime.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { B as Download, K as CircleAlert, V as Copy, X as ChevronDown, Z as Check, g as RotateCcw, it as ArrowRightLeft, l as Sparkles, st as Activity, u as Smartphone } from "../_libs/lucide-react.mjs";
import { a as SheetContent, c as SheetTitle, i as Sheet, l as SheetTrigger, o as SheetDescription, s as SheetHeader, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as Badge } from "./badge-o8QNRxtw.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as EmptyHeader, o as EmptyTitle, r as EmptyDescription, t as Empty } from "./empty-qtSrrSOA.mjs";
import { n as describeFailure } from "./insights-failures-DGO2_3Vx.mjs";
import { s as isBuiltinBundle, t as BuiltinBundleBadge } from "./InsightsPageHeader-DdY_p5TY.mjs";
import { t as HashValueDisplay } from "./HashValueDisplay-BAS89lvP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/EventDetails-DNlQeQSr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var eventTypes = {
	UPDATE_DOWNLOADED: {
		label: "Downloaded",
		description: "Downloaded. It launches when the app restarts.",
		variant: "default",
		icon: Download
	},
	UPDATE_APPLIED: {
		label: "Launched",
		description: "The app restarted into the downloaded bundle.",
		variant: "success",
		icon: Check
	},
	RECOVERED: {
		label: "Crashed",
		description: "Crashed on the bundle and rolled back.",
		variant: "warning",
		icon: RotateCcw
	},
	UPDATE_FAILED: {
		label: "Update failed",
		description: "An update check, download, or install failed.",
		variant: "destructive",
		icon: CircleAlert
	},
	UNCHANGED: {
		label: "Launch",
		description: "The app launched; the report changed nothing.",
		variant: "secondary",
		icon: Activity
	}
};
/**
* A kept UNCHANGED report, named by what it changed: an installation first
* seen, an App Store update, a launch with no apply report, an adopted
* release, or a channel switch.
*/
var changeTypeOf = (event) => {
	const { kinds = [], previous } = event.change ?? {};
	if (kinds.includes("first_seen")) return {
		label: "First seen",
		description: "The installation's first report to this server.",
		variant: "secondary",
		icon: Sparkles
	};
	if (kinds.includes("app_version") || kinds.includes("native_build")) return {
		label: "App updated",
		description: previous && previous.appVersion !== event.appVersion ? `From app ${previous.appVersion} to ${event.appVersion}.` : "A new build of the same app version.",
		variant: "secondary",
		icon: Smartphone
	};
	if (kinds.includes("bundle")) return {
		label: "Launched",
		description: "Seen running this bundle; the report of the restart into it never arrived.",
		variant: "success",
		icon: Check
	};
	if (kinds.includes("release")) return {
		label: "Release adopted",
		description: "The bundle it runs now ships under another release.",
		variant: "secondary",
		icon: ArrowRightLeft
	};
	if (kinds.includes("channel")) return {
		label: "Channel changed",
		description: previous ? `From ${previous.channel} to ${event.channel}.` : "It reports on another channel.",
		variant: "secondary",
		icon: ArrowRightLeft
	};
	return eventTypes.UNCHANGED;
};
/** How the console names an event's type. */
var eventTypeOf = (event) => event.type === "UNCHANGED" && event.change ? changeTypeOf({
	change: event.change,
	appVersion: event.appVersion ?? "",
	channel: event.channel ?? ""
}) : eventTypes[event.type];
function useInsightsTimeFormat() {
	const [timeZone, setTimeZone] = (0, import_react.useState)("UTC");
	(0, import_react.useEffect)(() => {
		setTimeZone(Intl.DateTimeFormat().resolvedOptions().timeZone);
	}, []);
	return new Intl.DateTimeFormat("en", {
		timeZone,
		timeZoneName: "shortOffset",
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hourCycle: "h23"
	});
}
function formatInsightsTimestamp(value, formatter) {
	const parts = Object.fromEntries(formatter.formatToParts(new Date(value)).map(({ type, value }) => [type, value]));
	const offset = parts.timeZoneName === "GMT" ? "GMT+0" : parts.timeZoneName;
	return `${parts.year}/${parts.month}/${parts.day} ${parts.hour}:${parts.minute}:${parts.second} ${offset}`;
}
function EventTimestamp({ value, formatter, touch = false }) {
	const date = new Date(value);
	const localTime = formatInsightsTimestamp(value, formatter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "group/time",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
			className: `cursor-pointer list-none rounded-md outline-none focus-visible:ring-2 focus-visible:ring-ring/30 [&::-webkit-details-marker]:hidden ${touch ? "flex min-h-11 items-center" : ""}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
					dateTime: date.toISOString(),
					className: "whitespace-nowrap",
					children: localTime
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					"aria-hidden": "true",
					className: "size-3 text-muted-foreground group-open/time:rotate-180"
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted-foreground",
			children: date.toISOString().replace("T", " ").replace("Z", " UTC")
		})]
	});
}
var deliveries = {
	patch: "A patch delivered it.",
	manifest: "Only the changed files were downloaded.",
	archive: "The full archive was downloaded."
};
/** What the event's report added: where an update failed, or how a bundle arrived. */
var eventNote = (event) => {
	if (event.late) return "Counted nothing: the installation had already downloaded or run this bundle.";
	if (event.impliedDownload) return "Its download report never arrived; the download counted with it.";
	if (event.type === "UPDATE_FAILED" && event.failure) return describeFailure(event.failure);
	if (event.type === "UPDATE_DOWNLOADED" && event.delivery) {
		const delivered = deliveries[event.delivery] ?? null;
		return event.patchFallback ? `The patch failed. ${delivered ?? ""}`.trim() : delivered;
	}
	return null;
};
function HttpResponseBody({ response }) {
	const copyBody = async () => {
		try {
			await navigator.clipboard.writeText(response.body);
			toast.success("Response body copied");
		} catch {
			toast.error("Could not copy the response body");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-label": "Response body",
		className: "flex min-w-0 flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: "Response body"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					variant: "outline",
					className: "min-h-11",
					disabled: response.body === null || response.body === "",
					onClick: () => void copyBody(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
						"aria-hidden": "true",
						"data-icon": "inline-start"
					}), " Copy body"]
				})]
			}),
			response.bodyTruncated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Truncated to the 4 KiB reporting limit. Copy includes only the stored text."
			}) : null,
			response.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "rounded-md border bg-muted/30 p-4 font-mono text-xs leading-relaxed whitespace-pre-wrap wrap-anywhere",
				children: response.body
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, { children: response.body === null ? "Response body unavailable" : "Empty response body" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, { children: response.body === null ? "The client received the HTTP status but could not read the body." : response.status === 304 ? "The server returned no body. The client can reuse its cached catalog." : "The server returned no text in this response." })] }) })
		]
	});
}
function HttpResponseDetails({ event }) {
	const response = event.httpResponse;
	const formatter = useInsightsTimeFormat();
	const status = response.status === 304 ? "Not modified" : response.status >= 500 ? "Server error" : response.status >= 400 ? "Request error" : response.status >= 300 ? "Redirect" : "Success";
	const resource = response.resource === "catalog" ? "Catalog" : "Artifact";
	const context = [
		["App", event.platform && `${event.platform === "ios" ? "iOS" : "Android"} ${event.appVersion}`],
		["Channel", event.channel],
		["SDK", event.sdkVersion],
		["Installation", event.installId]
	].filter(([, value]) => value != null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTrigger, {
		"aria-label": `View ${resource.toLowerCase()} response: HTTP ${response.status}`,
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			variant: "ghost",
			className: "-ml-2 h-auto min-h-11 justify-start"
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
			variant: response.status >= 400 ? "destructive" : "secondary",
			children: ["HTTP ", response.status]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [resource, " response"] })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
		className: "data-[side=right]:w-full data-[side=right]:sm:max-w-2xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
			className: "border-b pr-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "HTTP response" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, { children: [
				resource,
				" · HTTP ",
				response.status,
				" · ",
				status,
				". Most recent response available when this report was created."
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col gap-6 overflow-y-auto p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": "Request",
					className: "flex min-w-0 flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Request"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs leading-relaxed whitespace-pre-wrap wrap-anywhere",
							children: ["GET ", response.path]
						}),
						response.receivedAtMs != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [
								"Response received",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventTimestamp, {
									value: response.receivedAtMs,
									formatter
								})
							]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HttpResponseBody, { response }),
				context.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": "Response context",
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Response context"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "grid grid-cols-2 gap-x-6 gap-y-4",
						children: context.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-muted-foreground",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm wrap-anywhere",
								children: value
							})]
						}, label))
					})]
				}) : null
			]
		})]
	})] });
}
function EventTypeDetails({ event }) {
	const eventType = eventTypeOf(event);
	const Icon = eventType.icon;
	const note = eventNote(event);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col items-start gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
				variant: eventType.variant,
				className: "gap-1 whitespace-nowrap [&_svg]:size-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { "aria-hidden": "true" }), eventType.label]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-56 whitespace-pre-wrap wrap-anywhere text-xs text-muted-foreground",
				children: event.type === "UPDATE_FAILED" && note ? note : eventType.description
			}),
			event.httpResponse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HttpResponseDetails, { event }) : null,
			event.type === "UPDATE_FAILED" && event.failure?.errorStack ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "w-full max-w-56 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-muted-foreground",
					children: "Stack trace"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-2 max-h-64 overflow-auto whitespace-pre-wrap wrap-anywhere font-mono",
					children: event.failure.errorStack
				})]
			}) : null,
			event.type !== "UPDATE_FAILED" && note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-56 whitespace-normal text-xs text-muted-foreground",
				children: note
			}) : null
		]
	});
}
function EventBundleTransition({ event, touch = false }) {
	const downloaded = event.type === "UPDATE_DOWNLOADED";
	const failed = event.type === "UPDATE_FAILED";
	const targeted = !failed || event.failure?.stage !== "check";
	const moved = event.type === "UNCHANGED" && event.change?.kinds.includes("bundle") === true && event.change.previous !== void 0;
	const fromBundleId = moved ? event.change.previous.bundleId : event.fromBundleId;
	const changed = downloaded || failed || moved || event.type === "UPDATE_APPLIED" || event.type === "RECOVERED";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
		className: "grid grid-cols-[auto_minmax(0,1fr)] items-center gap-x-2 gap-y-2",
		children: [fromBundleId && changed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted-foreground",
			children: downloaded || failed ? "Running" : "From"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
			className: "flex min-w-0 flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
				value: fromBundleId,
				buttonClassName: touch ? "min-h-11 px-3" : void 0
			}), isBuiltinBundle(fromBundleId, moved ? event.change.previous.minBundleId : event.minBundleId) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuiltinBundleBadge, {}) : null]
		})] }) : null, targeted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted-foreground",
			children: downloaded ? "Pending" : failed ? "Target" : changed ? "To" : "Current"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
			className: "flex min-w-0 flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashValueDisplay, {
				value: event.toBundleId,
				buttonClassName: touch ? "min-h-11 px-3" : void 0
			}), isBuiltinBundle(event.toBundleId, event.minBundleId) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuiltinBundleBadge, {}) : null]
		})] }) : null]
	});
}
//#endregion
export { HttpResponseDetails as a, HttpResponseBody as i, EventTimestamp as n, useInsightsTimeFormat as o, EventTypeDetails as r, EventBundleTransition as t };
