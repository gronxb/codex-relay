import { n as createStartHandler, r as defaultStreamHandler, t as createServerEntry$1 } from "./server-CUH0Oy00.mjs";
//#region node_modules/.nitro/vite/services/ssr/index.js
var fetch = createStartHandler(defaultStreamHandler);
var createServerEntry = createServerEntry$1;
var server_default = createServerEntry({ fetch });
//#endregion
export { createServerEntry, server_default as default };
