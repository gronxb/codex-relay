import { i as __toESM } from "../_runtime.mjs";
import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { Et as require_react, Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { D as LoaderCircle, H as Clipboard, Z as Check, _ as RefreshCw, f as ShieldOff, i as TriangleAlert, k as KeyRound, v as Plus } from "../_libs/lucide-react.mjs";
import { A as createSsrRpc, C as Skeleton, S as SidebarTrigger, n as Input, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as CardHeader, n as CardContent, o as CardTitle, t as Card } from "./card-CsUxqR3-.mjs";
import { a as Badge, i as AlertTitle, n as AlertAction, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { a as FieldLabel, i as FieldGroup, n as FieldDescription, r as FieldError, t as Field } from "./field-BVbdqLG6.mjs";
import { a as AlertDialogDescription, c as AlertDialogMedia, i as AlertDialogContent, l as AlertDialogTitle, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog$1, u as AlertDialogTrigger } from "./alert-dialog-ByY_ghMv.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog$1 } from "./dialog-CNWOO08-.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-4qgdiham.mjs";
import { i as useQuery, n as useMutation, s as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-keys-B0kG9UlP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var parseName = (input) => {
	const name = typeof input === "object" && input !== null ? Reflect.get(input, "name") : void 0;
	if (typeof name !== "string") throw new TypeError("API key name must be a string.");
	return { name };
};
var parseId = (input) => {
	const id = typeof input === "object" && input !== null ? Reflect.get(input, "id") : void 0;
	if (typeof id !== "string" || !/^api-[A-Za-z0-9_-]{43}$/u.test(id)) throw new TypeError("Invalid API key id.");
	return { id };
};
/** API key management, once the console's access check and the feature guard pass. */
var listApiKeysRpc = createServerFn({ method: "GET" }).middleware([consoleAccess]).handler(createSsrRpc("2c7f3cdb9bd3cab2c026a48abdc84c362db0362924a08679052a325640aec56b"));
var createApiKeyRpc = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator(parseName).handler(createSsrRpc("68a2d94ee016be64936401f5eba60ab08a47ff373e1cf9de48e4413336e6034b"));
var revokeApiKeyRpc = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator(parseId).handler(createSsrRpc("a1cb80b19ca72a64fb631ca28ebb9b6941db245983de082d5dd3203ec2eef795"));
var apiKeyQueryKeys = { list: ["api-keys", "list"] };
var useApiKeysQuery = () => useQuery({
	queryKey: apiKeyQueryKeys.list,
	queryFn: () => listApiKeysRpc()
});
var useCreateApiKeyMutation = () => {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (name) => createApiKeyRpc({ data: { name } }),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: apiKeyQueryKeys.list });
		}
	});
};
var useRevokeApiKeyMutation = () => {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (id) => revokeApiKeyRpc({ data: { id } }),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: apiKeyQueryKeys.list });
		}
	});
};
var formatCreatedAt = (createdAt) => new Date(createdAt).toISOString().slice(0, 10);
function CreateApiKeyDialog() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [apiKey, setApiKey] = (0, import_react.useState)(null);
	const create = useCreateApiKeyMutation();
	const normalizedName = name.trim();
	const nameError = normalizedName.length > 64 ? "Name must be 64 characters or fewer." : null;
	const reset = () => {
		setName("");
		setApiKey(null);
		create.reset();
	};
	const handleOpenChange = (nextOpen) => {
		setOpen(nextOpen);
		if (!nextOpen) reset();
	};
	const handleSubmit = async (event) => {
		event.preventDefault();
		if (normalizedName.length === 0 || nameError !== null) return;
		try {
			setApiKey((await create.mutateAsync(normalizedName)).apiKey);
			toast.success("API key created");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Unable to create API key");
		}
	};
	const copyKey = async () => {
		if (apiKey === null) return;
		try {
			await navigator.clipboard.writeText(apiKey);
			toast.success("API key copied");
		} catch {
			toast.error("Unable to copy API key");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
		className: "max-md:h-11",
		onClick: () => setOpen(true),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), "Create API key"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open,
		onOpenChange: handleOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			showCloseButton: apiKey === null,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: apiKey === null ? "Create API key" : "Save your API key" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: apiKey === null ? "Name the app or environment that will use this key." : "This key is shown once. Store it securely before closing." })] }), apiKey === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldGroup, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					"data-invalid": nameError !== null || void 0,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "api-key-name",
							children: "Name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "api-key-name",
							autoComplete: "off",
							maxLength: 65,
							onChange: (event) => setName(event.target.value),
							placeholder: "Production app",
							value: name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "Use a name you can identify before revoking the key." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: nameError })
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
						disabled: create.isPending || normalizedName.length === 0 || nameError !== null,
						type: "submit",
						children: [create.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							"data-icon": "inline-start",
							className: "animate-spin motion-reduce:animate-none"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { "data-icon": "inline-start" }), "Create API key"]
					})
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				htmlFor: "created-api-key",
				children: "API key"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "created-api-key",
					className: "font-mono",
					readOnly: true,
					value: apiKey
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
					onClick: copyKey,
					type: "button",
					variant: "outline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clipboard, { "data-icon": "inline-start" }), "Copy"]
				})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
				onClick: () => handleOpenChange(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { "data-icon": "inline-start" }), "Done"]
			}) })] })]
		})
	})] });
}
function RevokeApiKeyDialog({ record }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const revoke = useRevokeApiKeyMutation();
	const handleRevoke = async (event) => {
		event.preventDefault();
		try {
			await revoke.mutateAsync(record.id);
			setOpen(false);
			toast.success("API key revoked");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Unable to revoke API key");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog$1, {
		open,
		onOpenChange: (nextOpen) => {
			if (!revoke.isPending) setOpen(nextOpen);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTrigger, {
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
				className: "max-md:h-11",
				size: "sm",
				variant: "ghost"
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, { "data-icon": "inline-start" }), "Revoke"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogMedia, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, { children: [
				"Revoke ",
				record.name,
				"?"
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
				"Apps using ",
				record.prefix,
				"… will immediately lose OTA update and insights access. This action cannot be undone."
			] })
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
			disabled: revoke.isPending,
			children: "Cancel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
			disabled: revoke.isPending,
			onClick: (event) => void handleRevoke(event),
			variant: "destructive",
			children: "Revoke API key"
		})] })] })]
	});
}
function ApiKeysPage() {
	const apiKeys = useApiKeysQuery();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
			className: "flex-row items-center justify-between space-y-0 border-b px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "API keys" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateApiKeyDialog, {})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-0",
			children: apiKeys.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "API keys couldn't be loaded" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Check your connection and try again." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							onClick: () => void apiKeys.refetch(),
							size: "xs",
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry"]
						}) })
					]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
				"aria-label": "API keys",
				className: "table-fixed",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Key" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "w-32",
						children: "Created"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "w-24 text-right",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Actions"
						})
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: apiKeys.isLoading ? Array.from({ length: 3 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
						className: "space-y-2 py-3",
						children: [
							index === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Loading API keys"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3.5 w-32" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-20" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3.5 w-20" }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "ml-auto h-6 w-16" }) })
				] }, index)) : apiKeys.data?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					colSpan: 3,
					className: "h-40 text-center text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-xs flex-col items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-5" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-foreground",
								children: "No API keys"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Create an API key to connect an app." })
						]
					})
				}) }) : apiKeys.data?.map((apiKey) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
					className: apiKey.revoked_at_ms === null ? void 0 : "text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "whitespace-normal py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "break-words font-medium text-foreground",
									children: apiKey.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted-foreground",
									children: [apiKey.prefix, "…"]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-xs text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
								dateTime: new Date(apiKey.created_at_ms).toISOString(),
								children: formatCreatedAt(apiKey.created_at_ms)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right",
							children: apiKey.revoked_at_ms === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RevokeApiKeyDialog, { record: apiKey }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: "Revoked"
							})
						})
					]
				}, apiKey.id)) })]
			})
		})]
	});
}
function ApiKeysRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-10 flex shrink-0 flex-wrap items-center gap-x-3 gap-y-1 border-b bg-background px-3 py-3 sm:min-h-12 sm:flex-nowrap sm:bg-card/70 sm:px-4 sm:backdrop-blur-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
						"aria-hidden": "true",
						className: "size-3.5 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-sm font-medium",
						children: "API keys"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "basis-full pl-9 text-xs text-muted-foreground sm:basis-auto sm:pl-0",
					children: "API keys can download OTA updates and submit insights only."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 min-w-0 flex-1 overflow-y-auto bg-muted/5 p-3 sm:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-5xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApiKeysPage, {})
			})
		})]
	});
}
//#endregion
export { ApiKeysRoute as component };
