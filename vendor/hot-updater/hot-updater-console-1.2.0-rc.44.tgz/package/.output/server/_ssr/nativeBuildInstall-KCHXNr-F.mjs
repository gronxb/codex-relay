import { D as nativeBuildManifestPath, S as nativeBuildDownloadPath, c as NATIVE_BUILD_INSTALL_LINK_TTL_MS } from "./native-builds-lEyKQemV.mjs";
import { issueNativeBuildDownloadLink, refuseNativeBuildDownloadToken } from "./nativeBuildDownloadLink-CgZaRE6C.mjs";
import { listIosDevices } from "./iosDevices-mJefvrvf.mjs";
import { t as publicConsoleBase } from "./publicConsoleBase-wTKw3_iB.mjs";
import { normalizeIosUdid, readIpaInstallInfo } from "./native-artifact-D4ZISXRZ.mjs";
import { t as escapePlistText } from "./plistText-DkzlCfPI.mjs";
import { nativeBuildArtifactUrl } from "./nativeBuilds-S1_ZcH6M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nativeBuildInstall-KCHXNr-F.js
var KiB = 1024;
var MiB = 1024 * KiB;
/**
* What one request asks for at least: a zip entry's local header and, for
* something the size of a profile, its data, so reading one takes one request.
*/
var READ_AHEAD_BYTES = 64 * KiB;
/** How many requests' bytes stay at hand: the archive's tail, and its entries. */
var KEPT_BLOCKS = 4;
/** The most one IPA's reading downloads: a directory and a few small files. */
var MAX_BYTES = 16 * MiB;
/** The most requests one IPA's reading makes, past a dozen extensions' profiles. */
var MAX_REQUESTS = 24;
var REQUEST_TIMEOUT_MS = 15e3;
/** Why a remote artifact can't be read in parts. */
var RangeSourceError = class extends Error {
	name = "RangeSourceError";
};
/**
* The bytes of `url` by HTTP Range requests, without ever downloading the
* file: a server that answers a Range request with the whole file (200) is
* cut off at once, as is one that sends more than it was asked for. Reading
* stops at `MAX_BYTES` and `MAX_REQUESTS`.
*/
var httpRangeSource = ({ url, size, fetch = globalThis.fetch }) => {
	const blocks = [];
	let requests = 0;
	let downloaded = 0;
	const request = async (start, end) => {
		if (requests === MAX_REQUESTS) throw new RangeSourceError("Reading the artifact took too many requests.");
		const length = end - start;
		if (downloaded + length > MAX_BYTES) throw new RangeSourceError("Reading the artifact would download too much.");
		requests += 1;
		const response = await fetch(url, {
			headers: {
				range: `bytes=${start}-${end - 1}`,
				"accept-encoding": "identity"
			},
			signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
		});
		const contentRange = /^bytes (\d+)-(\d+)\/(\d+|\*)$/u.exec(response.headers.get("content-range") ?? "");
		if (response.status !== 206 || Number(contentRange?.[1]) !== start || Number(contentRange?.[2]) !== end - 1 || contentRange?.[3] !== "*" && Number(contentRange?.[3]) !== size || response.body === null) {
			await response.body?.cancel().catch(() => {});
			throw new RangeSourceError(`The storage answered ${response.status} to a Range request.`);
		}
		const bytes = new Uint8Array(length);
		const reader = response.body.getReader();
		let written = 0;
		try {
			for (;;) {
				const { done, value } = await reader.read();
				if (done) break;
				if (written + value.byteLength > length) throw new RangeSourceError("The storage sent more than it was asked.");
				bytes.set(value, written);
				written += value.byteLength;
			}
		} finally {
			await reader.cancel().catch(() => {});
		}
		if (written !== length) throw new RangeSourceError("The storage sent less than it was asked.");
		downloaded += length;
		return bytes;
	};
	return {
		size,
		async read(offset, length) {
			const end = Math.min(size, offset + length);
			if (offset >= end) return new Uint8Array(0);
			for (const block of blocks) if (block.start <= offset && end <= block.start + block.bytes.length) return block.bytes.subarray(offset - block.start, end - block.start);
			const bytes = await request(offset, Math.min(size, Math.max(end, offset + READ_AHEAD_BYTES)));
			blocks.push({
				start: offset,
				bytes
			});
			if (blocks.length > KEPT_BLOCKS) blocks.splice(1, 1);
			return bytes.subarray(0, end - offset);
		}
	};
};
/**
* What an IPA in storage installs as, or null when that can't be read in parts:
* a storage with no HTTPS download URL, one that ignores Range requests, or an
* artifact that isn't what it should be. It reads only the storage, and never
* logs the URL, which may be signed.
*/
var readNativeBuildInstallInfo = async (build, storage, fetch = globalThis.fetch) => {
	if (build.artifact_kind !== "ipa") return null;
	try {
		const url = await nativeBuildArtifactUrl(build, storage);
		if (url === null || new URL(url).protocol !== "https:") return null;
		return await readIpaInstallInfo(httpRangeSource({
			url,
			size: build.byte_size,
			fetch
		}));
	} catch (error) {
		console.warn(`Installation details unavailable: ${error instanceof Error ? error.message : String(error)}`);
		return null;
	}
};
var isExpired = ({ expiresAtMs }, now) => expiresAtMs !== null && expiresAtMs <= now;
/**
* The build a registered device's row names, when it is newer than `build`,
* of the same app (bundle ID, read from its IPA, and sandbox or not), on the
* same channel, or for a sandbox build, of the same sandbox scope on any
* channel, ad hoc, unexpired, and its IPA lists the device; null
* otherwise, and for a build gone or unreadable. Its row is read only for a
* registered device whose row names a newer build, and its IPA only when the
* row matches.
*/
var newerBuildListing = async (build, info, device, key, { core, storage, fetch, now }) => {
	const id = device.build_id;
	if (device.status !== "registered" || id === null || id <= build.id) return null;
	const newer = await core.getNativeBuild(id).catch(() => null);
	if (newer === null || newer.artifact_kind !== "ipa" || newer.platform !== build.platform || newer.is_sandbox !== build.is_sandbox || (build.is_sandbox ? newer.scope_key !== build.scope_key : newer.channel_id !== build.channel_id) || newer.export_method !== null && newer.export_method !== "ad-hoc") return null;
	const listing = await readNativeBuildInstallInfo(newer, storage, fetch);
	return listing !== null && listing.bundleId === info.bundleId && listing.distribution === "ad-hoc" && listing.devices.includes(key) && !isExpired(listing, now) ? id : null;
};
/**
* What an iPhone can do with a build, for a caller the Console already let in:
* one read of the build's row, and the IPA's few parts from storage. App Store
* Connect isn't asked, so this says what the IPA's bytes allow, which is what
* iOS enforces; registering a device changes nothing until a new IPA has it.
*/
var checkNativeBuildInstall = async (id, udid, { core, storage }, { request, now = Date.now(), fetch = globalThis.fetch, canApprove = async () => false } = {}) => {
	const build = await core.getNativeBuild(id);
	if (build === null) return { status: "unavailable" };
	const info = await readNativeBuildInstallInfo(build, storage, fetch);
	if (info === null) return { status: "unavailable" };
	if (info.distribution === "store") return { status: "store" };
	const expiresAt = info.expiresAtMs === null ? null : new Date(info.expiresAtMs).toISOString();
	if (expiresAt !== null && isExpired(info, now)) return {
		status: "expired",
		expiresAt
	};
	const key = udid === void 0 ? null : normalizeIosUdid(udid);
	const device = key === null ? "unknown" : info.distribution === "enterprise" || info.devices.includes(key) ? "included" : "not-included";
	const registry = device === "not-included" && key !== null ? await core.findIosDevice(key) : null;
	return {
		status: "installable",
		device,
		registry,
		newerBuild: registry === null || key === null ? null : await newerBuildListing(build, info, registry, key, {
			core,
			storage,
			fetch,
			now
		}),
		canApprove: registry?.apple_error == null ? false : await canApprove(),
		expiresAt,
		link: await issueNativeBuildDownloadLink(id, request, now, NATIVE_BUILD_INSTALL_LINK_TTL_MS)
	};
};
var installRefusal = (status, message) => new Response(message, {
	status,
	headers: {
		"cache-control": "no-store",
		"content-type": "text/plain; charset=utf-8"
	}
});
/**
* The manifest iOS installs a build from, at `/_hot-updater/native-builds/
* <id>/manifest.plist?t=<download token>`. The installer has no session, so the
* token is all it answers to, and it is checked before anything is read. It
* mints nothing: the manifest's IPA URL carries the same token.
*
* - 403: no token, or one that isn't this build's, or has expired;
* - 404: no such build, or not an IPA;
* - 409: an IPA that can't install this way (App Store export, expired profile);
* - 503: the IPA can't be read in parts.
*/
var serveNativeBuildManifest = async (request, id, loadDeps, fetch = globalThis.fetch) => {
	const token = new URL(request.url).searchParams.get("t");
	if (token === null) return installRefusal(403, "This install link isn't valid. Open the build's Console page for a new one.");
	const refused = await refuseNativeBuildDownloadToken(request, id, token);
	if (refused !== void 0) return refused;
	const { core, storage } = await loadDeps();
	const build = await core.getNativeBuild(id);
	if (build === null || build.artifact_kind !== "ipa") return installRefusal(404, "This build has no IPA to install.");
	const info = await readNativeBuildInstallInfo(build, storage, fetch);
	if (info === null) return installRefusal(503, "Installation details unavailable.");
	if (info.distribution === "store") return installRefusal(409, build.is_sandbox ? "This IPA is an App Store export, which doesn't install from a link." : "This IPA is an App Store export, which installs through TestFlight.");
	if (isExpired(info, Date.now())) return installRefusal(409, "This IPA's provisioning profile has expired. Rebuild it.");
	const manifest = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>items</key>
  <array>
    <dict>
      <key>assets</key>
      <array>
        <dict>
          <key>kind</key>
          <string>software-package</string>
          <key>url</key>
          <string>${escapePlistText(`${publicConsoleBase(request, nativeBuildManifestPath(id))}${nativeBuildDownloadPath(id)}?t=${encodeURIComponent(token)}`)}</string>
        </dict>
      </array>
      <key>metadata</key>
      <dict>
        <key>bundle-identifier</key>
        <string>${escapePlistText(info.bundleId)}</string>
        <key>bundle-version</key>
        <string>${escapePlistText(info.bundleVersion)}</string>
        <key>kind</key>
        <string>software</string>
        <key>title</key>
        <string>${escapePlistText(info.title)}</string>
      </dict>
    </dict>
  </array>
</dict>
</plist>
`;
	return new Response(manifest, { headers: {
		"cache-control": "private, no-store",
		"content-type": "text/xml; charset=utf-8",
		"referrer-policy": "no-referrer",
		"x-content-type-options": "nosniff"
	} });
};
/** The registry statuses whose devices an IPA's profile can list. */
var NAMED_STATUSES = ["registered", "approved"];
/**
* The devices an IPA's profile lists, read from storage as the install check
* reads it, each named by the device registry when it knows the UDID. The IPA
* decides: the registry only names what it lists. One build read, the IPA's
* few parts, and the registry's registered and approved devices.
*/
var readNativeBuildIpaDevices = async (id, { core, storage }, fetch = globalThis.fetch) => {
	const build = await core.getNativeBuild(id);
	if (build === null) return { status: "unavailable" };
	const info = await readNativeBuildInstallInfo(build, storage, fetch);
	if (info === null) return { status: "unavailable" };
	if (info.distribution === "store" || info.distribution === "enterprise") return { status: info.distribution };
	const rows = info.devices.length === 0 ? [] : (await Promise.all(NAMED_STATUSES.map((status) => listIosDevices(core, status)))).flat();
	const names = new Map(rows.map((row) => [row.udid, row.name]));
	return {
		status: "listed",
		devices: info.devices.map((udid) => ({
			udid,
			name: names.get(udid) ?? null
		}))
	};
};
//#endregion
export { RangeSourceError, checkNativeBuildInstall, httpRangeSource, readNativeBuildInstallInfo, readNativeBuildIpaDevices, serveNativeBuildManifest };
