import { l as createServerFn } from "./createServerFn-AQvBMBjJ.mjs";
import { t as consoleAccess } from "./console-access-mW5AcyIb.mjs";
import { t as createServerRpc } from "./createServerRpc-DJZel12M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ios-devices-rpc-Bj59mqiF.js
var STATUSES = [
	"pending",
	"approved",
	"registered"
];
var record = (input) => {
	if (typeof input !== "object" || input === null) throw new TypeError("Invalid input.");
	return input;
};
var text = (input, field, max = 2048) => {
	const value = record(input)[field];
	if (typeof value !== "string" || value.length === 0 || value.length > max) throw new TypeError(`Invalid ${field}.`);
	return value;
};
/**
* The registry over the Console's own assembly, with the signed-in viewer's
* rights: the access check runs first, in the middleware and again here.
*/
var registry = async () => {
	const [{ getRequest }, { prepareConfig }, { requireConsoleAccess }, devices] = await Promise.all([
		import("../_libs/_.mjs").then((n) => n.t),
		import("./config.server-CvAlgb8E.mjs"),
		import("./auth.server-BtwE9LLM.mjs"),
		import("./iosDevices-mJefvrvf.mjs")
	]);
	const request = getRequest();
	const [{ core, config }, principal] = await Promise.all([prepareConfig(request), requireConsoleAccess(request)]);
	return {
		request,
		core,
		principal,
		viewer: await devices.iosDeviceViewer(principal, config.deviceApprovers),
		devices
	};
};
var getIosDevices_createServerFn_handler = createServerRpc({
	id: "3a62744a539db57f5a29f39cec7fb03fd2817703b40d98e6da69e2f5e7ae6f3d",
	name: "getIosDevices",
	filename: "src/lib/ios-devices-rpc.ts"
}, (opts) => getIosDevices.__executeServer(opts));
var getIosDevices = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => {
	const status = input?.status;
	if (status !== void 0 && !STATUSES.includes(status)) throw new TypeError("Invalid status.");
	return status === void 0 ? {} : { status };
}).handler(getIosDevices_createServerFn_handler, async ({ data }) => {
	const [{ request, core, principal, viewer, devices }, { CONSOLE_SECRET_ENV }] = await Promise.all([registry(), import("./nativeBuildDownloadLink-CgZaRE6C.mjs")]);
	return {
		devices: await devices.listIosDevices(core, data.status),
		viewer,
		defaultName: devices.defaultDeviceName(principal),
		registration: await devices.deviceRegistration(request),
		secretName: CONSOLE_SECRET_ENV
	};
});
var getIosDevice_createServerFn_handler = createServerRpc({
	id: "7138a71df2ede8dd2c3db732d8d0ae10c56b85a8177dcdacf4e747b8087177c6",
	name: "getIosDevice",
	filename: "src/lib/ios-devices-rpc.ts"
}, (opts) => getIosDevice.__executeServer(opts));
var getIosDevice = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => ({ udid: text(input, "udid", 64) })).handler(getIosDevice_createServerFn_handler, async ({ data }) => {
	const [{ core }, { normalizeIosUdid }] = await Promise.all([registry(), import("./native-artifact-D4ZISXRZ.mjs")]);
	const udid = normalizeIosUdid(data.udid);
	return udid === null ? null : core.findIosDevice(udid);
});
var createIosDeviceProfileLink_createServerFn_handler = createServerRpc({
	id: "4b173c2b2f5ea074a1f10862282308f11f5a043c044d64b6f63e6a29d571ec64",
	name: "createIosDeviceProfileLink",
	filename: "src/lib/ios-devices-rpc.ts"
}, (opts) => createIosDeviceProfileLink.__executeServer(opts));
var createIosDeviceProfileLink = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => {
	const mode = record(input).mode;
	if (mode === "register") return {
		mode,
		name: text(input, "name", 100)
	};
	if (mode === "identify") return {
		mode,
		buildId: text(input, "buildId", 36)
	};
	throw new TypeError("Invalid mode.");
}).handler(createIosDeviceProfileLink_createServerFn_handler, async ({ data }) => {
	const { request, viewer, devices } = await registry();
	return devices.issueDeviceProfileLink(request, viewer, data);
});
var approveIosDevice_createServerFn_handler = createServerRpc({
	id: "7908c24ccc2674ce07a553a645b8f4790889975a80f424a05d71a9fb8ab49787",
	name: "approveIosDevice",
	filename: "src/lib/ios-devices-rpc.ts"
}, (opts) => approveIosDevice.__executeServer(opts));
var approveIosDevice = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => ({
	id: text(input, "id", 36),
	name: text(input, "name", 100)
})).handler(approveIosDevice_createServerFn_handler, async ({ data }) => {
	const { core, viewer, devices } = await registry();
	devices.requireDeviceApprover(viewer);
	return core.approveIosDevice(data.id, {
		name: devices.deviceName(data.name),
		approvedBy: viewer.email
	});
});
var renameIosDevice_createServerFn_handler = createServerRpc({
	id: "4c92dfeae76a6fc898d6f38941eeedaec1f3d118f51a6f31ebf0bb1cea3fcea4",
	name: "renameIosDevice",
	filename: "src/lib/ios-devices-rpc.ts"
}, (opts) => renameIosDevice.__executeServer(opts));
var renameIosDevice = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => ({
	id: text(input, "id", 36),
	name: text(input, "name", 100)
})).handler(renameIosDevice_createServerFn_handler, async ({ data }) => {
	const { core, viewer, devices } = await registry();
	devices.requireDeviceApprover(viewer);
	return core.renameIosDevice(data.id, devices.deviceName(data.name));
});
var removeIosDevice_createServerFn_handler = createServerRpc({
	id: "8e37ec67413ceba554adb2d4b15e53682595a089d4b431ba7965d4347fb500fc",
	name: "removeIosDevice",
	filename: "src/lib/ios-devices-rpc.ts"
}, (opts) => removeIosDevice.__executeServer(opts));
var removeIosDevice = createServerFn({ method: "POST" }).middleware([consoleAccess]).validator((input) => ({ udid: text(input, "udid", 40) })).handler(removeIosDevice_createServerFn_handler, async ({ data }) => {
	const { core, viewer, devices } = await registry();
	return devices.removeIosDevice(core, viewer, data.udid);
});
var getNativeBuildIpaDevices_createServerFn_handler = createServerRpc({
	id: "a11cb4014e6b23528f76382c43684798b0e84a6936aaba02c918e8f4e216e282",
	name: "getNativeBuildIpaDevices",
	filename: "src/lib/ios-devices-rpc.ts"
}, (opts) => getNativeBuildIpaDevices.__executeServer(opts));
var getNativeBuildIpaDevices = createServerFn({ method: "GET" }).middleware([consoleAccess]).validator((input) => ({ id: text(input, "id", 36) })).handler(getNativeBuildIpaDevices_createServerFn_handler, async ({ data }) => {
	const [{ prepareConfig }, { readNativeBuildIpaDevices }] = await Promise.all([import("./config.server-CvAlgb8E.mjs"), import("./nativeBuildInstall-KCHXNr-F.mjs")]);
	return readNativeBuildIpaDevices(data.id, await prepareConfig());
});
//#endregion
export { approveIosDevice_createServerFn_handler, createIosDeviceProfileLink_createServerFn_handler, getIosDevice_createServerFn_handler, getIosDevices_createServerFn_handler, getNativeBuildIpaDevices_createServerFn_handler, removeIosDevice_createServerFn_handler, renameIosDevice_createServerFn_handler };
