import { r as recoveryWindows, t as insightsPeriodEnd } from "./insights-recovery-Cdg3Msrj.mjs";
import { c as readUpdateFailuresInput, i as failureRate, t as checkFailureRate } from "./insights-failures-DGO2_3Vx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/updateFailures-BwDwIoNu.js
var total = (reports, count) => reports.reduce((sum, report) => sum + count(report), 0);
/** Counts summed by key, most first, then in key order. */
var summed = (rows, keyOf, merge) => {
	const groups = /* @__PURE__ */ new Map();
	for (const row of rows) {
		const key = keyOf(row);
		groups.set(key, [...groups.get(key) ?? [], row]);
	}
	return [...groups].map(([key, group]) => ({
		key,
		row: merge(group[0], group)
	})).sort((left, right) => right.row.events - left.row.events || (left.key < right.key ? -1 : left.key > right.key ? 1 : 0)).map(({ row }) => row);
};
/**
* Both platforms' failures as one report. An installation runs on one
* platform, so its counts and installation estimates add up; the period is
* complete only where both are.
*/
function mergeUpdateFailures(reports) {
	if (reports.length === 1) return reports[0];
	const sinceMs = reports.map(({ coverage }) => coverage.sinceMs);
	const latestSince = sinceMs.includes(null) ? null : Math.max(...sinceMs);
	const checks = reports.flatMap((report) => report.checks ? [report.checks] : []);
	const breakdowns = reports.flatMap((report) => report.breakdown ?? []);
	return {
		coverage: latestSince !== null && reports.every(({ coverage }) => coverage.kind === "complete") ? {
			kind: "complete",
			sinceMs: latestSince
		} : {
			kind: "partial",
			sinceMs: latestSince
		},
		measuredAtMs: Math.min(...reports.map((report) => report.measuredAtMs)),
		failedUpdates: total(reports, (report) => report.failedUpdates),
		failedInstallations: total(reports, (report) => report.failedInstallations),
		downloads: total(reports, (report) => report.downloads),
		patchDownloads: total(reports, (report) => report.patchDownloads),
		patchFallbacks: total(reports, (report) => report.patchFallbacks),
		...checks.length === 0 ? {} : { checks: {
			failures: checks.reduce((sum, row) => sum + row.failures, 0),
			failedInstallations: checks.reduce((sum, row) => sum + row.failedInstallations, 0),
			activeInstallations: checks.reduce((sum, row) => sum + row.activeInstallations, 0)
		} },
		...reports.some((report) => report.breakdown) ? { breakdown: summed(breakdowns, ({ stage, reason }) => JSON.stringify([stage, reason]), (first, group) => ({
			stage: first.stage,
			reason: first.reason,
			events: group.reduce((sum, row) => sum + row.events, 0),
			details: summed(group.flatMap((row) => row.details), ({ resource, httpStatus, originCode, transport }) => JSON.stringify([
				resource,
				httpStatus,
				originCode,
				transport
			]), (detail, details) => ({
				...detail,
				events: details.reduce((sum, row) => sum + row.events, 0)
			}))
		})) } : {}
	};
}
/**
* A release's or a channel's update failures over a period that ends with
* the current hour. Both platforms read each and merge, except a release's,
* which reads only the platform it was deployed to.
*/
async function getUpdateFailuresReport(reads, input, now = Date.now(), releases) {
	readUpdateFailuresInput(input);
	const end = insightsPeriodEnd(now);
	const timeRange = input.window === void 0 ? void 0 : {
		start: Math.max(0, end - recoveryWindows[input.window].durationMs),
		end
	};
	const scope = {
		channel: input.channel,
		...input.releaseId === void 0 ? {} : { releaseId: input.releaseId }
	};
	const release = input.platform === "all" && input.releaseId !== void 0 && releases ? await releases.getRelease(input.releaseId) : null;
	const platforms = input.platform !== "all" ? [input.platform] : release ? [release.platform] : ["ios", "android"];
	const read = async (range) => mergeUpdateFailures(await Promise.all(platforms.map((platform) => reads.getUpdateFailures({
		...scope,
		platform,
		...range === void 0 ? {} : { timeRange: range }
	}))));
	const previousRange = timeRange && timeRange.start >= timeRange.end - timeRange.start ? {
		start: timeRange.start - (timeRange.end - timeRange.start),
		end: timeRange.start
	} : void 0;
	const [failures, previous] = await Promise.all([read(timeRange), previousRange === void 0 ? void 0 : read(previousRange)]);
	return {
		...failures,
		startMs: timeRange?.start ?? null,
		endMs: end,
		...previous === void 0 ? {} : { previous: {
			attemptRate: failureRate(previous),
			checkRate: previous.checks ? checkFailureRate(previous.checks) : null,
			complete: previous.coverage.kind === "complete" && failures.coverage.kind === "complete"
		} }
	};
}
//#endregion
export { getUpdateFailuresReport, mergeUpdateFailures };
