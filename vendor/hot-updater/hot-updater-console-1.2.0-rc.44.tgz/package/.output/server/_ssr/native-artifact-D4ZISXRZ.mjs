import { n as assertCanonicalChannelName, o as encodeChannelKey, r as canonicalizeAppVersion, s as isUUIDv7 } from "./uuid-kZvLA0Ly-DNL0qBSj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-artifact-D4ZISXRZ.js
/** A `Blob`, such as Node's `fs.openAsBlob`, read by slices. */
var blobSource = (blob) => ({
	size: blob.size,
	async read(offset, length) {
		return new Uint8Array(await blob.slice(offset, Math.min(blob.size, offset + length)).arrayBuffer());
	}
});
/** Why an artifact can't be read, or can't serve as a native build. */
var NativeArtifactError = class extends Error {
	code;
	name = "NativeArtifactError";
	constructor(code, message) {
		super(message);
		this.code = code;
	}
};
var corrupt$1 = () => new NativeArtifactError("UNREADABLE", "The artifact's AndroidManifest.xml is corrupt.");
var view$3 = (bytes) => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
var RES_STRING_POOL_TYPE = 1;
var RES_XML_TYPE = 3;
var RES_XML_START_ELEMENT_TYPE = 258;
var RES_XML_END_ELEMENT_TYPE = 259;
var RES_XML_RESOURCE_MAP_TYPE = 384;
var UTF8_FLAG = 256;
var NO_INDEX = 4294967295;
/** A `ResXMLTree_attrExt`, and a `ResXMLTree_attribute`, in bytes. */
var ELEMENT_EXT_BYTES = 20;
var ATTRIBUTE_BYTES = 20;
/** How deep a manifest's elements nest: an AndroidManifest.xml, a few levels. */
var MAX_ELEMENT_DEPTH = 64;
var TYPE_REFERENCE = 1;
var TYPE_STRING = 3;
var TYPE_INT_DEC = 16;
var TYPE_INT_HEX = 17;
var TYPE_INT_BOOLEAN = 18;
/**
* How many bytes a manifest's strings decode to in all. A pool's offsets can
* point many indexes, or overlapping ranges, at one long string, so the
* manifest's own size bounds nothing.
*/
var DECODED_STRING_BYTES = 16777216;
/**
* A `ResStringPool` chunk's strings, decoded when an index is read: each
* offset once, against one budget, within the chunk.
*/
var readStringPool = (bytes, start, size) => {
	const data = view$3(bytes);
	const end = start + size;
	if (size < 28) throw corrupt$1();
	const count = data.getUint32(start + 8, true);
	const flags = data.getUint32(start + 16, true);
	const stringsStart = start + data.getUint32(start + 20, true);
	if (start + 28 + count * 4 > end || stringsStart > end) throw corrupt$1();
	const utf8 = (flags & UTF8_FLAG) !== 0;
	const decoder = new TextDecoder(utf8 ? "utf-8" : "utf-16le");
	const decoded = /* @__PURE__ */ new Map();
	let budget = DECODED_STRING_BYTES;
	return (index) => {
		if (index === NO_INDEX || index >= count) return "";
		const offset = data.getUint32(start + 28 + index * 4, true);
		const known = decoded.get(offset);
		if (known !== void 0) return known;
		let at = stringsStart + offset;
		let byteLength;
		if (at + 4 > end) throw corrupt$1();
		if (utf8) {
			at += bytes[at] & 128 ? 2 : 1;
			let length = bytes[at];
			if (length & 128) {
				length = (length & 127) << 8 | bytes[at + 1];
				at += 2;
			} else at += 1;
			byteLength = length;
		} else {
			let length = data.getUint16(at, true);
			if (length & 32768) {
				length = (length & 32767) << 16 | data.getUint16(at + 2, true);
				at += 4;
			} else at += 2;
			byteLength = length * 2;
		}
		budget -= byteLength;
		if (at + byteLength > end || budget < 0) throw corrupt$1();
		const text = decoder.decode(bytes.subarray(at, at + byteLength));
		decoded.set(offset, text);
		return text;
	};
};
var parseBinaryManifest = (bytes) => {
	const data = view$3(bytes);
	if (bytes.byteLength < 8 || data.getUint16(0, true) !== RES_XML_TYPE) throw corrupt$1();
	let stringAt = () => "";
	let resourceIds = [];
	const stack = [];
	let root = null;
	for (let at = data.getUint16(2, true); at + 8 <= bytes.byteLength;) {
		const type = data.getUint16(at, true);
		const headerSize = data.getUint16(at + 2, true);
		const size = data.getUint32(at + 4, true);
		if (size < 8 || at + size > bytes.byteLength) throw corrupt$1();
		if (type === RES_STRING_POOL_TYPE) stringAt = readStringPool(bytes, at, size);
		else if (type === RES_XML_RESOURCE_MAP_TYPE) {
			resourceIds = [];
			for (let i = at + headerSize; i + 4 <= at + size; i += 4) resourceIds.push(data.getUint32(i, true));
		} else if (type === RES_XML_START_ELEMENT_TYPE) {
			const ext = at + headerSize;
			const attributeStart = data.getUint16(ext + 8, true);
			const attributeSize = data.getUint16(ext + 10, true);
			const attributeCount = data.getUint16(ext + 12, true);
			if (headerSize < 16 || ext + ELEMENT_EXT_BYTES > at + size || attributeStart < ELEMENT_EXT_BYTES || attributeSize < ATTRIBUTE_BYTES || ext + attributeStart + attributeCount * attributeSize > at + size || stack.length >= MAX_ELEMENT_DEPTH) throw corrupt$1();
			const name = stringAt(data.getUint32(ext + 4, true));
			const attributes = [];
			for (let i = 0; i < attributeCount; i += 1) {
				const attr = ext + attributeStart + i * attributeSize;
				const nameIndex = data.getUint32(attr + 4, true);
				const raw = data.getUint32(attr + 8, true);
				const dataType = bytes[attr + 15];
				const value = data.getUint32(attr + 16, true);
				attributes.push({
					name: stringAt(nameIndex),
					resourceId: resourceIds[nameIndex] ?? 0,
					value: dataType === TYPE_STRING ? {
						type: "string",
						value: stringAt(raw === NO_INDEX ? value : raw)
					} : dataType === TYPE_INT_BOOLEAN ? {
						type: "boolean",
						value: value !== 0
					} : dataType === TYPE_INT_DEC || dataType === TYPE_INT_HEX ? {
						type: "int",
						value: value | 0
					} : dataType === TYPE_REFERENCE ? {
						type: "reference",
						id: value
					} : { type: "other" }
				});
			}
			stack.push({
				name,
				attributes,
				children: []
			});
		} else if (type === RES_XML_END_ELEMENT_TYPE) {
			const element = stack.pop();
			if (element === void 0) throw corrupt$1();
			const parent = stack.at(-1);
			if (parent === void 0) root ??= element;
			else parent.children.push(element);
		}
		at += size;
	}
	if (root === null) throw corrupt$1();
	return root;
};
/** A minimal protobuf reader: fields of one message, by number. */
var readMessage = (bytes) => {
	const fields = [];
	let at = 0;
	const varint = () => {
		let value = 0;
		let multiplier = 1;
		for (;;) {
			if (at >= bytes.byteLength) throw corrupt$1();
			const byte = bytes[at++];
			value += (byte & 127) * multiplier;
			if ((byte & 128) === 0) return value;
			multiplier *= 128;
			if (multiplier > 2 ** 63) throw corrupt$1();
		}
	};
	while (at < bytes.byteLength) {
		const key = varint();
		const field = Math.floor(key / 8);
		const wireType = key % 8;
		if (wireType === 0) fields.push({
			field,
			wireType,
			value: varint()
		});
		else if (wireType === 2) {
			const length = varint();
			if (at + length > bytes.byteLength) throw corrupt$1();
			fields.push({
				field,
				wireType,
				value: bytes.subarray(at, at + length)
			});
			at += length;
		} else if (wireType === 5) at += 4;
		else if (wireType === 1) at += 8;
		else throw corrupt$1();
	}
	return fields;
};
var decoder = new TextDecoder();
var bytesOf = (fields, field) => fields.filter((f) => f.field === field && f.value instanceof Uint8Array).map((f) => f.value);
var stringOf = (fields, field) => {
	const [value] = bytesOf(fields, field);
	return value === void 0 ? "" : decoder.decode(value);
};
var numberOf = (fields, field) => {
	const found = fields.find((f) => f.field === field && f.wireType === 0);
	return found === void 0 ? void 0 : found.value;
};
/** An `Item` of aapt2's Resources.proto, as an attribute's compiled value. */
var protoItemValue = (item, raw) => {
	const fields = readMessage(item);
	const [reference] = bytesOf(fields, 1);
	if (reference !== void 0) {
		const ref = readMessage(reference);
		return {
			type: "reference",
			id: numberOf(ref, 2) ?? 0,
			name: stringOf(ref, 3) || void 0
		};
	}
	const [str] = bytesOf(fields, 2);
	if (str !== void 0) return {
		type: "string",
		value: stringOf(readMessage(str), 1)
	};
	const [primitive] = bytesOf(fields, 7);
	if (primitive !== void 0) {
		const prim = readMessage(primitive);
		const boolean = numberOf(prim, 8);
		if (boolean !== void 0) return {
			type: "boolean",
			value: boolean !== 0
		};
		const int = numberOf(prim, 6) ?? numberOf(prim, 7);
		if (int !== void 0) return {
			type: "int",
			value: int | 0
		};
		if (raw !== "") return {
			type: "string",
			value: raw
		};
	}
	return null;
};
/** An `XmlElement` of aapt2's Resources.proto. */
var protoElement = (bytes, depth = 0) => {
	if (depth >= MAX_ELEMENT_DEPTH) throw corrupt$1();
	const fields = readMessage(bytes);
	const attributes = bytesOf(fields, 4).map((attribute) => {
		const attr = readMessage(attribute);
		const raw = stringOf(attr, 3);
		const [item] = bytesOf(attr, 6);
		return {
			name: stringOf(attr, 2),
			resourceId: numberOf(attr, 5) ?? 0,
			value: (item && protoItemValue(item, raw)) ?? {
				type: "string",
				value: raw
			}
		};
	});
	const children = bytesOf(fields, 5).flatMap((node) => {
		const [element] = bytesOf(readMessage(node), 1);
		return element === void 0 ? [] : [protoElement(element, depth + 1)];
	});
	return {
		name: stringOf(fields, 3),
		attributes,
		children
	};
};
/**
* An `.aab` module's `manifest/AndroidManifest.xml`, an `XmlNode` of
* aapt2's Resources.proto.
*/
var parseProtoManifest = (bytes) => {
	const [element] = bytesOf(readMessage(bytes), 1);
	if (element === void 0) throw corrupt$1();
	return protoElement(element);
};
var VERSION_CODE = 16843291;
var VERSION_NAME = 16843292;
var NAME = 16842755;
var VALUE = 16842788;
var RESOURCE = 16842789;
var SCHEME = 16842791;
var COMPONENTS = /* @__PURE__ */ new Set(["activity", "activity-alias"]);
var attributeOf = (element, resourceId, name) => element.attributes.find((attribute) => attribute.resourceId !== 0 ? attribute.resourceId === resourceId : attribute.name === name)?.value ?? null;
/** The values of a parsed manifest that import reads. */
var readAndroidManifest = (manifest) => {
	if (manifest.name !== "manifest") throw corrupt$1();
	const packageValue = manifest.attributes.find((attribute) => attribute.name === "package")?.value;
	const versionCode = attributeOf(manifest, VERSION_CODE, "versionCode");
	const application = manifest.children.find(({ name }) => name === "application");
	const metaData = /* @__PURE__ */ new Map();
	const launchers = [];
	const urlSchemes = /* @__PURE__ */ new Map();
	const componentMetaData = /* @__PURE__ */ new Map();
	const metaDataOf = (element, into) => {
		const name = attributeOf(element, NAME, "name");
		const value = attributeOf(element, VALUE, "value") ?? attributeOf(element, RESOURCE, "resource");
		if (name?.type === "string" && value !== null) into.set(name.value, value);
	};
	const stringAttribute = (element, id, name) => {
		const value = attributeOf(element, id, name);
		return value?.type === "string" ? value.value : null;
	};
	for (const element of application?.children ?? []) {
		if (COMPONENTS.has(element.name)) {
			const component = stringAttribute(element, NAME, "name");
			if (component === null) continue;
			for (const item of element.children) {
				if (item.name !== "meta-data") continue;
				const own = componentMetaData.get(component) ?? /* @__PURE__ */ new Map();
				metaDataOf(item, own);
				componentMetaData.set(component, own);
			}
			for (const filter of element.children) {
				if (filter.name !== "intent-filter") continue;
				const named = (child) => filter.children.filter(({ name }) => name === child).map((part) => stringAttribute(part, NAME, "name"));
				if (named("action").includes("android.intent.action.MAIN") && named("category").includes("android.intent.category.LAUNCHER") && !launchers.includes(component)) launchers.push(component);
				if (!named("action").includes("android.intent.action.VIEW")) continue;
				for (const data of filter.children) {
					if (data.name !== "data") continue;
					const scheme = stringAttribute(data, SCHEME, "scheme");
					if (scheme === null) continue;
					urlSchemes.set(component, [...urlSchemes.get(component) ?? [], scheme]);
				}
			}
			continue;
		}
		if (element.name !== "meta-data") continue;
		metaDataOf(element, metaData);
	}
	return {
		packageName: packageValue?.type === "string" ? packageValue.value : null,
		versionName: attributeOf(manifest, VERSION_NAME, "versionName"),
		versionCode: versionCode?.type === "int" ? versionCode.value : null,
		metaData,
		launchers,
		urlSchemes,
		componentMetaData
	};
};
/** How deep a plist nests: an Info.plist nests a few levels. */
var MAX_DEPTH = 64;
var corrupt = () => new NativeArtifactError("UNREADABLE", "The app's Info.plist is corrupt.");
var view$2 = (bytes) => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
/** A big-endian unsigned integer of `size` bytes. */
var uintAt = (bytes, offset, size) => {
	let value = 0;
	for (let i = 0; i < size; i += 1) value = value * 256 + bytes[offset + i];
	return value;
};
/** A binary property list (`bplist00`), as Xcode writes an app's Info.plist. */
var parseBinaryPlist = (bytes) => {
	if (bytes.byteLength < 40) throw corrupt();
	const trailer = bytes.byteLength - 32;
	const offsetSize = bytes[trailer + 6];
	const refSize = bytes[trailer + 7];
	const objectCount = uintAt(bytes, trailer + 8, 8);
	const top = uintAt(bytes, trailer + 16, 8);
	const tableOffset = uintAt(bytes, trailer + 24, 8);
	if (offsetSize < 1 || offsetSize > 8 || refSize < 1 || refSize > 8 || objectCount < 1 || top >= objectCount || tableOffset < 8 || tableOffset + objectCount * offsetSize > trailer) throw corrupt();
	const data = view$2(bytes);
	const seen = /* @__PURE__ */ new Set();
	const parsed = /* @__PURE__ */ new Map();
	let budget = 2 * bytes.byteLength + 4096;
	const spend = (units) => {
		budget -= units;
		if (budget < 0) throw corrupt();
	};
	const parse = (ref) => {
		if (ref >= objectCount) throw corrupt();
		const offset = uintAt(bytes, tableOffset + ref * offsetSize, offsetSize);
		if (offset < 8 || offset >= tableOffset) throw corrupt();
		const done = parsed.get(offset);
		if (done !== void 0) return done;
		if (seen.has(offset) || seen.size > MAX_DEPTH) throw corrupt();
		const value = parseObject(offset);
		parsed.set(offset, value);
		return value;
	};
	const parseObject = (offset) => {
		const marker = bytes[offset];
		const kind = marker >> 4;
		const info = marker & 15;
		/** `count` units of `unit` bytes from `start`, which must fit the objects. */
		const fits = (start, count, unit) => {
			if (start + count * unit > tableOffset) throw corrupt();
		};
		/**
		* A length in the marker, or in the integer object after it, and where
		* its `unit`-byte items start, all of which must fit the objects.
		*/
		const lengthAt = (unit) => {
			let length = info;
			let start = offset + 1;
			if (info === 15) {
				const sizeMarker = bytes[offset + 1];
				if (sizeMarker >> 4 !== 1 || (sizeMarker & 15) > 3) throw corrupt();
				const size = 1 << (sizeMarker & 15);
				fits(offset + 2, size, 1);
				length = uintAt(bytes, offset + 2, size);
				start = offset + 2 + size;
			}
			fits(start, length, unit);
			spend(length + 1);
			return [length, start];
		};
		switch (kind) {
			case 0: return info === 9 ? true : info === 8 ? false : null;
			case 1: {
				if (info > 3) throw corrupt();
				const size = 1 << info;
				fits(offset + 1, size, 1);
				return size === 8 ? Number(data.getBigInt64(offset + 1, false)) : uintAt(bytes, offset + 1, size);
			}
			case 2:
				if (info !== 2 && info !== 3) throw corrupt();
				fits(offset + 1, 1 << info, 1);
				return info === 2 ? data.getFloat32(offset + 1, false) : data.getFloat64(offset + 1, false);
			case 3:
				fits(offset + 1, 8, 1);
				return data.getFloat64(offset + 1, false);
			case 4: {
				const [length, start] = lengthAt(1);
				return bytes.slice(start, start + length);
			}
			case 5: {
				const [length, start] = lengthAt(1);
				return new TextDecoder("latin1").decode(bytes.subarray(start, start + length));
			}
			case 6: {
				const [length, start] = lengthAt(2);
				let text = "";
				for (let i = 0; i < length; i += 1) text += String.fromCharCode(data.getUint16(start + i * 2, false));
				return text;
			}
			case 8:
				if (info > 7) throw corrupt();
				fits(offset + 1, info + 1, 1);
				return uintAt(bytes, offset + 1, info + 1);
			case 10:
			case 12: {
				const [length, start] = lengthAt(refSize);
				seen.add(offset);
				const items = [];
				for (let i = 0; i < length; i += 1) items.push(parse(uintAt(bytes, start + i * refSize, refSize)));
				seen.delete(offset);
				return items;
			}
			case 13: {
				const [length, start] = lengthAt(2 * refSize);
				seen.add(offset);
				const dict = Object.create(null);
				for (let i = 0; i < length; i += 1) {
					const key = parse(uintAt(bytes, start + i * refSize, refSize));
					const value = parse(uintAt(bytes, start + (length + i) * refSize, refSize));
					if (typeof key !== "string") throw corrupt();
					dict[key] = value;
				}
				seen.delete(offset);
				return dict;
			}
			default: throw corrupt();
		}
	};
	return parse(top);
};
var ENTITIES = {
	amp: "&",
	lt: "<",
	gt: ">",
	quot: "\"",
	apos: "'"
};
var decodeEntities = (text) => text.replace(/&(#x[0-9a-f]+|#\d+|\w+);/giu, (whole, entity) => {
	if (entity[0] === "#") {
		const code = entity[1] === "x" || entity[1] === "X" ? Number.parseInt(entity.slice(2), 16) : Number.parseInt(entity.slice(1), 10);
		if (code > 1114111) throw corrupt();
		return String.fromCodePoint(code);
	}
	return ENTITIES[entity] ?? whole;
});
/**
* `text` without each `open`, what follows it, and its `close`. A scan, because
* a regular expression retries from every `open` that never closes, which on a
* crafted file takes minutes.
*/
var withoutSpans = (text, open, close) => {
	let kept = "";
	let position = 0;
	for (;;) {
		const start = text.indexOf(open, position);
		const end = start === -1 ? -1 : text.indexOf(close, start + open.length);
		if (end === -1) return kept + text.slice(position);
		kept += text.slice(position, start);
		position = end + close.length;
	}
};
/** An XML property list, as a provisioning profile holds one. */
var parseXmlPlist = (text) => {
	const tokens = withoutSpans(withoutSpans(text, "<!--", "-->"), "<?", "?>").replace(/<!DOCTYPE[^<>]*>/giu, "").split(/(<[^<>]+>)/u);
	let i = 0;
	const nextTag = () => {
		while (i < tokens.length) {
			const token = tokens[i++];
			if (token.startsWith("<")) return token;
			if (token.trim() !== "") throw corrupt();
		}
		throw corrupt();
	};
	const textUntil = (close) => {
		let value = "";
		while (i < tokens.length && tokens[i] !== close) value += tokens[i++];
		if (tokens[i++] !== close) throw corrupt();
		return decodeEntities(value);
	};
	let depth = 0;
	const parseValue = (tag) => {
		if (depth > MAX_DEPTH) throw corrupt();
		const name = /^<\s*([\w]+)/u.exec(tag)?.[1];
		const empty = tag.endsWith("/>");
		switch (name) {
			case "string": return empty ? "" : textUntil("</string>");
			case "integer": return Number(textUntil("</integer>"));
			case "real": return Number(textUntil("</real>"));
			case "true": return true;
			case "false": return false;
			case "date": return textUntil("</date>");
			case "data": return textUntil("</data>").replace(/\s+/gu, "");
			case "array": {
				const items = [];
				if (empty) return items;
				depth += 1;
				for (let next = nextTag(); next !== "</array>"; next = nextTag()) items.push(parseValue(next));
				depth -= 1;
				return items;
			}
			case "dict": {
				const dict = Object.create(null);
				if (empty) return dict;
				depth += 1;
				for (let next = nextTag(); next !== "</dict>"; next = nextTag()) {
					if (next !== "<key>") throw corrupt();
					const key = textUntil("</key>");
					dict[key] = parseValue(nextTag());
				}
				depth -= 1;
				return dict;
			}
			default: throw corrupt();
		}
	};
	let tag = nextTag();
	if (/^<plist\b/u.test(tag)) tag = nextTag();
	return parseValue(tag);
};
/** A property list, binary or XML, as a JavaScript value. */
var parsePlist = (bytes) => {
	if (new TextDecoder().decode(bytes.subarray(0, 8)) === "bplist00") return parseBinaryPlist(bytes);
	return parseXmlPlist(new TextDecoder().decode(bytes));
};
/**
* What a sandbox build is, wherever it is built or read: `sandbox: true` on a
* `nativeBuild` scheme adds a native layer to the app, which a normal build
* never compiles.
*/
/**
* The literal the sandbox layer's code holds, in `ios/HotUpdater/Sandbox` and
* `android/src/sandbox`: reading an artifact's strings finds it. Its length
* is its own among the lengths those reads keep.
*/
var SANDBOX_CODE_MARKER = "HOT_UPDATER_SANDBOX_NATIVE_LAYER";
/** The Info.plist key an iOS sandbox build declares itself with. */
var SANDBOX_INFO_PLIST_KEY = "HOT_UPDATER_SANDBOX";
/**
* The Info.plist key that records the URL scheme an iOS sandbox build
* registers in its `SANDBOX_URL_TYPE_NAME` URL type: the build reads its own
* scheme from it, and a later patch knows which scheme is the sandbox's.
*/
var SANDBOX_URL_SCHEME_INFO_PLIST_KEY = "HOT_UPDATER_SANDBOX_URL_SCHEME";
var URL_SCHEME_SYNTAX = /^[a-z][a-z0-9+.-]*$/;
/**
* Whether a value is a URL scheme in lower-case ASCII, as written: what a
* build records, read before any lower-casing.
*/
var isRecordedUrlSchemeSyntax = (value) => typeof value === "string" && URL_SCHEME_SYNTAX.test(value);
/**
* The URL scheme an iOS sandbox build registers, by one rule its patch, its
* reader, and its own code apply alike. `recorded` is the Info.plist's
* `SANDBOX_URL_SCHEME_INFO_PLIST_KEY`, undefined when the key is absent, and
* `namedTypes` its URL types named `SANDBOX_URL_TYPE_NAME`.
* - Absent: a prerelease's build, which recorded none. Undefined: the caller
*   reads it the way that build was read.
* - Present: a scheme in lower-case ASCII, as written, that the one URL type
*   of the name holds alone. Anything else is null, with no fallback.
*/
var recordedSandboxUrlScheme = (recorded, namedTypes) => {
	if (recorded === void 0) return void 0;
	if (!isRecordedUrlSchemeSyntax(recorded) || namedTypes.length !== 1) return null;
	const schemes = namedTypes[0]?.CFBundleURLSchemes;
	return Array.isArray(schemes) && schemes.length === 1 && schemes[0] === recorded ? recorded : null;
};
/** The `<meta-data>` an Android sandbox build declares itself with. */
var SANDBOX_META_DATA = "com.hotupdater.SANDBOX";
/** The activity that takes an Android sandbox build's launcher entry and links. */
var SANDBOX_ACTIVITY = "com.hotupdater.HotUpdaterSandboxActivity";
/** The `applicationIdSuffix` an Android sandbox build appends. */
var SANDBOX_APPLICATION_ID_SUFFIX = ".sandbox";
/**
* The `CFBundleURLName` of the URL type an iOS sandbox build registers its URL
* scheme with, which the build reads its own scheme from.
*/
var SANDBOX_URL_TYPE_NAME = "hot-updater-sandbox";
/**
* The `<meta-data>` of `SANDBOX_ACTIVITY` that names the URL scheme an Android
* sandbox build registers, which the build reads its own scheme from.
*/
var SANDBOX_URL_SCHEME_META_DATA = "com.hotupdater.sandbox.URL_SCHEME";
var SANDBOX_URL_SCHEME_PREFIX = "hu-sandbox-";
/**
* The URL scheme a sandbox build registers when its scheme sets none, derived
* from the app's ID: the app's own scheme would ask which app to open beside
* the store app.
*/
var sandboxUrlSchemeOf = (appId) => `${SANDBOX_URL_SCHEME_PREFIX}${appId.toLowerCase().replace(/[^a-z0-9]+/gu, "-")}`;
/**
* Whether a URL scheme has the prefix of the derived one: how an artifact built
* before the URL scheme could be set is read, which registered no other.
*/
var isSandboxUrlScheme = (scheme) => scheme.toLowerCase().startsWith(SANDBOX_URL_SCHEME_PREFIX);
var CONFIGURED_URL_SCHEME = /^[a-z][a-z0-9+.-]{0,63}$/u;
var RESERVED_URL_SCHEMES = /* @__PURE__ */ new Set([
	"http",
	"https",
	"file",
	"data",
	"javascript",
	"true",
	"false"
]);
/**
* Whether `sandbox: { urlScheme }` can name a URL scheme: lower case, a letter
* then up to 63 letters, digits, `+`, `.` or `-`, none the system or a browser
* owns, and neither `true` nor `false`, which Android's manifest can't hold as
* a string.
*/
var isConfigurableSandboxUrlScheme = (urlScheme) => CONFIGURED_URL_SCHEME.test(urlScheme) && !RESERVED_URL_SCHEMES.has(urlScheme);
/**
* The link a preview QR holds. `urlScheme` is the one the sandbox build
* registered; without it, the one derived from `appId`, the scheme's
* `bundleIdentifier` or `packageName`: the ID before the Android sandbox's
* `.sandbox` suffix.
*/
var createPreviewLink = ({ urlScheme, appId, channel, fingerprintHash, platform }) => {
	assertCanonicalChannelName(channel);
	if (platform !== void 0 && !PREVIEW_LINK_PLATFORMS.has(platform)) throw new Error(`A preview link's platform is ios or android, not ${platform}.`);
	const link = `${(urlScheme ?? sandboxUrlSchemeOf(appId)).toLowerCase()}://hot-updater/preview?channel=${encodeURIComponent(channel)}&fingerprint=${encodeURIComponent(fingerprintHash)}`;
	return platform === void 0 ? link : `${link}&platform=${platform}`;
};
/** Any URL scheme: which app's it is, the app that opens the link decides. */
var PREVIEW_LINK = /^([a-z][a-z0-9+.-]*):\/\/hot-updater\/preview\?([^#]*)$/iu;
/**
* A URL scheme in ASCII alone: case folding lets `/iu` match `K` (Kelvin) or
* `ſ` as a letter.
*/
var ASCII_URL_SCHEME = /^[A-Za-z][A-Za-z0-9+.-]*$/;
var MAX_FINGERPRINT_LENGTH = 256;
var PREVIEW_LINK_PLATFORMS = /* @__PURE__ */ new Set(["ios", "android"]);
/**
* What a preview link says, or null for anything else: another shape, a
* repeated or missing parameter, or a channel no release can target. It takes
* any URL scheme: a sandbox build refuses a link of another scheme than its
* own. A `platform` other than `ios` or `android` reads as none. Native code
* parses it the same way before any JavaScript runs, in HotUpdaterSandboxLink,
* and shares the vectors in test-utils' `sandbox-preview-links.json`.
*/
var parsePreviewLink = (link) => {
	const match = PREVIEW_LINK.exec(link);
	if (match === null || !ASCII_URL_SCHEME.test(match[1])) return null;
	const parameters = /* @__PURE__ */ new Map();
	for (const parameter of match[2].split("&")) {
		const separator = parameter.indexOf("=");
		if (separator === -1) return null;
		const name = parameter.slice(0, separator);
		if (parameters.has(name)) return null;
		let value;
		try {
			value = decodeURIComponent(parameter.slice(separator + 1));
		} catch {
			return null;
		}
		parameters.set(name, value);
	}
	const channel = parameters.get("channel");
	const fingerprintHash = parameters.get("fingerprint");
	if (channel === void 0 || fingerprintHash === void 0 || fingerprintHash.length === 0 || fingerprintHash.length > MAX_FINGERPRINT_LENGTH) return null;
	try {
		assertCanonicalChannelName(channel);
	} catch {
		return null;
	}
	const platform = parameters.get("platform");
	return {
		urlScheme: match[1].toLowerCase(),
		channel,
		fingerprintHash,
		...platform !== void 0 && PREVIEW_LINK_PLATFORMS.has(platform) ? { platform } : {}
	};
};
var view$1 = (bytes) => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
/** Bytes that are all ASCII, as text; null otherwise. */
var asciiOf = (bytes) => {
	let text = "";
	for (const byte of bytes) {
		if (byte === 0 || byte >= 128) return null;
		text += String.fromCharCode(byte);
	}
	return text;
};
/**
* The string constants of a dex file with one of `lengths`, from its string
* pool: every string literal the app's code holds, each one whole. R8
* renames and inlines classes, but never drops a literal the code returns,
* so the pool still holds a value the native SDK compiled in.
*/
var readDexStrings = (dex, lengths) => {
	const data = view$1(dex);
	if (dex.byteLength < 112 || asciiOf(dex.subarray(0, 3)) !== "dex" || dex[3] !== 10) throw new NativeArtifactError("UNREADABLE", "A dex file is corrupt.");
	const count = data.getUint32(56, true);
	const idsOffset = data.getUint32(60, true);
	if (idsOffset + count * 4 > dex.byteLength) throw new NativeArtifactError("UNREADABLE", "A dex file is corrupt.");
	const strings = [];
	const read = /* @__PURE__ */ new Set();
	for (let i = 0; i < count; i += 1) {
		let offset = data.getUint32(idsOffset + i * 4, true);
		if (read.has(offset)) continue;
		read.add(offset);
		let utf16Length = 0;
		for (let shift = 0; offset < dex.byteLength; shift += 7) {
			const byte = dex[offset++];
			utf16Length |= (byte & 127) << shift;
			if ((byte & 128) === 0 || shift > 28) break;
		}
		if (!lengths.has(utf16Length)) continue;
		const end = offset + utf16Length;
		if (end >= dex.byteLength || dex[end] !== 0) continue;
		const text = asciiOf(dex.subarray(offset, end));
		if (text !== null) strings.push(text);
	}
	return strings;
};
var MH_MAGIC = 4277009102;
var MH_MAGIC_64 = 4277009103;
var FAT_MAGIC = 3405691582;
var FAT_MAGIC_64 = 3405691583;
var LC_SEGMENT = 1;
var LC_SEGMENT_64 = 25;
var CPU_TYPE_ARM64 = 16777228;
var nameAt = (bytes, offset) => {
	let name = "";
	for (let i = offset; i < offset + 16 && bytes[i] !== 0; i += 1) name += String.fromCharCode(bytes[i]);
	return name;
};
/** The slice of a universal binary to read: arm64's, else the first. */
var sliceOf = async (read) => {
	const head = await read(0, 4096);
	if (head.byteLength < 8) return null;
	const data = view$1(head);
	const magic = data.getUint32(0, false);
	if (magic !== FAT_MAGIC && magic !== FAT_MAGIC_64) return 0;
	const count = data.getUint32(4, false);
	const size = magic === FAT_MAGIC ? 20 : 32;
	let first = null;
	for (let i = 0; i < count && 8 + (i + 1) * size <= head.byteLength; i += 1) {
		const at = 8 + i * size;
		const offset = magic === FAT_MAGIC ? data.getUint32(at + 8, false) : Number(data.getBigUint64(at + 8, false));
		if (data.getUint32(at, false) === CPU_TYPE_ARM64) return offset;
		first ??= offset;
	}
	return first;
};
/**
* The C string literals of a Mach-O binary with one of `lengths`, from its
* `__TEXT,__cstring` section, each one whole: the literals an Objective-C or
* Swift source compiled in. A universal binary is read by its arm64 slice.
* A file that is no Mach-O binary holds none.
*/
var readMachOStrings = async (read, lengths) => {
	const base = await sliceOf(read);
	if (base === null) return [];
	const header = await read(base, base + 32);
	if (header.byteLength < 28) return [];
	const data = view$1(header);
	const magic = data.getUint32(0, true);
	if (magic !== MH_MAGIC && magic !== MH_MAGIC_64) return [];
	const is64 = magic === MH_MAGIC_64;
	const headerSize = is64 ? 32 : 28;
	const commandCount = data.getUint32(16, true);
	const commandsSize = data.getUint32(20, true);
	const commands = await read(base + headerSize, base + headerSize + commandsSize);
	const cmds = view$1(commands);
	let section = null;
	for (let i = 0, at = 0; i < commandCount && at + 8 <= commands.byteLength && section === null; i += 1) {
		const cmd = cmds.getUint32(at, true);
		const cmdSize = cmds.getUint32(at + 4, true);
		if (cmdSize < 8) break;
		if ((cmd === LC_SEGMENT_64 || cmd === LC_SEGMENT) && nameAt(commands, at + 8) === "__TEXT") {
			const sectionCount = cmds.getUint32(at + (is64 ? 64 : 48), true);
			const first = at + (is64 ? 72 : 56);
			const sectionSize = is64 ? 80 : 68;
			for (let s = 0; s < sectionCount; s += 1) {
				const sec = first + s * sectionSize;
				if (sec + sectionSize > commands.byteLength) break;
				if (nameAt(commands, sec) !== "__cstring") continue;
				section = is64 ? {
					size: Number(cmds.getBigUint64(sec + 40, true)),
					offset: cmds.getUint32(sec + 48, true)
				} : {
					size: cmds.getUint32(sec + 36, true),
					offset: cmds.getUint32(sec + 40, true)
				};
				break;
			}
		}
		at += cmdSize;
	}
	if (section === null || section.size === 0) return [];
	const cstrings = await read(base + section.offset, base + section.offset + section.size);
	const strings = [];
	for (let start = 0; start < cstrings.byteLength;) {
		let end = cstrings.indexOf(0, start);
		if (end === -1) end = cstrings.byteLength;
		if (lengths.has(end - start)) {
			const text = asciiOf(cstrings.subarray(start, end));
			if (text !== null) strings.push(text);
		}
		start = end + 1;
	}
	return strings;
};
var EOCD_SIGNATURE = 101010256;
var ZIP64_EOCD_LOCATOR_SIGNATURE = 117853008;
var ZIP64_EOCD_SIGNATURE = 101075792;
var CENTRAL_HEADER_SIGNATURE = 33639248;
var LOCAL_HEADER_SIGNATURE = 67324752;
var ZIP64_EXTRA_ID = 1;
var UINT32_MAX = 4294967295;
/** The end-of-central-directory record and the longest comment after it. */
var EOCD_SEARCH_LENGTH = 65557;
/** How much compressed data one read takes. */
var READ_CHUNK = 1048576;
var MiB$2 = 1048576;
/**
* What an archive may hold before it is refused as no artifact: an upload is
* untrusted, so a crafted directory or entry (a zip bomb) stops here, not
* after filling memory.
*/
var ZIP_LIMITS = {
	directoryBytes: 64 * MiB$2,
	entries: 5e5,
	entryBytes: 1024 * MiB$2
};
var UNIX_HOST = 3;
var S_IFMT = 61440;
var S_IFLNK = 40960;
var view = (bytes) => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
var notZip = () => new NativeArtifactError("UNREADABLE", "The file is not a zip archive, as an .ipa, .aab or .apk is.");
var u64 = (data, offset) => Number(data.getBigUint64(offset, true));
/** The central directory's offset and size, from its end record (ZIP64 too). */
var centralDirectoryOf = async (source) => {
	const start = Math.max(0, source.size - EOCD_SEARCH_LENGTH);
	const tail = await source.read(start, source.size - start);
	const data = view(tail);
	for (let i = tail.length - 22; i >= 0; i -= 1) {
		if (data.getUint32(i, true) !== EOCD_SIGNATURE) continue;
		let size = data.getUint32(i + 12, true);
		let offset = data.getUint32(i + 16, true);
		if (offset === UINT32_MAX || size === UINT32_MAX) {
			const locator = i - 20;
			if (locator < 0 || data.getUint32(locator, true) !== ZIP64_EOCD_LOCATOR_SIGNATURE) throw notZip();
			const record = view(await source.read(u64(data, locator + 8), 56));
			if (record.byteLength < 56 || record.getUint32(0, true) !== ZIP64_EOCD_SIGNATURE) throw notZip();
			size = u64(record, 40);
			offset = u64(record, 48);
		}
		if (offset + size > source.size) throw notZip();
		return {
			offset,
			size
		};
	}
	throw notZip();
};
/** Every entry of a zip archive, reading only its central directory. */
var readZipDirectory = async (source) => {
	const { offset, size } = await centralDirectoryOf(source);
	if (size > ZIP_LIMITS.directoryBytes) throw new NativeArtifactError("UNREADABLE", "The archive's directory is larger than any artifact's.");
	const directory = await source.read(offset, size);
	const data = view(directory);
	const decoder = new TextDecoder();
	const entries = [];
	for (let i = 0; i + 46 <= directory.length;) {
		if (data.getUint32(i, true) !== CENTRAL_HEADER_SIGNATURE) break;
		if (entries.length >= ZIP_LIMITS.entries) throw new NativeArtifactError("UNREADABLE", "The archive holds more entries than any artifact.");
		const madeBy = data.getUint16(i + 4, true);
		const externalAttributes = data.getUint32(i + 38, true);
		const method = data.getUint16(i + 10, true);
		let compressedSize = data.getUint32(i + 20, true);
		let uncompressedSize = data.getUint32(i + 24, true);
		const nameLength = data.getUint16(i + 28, true);
		const extraLength = data.getUint16(i + 30, true);
		const commentLength = data.getUint16(i + 32, true);
		let localHeaderOffset = data.getUint32(i + 42, true);
		const nameStart = i + 46;
		const name = decoder.decode(directory.subarray(nameStart, nameStart + nameLength));
		const extraStart = nameStart + nameLength;
		for (let j = extraStart; j + 4 <= extraStart + extraLength;) {
			const id = data.getUint16(j, true);
			const length = data.getUint16(j + 2, true);
			if (id === ZIP64_EXTRA_ID) {
				let k = j + 4;
				if (uncompressedSize === UINT32_MAX) {
					uncompressedSize = u64(data, k);
					k += 8;
				}
				if (compressedSize === UINT32_MAX) {
					compressedSize = u64(data, k);
					k += 8;
				}
				if (localHeaderOffset === UINT32_MAX) localHeaderOffset = u64(data, k);
			}
			j += 4 + length;
		}
		const segments = name.split("/");
		entries.push({
			name,
			unsafe: name.startsWith("/") || /^[A-Za-z]:/u.test(name) || name.includes("\\") || name.includes("\0") || segments.includes(".."),
			symlink: madeBy >> 8 === UNIX_HOST && (externalAttributes >>> 16 & S_IFMT) === S_IFLNK,
			method,
			compressedSize,
			uncompressedSize,
			localHeaderOffset
		});
		i = extraStart + extraLength + commentLength;
	}
	return entries;
};
/**
* The one entry an artifact's reader takes by `name`: a symbolic link, or a
* name the archive holds twice, which could hand the reader other bytes
* than an installer reads, is refused. Unsafe names match nothing.
*/
var findZipEntry = (entries, match) => {
	const test = typeof match === "string" ? (name) => name === match : match;
	const found = entries.filter(({ name, unsafe }) => !unsafe && test(name));
	for (const entry of found) assertReadable(entry);
	if (typeof match === "string" && found.length > 1) throw new NativeArtifactError("UNREADABLE", `The archive holds ${match} more than once.`);
	return found[0];
};
/** Every safe entry `match` takes, each a file the reader may read. */
var filterZipEntries = (entries, match) => {
	const found = entries.filter(({ name, unsafe }) => !unsafe && match(name));
	for (const entry of found) assertReadable(entry);
	return found;
};
var assertReadable = (entry) => {
	if (entry.symlink) throw new NativeArtifactError("UNREADABLE", `The archive's ${entry.name} is a symbolic link, not a file.`);
};
var tooLarge = (entry, limit) => new NativeArtifactError("UNREADABLE", `The archive's ${entry.name} is larger than ${Math.round(limit / MiB$2)} MB, more than any artifact's.`);
/** Where an entry's data starts, past its local header. */
var dataOffsetOf = async (source, entry) => {
	const local = view(await source.read(entry.localHeaderOffset, 30));
	if (local.byteLength < 30 || local.getUint32(0, true) !== LOCAL_HEADER_SIGNATURE) throw new NativeArtifactError("UNREADABLE", `The archive's ${entry.name} is corrupt.`);
	return entry.localHeaderOffset + 30 + local.getUint16(26, true) + local.getUint16(28, true);
};
/**
* An entry's uncompressed bytes as a stream, read from the source a chunk at
* a time, so a large entry is never held whole.
*/
var openZipEntry = async (source, entry, { maxBytes = ZIP_LIMITS.entryBytes } = {}) => {
	assertReadable(entry);
	if (entry.unsafe) throw new NativeArtifactError("UNREADABLE", `The archive's entry ${JSON.stringify(entry.name)} has a name no artifact holds.`);
	if (entry.uncompressedSize > maxBytes) throw tooLarge(entry, maxBytes);
	if (entry.method !== 0 && entry.method !== 8) throw new NativeArtifactError("UNREADABLE", `The archive stores ${entry.name} with an unsupported compression method (${entry.method}).`);
	const start = await dataOffsetOf(source, entry);
	const end = start + entry.compressedSize;
	let position = start;
	const compressed = new ReadableStream({ async pull(controller) {
		if (position >= end) {
			controller.close();
			return;
		}
		const chunk = await source.read(position, Math.min(READ_CHUNK, end - position));
		if (chunk.byteLength === 0) {
			controller.error(new NativeArtifactError("UNREADABLE", `The archive ends inside ${entry.name}.`));
			return;
		}
		position += chunk.byteLength;
		controller.enqueue(chunk);
	} });
	const inflated = entry.method === 0 ? compressed : compressed.pipeThrough(new DecompressionStream("deflate-raw"));
	const limit = Math.min(entry.uncompressedSize, maxBytes);
	let produced = 0;
	return inflated.pipeThrough(new TransformStream({ transform(chunk, controller) {
		produced += chunk.byteLength;
		if (produced > limit) {
			controller.error(new NativeArtifactError("UNREADABLE", `The archive's ${entry.name} inflates past the size it declares.`));
			return;
		}
		controller.enqueue(chunk);
	} }));
};
/**
* The uncompressed bytes in `[start, end)` of an entry, which stops
* inflating once it has them: a Mach-O header without the rest of the
* binary.
*/
var readZipEntryRange = async (source, entry, start, end, budget) => {
	const length = Math.max(0, Math.min(end, entry.uncompressedSize) - start);
	if (budget !== void 0 && start + length > budget.remaining) throw new NativeArtifactError("UNREADABLE", "The artifact inflates to more than any artifact's.");
	const out = new Uint8Array(length);
	if (length === 0) return out;
	const reader = (await openZipEntry(source, entry)).getReader();
	let position = 0;
	let written = 0;
	try {
		while (written < length) {
			if (budget !== void 0 && Date.now() > budget.deadline) throw new NativeArtifactError("UNREADABLE", "Reading the artifact took too long.");
			const { done, value } = await reader.read();
			if (done) break;
			if (budget !== void 0) budget.remaining -= value.byteLength;
			const from = Math.max(start - position, 0);
			const to = Math.min(start + length - position, value.byteLength);
			if (from < to) {
				out.set(value.subarray(from, to), position + from - start);
				written += to - from;
			}
			position += value.byteLength;
		}
	} catch (error) {
		throw error instanceof NativeArtifactError ? error : new NativeArtifactError("UNREADABLE", `The archive's ${entry.name} can't be decompressed: ${error instanceof Error ? error.message : String(error)}.`);
	} finally {
		await reader.cancel().catch(() => {});
	}
	return written === length ? out : out.subarray(0, written);
};
/** An entry's uncompressed bytes, refused past `maxBytes`. */
var readZipEntry = (source, entry, maxBytes, budget) => {
	if (entry.uncompressedSize > maxBytes) throw tooLarge(entry, maxBytes);
	return readZipEntryRange(source, entry, 0, entry.uncompressedSize, budget);
};
var MiB$1 = 1048576;
/** The most a manifest or an Info.plist holds. */
var METADATA_BYTES$1 = 16 * MiB$1;
/** The most one dex file holds. */
var DEX_BYTES = 256 * MiB$1;
/** The most reading one artifact inflates, across every entry it reads. */
var READ_BUDGET_BYTES$1 = 2048 * MiB$1;
/** How long reading one artifact may take. */
var DEFAULT_TIMEOUT_MS = 12e4;
/** Where each kind of artifact packs its built-in bundle. */
var builtInBundlePathOf = (kind, appDirectory = kind === "app" ? "<App>.app/" : "Payload/<App>.app/") => kind === "aab" ? "base/assets/index.android.bundle" : kind === "apk" ? "assets/index.android.bundle" : `${appDirectory}main.jsbundle`;
/** The kind of artifact a file name names, or null. */
var nativeArtifactKindOf = (fileName) => {
	if (/\.app\.zip$/iu.test(fileName)) return "app";
	const extension = /\.([^./\\]+)$/u.exec(fileName)?.[1]?.toLowerCase();
	return extension === "ipa" || extension === "aab" || extension === "apk" ? extension : null;
};
var UUID_LENGTH = 36;
var SHA256_HEX = /^[0-9a-f]{64}$/u;
var LENGTHS = /* @__PURE__ */ new Set([
	UUID_LENGTH,
	64,
	32
]);
var unique = (values) => [...new Set(values)].sort();
var candidatesOf = (strings) => {
	const all = [...strings];
	return {
		minBundleIds: unique(all.filter(isUUIDv7)),
		fingerprints: unique(all.filter((value) => SHA256_HEX.test(value)))
	};
};
var literalOf = (value, what) => {
	if (value === null || value === void 0) return null;
	if (value.type === "string") return value.value;
	if (value.type === "int") return String(value.value);
	return { unreadable: value.type === "reference" ? `${what} is a resource reference (${value.name ?? `@0x${value.id.toString(16)}`}), not a literal` : `${what} is not a string` };
};
/**
* The channel an Android app reports from its `com.hotupdater.CHANNEL`
* meta-data, as the SDK reads it (`NativeConfigUtils`): the value as a
* string, and none when it is empty, which the SDK reports as `production`.
*/
var androidChannelOf = (value) => {
	if (value === void 0) return null;
	if (value.type === "boolean") return String(value.value);
	const channel = literalOf(value, "The com.hotupdater.CHANNEL meta-data");
	return channel === "" ? null : channel;
};
var readAndroid = async (source, kind, entries, budget) => {
	const manifestEntry = findZipEntry(entries, kind === "aab" ? "base/manifest/AndroidManifest.xml" : "AndroidManifest.xml");
	if (manifestEntry === void 0) throw new NativeArtifactError("UNREADABLE", `The ${kind === "aab" ? ".aab has no base/manifest/AndroidManifest.xml" : ".apk has no AndroidManifest.xml"}.`);
	const manifestBytes = await readZipEntry(source, manifestEntry, METADATA_BYTES$1, budget);
	const manifest = readAndroidManifest(kind === "aab" ? parseProtoManifest(manifestBytes) : parseBinaryManifest(manifestBytes));
	const strings = [];
	const dexes = filterZipEntries(entries, (name) => kind === "aab" ? /^base\/dex\/classes\d*\.dex$/u.test(name) : /^classes\d*\.dex$/u.test(name));
	for (const entry of dexes) strings.push(...readDexStrings(await readZipEntry(source, entry, DEX_BYTES, budget), LENGTHS));
	const { minBundleIds, fingerprints } = candidatesOf(strings);
	const bundle = findZipEntry(entries, builtInBundlePathOf(kind));
	return {
		platform: "android",
		kind,
		appId: manifest.packageName,
		appVersion: literalOf(manifest.versionName, "versionName"),
		buildNumber: manifest.versionCode === null ? null : String(manifest.versionCode),
		channel: androidChannelOf(manifest.metaData.get("com.hotupdater.CHANNEL")),
		minBundleIdCandidates: minBundleIds,
		fingerprintCandidates: fingerprints,
		sandbox: {
			code: strings.includes(SANDBOX_CODE_MARKER),
			declared: manifest.metaData.has(SANDBOX_META_DATA)
		},
		entry: {
			launchers: manifest.launchers,
			sandboxUrlScheme: androidSandboxUrlScheme(manifest)
		},
		builtInBundle: bundle === void 0 ? null : {
			path: bundle.name,
			byteSize: bundle.uncompressedSize
		}
	};
};
/**
* The URL scheme an Android sandbox build registers, or null: the one its
* activity's `SANDBOX_URL_SCHEME_META_DATA` names, when the activity's `VIEW`
* filters take it too. An artifact built before the meta-data takes the one
* with the derived scheme's prefix.
*/
var androidSandboxUrlScheme = (manifest) => {
	const schemes = manifest.urlSchemes.get("com.hotupdater.HotUpdaterSandboxActivity") ?? [];
	const declared = manifest.componentMetaData.get(SANDBOX_ACTIVITY)?.get(SANDBOX_URL_SCHEME_META_DATA);
	if (declared === void 0) return schemes.find(isSandboxUrlScheme) ?? null;
	if (declared.type !== "string") return null;
	return schemes.includes(declared.value) ? declared.value : null;
};
/**
* The sandbox URL scheme of an Info.plist, or null: the one
* `SANDBOX_URL_SCHEME_INFO_PLIST_KEY` records, by `recordedSandboxUrlScheme`'s
* rule. A prerelease's artifact, with no key, gives its named URL type's one
* scheme, or, with no named type, one with the derived scheme's prefix.
*/
var sandboxUrlSchemeIn = (info) => {
	const types = info["CFBundleURLTypes"];
	if (!Array.isArray(types)) return null;
	const schemesOf = (type) => {
		const schemes = type?.CFBundleURLSchemes;
		return Array.isArray(schemes) ? schemes.filter((scheme) => typeof scheme === "string") : [];
	};
	const named = types.filter((type) => type?.CFBundleURLName === SANDBOX_URL_TYPE_NAME);
	const recorded = recordedSandboxUrlScheme("HOT_UPDATER_SANDBOX_URL_SCHEME" in info ? info[SANDBOX_URL_SCHEME_INFO_PLIST_KEY] : void 0, named);
	if (recorded !== void 0) return recorded;
	if (named.length > 1) return null;
	if (named.length === 1) {
		const schemes = schemesOf(named[0]);
		return schemes.length === 1 ? schemes[0] : null;
	}
	return types.flatMap(schemesOf).find(isSandboxUrlScheme) ?? null;
};
var stringValue = (value) => typeof value === "string" && value !== "" ? value : null;
var readIos = async (source, kind, entries, budget) => {
	const infoPlist = kind === "ipa" ? /^Payload\/[^/]+\.app\/Info\.plist$/u : /^[^/]+\.app\/Info\.plist$/u;
	const plistEntry = findZipEntry(entries, (name) => infoPlist.test(name));
	if (plistEntry === void 0) throw new NativeArtifactError("UNREADABLE", kind === "ipa" ? "The .ipa has no Payload/<App>.app/Info.plist." : "The .app.zip has no <App>.app/Info.plist at its root.");
	const appDirectory = plistEntry.name.slice(0, -10);
	const plist = parsePlist(await readZipEntry(source, plistEntry, METADATA_BYTES$1, budget));
	if (plist === null || typeof plist !== "object" || Array.isArray(plist)) throw new NativeArtifactError("UNREADABLE", "The app's Info.plist is not a dictionary.");
	const info = plist;
	const machO = (entry) => readMachOStrings((start, end) => readZipEntryRange(source, entry, start, end, budget), LENGTHS);
	const frameworks = filterZipEntries(entries, (name) => {
		const match = new RegExp(`^${appDirectory.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&")}Frameworks/([^/]+)\\.framework/([^/]+)$`, "u").exec(name);
		return match !== null && match[1] === match[2];
	});
	const sdk = frameworks.find(({ name }) => name.endsWith("/HotUpdater"));
	const executable = stringValue(info["CFBundleExecutable"]);
	const executableEntry = executable === null ? void 0 : findZipEntry(entries, `${appDirectory}${executable}`);
	let strings = sdk === void 0 ? [] : await machO(sdk);
	if (!strings.some(isUUIDv7) && executableEntry !== void 0) strings = await machO(executableEntry);
	if (!strings.some(isUUIDv7)) {
		for (const framework of frameworks) if (framework !== sdk) strings.push(...await machO(framework));
	}
	const { minBundleIds, fingerprints } = candidatesOf(strings);
	const bundle = findZipEntry(entries, builtInBundlePathOf(kind, appDirectory));
	const channel = info["HOT_UPDATER_CHANNEL"];
	return {
		platform: "ios",
		kind,
		appId: stringValue(info["CFBundleIdentifier"]),
		appVersion: stringValue(info["CFBundleShortVersionString"]),
		buildNumber: stringValue(info["CFBundleVersion"]),
		channel: channel === void 0 || channel === "" ? null : typeof channel === "string" ? channel : { unreadable: "HOT_UPDATER_CHANNEL is not a string" },
		minBundleIdCandidates: minBundleIds,
		fingerprintCandidates: fingerprints,
		sandbox: {
			code: strings.includes(SANDBOX_CODE_MARKER),
			declared: info[SANDBOX_INFO_PLIST_KEY] !== void 0
		},
		entry: {
			launchers: [],
			sandboxUrlScheme: sandboxUrlSchemeIn(info)
		},
		builtInBundle: bundle === void 0 ? null : {
			path: bundle.name,
			byteSize: bundle.uncompressedSize
		}
	};
};
/**
* Reads a store artifact (`.ipa`, `.aab` or `.apk`) by its file name's
* extension: what its app reports at runtime, and its built-in bundle. It
* reads the archive's directory, the manifest or Info.plist, and the app's
* code, but not the built-in bundle, so a large artifact is never held
* whole. Whether the result can be imported is `checkNativeArtifact`'s.
*/
var readNativeArtifact = async (source, fileName, { timeoutMs = DEFAULT_TIMEOUT_MS } = {}) => {
	const kind = nativeArtifactKindOf(fileName);
	if (kind === null) throw new NativeArtifactError("UNSUPPORTED_FILE", `${fileName} is not an .ipa, .aab, .apk or a simulator .app. Import the artifact of a release build.`);
	const budget = {
		remaining: READ_BUDGET_BYTES$1,
		deadline: Date.now() + timeoutMs
	};
	const timed = {
		size: source.size,
		read(offset, length) {
			if (Date.now() > budget.deadline) return Promise.reject(new NativeArtifactError("UNREADABLE", "Reading the artifact took too long."));
			return source.read(offset, length);
		}
	};
	try {
		const entries = await readZipDirectory(timed);
		return await (kind === "ipa" || kind === "app" ? readIos(timed, kind, entries, budget) : readAndroid(timed, kind, entries, budget));
	} catch (error) {
		if (error instanceof NativeArtifactError) throw error;
		throw new NativeArtifactError("UNREADABLE", `The artifact is malformed: ${error instanceof Error ? error.message : String(error)}.`);
	}
};
/** The channel an app without a default channel reports. */
var DEFAULT_CHANNEL = "production";
/**
* Why an artifact can't register as what it is: the sandbox layer must be
* whole or absent, and a sandbox build must have the URL scheme its links
* open and the launcher its screen takes. A sandbox build registers on any
* channel, as any build does.
*/
var sandboxArtifactProblem = ({ kind, platform, sandbox, entry }) => {
	const declaration = platform === "ios" ? "Info.plist key" : "manifest meta-data";
	if (sandbox.code !== sandbox.declared) return {
		code: "SANDBOX_MISMATCH",
		message: sandbox.code ? `The .${kind} has the sandbox layer's code, but no sandbox ${declaration}.\nBuild it again with hot-updater native-build.` : `The .${kind} has a sandbox ${declaration}, but not the sandbox layer's code.\nBuild it again with hot-updater native-build.`
	};
	if (sandbox.code && entry.sandboxUrlScheme === null) return {
		code: "SANDBOX_MISMATCH",
		message: `The .${kind} is a sandbox build with no sandbox URL scheme, so no link can open it.\nBuild it again with hot-updater native-build.`
	};
	if (sandbox.code && platform === "android" && (entry.launchers.length !== 1 || entry.launchers[0] !== "com.hotupdater.HotUpdaterSandboxActivity")) return {
		code: "SANDBOX_MISMATCH",
		message: `The .${kind} is a sandbox build, but its launcher is ${entry.launchers.join(", ") || "missing"}.\nBuild it again with hot-updater native-build.`
	};
	return null;
};
var isUnreadable = (value) => typeof value === "object" && value !== null && "unreadable" in value;
/**
* Whether a read artifact can be imported as a native build, whose built-in
* bundle OTAs patch from, and what it registers as. It refuses an artifact
* that ships no built-in bundle, such as a debug build, which loads its
* JavaScript from Metro, one built without the native SDK's build step (no MIN_BUNDLE_ID), and
* one the project's update strategy can't place: no fingerprint under the
* fingerprint strategy, or no app version a device compares under the
* appVersion strategy. With `appIds`, the identifiers the project's
* `nativeBuild` schemes name, it warns about an artifact of another app.
*/
var checkNativeArtifact = (info, { updateStrategy, appIds = [], channel: channelOverride }) => {
	const problems = [];
	const warnings = [];
	const refuse = (code, message) => problems.push({
		code,
		message
	});
	if (info.builtInBundle === null) refuse("NO_BUILT_IN_BUNDLE", `The .${info.kind} has no ${builtInBundlePathOf(info.kind)}, so it ships no built-in bundle to patch from. A debug build loads its JavaScript from Metro, and a release build packs it there unless the project renames its bundle. Import a release build.`);
	const [minBundleId, ...otherMinBundleIds] = info.minBundleIdCandidates;
	if (minBundleId === void 0) refuse("NO_MIN_BUNDLE_ID", "The app's code holds no MIN_BUNDLE_ID: it was built without @hot-updater/react-native, or with a version of it that doesn't compile MIN_BUNDLE_ID in. Rebuild it with the @hot-updater/react-native this project uses.");
	else if (otherMinBundleIds.length > 0) refuse("AMBIGUOUS_MIN_BUNDLE_ID", `The app's code holds several UUIDv7 strings (${info.minBundleIdCandidates.join(", ")}), so which is MIN_BUNDLE_ID can't be told.`);
	let fingerprintHash = null;
	let appVersion = null;
	if (updateStrategy === "fingerprint") {
		const [fingerprint, ...others] = info.fingerprintCandidates;
		if (fingerprint === void 0) refuse("NO_FINGERPRINT", "The app's code holds no fingerprint, but hot-updater.config.ts updates by fingerprint: it was built without fingerprint.json, or with a @hot-updater/react-native that doesn't compile the fingerprint in, so its app can't check for fingerprint updates.");
		else if (others.length > 0) refuse("AMBIGUOUS_FINGERPRINT", `The app's code holds several SHA-256 strings (${info.fingerprintCandidates.join(", ")}), so which is its fingerprint can't be told.`);
		else fingerprintHash = fingerprint;
	} else if (info.appVersion === null) refuse("NO_APP_VERSION", `The app has no ${info.platform === "ios" ? "CFBundleShortVersionString" : "versionName"}, which the appVersion strategy updates by.`);
	else if (isUnreadable(info.appVersion)) refuse("NO_APP_VERSION", `The app's ${info.appVersion.unreadable}.`);
	else if (canonicalizeAppVersion(info.appVersion) === null) refuse("INVALID_SCOPE", `The app version ${info.appVersion} holds no version a device compares, such as 1.4.0, so no appVersion update targets it.`);
	else appVersion = info.appVersion;
	let channel = DEFAULT_CHANNEL;
	if (channelOverride !== void 0) {
		channel = channelOverride;
		try {
			encodeChannelKey(channel);
		} catch (error) {
			refuse("INVALID_SCOPE", `The channel ${JSON.stringify(channel)} is no channel a release can target: ${error instanceof Error ? error.message : String(error)}.`);
		}
	} else if (isUnreadable(info.channel)) refuse("INVALID_SCOPE", `${info.channel.unreadable}, so the channel its app reports can't be read: name it with --channel.`);
	else if (info.channel !== null) {
		channel = info.channel;
		try {
			encodeChannelKey(channel);
		} catch (error) {
			refuse("INVALID_SCOPE", `The app's channel ${JSON.stringify(channel)} is no channel a release can target: ${error instanceof Error ? error.message : String(error)}.`);
		}
	}
	const sandboxProblem = sandboxArtifactProblem(info);
	if (sandboxProblem !== null) problems.push(sandboxProblem);
	if (appIds.length > 0 && info.appId !== null && !appIds.includes(info.appId)) warnings.push({
		code: "APP_ID_MISMATCH",
		message: `The app is ${info.appId}, which no ${info.platform} scheme in nativeBuild names (${appIds.join(", ")}): check that it is this project's build.`
	});
	if (problems.length > 0 || minBundleId === void 0) return {
		ok: false,
		problems,
		warnings
	};
	return {
		ok: true,
		warnings,
		build: {
			platform: info.platform,
			kind: info.kind,
			appId: info.appId,
			buildNumber: info.buildNumber,
			minBundleId,
			channel,
			fingerprintHash,
			appVersion,
			nativeAppVersion: typeof info.appVersion === "string" && info.appVersion.trim() ? info.appVersion : null,
			builtInBundlePath: info.builtInBundle.path,
			sandbox: info.sandbox.code,
			sandboxUrlScheme: info.sandbox.code ? info.entry.sandboxUrlScheme : null
		}
	};
};
/**
* The refusal of an artifact whose built-in bundle is already registered:
* the registry takes a MIN_BUNDLE_ID once.
*/
var alreadyImportedProblem = (minBundleId, nativeBuildId) => ({
	code: "ALREADY_IMPORTED",
	...nativeBuildId === null ? {} : { nativeBuildId },
	message: nativeBuildId === null ? `The built-in bundle ${minBundleId} is already registered, as a bundle that is no native build's.` : `This build is already registered as native build ${nativeBuildId} (built-in bundle ${minBundleId}).`
});
var MiB = 1048576;
/** The most an app's Info.plist or a provisioning profile holds here. */
var METADATA_BYTES = 1 * MiB;
/** The most reading what an install needs inflates, across every entry. */
var READ_BUDGET_BYTES = 8 * MiB;
/** How long reading what an install needs may take. */
var READ_TIMEOUT_MS = 3e4;
/** The extensions an app may carry, each with a profile to read. */
var MAX_NESTED_PROFILES = 16;
var APP_INFO_PLIST = /^Payload\/[^/]+\.app\/Info\.plist$/u;
/**
* What installs with the app and must list the device too: not a Watch app's
* profile, which lists watches and installs on one.
*/
var NESTED_PROFILE = /^Payload\/[^/]+\.app\/(?:PlugIns|Extensions|AppClips)\/[^/]+\.(?:appex|app)\/embedded\.mobileprovision$/u;
/** A device's UDID: 40 hex digits, or 8 and 16 joined by a hyphen. */
var UDID = /^(?:[0-9a-f]{40}|[0-9a-f]{8}-[0-9a-f]{16})$/iu;
/**
* The form two UDIDs compare in, or null for text that isn't one. Apple writes
* them in either case, and App Store Connect takes the device's own.
*/
var normalizeIosUdid = (value) => {
	const trimmed = value.trim();
	return UDID.test(trimmed) ? trimmed.toLowerCase() : null;
};
/**
* The bytes from `<?xml` through `</plist>`, or null without both: a CMS
* message, as a provisioning profile and a Profile Service answer are, holds
* its plist as plain text among binary bytes.
*/
var sliceEmbeddedPlist = (bytes) => {
	const text = new TextDecoder("latin1").decode(bytes);
	const start = text.indexOf("<?xml");
	if (start === -1) return null;
	const end = text.indexOf("</plist>", start);
	return end === -1 ? null : bytes.subarray(start, end + 8);
};
/**
* The UDID in a Profile Service answer's body, or null when it has no one
* well-formed UDID. It only finds the text: nothing here verifies the signature
* around it, so nothing automated may trust the result.
*/
var readProfileServiceUdid = (body) => {
	const plist = sliceEmbeddedPlist(body);
	if (plist === null) return null;
	const matches = [...new TextDecoder().decode(plist).matchAll(/<key>\s*UDID\s*<\/key>\s*<string>([^<]*)<\/string>/gu)];
	if (matches.length !== 1) return null;
	const udid = matches[0][1].trim();
	return normalizeIosUdid(udid) === null ? null : udid;
};
var unreadable = (message) => new NativeArtifactError("UNREADABLE", message);
var isDict = (value) => typeof value === "object" && value !== null && !Array.isArray(value) && !(value instanceof Uint8Array);
var readProfile = (bytes, name) => {
	const plistBytes = sliceEmbeddedPlist(bytes);
	if (plistBytes === null) throw unreadable(`The archive's ${name} holds no property list.`);
	const plist = parsePlist(plistBytes);
	if (!isDict(plist)) throw unreadable(`The archive's ${name} is corrupt.`);
	const listed = plist["ProvisionedDevices"];
	if (listed !== void 0 && !Array.isArray(listed)) throw unreadable(`The archive's ${name} is corrupt.`);
	const devices = listed?.map((device) => {
		if (typeof device !== "string") throw unreadable(`The archive's ${name} is corrupt.`);
		return device.trim().toLowerCase();
	});
	const expiration = plist["ExpirationDate"];
	const expiresAtMs = typeof expiration === "string" ? Date.parse(expiration) : null;
	if (expiresAtMs !== null && Number.isNaN(expiresAtMs)) throw unreadable(`The archive's ${name} is corrupt.`);
	const entitlements = plist["Entitlements"];
	const applicationId = isDict(entitlements) ? entitlements["application-identifier"] : void 0;
	const bundleId = typeof applicationId === "string" ? applicationId.slice(applicationId.indexOf(".") + 1) : null;
	const teams = plist["TeamIdentifier"];
	const team = Array.isArray(teams) ? teams[0] : void 0;
	const uuid = plist["UUID"];
	return {
		allDevices: plist["ProvisionsAllDevices"] === true,
		devices: devices === void 0 ? null : new Set(devices),
		getTaskAllow: isDict(entitlements) && entitlements["get-task-allow"] === true,
		expiresAtMs,
		bundleId: bundleId === null || bundleId.includes("*") ? null : bundleId,
		applicationIdentifier: typeof applicationId === "string" ? applicationId : null,
		teamId: typeof team === "string" && team !== "" ? team : null,
		xcodeManaged: plist["IsXcodeManaged"] === true,
		uuid: typeof uuid === "string" && uuid !== "" ? uuid : null
	};
};
var distributionOf = (profile) => {
	if (profile === null) return "store";
	if (profile.allDevices) return "enterprise";
	if (profile.devices === null) return "store";
	return profile.getTaskAllow ? "development" : "ad-hoc";
};
/**
* What a provisioning profile's bytes (a `.mobileprovision`, a CMS message
* around a plist) say: the same reading an `.ipa`'s profiles get. It verifies
* no signature. Throws `NativeArtifactError` for one it can't read.
*/
var readProvisioningProfile = (bytes) => {
	const profile = readProfile(bytes, "provisioning profile");
	return {
		uuid: profile.uuid,
		distribution: distributionOf(profile),
		teamId: profile.teamId,
		applicationIdentifier: profile.applicationIdentifier,
		xcodeManaged: profile.xcodeManaged,
		devices: [...profile.devices ?? []].sort(),
		expiresAtMs: profile.expiresAtMs
	};
};
/**
* What an `.ipa` installs as, reading only its directory, its app's Info.plist
* and its provisioning profiles: a few requests of a remote file, whatever its
* size. The `.ipa` is untrusted, and each part is bounded before it is read.
* Throws `NativeArtifactError` for one it can't read.
*/
var readIpaInstallInfo = async (source) => {
	const entries = await readZipDirectory(source);
	const infoPlists = filterZipEntries(entries, (name) => APP_INFO_PLIST.test(name));
	const infoEntry = infoPlists[0];
	if (infoEntry === void 0 || infoPlists.length > 1) throw unreadable("The .ipa has no one Payload/<App>.app/Info.plist.");
	const budget = {
		remaining: READ_BUDGET_BYTES,
		deadline: Date.now() + READ_TIMEOUT_MS
	};
	const read = (entry) => readZipEntry(source, entry, METADATA_BYTES, budget);
	const info = parsePlist(await read(infoEntry));
	if (!isDict(info)) throw unreadable("The app's Info.plist is corrupt.");
	const bundleId = info["CFBundleIdentifier"];
	const bundleVersion = info["CFBundleVersion"];
	if (typeof bundleId !== "string" || bundleId === "") throw unreadable("The app's Info.plist has no CFBundleIdentifier.");
	if (typeof bundleVersion !== "string" || bundleVersion === "") throw unreadable("The app's Info.plist has no CFBundleVersion.");
	const displayName = info["CFBundleDisplayName"];
	const bundleName = info["CFBundleName"];
	const title = typeof displayName === "string" && displayName !== "" ? displayName : typeof bundleName === "string" && bundleName !== "" ? bundleName : bundleId;
	const appDirectory = infoEntry.name.slice(0, -10);
	const profileEntry = findZipEntry(entries, `${appDirectory}embedded.mobileprovision`);
	const nestedEntries = filterZipEntries(entries, (name) => name.startsWith(appDirectory) && NESTED_PROFILE.test(name));
	if (nestedEntries.length > MAX_NESTED_PROFILES) throw unreadable(`The app has more than ${MAX_NESTED_PROFILES} extensions with profiles.`);
	const profile = profileEntry === void 0 ? null : readProfile(await read(profileEntry), profileEntry.name);
	const nested = [];
	for (const entry of nestedEntries) nested.push(readProfile(await read(entry), entry.name));
	const distribution = distributionOf(profile);
	const profiles = profile === null ? nested : [profile, ...nested];
	const listDevices = distribution === "ad-hoc" || distribution === "development";
	const lists = profiles.flatMap(({ allDevices, devices }) => allDevices ? [] : [devices ?? /* @__PURE__ */ new Set()]);
	const expiries = profiles.flatMap(({ expiresAtMs }) => expiresAtMs === null ? [] : [expiresAtMs]);
	return {
		bundleId,
		bundleVersion,
		title,
		distribution,
		devices: listDevices ? [...lists[0] ?? []].filter((udid) => lists.every((list) => list.has(udid))).sort() : [],
		expiresAtMs: expiries.length === 0 ? null : Math.min(...expiries),
		profileBundleIds: [.../* @__PURE__ */ new Set([bundleId, ...profiles.flatMap((item) => item.bundleId ?? [])])],
		teamId: profile?.teamId ?? null
	};
};
//#endregion
export { NativeArtifactError, SANDBOX_ACTIVITY, SANDBOX_APPLICATION_ID_SUFFIX, SANDBOX_CODE_MARKER, SANDBOX_INFO_PLIST_KEY, SANDBOX_META_DATA, SANDBOX_URL_SCHEME_INFO_PLIST_KEY, SANDBOX_URL_SCHEME_META_DATA, SANDBOX_URL_TYPE_NAME, alreadyImportedProblem, blobSource, checkNativeArtifact, createPreviewLink, findZipEntry, isConfigurableSandboxUrlScheme, isRecordedUrlSchemeSyntax, isSandboxUrlScheme, normalizeIosUdid, openZipEntry, parsePreviewLink, readIpaInstallInfo, readNativeArtifact, readProfileServiceUdid, readProvisioningProfile, readZipDirectory, recordedSandboxUrlScheme, sandboxArtifactProblem, sandboxUrlSchemeOf };
