import { Tt as require_jsx_runtime } from "../_libs/@base-ui/react+[...].mjs";
import { I as FileUp, M as HardDrive, _ as RefreshCw, i as TriangleAlert, j as History, nt as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { O as buttonVariants, S as SidebarTrigger, j as useIsMobile, t as Button$1 } from "./sidebar-COdOWPGC.mjs";
import { a as Badge, i as AlertTitle, n as AlertAction, r as AlertDescription, t as Alert } from "./badge-o8QNRxtw.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, s as DialogTrigger, t as Dialog$1 } from "./dialog-CNWOO08-.mjs";
import { i as TableHead, r as TableCell } from "./table-4qgdiham.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as nativeBuildLabel, b as nativeBuildChannel, j as platformLabel, m as formatByteSize, v as nativeBuildArtifacts } from "./native-builds-lEyKQemV.mjs";
import { r as extractTimestampFromUUIDv7 } from "./uuidv7-C0jNe2Om.mjs";
import { g as useNativeBuildsQuery, i as useChannelsQuery, p as useNativeBuildFoldQuery } from "./api-BISxaFip.mjs";
import { n as PlatformLabel, t as PlatformIcon } from "./PlatformIcon-C22qEcwo.mjs";
import { t as ChannelPicker } from "./ChannelPicker-DNX6PX8b.mjs";
import { t as resolveNativeBuildsSearch } from "./-native-builds-search-Bwt8tQzp.mjs";
import { t as Route } from "./native-builds-BN0EyqQH.mjs";
import { t as ChannelBadge } from "./ChannelBadge-DsA4srwK.mjs";
import { a as DataTableBody, c as DataTableFullRow, d as DataTableSkeletonRows, f as RelativeTime, i as DataTable, l as DataTablePagination, n as DataCardSkeletons, o as DataTableEmpty, p as openOutsideControls, r as DataCardsEmpty, s as DataTableFrame, t as DataCard, u as DataTableRow } from "./RelativeTime-jQk9a1D5.mjs";
import { i as TargetDisplay, n as CopyableText, r as NoValue, t as BuildKeyDisplay } from "./TargetDisplay-CwHH2uJ2.mjs";
import { a as foldKey, c as groupsOf, i as RowReason, l as useOpenFolds, n as DataTableFold, o as foldLabel, r as FoldStatus, s as foldedTotal, t as DataCardFold } from "./RowReason-DJegqY99.mjs";
import { n as NativeBuildsNav } from "./NativeBuildsNav-CPmrkQr0.mjs";
import { i as storeTrackLabels, n as StoreSubmissionBadge, r as isSubmitted, t as SandboxBadge } from "./SandboxBadge-C-Yh0M84.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/native-builds-1M1S1lhY.js
var import_jsx_runtime = require_jsx_runtime();
/** The command that tracks a build made elsewhere. */
var IMPORT_COMMAND = "npx hot-updater native-build import <file>";
/** `native-build import`'s section of the native build guide. */
var IMPORT_GUIDE_URL = "https://hot-updater.dev/docs/guides/native-build#import-a-build-made-elsewhere";
/**
* The toolbar's "Import a build" button and the command it shows: the CLI
* reads the artifact on the machine that has it, so the Console uploads
* nothing, since a host may cap a request's body far below an `.ipa`. The
* guide has the rest, such as `--channel`.
*/
function ImportBuildDialog() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			"aria-label": "Import a build",
			className: "min-h-11 min-w-11 sm:min-h-7 sm:min-w-0",
			size: "sm",
			variant: "outline"
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { "data-icon": "inline-start" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden sm:inline",
			children: "Import a build"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
		className: "sm:max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Import a build" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Track an .ipa, .aab, .apk or .app built elsewhere as a patch base." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
				label: "the import command",
				value: IMPORT_COMMAND,
				wrap: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: buttonVariants({
					className: "min-h-11 w-full sm:min-h-8 sm:w-fit",
					variant: "outline"
				}),
				href: IMPORT_GUIDE_URL,
				rel: "noreferrer",
				target: "_blank",
				children: ["Import guide", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { "data-icon": "inline-end" })]
			})
		]
	})] });
}
/** How an `.ipa`'s export method names it, such as "ad hoc IPA". */
var EXPORT_METHOD_LABELS = {
	"app-store": "App Store",
	"ad-hoc": "ad hoc",
	development: "development",
	enterprise: "enterprise"
};
/** What a path's builds are called, such as "TestFlight build" or "ad hoc IPA". */
var pathNoun = (build) => {
	const artifact = nativeBuildArtifacts[build.artifact_kind].label;
	const noun = build.submitted_to !== null ? `${storeTrackLabels[build.submitted_to]} build` : build.artifact_kind === "ipa" && build.export_method !== null ? `${EXPORT_METHOD_LABELS[build.export_method]} ${artifact}` : artifact;
	return build.is_sandbox ? `sandbox ${noun}` : noun;
};
/** Why a build shows as older: the newer build on its path, when found. */
var olderBuildReason = (newer) => {
	if (newer === void 0) return {
		sentence: "A newer build on its channel reaches people the same way.",
		label: "Older: a newer build on its channel reaches people the same way"
	};
	const name = nativeBuildLabel(newer);
	return {
		sentence: `A newer ${pathNoun(newer)} exists${name === null ? "." : `: ${name}`}`,
		label: `Older: a newer ${pathNoun(newer)} exists${name === null ? "" : `, ${name}`}`
	};
};
/**
* "Older" on a build a newer one on its path passes over, quiet like the
* Bundles list's "Unreachable", naming the newer build. The build may still
* install, so it says no more.
*/
function OlderBuildLabel({ newer }) {
	const reason = olderBuildReason(newer);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowReason, {
		icon: History,
		label: reason.label,
		reason: reason.sentence,
		children: "Older"
	});
}
var NATIVE_BUILD_GUIDE_URL = "https://hot-updater.dev/docs/guides/native-build#how-a-build-is-tracked";
var COLUMNS = 9;
/** The page of the list that shows `channel`'s builds, or every build. */
var channelSearch = (channel) => channel === void 0 ? { channels: "all" } : { channel };
/** A fold of older builds: "1 older build", "12 older builds". */
var OLDER_BUILDS = {
	one: "older build",
	other: "older builds"
};
function EmptyState({ channel, paged, folded, onClearChannel }) {
	if (paged || folded) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableEmpty, {
		icon: HardDrive,
		title: folded ? "Each build here has a newer one" : "No more native builds",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			className: buttonVariants({
				className: "mt-1 min-h-11 sm:min-h-8",
				variant: "outline"
			}),
			search: channelSearch(channel),
			to: "/native-builds",
			children: "Show the newest builds"
		})
	});
	if (channel !== void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTableEmpty, {
		icon: HardDrive,
		title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["No native build embeds ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			translate: "no",
			children: channel
		})] }),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A build embeds the channel it was built on. Build one on this channel, or list every channel's builds." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
			className: "mt-1 min-h-11 sm:min-h-8",
			onClick: onClearChannel,
			variant: "outline",
			children: "Show all channels"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTableEmpty, {
		icon: HardDrive,
		title: "No native builds",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Build one with",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
					className: "font-mono text-xs",
					children: "native-build android"
				}),
				" or",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
					className: "font-mono text-xs",
					children: "native-build ios"
				}),
				", or import one built elsewhere:"
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-full text-left",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableText, {
					label: "the import command",
					value: IMPORT_COMMAND,
					wrap: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: buttonVariants({
					className: "mt-1 min-h-11 sm:min-h-8",
					variant: "outline"
				}),
				href: NATIVE_BUILD_GUIDE_URL,
				rel: "noreferrer",
				target: "_blank",
				children: ["Native build guide", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { "data-icon": "inline-end" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: buttonVariants({
					className: "min-h-11 sm:min-h-8",
					variant: "outline"
				}),
				href: IMPORT_GUIDE_URL,
				rel: "noreferrer",
				target: "_blank",
				children: ["Import guide", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { "data-icon": "inline-end" })]
			})
		]
	});
}
/** What a build is: its platform's name and artifact kind, such as "Android APK". */
var buildTitle = (build) => `${platformLabel(build.platform)} ${nativeBuildArtifacts[build.artifact_kind].label}`;
/**
* The build's artifact kind, such as "IPA", linking to its page. The Platform
* beside it names the platform; the link's name is the whole build.
*/
function BuildLink({ build }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		"aria-label": buildTitle(build),
		className: "relative rounded-sm font-medium whitespace-nowrap text-foreground transition-colors underline-offset-4 after:absolute after:-inset-x-[10px] after:-inset-y-[10px] hover:text-primary hover:underline focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none sm:after:hidden",
		params: { buildId: build.id },
		to: "/native-builds/$buildId",
		children: nativeBuildArtifacts[build.artifact_kind].label
	});
}
/**
* What the build is, its artifact kind and whether it is a sandbox build, kept
* together so the tag never wraps away from the kind it qualifies. In a table
* cell the tag sits beside the kind, so a sandbox row is as tall as any other,
* and the cell is capped at its widest short kind ("AAB Sandbox"): only a
* longer kind, such as a sandbox "Simulator app", puts its tag under it rather
* than widen the table past its frame. A fold's build says "Older" after them,
* as a Bundles row says "Unreachable" beside its ID, wrapping under the kind
* within the same cap. On a card the tag sits beside the kind, under it only
* when a narrow card has no room.
*/
function BuildIdentity({ build, inTable = false, older = false, newer }) {
	if (inTable) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex max-w-24 flex-wrap items-center gap-x-1.5 gap-y-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildLink, { build }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SandboxBadge, { build }),
			older ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OlderBuildLabel, { newer }) : null
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex min-w-0 flex-wrap items-center gap-x-1.5 gap-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildLink, { build }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SandboxBadge, { build })]
	});
}
/** The channel the build embeds; a click lists that channel's builds. */
function ChannelFilterButton({ channel, onChannel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		"aria-label": `Show the builds that embed ${channel}`,
		className: "relative flex max-w-full min-w-0 rounded-md text-left after:absolute after:-inset-x-1 after:-inset-y-[11px] focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none sm:after:hidden",
		onClick: () => onChannel(channel),
		title: channel,
		type: "button",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelBadge, {
			channel,
			className: "block max-w-32 truncate"
		})
	});
}
/**
* The store track a build went to, and under it the store build mark, so a
* build with both stays one badge wide.
*/
function StoreCell({ build }) {
	if (!isSubmitted(build) && !build.is_store_build) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoValue, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreBadges, {
		build,
		className: "flex flex-col items-start gap-1"
	});
}
/** The store badges, laid out by the caller. */
function StoreBadges({ build, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreSubmissionBadge, { build }), build.is_store_build ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			className: "px-1.5",
			variant: "muted",
			children: "Store build"
		}) : null]
	});
}
function BuildNumber({ build }) {
	return build.build_number ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-mono tabular-nums",
		translate: "no",
		children: build.build_number
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoValue, {});
}
/** When the build was registered, from its ID. */
var createdAt = (build) => extractTimestampFromUUIDv7(build.id);
function BuildRow({ build, older = false, newer, onChannel }) {
	const navigate = useNavigate();
	const channel = nativeBuildChannel(build);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTableRow, {
		"aria-label": `Open native build ${build.id}`,
		className: "data-[older=true]:bg-muted/60 data-[older=true]:saturate-50 data-[older=true]:hover:bg-muted/60 data-[older=true]:hover:saturate-100 data-[older=true]:focus-within:saturate-100",
		"data-older": older ? true : void 0,
		onOpen: () => void navigate({
			to: "/native-builds/$buildId",
			params: { buildId: build.id }
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildIdentity, {
				build,
				inTable: true,
				newer,
				older
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelFilterButton, {
				channel,
				onChannel
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformLabel, { platform: build.platform })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildNumber, { build }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetDisplay, {
				appVersion: build.app_version,
				fingerprintHash: build.fingerprint_hash,
				nativeAppVersion: build.native_app_version
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildKeyDisplay, { value: build.build_key }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreCell, { build }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap text-muted-foreground tabular-nums",
				children: formatByteSize(build.byte_size)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-xs text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelativeTime, { ms: createdAt(build) })
			})
		]
	});
}
/**
* A build's card on a narrow screen, scannable a few to a screen: what it is
* and where, then when, then its target and build key, then its store. Every
* value of the row is on it, and a tap opens the build's page.
*/
function BuildCard({ build, older = false, newer, onChannel }) {
	const navigate = useNavigate();
	const channel = nativeBuildChannel(build);
	const stored = isSubmitted(build) || build.is_store_build;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataCard, {
		"aria-label": `Native build ${buildTitle(build)} ${build.id}`,
		className: "gap-3 border-b-0 data-[older=true]:bg-muted/60 data-[older=true]:saturate-50 data-[older=true]:hover:bg-muted/60 data-[older=true]:hover:saturate-100 data-[older=true]:focus-within:saturate-100",
		"data-older": older ? true : void 0,
		onClick: openOutsideControls(() => void navigate({
			to: "/native-builds/$buildId",
			params: { buildId: build.id }
		})),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 items-center gap-x-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformIcon, {
						className: "size-4 shrink-0 text-muted-foreground",
						platform: build.platform
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildIdentity, { build }),
					older ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OlderBuildLabel, { newer }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-w-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelFilterButton, {
					channel,
					onChannel
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex flex-wrap items-center gap-x-1.5 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: platformLabel(build.platform)
					}),
					build.build_number ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						translate: "no",
						children: [
							"Build",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono tabular-nums text-foreground",
								children: build.build_number
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "·"
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatByteSize(build.byte_size)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelativeTime, { ms: createdAt(build) })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-x-4 gap-y-6 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Target "
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetDisplay, {
						appVersion: build.app_version,
						fingerprintHash: build.fingerprint_hash,
						nativeAppVersion: build.native_app_version
					})]
				}), build.build_key ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Build key "
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildKeyDisplay, { value: build.build_key })]
				}) : null]
			}),
			stored ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreBadges, {
				build,
				className: "flex flex-wrap items-center gap-1.5"
			}) : null
		]
	});
}
/**
* A fold of older builds, where they sit in the list: closed, the number it
* holds; open, those builds in order, each shaded and saying which newer
* build passes it over, read a chunk at a time once it opens.
*/
function OlderBuildsFold({ fold, channel, isMobile, open, onOpenChange, onChannel }) {
	const query = useNativeBuildFoldQuery(channel, {
		...fold.from === void 0 ? {} : { from: fold.from },
		to: fold.to
	}, open);
	const pages = query.data?.pages ?? [];
	const newer = Object.assign({}, ...pages.map((page) => page.newer));
	const rows = pages.flatMap((page) => page.rows);
	const columns = isMobile ? void 0 : COLUMNS;
	const status = query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldStatus, {
		columns,
		label: "Older builds",
		onRetry: () => void query.refetch(),
		state: "error"
	}) : query.isPending || query.isFetchingNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldStatus, {
		columns,
		label: "Loading older builds",
		state: "loading"
	}) : query.hasNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoldStatus, {
		columns,
		label: "Older builds",
		onMore: () => void query.fetchNextPage(),
		state: "more"
	}) : null;
	const props = {
		label: foldLabel(fold, OLDER_BUILDS),
		open,
		onOpenChange,
		panelId: `native-build-fold-${fold.to}`
	};
	return isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataCardFold, {
		...props,
		inList: true,
		children: [rows.map((build) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-b last:border-b-0",
			role: "listitem",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildCard, {
				build,
				newer: newer[build.id],
				older: true,
				onChannel
			})
		}, build.id)), status]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTableFold, {
		...props,
		columns: COLUMNS,
		children: [rows.map((build) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildRow, {
			build,
			newer: newer[build.id],
			older: true,
			onChannel
		}, build.id)), status]
	});
}
/**
* The registered native builds, newest first, one page at a time, as a
* column table like Bundles' on wide screens and cards on narrow ones. A
* row opens the build's page; its channel filters the list by that channel.
* A page counts the newest build of each distribution path and the store
* build; the builds a newer one passes over fold where they sit, each run
* one fold that opens on its own.
*/
function NativeBuildsTable({ builds, channel, paged, onChannel }) {
	const isMobile = useIsMobile();
	const folds = useOpenFolds();
	const entries = builds.data?.entries;
	const { next, previous } = builds.data ?? {};
	const count = entries?.filter(({ kind }) => kind === "row").length ?? 0;
	if (builds.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "destructive",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Native builds couldn't be loaded" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Check your connection and try again." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
				onClick: () => void builds.refetch(),
				size: "xs",
				variant: "outline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry"]
			}) })
		]
	});
	const empty = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		channel,
		folded: (entries?.length ?? 0) > 0,
		onClearChannel: () => onChannel(void 0),
		paged
	});
	const fold = (entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OlderBuildsFold, {
		channel,
		fold: entry,
		isMobile,
		onChannel,
		onOpenChange: (open) => folds.set(foldKey(entry), open),
		open: folds.isOpen(foldKey(entry))
	}, `fold-${entry.to}`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFrame, { children: isMobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-busy": builds.isPlaceholderData,
		"aria-label": "Native builds",
		className: "h-full overflow-y-auto aria-busy:opacity-60",
		role: "list",
		children: builds.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataCardSkeletons, { label: "Loading native builds" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [count === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataCardsEmpty, { children: empty }) : null, entries?.map((entry) => entry.kind === "fold" ? fold(entry) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-b last:border-b-0",
			role: "listitem",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildCard, {
				build: entry.row,
				onChannel
			})
		}, entry.row.id))] })
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
		"aria-busy": builds.isPlaceholderData,
		"aria-label": "Native builds",
		className: "aria-busy:opacity-60 [&_td]:px-1.5 [&_th]:px-1.5",
		header: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Artifact" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Channel" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Platform" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Build" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Target" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Build key" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Store" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Size" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Created" })
		] }),
		rowGroups: true,
		children: builds.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableBody, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableSkeletonRows, {
			columns: COLUMNS,
			label: "Loading native builds"
		}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [count === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableBody, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFullRow, {
			columns: COLUMNS,
			children: empty
		}) }) : null, groupsOf(entries ?? []).map((group) => group.kind === "fold" ? fold(group.fold) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableBody, { children: group.rows.map((build) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildRow, {
			build,
			onChannel
		}, build.id)) }, `rows-${group.rows[0].id}`))] })
	}) }), builds.isPending || entries === void 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTablePagination, {
		count,
		folded: {
			...foldedTotal(entries),
			label: "older"
		},
		label: "Native build pages",
		noun: ["build", "builds"],
		pending: builds.isPlaceholderData,
		newest: paged ? {
			search: channelSearch(channel),
			to: "/native-builds"
		} : void 0,
		next: next === void 0 ? void 0 : {
			search: {
				...channelSearch(channel),
				before: next
			},
			to: "/native-builds"
		},
		previous: previous === void 0 ? void 0 : {
			search: {
				...channelSearch(channel),
				...previous
			},
			to: "/native-builds"
		}
	})] });
}
/**
* The list while its channel is unknown: loading, whatever the cache holds,
* and nothing to refresh. A disabled query still reads when refetched.
*/
var PENDING_BUILDS = {
	data: void 0,
	isError: false,
	isPending: true,
	isPlaceholderData: false,
	refetch: () => void 0
};
/**
* The native builds Hot Updater tracks: one page at a time, newest first,
* those that embed one channel, the default one unless the URL names another
* or every channel. The page and the channel are in the URL, so a pull
* request links to its channel's builds.
*/
function NativeBuildsPage({ search, onSearchChange }) {
	const channels = useChannelsQuery();
	const channelNames = channels.data?.map(({ name }) => name) ?? [];
	const page = resolveNativeBuildsSearch(search, channels.data && channelNames);
	const pending = page === void 0;
	const channelsFailed = pending && channels.isError;
	const { channel, before, after } = page ?? search;
	const query = useNativeBuildsQuery(page ?? {}, { enabled: !pending });
	const builds = pending ? PENDING_BUILDS : query;
	const filterBy = (next) => onSearchChange(next === void 0 ? { channels: "all" } : { channel: next });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-svh min-h-0 min-w-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-10 flex shrink-0 flex-wrap items-center gap-x-3 gap-y-1 border-b bg-background px-3 py-3 sm:min-h-12 sm:flex-nowrap sm:bg-card/70 sm:px-4 sm:backdrop-blur-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1 size-11 lg:size-7" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, {
						"aria-hidden": "true",
						className: "size-3.5 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-sm font-medium",
						children: "Native builds"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "basis-full pl-12 text-xs text-muted-foreground sm:basis-auto sm:pl-0",
					children: "Store and test builds, each the built-in bundle its OTAs patch from."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 min-w-0 flex-1 flex-col gap-4 bg-muted/5 p-3 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeBuildsNav, { current: "builds" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelPicker, {
							allChannels: true,
							className: "max-sm:min-w-0 max-sm:basis-full",
							onValueChange: filterBy,
							pending,
							value: channel
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "ml-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportBuildDialog, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
							"aria-label": "Refresh native builds",
							className: "size-11 sm:size-7",
							disabled: builds.isPending,
							onClick: () => void builds.refetch(),
							size: "icon-sm",
							variant: "ghost",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "aria-hidden": "true" })
						})
					]
				}),
				channelsFailed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Channels couldn't be loaded" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Native builds show once the channels load." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
							className: "min-h-11 sm:min-h-7",
							onClick: () => void channels.refetch(),
							size: "xs",
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }), "Retry"]
						}) })
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeBuildsTable, {
					builds,
					channel,
					onChannel: filterBy,
					paged: before !== void 0 || after !== void 0
				})
			]
		})]
	});
}
function NativeBuildsRoute() {
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeBuildsPage, {
		onSearchChange: (next) => void navigate({ search: next }),
		search
	});
}
//#endregion
export { NativeBuildsRoute as component };
