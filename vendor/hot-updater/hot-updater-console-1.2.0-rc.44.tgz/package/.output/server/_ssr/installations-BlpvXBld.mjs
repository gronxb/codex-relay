import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as requireConsoleFeature } from "./console-features-api-DbEAU6JB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/installations-BlpvXBld.js
var DAY_MS = 864e5;
/** The time ranges an event list reads, shortest first. */
var eventRanges = {
	"24h": {
		period: "24 hours",
		durationMs: DAY_MS
	},
	"7d": {
		period: "7 days",
		durationMs: 7 * DAY_MS
	},
	"30d": {
		period: "30 days",
		durationMs: 30 * DAY_MS
	},
	"90d": {
		period: "90 days",
		durationMs: 90 * DAY_MS
	}
};
var EVENT_RANGES = Object.keys(eventRanges);
/** The next longer range, or undefined for the longest. */
var widerEventRange = (range) => EVENT_RANGES[EVENT_RANGES.indexOf(range) + 1];
/**
* The receipt interval [sinceMs, beforeReceivedAtMs) a range covers. The end
* stays fixed while the list pages, so every page reads the same interval.
*/
var eventRangeBounds = (range, beforeReceivedAtMs) => ({
	beforeReceivedAtMs,
	sinceMs: Math.max(0, beforeReceivedAtMs - eventRanges[range].durationMs)
});
var readCursor = (value) => typeof value === "string" && value.length > 0 ? value : void 0;
var readTimestamp = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? value : void 0;
var readEventRange = (value) => EVENT_RANGES.find((range) => range === value);
/**
* The installations route's scroll-restoration key: every visit to one page
* of the event list shares its scroll position, and a lookup keeps its own
* for each history entry.
*/
function installationsScrollRestorationKey(location) {
	const search = validateInstallationsSearch(location.search);
	return search.query === void 0 && search.installId === void 0 ? `/installations?eventsBefore=${search.eventsBefore ?? "new"}&eventsRange=${search.eventsRange ?? "7d"}&eventsCursor=${search.eventsCursor ?? "first"}` : location.state.__TSR_key;
}
function validateInstallationsSearch(search) {
	return {
		query: typeof search.query === "string" ? search.query : void 0,
		installId: typeof search.installId === "string" ? search.installId : void 0,
		eventsCursor: readCursor(search.eventsCursor),
		eventsBefore: readTimestamp(search.eventsBefore),
		eventsRange: readEventRange(search.eventsRange),
		searchCursor: readCursor(search.searchCursor),
		historyCursor: readCursor(search.historyCursor),
		historyBefore: readTimestamp(search.historyBefore)
	};
}
var $$splitComponentImporter = () => import("./installations-DJyZCAbN.mjs");
var $$splitNotFoundComponentImporter = () => import("./installations-itVpa8FC.mjs");
var Route = createFileRoute("/installations")({
	beforeLoad: ({ context }) => requireConsoleFeature(context.queryClient, "insights"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	staticData: { scrollRestorationKey: installationsScrollRestorationKey },
	validateSearch: validateInstallationsSearch
});
//#endregion
export { installationsScrollRestorationKey as a, eventRanges as i, Route as n, widerEventRange as o, eventRangeBounds as r, EVENT_RANGES as t };
