//#region node_modules/.nitro/vite/services/ssr/assets/console-features-DTYyXrWO.js
/**
* The console's features and the server plugin each one needs. The console
* serves a feature only when its config lists the plugin, as the server runs
* it, and against a self-hosted server (`standaloneRepository`) only the
* features its admin API serves (`remote`); the rest read the database.
* Navigation, route guards, and server functions all read this registry. Its
* other halves, keyed by the same features, hold what serves each feature on
* the server (`server/console-feature-apis.ts`) and what each adds to pages
* (`components/features/FeatureSlots.tsx`). Their order is the sidebar's,
* below Bundles.
*/
var consoleFeatures = {
	insights: {
		plugin: "insights",
		label: "Insights",
		remote: true
	},
	insightsAnalytics: {
		plugin: "insights",
		label: "Insights",
		remote: false
	},
	remoteConfig: {
		plugin: "remoteConfig",
		label: "Remote Config",
		remote: true
	},
	apiKeys: {
		plugin: "apiKeys",
		label: "API keys",
		remote: false
	}
};
var featureIds = Object.keys(consoleFeatures);
/** The features on for the plugins the console's config lists, from where the console reads them. */
var resolveConsoleFeatures = (plugins, { remote }) => {
	const installed = new Set(plugins);
	return Object.fromEntries(featureIds.map((feature) => {
		const { plugin, remote: servedRemotely } = consoleFeatures[feature];
		return [feature, installed.has(plugin) && (servedRemotely || !remote)];
	}));
};
/** Why a feature is off: its plugin is missing, or it reads a database the console does not open. */
var unavailableReason = (feature, { remote }) => remote && !consoleFeatures[feature].remote ? "remote" : "plugin";
/**
* A server function refused a feature the console does not serve: the
* features' 404. The client recognizes it by `name`, which survives
* serialization where the class does not.
*/
var ConsoleFeatureUnavailableError = class extends Error {
	name = "ConsoleFeatureUnavailableError";
	status = 404;
	constructor(feature, { remote }) {
		super(unavailableReason(feature, { remote }) === "remote" ? "The console reads this from the database, and it reaches a self-hosted server through its admin API instead." : `The server runs without the ${consoleFeatures[feature].plugin}() plugin.`);
		this.feature = feature;
	}
};
var isConsoleFeatureUnavailableError = (error) => error instanceof Error && error.name === "ConsoleFeatureUnavailableError" && featureIds.includes(Reflect.get(error, "feature"));
//#endregion
export { unavailableReason as a, resolveConsoleFeatures as i, consoleFeatures as n, isConsoleFeatureUnavailableError as r, ConsoleFeatureUnavailableError as t };
