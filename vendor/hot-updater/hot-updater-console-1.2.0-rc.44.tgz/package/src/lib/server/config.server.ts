import type { HotUpdaterCoreApi } from "@hot-updater/plugin-core";
import { getRequest } from "@tanstack/react-start/server";

import { requireConsoleAccess } from "./auth.server";
import {
  resolveConsoleConfig,
  type ResolvedConsoleConfig,
} from "./console-runtime.server";
import type { ConsoleRuntime } from "./runtime.server";

let configPromise: Promise<ResolvedConsoleConfig> | null = null;
let core: HotUpdaterCoreApi | null = null;
let runtime: ConsoleRuntime | null = null;

const loadCachedConfig = async (request: Request) => {
  if (!configPromise) {
    configPromise = resolveConsoleConfig(request).catch((error) => {
      configPromise = null;
      throw error;
    });
  }

  return configPromise;
};

/**
 * The console's config, core, and features, without the access check: for
 * routes that take no session, such as a channel link's QR code. Everything
 * else goes through {@link prepareConfig}.
 */
export const loadConsole = async (request: Request = getRequest()) => {
  const config = await loadCachedConfig(request);

  // Bundles, releases, catalogs, and channels: core assembled as the
  // server's, on the server's own path, or a self-hosted server's admin API.
  core ??= config.core;

  // The console's features: those of the plugins its config lists.
  if (!runtime) {
    const { createConsoleRuntime } = await import("./runtime.server");
    runtime = createConsoleRuntime(config);
  }

  // Each bundle file is read and deleted with its protocol's storage.
  return { config, core, runtime, storage: config.storage };
};

export const prepareConfig = async (request: Request = getRequest()) => {
  try {
    await requireConsoleAccess(request);
    return await loadConsole(request);
  } catch (error) {
    if (
      !(
        error instanceof Response &&
        (error.status === 401 || error.status === 403)
      )
    ) {
      console.error("Error during configuration initialization:", error);
    }
    throw error;
  }
};
