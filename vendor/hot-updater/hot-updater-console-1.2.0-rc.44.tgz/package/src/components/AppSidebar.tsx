import { Link, useRouterState } from "@tanstack/react-router";
import { LogOut, HardDrive, Moon, Package, Sun } from "lucide-react";
import { type ReactElement, type ReactNode, useState } from "react";
import { toast } from "sonner";

import { useFeatureUi } from "@/components/features/FeatureSlots";
import { isIosBrowser } from "@/components/features/native-builds/IosInstall";
import { HotUpdaterLogo } from "@/components/HotUpdaterLogo";
import { useTheme } from "@/components/ThemeProvider";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { forgetKeptIosDevice } from "@/lib/ios-devices-api";
import { consolePathFromRouter } from "@/lib/native-builds";

type NavigationItem = {
  readonly label: string;
  readonly icon: ReactNode;
  readonly active: boolean;
  readonly link: ReactElement;
};

export function AppSidebar({ canSignOut = false }: { canSignOut?: boolean }) {
  const { setOpenMobile } = useSidebar();
  const closeMobileSidebar = () => setOpenMobile(false);
  const [signingOut, setSigningOut] = useState(false);
  const featureUi = useFeatureUi();
  const { theme, setTheme } = useTheme();
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;

  const navigation: readonly NavigationItem[] = [
    {
      label: "Bundles",
      icon: <Package />,
      active: currentPath === "/",
      link: (
        <Link
          to="/"
          onClick={closeMobileSidebar}
          search={{
            afterReleaseId: undefined,
            beforeReleaseId: undefined,
            channelId: undefined,
            enabled: undefined,
            releaseId: undefined,
            platform: undefined,
            bundleId: undefined,
            scopeKey: undefined,
          }}
        />
      ),
    },
    {
      label: "Native builds",
      icon: <HardDrive />,
      // A build's page keeps its list's item active.
      active:
        currentPath === "/native-builds" ||
        currentPath.startsWith("/native-builds/"),
      link: (
        <Link to="/native-builds" onClick={closeMobileSidebar} search={{}} />
      ),
    },
    // Each feature that is on adds its item, as the feature registry lists it.
    ...featureUi.flatMap(({ features, label, navigation }) =>
      navigation === undefined
        ? []
        : [
            {
              label,
              icon: navigation.icon,
              active: navigation.paths.includes(currentPath),
              link: navigation.link({ features, onClick: closeMobileSidebar }),
            },
          ],
    ),
  ];

  const signOut = async () => {
    setSigningOut(true);
    try {
      // Only an iPhone or iPad holds this Safari's proof of itself.
      if (isIosBrowser(navigator)) {
        await forgetKeptIosDevice(
          consolePathFromRouter(window.location, routerState.location.pathname),
        );
      }
      const response = await fetch("/api/auth/sign-out", {
        body: "{}",
        headers: { "content-type": "application/json" },
        method: "POST",
      });
      if (!response.ok) throw new Error("Sign-out failed. Please try again.");
      window.location.reload();
    } catch {
      setSigningOut(false);
      toast.error("Sign-out failed. Please try again.");
    }
  };

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="h-12 justify-center">
        <Link
          to="/"
          onClick={closeMobileSidebar}
          search={{
            afterReleaseId: undefined,
            beforeReleaseId: undefined,
            channelId: undefined,
            enabled: undefined,
            releaseId: undefined,
            platform: undefined,
            bundleId: undefined,
            scopeKey: undefined,
          }}
          className="flex items-center gap-3 p-1 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:p-2 max-md:min-h-11"
        >
          <HotUpdaterLogo className="h-7 w-7 shrink-0" />
          <div className="flex flex-col gap-0 group-data-[collapsible=icon]:hidden">
            <span className="text-sm font-semibold tracking-tight text-sidebar-foreground leading-tight">
              Hot Updater
            </span>
            <span className="text-[10px] text-sidebar-foreground/60 leading-tight">
              Console
            </span>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigation.map((item) => (
                <SidebarMenuItem key={item.label}>
                  <SidebarMenuButton
                    isActive={item.active}
                    render={item.link}
                    tooltip={item.label}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          {canSignOut ? (
            <SidebarMenuItem>
              <SidebarMenuButton
                disabled={signingOut}
                onClick={() => void signOut()}
                tooltip="Sign out"
              >
                <LogOut />
                <span>{signingOut ? "Signing out…" : "Sign out"}</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ) : null}
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              tooltip={theme === "dark" ? "Light mode" : "Dark mode"}
            >
              {theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
              <span>{theme === "dark" ? "Light mode" : "Dark mode"}</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
        {/* The Console's license asks a hosted service to keep this notice. */}
        <a
          href="https://hot-updater.dev"
          target="_blank"
          rel="noreferrer"
          className="px-2 pb-1 text-[11px] text-sidebar-foreground/60 hover:text-sidebar-foreground group-data-[collapsible=icon]:hidden max-md:flex max-md:min-h-11 max-md:items-center"
        >
          Powered by hot-updater
        </a>
      </SidebarFooter>
    </Sidebar>
  );
}
