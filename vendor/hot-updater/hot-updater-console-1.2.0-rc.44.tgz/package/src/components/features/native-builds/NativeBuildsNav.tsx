import { Link } from "@tanstack/react-router";

import { tabsListVariants } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

/** A segment of a nav of links, the current one raised, as a tab is. */
export const NAV_TAB_CLASS =
  "relative inline-flex h-full min-h-11 items-center justify-center rounded-md border border-transparent px-3 text-xs font-medium whitespace-nowrap text-foreground/60 transition-colors hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-none aria-[current=page]:bg-background aria-[current=page]:text-foreground aria-[current=page]:shadow-sm dark:text-muted-foreground dark:hover:text-foreground dark:aria-[current=page]:border-input dark:aria-[current=page]:bg-input/30 dark:aria-[current=page]:text-foreground";

/**
 * The two views of Native builds: the builds, and the iOS devices ad hoc
 * builds install on. Links, so each view has its own URL and Back works.
 */
export function NativeBuildsNav({
  current,
}: {
  readonly current: "builds" | "devices";
}) {
  return (
    <nav
      aria-label="Native builds views"
      className={cn(
        tabsListVariants(),
        "h-auto min-h-11 sm:h-8 sm:min-h-0 [&>a]:min-h-11 sm:[&>a]:min-h-0",
      )}
    >
      <Link
        activeOptions={{ exact: true, includeSearch: false }}
        aria-current={current === "builds" ? "page" : undefined}
        className={NAV_TAB_CLASS}
        to="/native-builds"
      >
        Builds
      </Link>
      <Link
        activeOptions={{ exact: true, includeSearch: false }}
        aria-current={current === "devices" ? "page" : undefined}
        className={NAV_TAB_CLASS}
        to="/native-builds/devices"
      >
        iOS devices
      </Link>
    </nav>
  );
}
