import { RefreshCw } from "lucide-react";

import { HashValueDisplay } from "@/components/HashValueDisplay";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DEFAULT_INSIGHTS_RETENTION,
  formatDays,
  type InsightsRetentionDays,
} from "@/lib/insights-retention";
import type {
  InsightsEventRow,
  InsightsInstallationViewRow,
  InsightsViewPage,
} from "@/lib/insights-view";

import { BuiltinBundleBadge, isBuiltinBundle } from "./BuiltinBundle";
import {
  EventBundleTransition,
  EventTimestamp,
  EventTypeDetails,
  HttpResponseDetails,
  useInsightsTimeFormat,
} from "./EventDetails";
import { EventHistoryList } from "./EventHistoryList";
import { InsightsErrorAlert } from "./InsightsErrorAlert";
import { InsightsPagination } from "./InsightsPagination";

const getUserLabel = (event: { readonly userId: string | null }) =>
  event.userId ?? "—";

/** A download or a failed update leaves the installation on the bundle it ran. */
const getLastKnownBundleId = (
  event: InsightsEventRow | InsightsInstallationViewRow,
) =>
  "lastKnownBundleId" in event
    ? event.lastKnownBundleId
    : event.type === "UPDATE_DOWNLOADED" || event.type === "UPDATE_FAILED"
      ? event.fromBundleId
      : event.toBundleId;

export function InstallationHistoryCard({
  error,
  history,
  isLoading,
  onNext,
  onPrevious,
  onRefresh,
  pageNumber,
  retention = DEFAULT_INSIGHTS_RETENTION,
  selectedEvent,
  selectedInstallId,
}: {
  readonly error: unknown;
  readonly history: InsightsViewPage<InsightsEventRow> | undefined;
  readonly isLoading: boolean;
  readonly onRefresh?: () => void;
  readonly onNext: () => void;
  readonly onPrevious: () => void;
  readonly pageNumber: number;
  /** How long the server keeps Insights rows. */
  readonly retention?: InsightsRetentionDays;
  readonly selectedEvent:
    | InsightsEventRow
    | InsightsInstallationViewRow
    | undefined;
  readonly selectedInstallId: string | undefined;
}) {
  const dateTimeFormat = useInsightsTimeFormat();
  const lastKnownBundleId = selectedEvent
    ? getLastKnownBundleId(selectedEvent)
    : undefined;

  const pendingBundleId =
    selectedEvent && "pendingBundleId" in selectedEvent
      ? selectedEvent.pendingBundleId
      : selectedEvent &&
          "type" in selectedEvent &&
          selectedEvent.type === "UPDATE_DOWNLOADED"
        ? selectedEvent.toBundleId
        : null;

  return (
    <Card className="@container min-h-0 min-w-0 shadow-sm">
      <CardHeader className="p-4 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex min-w-0 flex-col gap-1.5">
            <CardTitle className="text-sm font-medium">
              <h2>
                {selectedInstallId !== undefined
                  ? "Installation history"
                  : "Select an installation"}
              </h2>
            </CardTitle>
            {selectedInstallId !== undefined ? (
              <CardDescription>
                Bundle changes and update failures are kept for{" "}
                {formatDays(retention.rawDays)}; the latest report, for{" "}
                {formatDays(retention.dailyDays)} after the installation last
                reports.
              </CardDescription>
            ) : null}
          </div>
          {onRefresh && selectedInstallId !== undefined ? (
            <Button
              className="h-11 lg:h-8"
              size="lg"
              variant="outline"
              onClick={onRefresh}
              disabled={isLoading}
            >
              <RefreshCw aria-hidden="true" data-icon="inline-start" />
              Refresh
            </Button>
          ) : null}
        </div>
      </CardHeader>
      <CardContent className="min-h-0 p-0">
        {selectedInstallId !== undefined && selectedEvent ? (
          <>
            <section
              aria-labelledby="latest-installation-state"
              className="px-4 pb-4 sm:px-6 sm:pb-6"
            >
              <h3 className="sr-only" id="latest-installation-state">
                Latest reported state
              </h3>
              <dl className="grid grid-cols-2 gap-4 @[36rem]:grid-cols-3">
                <div className="col-span-2 min-w-0 @[36rem]:col-span-1">
                  <dt className="text-xs text-muted-foreground">User ID</dt>
                  <dd className="mt-1 text-sm font-medium wrap-anywhere">
                    {getUserLabel(selectedEvent)}
                  </dd>
                </div>
                <div className="min-w-0">
                  <dt className="text-xs text-muted-foreground">Install ID</dt>
                  <dd className="mt-1 font-mono text-xs">
                    <HashValueDisplay
                      value={selectedInstallId}
                      buttonClassName="min-h-11 px-3 lg:min-h-0 lg:px-1.5"
                    />
                  </dd>
                </div>
                <div className="min-w-0">
                  <dt className="text-xs text-muted-foreground">
                    Last known bundle
                  </dt>
                  <dd className="mt-1 flex min-w-0 flex-wrap items-center gap-2 font-mono text-xs">
                    {lastKnownBundleId ? (
                      <HashValueDisplay
                        value={lastKnownBundleId}
                        buttonClassName="min-h-11 px-3 lg:min-h-0 lg:px-1.5"
                      />
                    ) : (
                      "—"
                    )}
                    {isBuiltinBundle(
                      lastKnownBundleId,
                      selectedEvent.minBundleId,
                    ) ? (
                      <BuiltinBundleBadge />
                    ) : null}
                  </dd>
                </div>
                {pendingBundleId ? (
                  <div className="col-span-2 min-w-0">
                    <dt className="text-xs text-muted-foreground">
                      Downloaded · Not launched yet
                    </dt>
                    <dd className="mt-1 text-xs">
                      <HashValueDisplay value={pendingBundleId} />
                    </dd>
                  </div>
                ) : null}
              </dl>
              {selectedEvent.httpResponse ? (
                <div className="mt-4">
                  <HttpResponseDetails event={selectedEvent} />
                </div>
              ) : null}
            </section>
            <Separator />
          </>
        ) : null}
        {selectedInstallId !== undefined ? (
          isLoading ? (
            <div
              className="flex flex-col gap-3 p-6"
              role="status"
              aria-label="Loading installation history"
            >
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : error ? (
            <div className="p-6">
              <InsightsErrorAlert
                error={error instanceof Error ? error : new Error()}
                fallbackTitle="Installation history unavailable"
              />
            </div>
          ) : history && history.data.length > 0 ? (
            <>
              <div className="@[48rem]:hidden">
                <EventHistoryList
                  events={history.data}
                  formatter={dateTimeFormat}
                />
              </div>
              <div className="hidden @[48rem]:block">
                <Table className="min-w-3xl table-fixed">
                  <TableHeader>
                    <TableRow className="[&>th]:px-4 sm:[&>th]:px-6">
                      <TableHead className="w-64">Time</TableHead>
                      <TableHead className="w-48">Event</TableHead>
                      <TableHead className="w-32">App</TableHead>
                      <TableHead className="w-52">Bundle</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {history.data.map((event) => (
                      <TableRow
                        className="[&>td]:px-4 [&>td]:py-4 [&>td]:align-top sm:[&>td]:px-6"
                        key={event.id}
                      >
                        <TableCell className="whitespace-normal text-xs tabular-nums">
                          <EventTimestamp
                            value={event.receivedAtMs}
                            formatter={dateTimeFormat}
                          />
                        </TableCell>
                        <TableCell>
                          <EventTypeDetails event={event} />
                        </TableCell>
                        <TableCell className="whitespace-normal text-xs">
                          <div className="flex flex-col gap-2">
                            <span>
                              {event.platform === "ios" ? "iOS" : "Android"}{" "}
                              {event.appVersion}
                            </span>
                            <span className="text-muted-foreground">
                              {event.channel}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-normal text-xs">
                          <EventBundleTransition event={event} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <InsightsPagination
                hasPrevious={pageNumber > 1}
                label="Installation history"
                nextCursor={history.nextCursor}
                onNext={onNext}
                onPrevious={onPrevious}
                pageLength={history.data.length}
                pageNumber={pageNumber}
              />
            </>
          ) : (
            <>
              <div className="p-6 text-sm text-muted-foreground">
                {pageNumber > 1
                  ? "No older bundle changes."
                  : "No bundle changes recorded yet."}
              </div>
              {history && (pageNumber > 1 || history.nextCursor) ? (
                <InsightsPagination
                  hasPrevious={pageNumber > 1}
                  label="Installation history"
                  nextCursor={history.nextCursor}
                  onNext={onNext}
                  onPrevious={onPrevious}
                  pageLength={0}
                  pageNumber={pageNumber}
                />
              ) : null}
            </>
          )
        ) : null}
      </CardContent>
    </Card>
  );
}
