import { Link } from "@tanstack/react-router";
import {
  CircleOff,
  ListIcon,
  RotateCcw,
  RotateCw,
  TriangleAlert,
  X,
} from "lucide-react";
import { useState } from "react";

import { BundleIdDisplay } from "@/components/BundleIdDisplay";
import { InfoTooltip } from "@/components/InfoTooltip";
import { PlatformIcon } from "@/components/PlatformIcon";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyTitle,
} from "@/components/ui/empty";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { ReleaseHealthInput } from "@/lib/insights-recovery";
import type { HealthChart } from "@/lib/insights-search";
import {
  CRASH_MIN_ATTEMPTS,
  CRASH_RATE_THRESHOLD,
  crashRateOf,
  MAX_ADOPTION_RELEASES,
  recommendsRollback,
} from "@/lib/release-adoption";
import type {
  ComparedBundle,
  ReleaseHealthState,
} from "@/lib/release-adoption-api";
import { cn } from "@/lib/utils";

import {
  ComparedBundlesChart,
  formatDeployedAt,
  useSeriesColors,
} from "./ComparedBundlesChart";
import { InsightsErrorAlert } from "./InsightsErrorAlert";
import { InsightsPeriodSelector } from "./InsightsPeriodSelector";
import { InsightsScope, platformLabel } from "./InsightsScope";
import { ReleaseCombobox } from "./ReleaseCombobox";
import { RollbackButton } from "./RollbackButton";

const HOUR = 3_600_000;
const DAY = 24 * HOUR;
const percent = (rate: number) => `${(rate * 100).toFixed(1)}%`;
const lengthOf = (durationMs: number) =>
  durationMs > DAY ? `${durationMs / DAY} days` : `${durationMs / HOUR} hours`;
const cadenceOf = (intervalMs: number) =>
  intervalMs === HOUR
    ? "Hourly"
    : intervalMs === DAY
      ? "Daily"
      : `Every ${intervalMs / HOUR} hours`;

/** A bundle's crash numbers over the period, once both counts are read. */
const crashesOf = ({ release, launched, recovered }: ComparedBundle) =>
  launched === undefined || recovered === undefined
    ? undefined
    : {
        crashes: recovered.total,
        ...crashRateOf(launched.total, recovered.total),
        recommended: recommendsRollback(
          release,
          launched.total,
          recovered.total,
        ),
      };

/** A line sample for the legend: solid or dashed, in the text color. */
function LineSample({ dashed }: { readonly dashed?: boolean }) {
  return (
    <svg
      aria-hidden="true"
      className="h-3 w-6 shrink-0"
      viewBox="0 0 24 12"
      preserveAspectRatio="none"
    >
      <line
        x1="0"
        y1="6"
        x2="24"
        y2="6"
        stroke="currentColor"
        strokeWidth="2"
        strokeDasharray={dashed ? "6 4" : undefined}
      />
    </svg>
  );
}

/**
 * Release health: how the live bundles fare after their deployment, on
 * one timeline, per interval. Adoption shows installations downloading each
 * bundle (dashed) and launching it (solid), so the gap is the restarts still
 * to come; Crashes shows them crashing back from it, and offers a rollback
 * when a bundle crashes for too many of them.
 */
export function InsightsOverview({
  input,
  chart,
  onChartChange,
  health,
  onReleasesChange,
  onWindowChange,
  onShowAllPlatforms,
}: {
  readonly input: ReleaseHealthInput;
  readonly chart: HealthChart;
  readonly onChartChange: (chart: HealthChart) => void;
  readonly health: ReleaseHealthState;
  /** Chooses the bundles to compare; undefined returns to the default. */
  readonly onReleasesChange: (releaseIds?: readonly string[]) => void;
  readonly onWindowChange: (window: ReleaseHealthInput["window"]) => void;
  /** Widens the platform filter, offered when one platform has no bundles. */
  readonly onShowAllPlatforms?: () => void;
}) {
  const [active, setActive] = useState<string | null>(null);
  const { period, candidates, releases } = health;
  const ids = (releases ?? []).map(({ release }) => release.releaseId);
  const colorOf = useSeriesColors(ids);
  const full = ids.length >= MAX_ADOPTION_RELEASES;
  const wider =
    period.durationMs < 7 * DAY
      ? "7d"
      : period.durationMs < 30 * DAY
        ? "30d"
        : null;
  const reset = health.isDefault ? null : (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => onReleasesChange(undefined)}
    >
      <RotateCcw aria-hidden="true" data-icon="inline-start" />
      Show live bundles
    </Button>
  );
  // Adoption draws each bundle's launches solid and its downloads dashed;
  // Crashes draws its crashes.
  const seriesOf = (bundle: ComparedBundle) =>
    chart === "adoption" ? bundle.launched : bundle.recovered;
  const loaded = (releases ?? []).filter(
    (bundle) =>
      seriesOf(bundle) !== undefined &&
      (chart !== "adoption" || bundle.downloaded !== undefined),
  );
  const failed =
    (releases ?? []).find(({ error }) => error !== null)?.error ?? null;
  const flagged = (releases ?? []).flatMap((bundle) => {
    const crashes = crashesOf(bundle);
    return crashes?.recommended ? [{ ...bundle, ...crashes }] : [];
  });

  const remove = (releaseId: string) => {
    const rest = ids.filter((id) => id !== releaseId);
    onReleasesChange(rest.length === 0 ? undefined : rest);
  };

  const heading =
    chart === "adoption" ? (
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-1 text-sm font-medium">
          Installations downloading and launching each bundle
          <InfoTooltip label="About adoption">
            Dashed: installations that downloaded the bundle. Solid:
            installations that launched it. After a forced update the two lines
            meet.
          </InfoTooltip>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <p>
            {cadenceOf(period.intervalMs)} · last {lengthOf(period.durationMs)}{" "}
            · UTC
          </p>
          <ul aria-label="Line styles" className="flex items-center gap-3">
            <li className="flex items-center gap-1.5">
              <LineSample dashed />
              Downloaded
            </li>
            <li className="flex items-center gap-1.5">
              <LineSample />
              Launched
            </li>
          </ul>
        </div>
      </div>
    ) : (
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-1 text-sm font-medium">
          Crashes after each deployment
          <InfoTooltip label="About crashes">
            Installations that crashed on a bundle and rolled back. Crash rate =
            crashed ÷ (launched + crashed). A rollback is suggested at{" "}
            {percent(CRASH_RATE_THRESHOLD)} once {CRASH_MIN_ATTEMPTS}{" "}
            installations tried it.
          </InfoTooltip>
        </div>
        <p className="text-xs text-muted-foreground">
          {cadenceOf(period.intervalMs)} · last {lengthOf(period.durationMs)} ·
          UTC
        </p>
      </div>
    );

  const body = (() => {
    if (releases === undefined) {
      return health.error ? (
        <InsightsErrorAlert
          error={health.error}
          fallbackTitle="Release health unavailable"
        />
      ) : (
        <Skeleton aria-label="Loading release health" className="h-64" />
      );
    }
    if (releases.length === 0) {
      return (
        <Empty className="min-h-64">
          <EmptyHeader>
            <EmptyTitle>
              No bundles deployed to {input.channel} ·{" "}
              {platformLabel(input.platform)}
            </EmptyTitle>
            <EmptyDescription>
              Deploy one, or choose another channel or platform in the filters.
            </EmptyDescription>
          </EmptyHeader>
          {reset || (input.platform !== "all" && onShowAllPlatforms) ? (
            <EmptyContent className="flex-row flex-wrap justify-center">
              {input.platform !== "all" && onShowAllPlatforms ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onShowAllPlatforms}
                >
                  Show all platforms
                </Button>
              ) : null}
              {reset}
            </EmptyContent>
          ) : null}
        </Empty>
      );
    }
    if (loaded.length === 0) {
      return failed ? (
        <InsightsErrorAlert
          error={failed}
          fallbackTitle="Release health unavailable"
        />
      ) : (
        <Skeleton aria-label="Loading release health" className="h-64" />
      );
    }
    if (
      loaded.every(
        (bundle) =>
          seriesOf(bundle)!.total === 0 &&
          (chart !== "adoption" || bundle.downloaded!.total === 0),
      )
    ) {
      return chart === "adoption" ? (
        <Empty className="min-h-48">
          <EmptyHeader>
            <EmptyTitle>
              No installation downloaded or launched these bundles in the last{" "}
              {lengthOf(period.durationMs)}
            </EmptyTitle>
            <EmptyDescription>
              {wider
                ? "Choose a longer period, or refresh after apps download them."
                : "Refresh after apps download them."}
            </EmptyDescription>
          </EmptyHeader>
          {wider ? (
            <EmptyContent>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onWindowChange(wider)}
              >
                Show {lengthOf(wider === "7d" ? 7 * DAY : 30 * DAY)}
              </Button>
            </EmptyContent>
          ) : null}
        </Empty>
      ) : (
        <Empty className="min-h-48">
          <EmptyHeader>
            <EmptyTitle>
              No crashes in the last {lengthOf(period.durationMs)}
            </EmptyTitle>
            <EmptyDescription>
              No launch of these bundles crashed and recovered.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      );
    }
    return (
      <ComparedBundlesChart
        period={period}
        lines={releases.map((bundle) => ({
          release: bundle.release,
          points: seriesOf(bundle)?.points,
          ...(chart === "adoption"
            ? { dashed: bundle.downloaded?.points }
            : {}),
          measuredAtMs: seriesOf(bundle)?.measuredAtMs,
        }))}
        colorOf={colorOf}
        active={active}
        names={
          chart === "adoption"
            ? { solid: "Launched", dashed: "Downloaded" }
            : { solid: "Crashed" }
        }
        label={
          chart === "adoption"
            ? "Installations downloading (dashed) and launching (solid) each bundle per interval"
            : "Crashes of each bundle per interval"
        }
      />
    );
  })();

  return (
    <section aria-label="Release health">
      <Card className="min-w-0 overflow-hidden shadow-sm">
        <CardHeader className="flex flex-col gap-4 p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex min-w-0 flex-col gap-1">
              <CardTitle>Release health</CardTitle>
              <InsightsScope
                channel={input.channel}
                platform={input.platform}
                narrower={input.releaseId ? [`Release ${input.releaseId}`] : []}
              />
            </div>
            <div className="flex items-center gap-2">
              <InsightsPeriodSelector
                window={input.window}
                onWindowChange={onWindowChange}
              />
              <Button
                aria-label="Refresh release health"
                variant="ghost"
                size="icon-lg"
                className="max-md:size-11"
                disabled={health.isFetching}
                onClick={health.refresh}
              >
                <RotateCw
                  aria-hidden="true"
                  className={cn(
                    health.isFetching && "motion-safe:animate-spin",
                  )}
                />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent
          aria-busy={health.isFetching}
          className="flex flex-col gap-5 px-6 pb-6"
        >
          <Tabs
            value={chart}
            onValueChange={(value) => onChartChange(value as HealthChart)}
            className="gap-5"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <TabsList
                aria-label="Release health chart"
                className="min-h-11 sm:min-h-9"
              >
                <TabsTrigger value="adoption" className="px-3">
                  Adoption
                </TabsTrigger>
                <TabsTrigger value="crashes" className="px-3">
                  Crashes
                  {flagged.length > 0 ? (
                    <>
                      <TriangleAlert
                        aria-hidden="true"
                        className="text-destructive"
                      />
                      <span className="sr-only">, rollback recommended</span>
                    </>
                  ) : null}
                </TabsTrigger>
              </TabsList>
              {reset}
            </div>
            <TabsContent value="adoption" className="flex flex-col gap-4">
              {heading}
              {chart === "adoption" ? body : null}
            </TabsContent>
            <TabsContent value="crashes" className="flex flex-col gap-4">
              {flagged.map((bundle) => (
                <Alert key={bundle.release.releaseId} variant="destructive">
                  <TriangleAlert aria-hidden="true" />
                  <AlertTitle>
                    Roll back{" "}
                    <BundleIdDisplay
                      bundleId={bundle.release.releaseId}
                      className="text-sm"
                    />
                  </AlertTitle>
                  <AlertDescription className="flex flex-col items-start gap-3">
                    It crashed for {percent(bundle.rate)} of the installations
                    that tried it ({bundle.crashes.toLocaleString()} of{" "}
                    {bundle.attempts.toLocaleString()}), above{" "}
                    {percent(CRASH_RATE_THRESHOLD)}.
                    <RollbackButton
                      release={bundle.release}
                      rate={bundle.rate}
                      crashes={bundle.crashes}
                      attempts={bundle.attempts}
                      // The live bundles no longer include it once it is
                      // disabled: keep comparing the same ones.
                      onRolledBack={
                        health.isDefault
                          ? () => onReleasesChange(ids)
                          : undefined
                      }
                    />
                  </AlertDescription>
                </Alert>
              ))}
              {heading}
              {chart === "crashes" ? body : null}
            </TabsContent>
          </Tabs>
          {releases !== undefined && releases.length > 0 ? (
            <>
              {failed && loaded.length > 0 ? (
                <InsightsErrorAlert
                  error={failed}
                  fallbackTitle="Some bundles could not be read"
                />
              ) : null}
              <Table aria-label="Compared bundles">
                <TableHeader>
                  <TableRow>
                    <TableHead>Bundle</TableHead>
                    {chart === "adoption" ? (
                      <>
                        <TableHead className="text-right">Downloaded</TableHead>
                        <TableHead className="text-right">Launched</TableHead>
                      </>
                    ) : (
                      <>
                        <TableHead className="text-right">Crashed</TableHead>
                        <TableHead className="text-right">Crash rate</TableHead>
                      </>
                    )}
                    <TableHead className="w-10">
                      <span className="sr-only">Remove</span>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {releases.map((bundle) => {
                    const { release } = bundle;
                    const crashes = crashesOf(bundle);
                    return (
                      <TableRow
                        key={release.releaseId}
                        data-state={
                          active === release.releaseId ? "selected" : undefined
                        }
                        onMouseEnter={() => setActive(release.releaseId)}
                        onMouseLeave={() => setActive(null)}
                        onFocus={() => setActive(release.releaseId)}
                        onBlur={() => setActive(null)}
                      >
                        {/* The bundle cell takes the room left, and wraps in it. */}
                        <TableCell className="w-full max-w-0 whitespace-normal">
                          <div className="flex min-w-0 items-center gap-2 sm:gap-3">
                            {/* Narrower on a phone, so a bundle's ID keeps more of the row. */}
                            <svg
                              aria-hidden="true"
                              className="h-3 w-4 shrink-0 sm:w-6"
                              viewBox="0 0 24 12"
                              preserveAspectRatio="none"
                            >
                              <line
                                x1="0"
                                y1="6"
                                x2="24"
                                y2="6"
                                stroke={colorOf(release.releaseId)}
                                strokeWidth="3"
                              />
                            </svg>
                            <div className="flex min-w-0 flex-col">
                              <span className="flex min-w-0 items-center gap-2">
                                <BundleIdDisplay
                                  bundleId={release.releaseId}
                                  className="min-w-0"
                                />
                                {release.enabled ? null : (
                                  <Badge variant="outline">Disabled</Badge>
                                )}
                              </span>
                              <span className="text-xs break-words text-muted-foreground">
                                <PlatformIcon
                                  platform={release.platform}
                                  className="mr-1 inline size-3 align-[-1px]"
                                />
                                <span className="sr-only">
                                  {platformLabel(release.platform)}{" "}
                                </span>
                                Deployed{" "}
                                {formatDeployedAt(release.deployedAtMs)}
                                {release.targetAppVersion
                                  ? ` · ${release.targetAppVersion}`
                                  : ""}
                                {release.enabled && !release.live ? (
                                  <>
                                    {" · "}
                                    <span
                                      className="inline-flex items-center gap-1 align-middle"
                                      title="No device gets this bundle with the current delivery settings."
                                    >
                                      <CircleOff
                                        aria-hidden="true"
                                        className="size-3"
                                      />
                                      Unreachable
                                    </span>
                                  </>
                                ) : null}
                              </span>
                            </div>
                          </div>
                        </TableCell>
                        {chart === "adoption" ? (
                          <>
                            <TableCell className="text-right whitespace-nowrap tabular-nums">
                              {bundle.downloaded?.total.toLocaleString() ?? "—"}
                            </TableCell>
                            <TableCell className="text-right font-medium whitespace-nowrap tabular-nums">
                              {bundle.launched?.total.toLocaleString() ?? "—"}
                            </TableCell>
                          </>
                        ) : (
                          <>
                            <TableCell className="text-right whitespace-nowrap tabular-nums">
                              {crashes === undefined ? (
                                "—"
                              ) : crashes.crashes === 0 ? (
                                <span className="text-muted-foreground">0</span>
                              ) : (
                                crashes.crashes.toLocaleString()
                              )}
                            </TableCell>
                            <TableCell className="text-right whitespace-nowrap tabular-nums">
                              {crashes === undefined ||
                              crashes.attempts === 0 ? (
                                "—"
                              ) : crashes.recommended ? (
                                <span className="inline-flex items-center gap-1 font-medium text-destructive">
                                  <TriangleAlert
                                    aria-hidden="true"
                                    className="size-3.5"
                                  />
                                  {percent(crashes.rate)}
                                  <span className="sr-only">
                                    , rollback recommended
                                  </span>
                                </span>
                              ) : (
                                <span
                                  className={cn(
                                    crashes.attempts < CRASH_MIN_ATTEMPTS &&
                                      "text-muted-foreground",
                                  )}
                                  title={
                                    crashes.attempts < CRASH_MIN_ATTEMPTS
                                      ? `Only ${crashes.attempts} installations tried it`
                                      : undefined
                                  }
                                >
                                  {percent(crashes.rate)}
                                </span>
                              )}
                            </TableCell>
                          </>
                        )}
                        <TableCell>
                          <Button
                            aria-label={`Remove ${release.releaseId}`}
                            className="max-md:size-11"
                            variant="ghost"
                            size="icon-xs"
                            onClick={() => remove(release.releaseId)}
                          >
                            <X aria-hidden="true" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              {(candidates ?? []).length > 0 ? (
                <ReleaseCombobox
                  scope={{ channel: input.channel, platform: input.platform }}
                  candidates={candidates ?? []}
                  excluded={ids}
                  disabled={full}
                  label="Add a bundle"
                  placeholder={
                    full
                      ? `Up to ${MAX_ADOPTION_RELEASES} bundles`
                      : "Add a bundle by ID or app version…"
                  }
                  onPick={(release) =>
                    onReleasesChange([...ids, release.releaseId])
                  }
                />
              ) : null}
            </>
          ) : null}
        </CardContent>
        <CardFooter className="flex items-center justify-end border-t px-6 py-5">
          <Link
            className={buttonVariants({
              className: "max-md:h-11",
              variant: "outline",
              size: "sm",
            })}
            to="/installations"
          >
            <ListIcon aria-hidden="true" />
            Event history
          </Link>
        </CardFooter>
      </Card>
    </section>
  );
}
