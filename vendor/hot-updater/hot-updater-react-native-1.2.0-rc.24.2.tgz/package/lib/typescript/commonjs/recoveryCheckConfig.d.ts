import type { CheckForUpdateOptions } from "./checkForUpdate";
/**
 * The native key-value entry native reads after a crash: once a launch of the
 * app ends in a crash that doesn't roll back, the next launch checks for an
 * update natively, without the app's JavaScript, whose own update flow may be
 * what crashes. Native knows no server of its own, so the app's update checks
 * leave it here. A device that never checked, such as one whose user hasn't
 * accepted the privacy terms yet, has none, so native sends no request.
 */
export declare const RECOVERY_CHECK_CONFIG_KEY = "hot-updater/recovery-check-config";
/**
 * Saves the request of an update check the server answered: the server it
 * resolved, its headers and timeout, and its update strategy, which only a
 * check knows. Only answered checks save it, so native always repeats a
 * request that reached the server, whichever instance made it last, and a
 * device that never checked sends nothing. Native checks of main save theirs
 * the same way. The channel is left out on purpose: native checks
 * the device's own channel, the one the crashing bundle came from and its fix
 * is published to. A check of another channel is a one-off until its update
 * is applied, and a crash must not switch the device's channel.
 */
export declare const saveRecoveryCheckConfig: (input: {
    readonly baseURL: string;
    readonly requestHeaders?: Record<string, string>;
    readonly requestTimeout?: number;
    readonly updateStrategy: CheckForUpdateOptions["updateStrategy"];
}) => void;
//# sourceMappingURL=recoveryCheckConfig.d.ts.map