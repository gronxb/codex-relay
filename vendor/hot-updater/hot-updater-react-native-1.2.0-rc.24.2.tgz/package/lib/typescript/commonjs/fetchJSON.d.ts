import { type UpdateRequest } from "./fetchUpdateResponse";
import { UpdateHttpError } from "./updateError";
export declare class FetchJSONResponseError extends UpdateHttpError {
}
export declare const fetchJSON: <T>(input: Omit<UpdateRequest, "resource">) => Promise<T>;
//# sourceMappingURL=fetchJSON.d.ts.map