import React from "react";
import type { InternalWrapOptions } from "./wrap.types";
export type { HotUpdaterFallbackComponentProps, HotUpdaterWrapOptions, InternalWrapOptions, RunUpdateProcessResponse, } from "./wrap.types";
export declare function wrap(options: InternalWrapOptions): <P extends object>(WrappedComponent: React.ComponentType<P>) => React.ComponentType<P>;
//# sourceMappingURL=wrap.d.ts.map