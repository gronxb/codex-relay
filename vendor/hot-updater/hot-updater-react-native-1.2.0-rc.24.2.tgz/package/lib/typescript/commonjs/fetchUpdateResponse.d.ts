import type { UpdateHttpResponse } from "@hot-updater/protocol";
export interface UpdateRequest {
    readonly url: string;
    readonly resource: UpdateHttpResponse["resource"];
    readonly requestHeaders?: Record<string, string>;
    readonly requestTimeout?: number;
    readonly onResponse?: (response: UpdateHttpResponse) => void;
}
/** How long an update request may take when the app sets no `requestTimeout`. */
export declare const DEFAULT_REQUEST_TIMEOUT_MS = 5000;
/** Read once for parsing and diagnostics, under the same request timeout. */
export declare const fetchUpdateResponse: ({ url, resource, requestHeaders, requestTimeout, onResponse, }: UpdateRequest) => Promise<{
    response: Response;
    body: string | null;
}>;
//# sourceMappingURL=fetchUpdateResponse.d.ts.map