import { type ExpectedReleaseCatalogScope, type ReleaseCatalog } from "@hot-updater/protocol";
import { type UpdateRequest } from "./fetchUpdateResponse";
export declare const MAX_RELEASE_CATALOG_CACHE_ENTRY_BYTES: number;
type FetchReleaseCatalogInput = {
    readonly baseURL: string;
    readonly expectedScope: ExpectedReleaseCatalogScope;
    readonly requestHeaders?: Record<string, string>;
    readonly requestTimeout?: number;
    readonly url: string;
    readonly onResponse?: UpdateRequest["onResponse"];
};
export declare const createReleaseCatalogCachePartition: (input: Pick<FetchReleaseCatalogInput, "baseURL" | "requestHeaders" | "url">) => string;
/**
 * Fetches a scope's catalog, or null when the server answers that the scope
 * has none (a 404 with `x-hot-updater-catalog: none`).
 */
export declare const fetchReleaseCatalogWithCache: (input: FetchReleaseCatalogInput) => Promise<ReleaseCatalog | null>;
export {};
//# sourceMappingURL=releaseCatalogCache.d.ts.map