import { type ArtifactInfo, type ChangedAssetPatch, type HotUpdaterBaseURL, type ReleaseCatalog, type UpdateHttpResponse } from "@hot-updater/protocol";
export interface ReleaseCatalogRequest {
    readonly platform: "ios" | "android";
    readonly channel: string;
    readonly updateStrategy: "fingerprint" | "appVersion";
    readonly appVersion: string;
    readonly fingerprintHash: string | null;
    readonly requestHeaders?: Record<string, string>;
    readonly requestTimeout?: number;
}
export interface ArtifactRequest {
    /**
     * The newest artifact protocol native installs: 1 for native built from an
     * SDK older than protocol v2. 2 by default.
     */
    readonly artifactProtocol?: 1 | 2;
    readonly targetBundleId: string;
    readonly currentBundleId: string;
    readonly requestHeaders?: Record<string, string>;
    readonly requestTimeout?: number;
}
/**
 * How native downloads a Bundle: with a URL for every file in artifact
 * protocol v1, or in v2 with only the Hermes patch, asking `filesUrl` for the
 * files it downloads one by one.
 */
export type ResolvedArtifact = {
    readonly manifestUrl: string;
    readonly manifestFileHash: string;
    readonly archiveUrl?: string;
    readonly assets: ArtifactInfo["assets"];
} | {
    readonly manifestUrl: string;
    readonly manifestFileHash: string;
    readonly archiveUrl?: string;
    readonly patch?: ChangedAssetPatch & {
        assetPath: string;
    };
    readonly filesUrl: string;
};
export interface HotUpdaterHttpSession {
    /** The server this session requests, with a baseURL function resolved. */
    readonly baseURL: string;
    /** Resolves to null when the server says the scope has no catalog, so no update. */
    fetchReleaseCatalog: (params: ReleaseCatalogRequest) => Promise<ReleaseCatalog | null>;
    resolveArtifact: (params: ArtifactRequest) => Promise<ResolvedArtifact>;
}
export interface HotUpdaterHttpClient {
    createSession: () => Promise<HotUpdaterHttpSession>;
}
/** Creates the private HTTP client HotUpdater.init configures. */
export declare const createHttpClient: (baseURL: HotUpdaterBaseURL, onResponse?: (response: UpdateHttpResponse) => void) => HotUpdaterHttpClient;
//# sourceMappingURL=httpClient.d.ts.map