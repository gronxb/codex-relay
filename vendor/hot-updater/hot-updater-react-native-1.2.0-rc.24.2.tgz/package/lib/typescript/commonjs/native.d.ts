import { type CatalogHighWater, type ChangedAssetPatch, type UpdateStatus, type PersistedSelectionReceipt } from "@hot-updater/protocol";
import { HotUpdaterErrorCode, isHotUpdaterError } from "./error";
import { type InstallArtifactParams, type UpdateBundleParams } from "./specs/NativeHotUpdater";
export { HotUpdaterErrorCode, isHotUpdaterError };
type PersistedUpdateStrategy = "fingerprint" | "appVersion";
export interface ManifestAsset {
    fileHash: string;
    signature?: string;
}
export interface Manifest {
    bundleId: string;
    assets: Record<string, ManifestAsset>;
}
export type HotUpdaterProgressArtifactType = "diff";
export type HotUpdaterDiffFileStatus = "pending" | "downloading" | "downloaded" | "failed";
export interface HotUpdaterDiffFileSnapshot {
    /**
     * Manifest asset path for this progress entry.
     *
     * This is the stable identity of the asset in the installed bundle. Use this
     * when matching progress back to the manifest or to the final file location.
     */
    path: string;
    /**
     * Artifact path currently being transferred for this progress entry.
     *
     * Usually this is the same as `path`. It can differ when the updater
     * downloads an intermediate artifact that will be applied to produce the
     * final asset.
     */
    downloadPath: string;
    /**
     * Current download state for this asset within the manifest diff update.
     */
    status: HotUpdaterDiffFileStatus;
    /**
     * Download progress for this file, normalized from 0 to 1.
     */
    progress: number;
    /**
     * Stable display order among diff files.
     */
    order: number;
    /**
     * Bytes downloaded for `downloadPath`, when the native downloader reports it.
     */
    downloadedBytes?: number;
    /**
     * Total expected bytes for `downloadPath`, when known.
     */
    totalBytes?: number;
}
export interface HotUpdaterDiffProgressDetails {
    totalFilesCount: number;
    completedFilesCount: number;
    files: HotUpdaterDiffFileSnapshot[];
}
export type HotUpdaterProgressEvent = {
    progress: number;
    artifactType: "diff";
    details: HotUpdaterDiffProgressDetails;
};
export type HotUpdaterEvent = {
    onProgress: HotUpdaterProgressEvent;
};
export declare const addListener: <T extends keyof HotUpdaterEvent>(eventName: T, listener: (event: HotUpdaterEvent[T]) => void) => () => void;
export type UpdateParams = UpdateBundleParams & {
    status: UpdateStatus;
    shouldSkipCurrentBundleIdCheck?: boolean;
};
/** How the update check stages a Bundle over artifact protocol v2. */
export type InstallArtifactUpdateParams = Omit<InstallArtifactParams, "patch"> & {
    patch?: (ChangedAssetPatch & {
        assetPath: string;
    }) | null;
    status: UpdateStatus;
    shouldSkipCurrentBundleIdCheck?: boolean;
};
/**
 * Whether native installs artifact protocol v2. Native built from an SDK
 * older than protocol v2 has no `installArtifact`, and an OTA can bring this
 * JavaScript to such native code, so the update check then asks for v1.
 */
export declare const supportsArtifactFiles: () => boolean;
export interface ActiveUpdateState {
    readonly activeSelection: ActiveUpdateSelection | null;
    readonly stableSelection: ActiveUpdateSelection | null;
    readonly verificationPending: boolean;
}
type ActiveUpdateSelection = Pick<PersistedSelectionReceipt, "kind" | "releaseId" | "bundleId" | "channel">;
export interface InternalActiveUpdateState {
    readonly activeSelection: PersistedSelectionReceipt | null;
    readonly stableSelection: PersistedSelectionReceipt | null;
    readonly verificationPending: boolean;
    readonly highestSeenCatalogs: Readonly<Record<string, CatalogHighWater>>;
}
export interface ReleaseSelectionGuard {
    readonly catalogId: string;
    readonly scopeKey: string;
    readonly generation: number;
    readonly catalogHash: string;
    readonly selectionContextHash: string;
    readonly channel: string;
}
export declare const acceptReleaseCatalog: (input: {
    readonly catalogId: string;
    readonly scopeKey: string;
    readonly generation: number;
    readonly catalogHash: string;
    readonly channel: string;
    readonly selectionContextHash: string;
}) => boolean;
export declare const getActiveUpdateState: () => InternalActiveUpdateState;
export declare const getPublicActiveUpdateState: () => ActiveUpdateState;
export declare const isReleaseSelectionCurrent: (input: ReleaseSelectionGuard) => boolean;
export declare const commitReleaseSelection: (input: {
    readonly selection: PersistedSelectionReceipt;
    readonly guard: ReleaseSelectionGuard;
}) => Promise<boolean>;
/** How native delivered a staged bundle. */
export type BundleDelivery = {
    /**
     * "patch" when a bsdiff patch produced a file, "manifest" when only the
     * changed files were downloaded, "archive" for the full archive.
     */
    readonly delivery: "patch" | "manifest" | "archive";
    /** A patch was tried, but the file or the archive was downloaded instead. */
    readonly patchFallback: boolean;
};
/**
 * Stages a bundle for the next launch. Resolves with how native delivered
 * it, or with null when this runtime had already staged it and nothing was
 * downloaded; rejects when the download or install fails.
 *
 * @throws {Error} Rejects with error.code from HotUpdaterErrorCode enum and error.message
 */
export declare function stageBundle(params: UpdateParams | InstallArtifactUpdateParams): Promise<BundleDelivery | null>;
/**
 * Downloads files and applies them to the app.
 *
 * @param {UpdateParams} params - Parameters object required for bundle update
 * @returns {Promise<boolean>} Resolves with true if download was successful
 * @throws {Error} Rejects with error.code from HotUpdaterErrorCode enum and error.message
 */
export declare function updateBundle(params: UpdateParams): Promise<boolean>;
/**
 * Fetches the current app version.
 */
export declare const getAppVersion: () => string | null;
/**
 * Restarts the app so it loads the current bundle.
 *
 * Android restarts the app process cold, so no native module can reach the
 * JavaScript runtime while it is replaced. iOS reloads React Native in place.
 */
export declare const reload: () => Promise<void>;
/**
 * Fetches the minimum bundle id created from the native app build time.
 *
 * Release Catalog selection uses this value as its minimum Release id.
 *
 * @returns {string} The minimum bundle id.
 */
export declare const getMinBundleId: () => string;
/** Returns the selected update ID shown in the console, including staged updates. */
export declare const getUpdateId: () => string;
/**
 * Fetches the current bundle version id.
 *
 * JS falls back to MIN_BUNDLE_ID only after native confirms there is no active
 * downloaded bundle. When the native module does not expose `getBundleId()`,
 * treat it as a JS/native SDK mismatch instead of silently reporting the
 * built-in bundle.
 *
 * @returns {string} Resolves with the current version id.
 */
export declare const getBundleId: () => string;
/**
 * Fetches the current manifest for the active bundle.
 *
 * Returns a normalized manifest with empty assets when manifest.json is missing
 * or invalid.
 */
export declare const getManifest: () => Manifest;
/**
 * Fetches the channel for the app.
 *
 * @returns {string} Resolves with the channel or null if not available.
 */
export declare const getChannel: () => string;
/**
 * Fetches the build-time default channel for the app.
 */
export declare const getDefaultChannel: () => string;
/**
 * Returns whether the app is currently using a runtime channel override.
 */
export declare const isChannelSwitched: () => boolean;
/**
 * Fetches the fingerprint for the app.
 *
 * @returns {string | null} Resolves with the fingerprint hash
 */
export declare const getFingerprintHash: () => string | null;
export declare const getInstallId: () => string;
/** Reads a value from the SDK's native key-value store. */
export declare const getStorageItem: (key: string) => string | null;
/** Writes a value to the SDK's native key-value store; null removes it. */
export declare const setStorageItem: (key: string, value: string | null) => void;
/**
 * Takes and clears the events of the native update checks, as JSON. Native
 * built from an earlier SDK has no `takeNativeUpdateEvents`, and an OTA can
 * bring this JavaScript to such native code, which has no events to replay.
 */
export declare const takeNativeUpdateEvents: () => string | null;
/**
 * Result returned by notifyAppReady()
 */
export type NotifyAppReadyResult = {
    status: "UNCHANGED";
} | {
    status: "UPDATE_APPLIED";
    fromBundleId: string;
    toBundleId: string;
    fromReleaseId?: string;
    toReleaseId?: string;
} | {
    status: "RECOVERED";
    fromBundleId: string;
    toBundleId: string;
    fromReleaseId?: string;
    toReleaseId?: string;
};
/** An update applied or recovered at this launch, as native persisted it. */
export type LaunchTransition = {
    type: "UPDATE_APPLIED" | "RECOVERED";
    fromBundleId: string;
    toBundleId: string;
    fromReleaseId: string | null;
    toReleaseId: string | null;
    updateStrategy: PersistedUpdateStrategy;
};
export declare const readNotifyAppReady: () => {
    result: NotifyAppReadyResult;
    transition: LaunchTransition | null;
    pending: boolean;
};
/**
 * Reads the native launch report for the current process.
 *
 * This function is called automatically after the app has rendered.
 *
 * @returns {NotifyAppReadyResult} Bundle state information
 * - `status: "UNCHANGED"` - No qualifying OTA transition to report
 * - `status: "UPDATE_APPLIED"` - A pending update became active
 * - `status: "RECOVERED"` - Crash recovery rolled back to another bundle
 *
 * @example
 * ```ts
 * const result = hotUpdater.notifyAppReady();
 *
 * if (result.status === "RECOVERED") {
 *   console.log(result.fromBundleId, result.toBundleId);
 * }
 * ```
 */
export declare const notifyAppReady: () => NotifyAppReadyResult;
/**
 * Gets the list of bundle IDs that have been marked as crashed.
 * These bundles will be rejected if attempted to install again.
 *
 * @returns {string[]} Array of crashed bundle IDs
 */
export declare const getCrashHistory: () => string[];
/**
 * Clears the crashed bundle history, allowing previously crashed bundles
 * to be installed again.
 *
 * @returns {boolean} true if clearing was successful
 */
export declare const clearCrashHistory: () => boolean;
/**
 * Gets the base URL for the current active bundle directory.
 * Returns the file:// URL to the bundle directory without trailing slash.
 * This is used for Expo DOM components to construct full asset paths.
 *
 * @returns {string | null} Base URL string (e.g., "file:///data/.../bundle-store/abc123") or null if not available
 */
export declare const getBaseURL: () => string | null;
/**
 * Clears the runtime channel override and restores the original bundle.
 */
export declare const resetChannel: () => Promise<boolean>;
/**
 * Clears the runtime channel only while the Release selection `guard` names
 * is current. Native that checks and resets in one step does so; native from
 * an earlier SDK is checked first, then reset. Returns false for a stale
 * selection.
 */
export declare const resetChannelIfSelectionCurrent: (guard: ReleaseSelectionGuard) => Promise<boolean>;
/**
 * Sets the persisted cohort used for update checks.
 *
 * HotUpdater only derives a device-based cohort when nothing has been stored
 * yet. If you need to restore that initial value later, read it with
 * `getCohort()` before calling `setCohort()`, then store it yourself.
 */
export declare const setCohort: (cohort: string) => void;
/**
 * Gets the persisted cohort used for rollout calculations.
 * If none has been stored yet, native derives the initial value once and
 * persists it before returning.
 */
export declare const getCohort: () => string;
//# sourceMappingURL=native.d.ts.map