import { type PluginHost } from "@hot-updater/protocol";
export type { PluginHost, PluginHostConfig } from "@hot-updater/protocol";
/**
 * Creates an instance's plugin host: its plugins read the native module and
 * fetch the server the instance was configured with.
 */
export declare const createAppPluginHost: () => PluginHost;
//# sourceMappingURL=pluginHost.d.ts.map