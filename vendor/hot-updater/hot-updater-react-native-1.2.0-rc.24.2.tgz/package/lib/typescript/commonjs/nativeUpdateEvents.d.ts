import type { LaunchReporter } from "./appReady";
/**
 * Reports the update checks native code ran without JavaScript, such as a
 * brownfield app's native `HotUpdaterInstance`, with the catalog and artifact
 * responses they received, to the instance's plugins before this launch's
 * report, which they precede. Native takes and clears them in one step, so
 * each is reported at most once. A native error carries a message instead of
 * the caught error, and each event keeps the time it happened as
 * `occurredAt`.
 */
export declare const replayNativeUpdateEvents: (emit: LaunchReporter["emit"]) => void;
//# sourceMappingURL=nativeUpdateEvents.d.ts.map