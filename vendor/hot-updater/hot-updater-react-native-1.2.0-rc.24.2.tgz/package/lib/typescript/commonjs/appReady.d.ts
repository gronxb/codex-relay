import type { HotUpdaterError } from "./error";
import { type NotifyAppReadyResult } from "./native";
import type { PluginHost } from "./pluginHost";
export type NotifyAppReadyOptions = {
    onNotifyAppReady?: (result: NotifyAppReadyResult) => void;
    onError?: (error: HotUpdaterError | Error | unknown) => void;
};
/**
 * The Release the running bundle was selected as: the active or stable
 * selection that names it on the current channel.
 */
export declare const getRunningReleaseId: (bundleId: string, channel: string) => string | null;
/** An instance's launch: read once, and reported to the instance's plugins. */
export interface LaunchReporter {
    /**
     * Reads this launch once native finalizes it and reports it to the
     * plugins, once. It rejects only if `onError` throws.
     */
    read(options: NotifyAppReadyOptions): Promise<NotifyAppReadyResult | undefined>;
    /** Settles once the launch was read, whether it was reported or failed. */
    readonly appReady: Promise<unknown>;
    /**
     * Calls a plugin hook after the instance's `onAppReady`, so plugins see the
     * launch before anything that followed it. The event is built now, from the
     * state it describes, and only when a plugin listens.
     */
    emit: PluginHost["emitPluginHook"];
}
export declare const createLaunchReporter: (host: PluginHost) => LaunchReporter;
//# sourceMappingURL=appReady.d.ts.map