import type { UpdateError, UpdateErrorResource, UpdateErrorStage } from "./clientPlugin";
import { HotUpdaterError } from "./error";
/**
 * A response the SDK cannot use: a malformed or stale catalog, an artifact
 * in another protocol, or an invalid URL.
 */
export declare class InvalidUpdateResponseError extends HotUpdaterError {
    constructor(message: string, options?: {
        cause?: unknown;
    });
}
/** A request the server answered with a status the SDK does not accept. */
export declare class UpdateHttpError extends HotUpdaterError {
    readonly status: number;
    constructor(status: number, statusText: string);
}
type Classification = Pick<UpdateError, "stage" | "reason" | "resource" | "httpStatus" | "originCode" | "transport">;
/**
 * Where and why an update failed, or null when the error is not an update
 * failure. Native rejections carry their own classification; an error the
 * SDK's JavaScript raised happened in `stage`, fetching `resource` when one
 * is given.
 */
export declare const classifyUpdateError: (error: unknown, stage: UpdateErrorStage, resource?: UpdateErrorResource) => Classification | null;
export {};
//# sourceMappingURL=updateError.d.ts.map