import { type LaunchReporter } from "./appReady";
import { type CheckForUpdateOptions } from "./checkForUpdate";
import type { ClientPluginApis, HotUpdaterClientPlugin } from "./clientPlugin";
import { type HotUpdaterHttpClient } from "./httpClient";
import type { HotUpdaterInitOptions } from "./init.types";
import { addListener, clearCrashHistory, getAppVersion, getUpdateId, getChannel, getCohort, getCrashHistory, getDefaultChannel, getFingerprintHash, getInstallId, getManifest, getMinBundleId, isChannelSwitched, notifyAppReady, reload, setCohort, type UpdateParams } from "./native";
import { type HotUpdaterWrapOptions } from "./wrap";
export { defineClientPlugin, type AppReadyResult, type BundleDownloadedInfo, type ClientPluginApi, type ClientPluginApis, type HotUpdaterClientContext, type HotUpdaterClientHooks, type HotUpdaterClientPlugin, type HotUpdaterClientSetup, type HotUpdaterClientStorage, type ReleaseTransitionKind, type UpdateCheckResult, type UpdateError, type UpdateErrorReason, type UpdateErrorStage, type UpdateHttpResponse, type UpdateStrategy, } from "./clientPlugin";
export { insights, type InsightsClient, type InsightsOptions, type InsightsPlugin, type InsightsUser, } from "@hot-updater/plugin-insights/client";
export { remoteConfig, type RemoteConfigClient, type RemoteConfigDefaults, type RemoteConfigDefaultValue, type RemoteConfigFetchOptions, type RemoteConfigFetchStatus, type RemoteConfigKey, type RemoteConfigOptions, type RemoteConfigPlugin, type RemoteConfigValue, type RemoteConfigValueSource, } from "@hot-updater/plugin-remote-config/client";
export type { HotUpdaterEvent, HotUpdaterProgressArtifactType, HotUpdaterProgressEvent, Manifest, ManifestAsset, NotifyAppReadyResult, ActiveUpdateState, } from "./native";
export * from "./store";
export { extractSignatureFailure, type HotUpdaterBaseURL, isSignatureVerificationError, type SignatureVerificationFailure, } from "./types";
export type { HotUpdaterInitOptions } from "./init.types";
export type { HotUpdaterFallbackComponentProps, HotUpdaterWrapOptions, RunUpdateProcessResponse, } from "./wrap";
/** The methods that read or change native state, the same on every instance. */
declare const nativeMethods: {
    /**
     * Restarts the app so it loads the current bundle: a cold process restart
     * on Android, an in-place React Native reload on iOS.
     */
    reload: typeof reload;
    /**
     * Returns whether an update has finished downloading in this app session.
     *
     * When it returns true, calling `hotUpdater.reload()` (or restarting the app)
     * will apply the downloaded update bundle.
     *
     * - Derived from `progress` reaching 1.0
     * - Resets to false when a new download starts (progress < 1)
     *
     * @returns {boolean} True if a downloaded update is ready to apply
     * @example
     * ```ts
     * if (hotUpdater.isUpdateDownloaded()) {
     *   await hotUpdater.reload();
     * }
     * ```
     */
    isUpdateDownloaded: () => boolean;
    /**
     * Fetches the current app version.
     */
    getAppVersion: typeof getAppVersion;
    /** Reads the active and stable Release/Bundle state. */
    getActiveUpdateState: () => Promise<import("./native").ActiveUpdateState>;
    /**
     * Returns the selected update ID, matching the ID shown in the console.
     * A staged update can change this ID before the app reloads.
     */
    getBundleId: typeof getUpdateId;
    /** Returns the minimum bundle ID based on the native app build time. */
    getMinBundleId: typeof getMinBundleId;
    /**
     * Fetches the current manifest for the active bundle.
     */
    getManifest: typeof getManifest;
    /**
     * Fetches the current channel of the app.
     *
     * If no channel is specified, the app is assigned to the 'production' channel.
     *
     * @returns {string} The current release channel of the app
     * @default "production"
     * @example
     * ```ts
     * const channel = hotUpdater.getChannel();
     * console.log(`Current channel: ${channel}`);
     * ```
     */
    getChannel: typeof getChannel;
    /**
     * Fetches the build-time default channel of the app.
     *
     * This value does not change when a runtime channel override is active.
     *
     * @returns {string} The default release channel embedded in the app
     * @example
     * ```ts
     * const defaultChannel = hotUpdater.getDefaultChannel();
     * console.log(`Default channel: ${defaultChannel}`);
     * ```
     */
    getDefaultChannel: typeof getDefaultChannel;
    /**
     * Returns whether the app is currently using a runtime channel override.
     *
     * @returns {boolean} true when a non-default channel has been applied
     */
    isChannelSwitched: typeof isChannelSwitched;
    /**
     * Sets the persisted cohort used for rollout calculations.
     * Call `getCohort()` first if you need to restore the initial value later.
     */
    setCohort: typeof setCohort;
    /**
     * Gets the persisted cohort used for rollout calculations.
     */
    getCohort: typeof getCohort;
    /**
     * Adds a listener to HotUpdater events.
     *
     * @param {keyof HotUpdaterEvent} eventName - The name of the event to listen for
     * @param {(event: HotUpdaterEvent[T]) => void} listener - The callback function to handle the event
     * @returns {() => void} A cleanup function that removes the event listener
     *
     * @example
     * ```ts
     * const unsubscribe = hotUpdater.addListener("onProgress", ({ progress }) => {
     *   console.log(`Update progress: ${progress * 100}%`);
     * });
     *
     * // Unsubscribe when no longer needed
     * unsubscribe();
     * ```
     */
    addListener: typeof addListener;
    /**
     * Clears the runtime channel override and restores the original bundle.
     *
     * @returns {Promise<boolean>} Resolves with true if reset was successful
     */
    resetChannel: () => Promise<boolean>;
    /**
     * Fetches the fingerprint of the app.
     *
     * @returns {string} The fingerprint of the app
     *
     * @example
     * ```ts
     * const fingerprint = hotUpdater.getFingerprintHash();
     * console.log(`Fingerprint: ${fingerprint}`);
     * ```
     */
    getFingerprintHash: typeof getFingerprintHash;
    /**
     * Fetches the persisted install id for this app installation.
     */
    getInstallId: typeof getInstallId;
    /**
     * Reads the native launch report for the current process.
     */
    notifyAppReady: typeof notifyAppReady;
    /**
     * Gets the list of bundle IDs that have been marked as crashed.
     * These bundles will be rejected if attempted to install again.
     *
     * @returns {string[]} Array of crashed bundle IDs
     *
     * @example
     * ```ts
     * const crashedBundles = hotUpdater.getCrashHistory();
     * console.log("Crashed bundles:", crashedBundles);
     * ```
     */
    getCrashHistory: typeof getCrashHistory;
    /**
     * Clears the crashed bundle history, allowing previously crashed bundles
     * to be installed again.
     *
     * @returns {boolean} true if clearing was successful
     *
     * @example
     * ```ts
     * // Clear crash history to allow retrying a previously failed bundle
     * hotUpdater.clearCrashHistory();
     * ```
     */
    clearCrashHistory: typeof clearCrashHistory;
};
/** What an instance's own methods use: its server, settings, and launch. */
interface InstanceConfig {
    readonly client: HotUpdaterHttpClient;
    readonly requestHeaders?: Record<string, string>;
    readonly requestTimeout?: number;
    readonly onError?: (error: unknown) => void;
    readonly launch: LaunchReporter;
}
/** The methods that use the instance's own configuration and plugins. */
declare const createConfiguredMethods: (config: InstanceConfig) => {
    /**
     * Checks for an update, with this instance's server and request
     * settings.
     *
     * @param {Object} config - Update check configuration
     * @param {string} [config.channel] - Optional channel override for this update check
     * @param {Record<string, string>} [config.requestHeaders] - Request headers
     *
     * @returns {Promise<CheckForUpdateResult | null>} Update information or null if up to date
     *
     * @example
     * ```ts
     * const updateInfo = await hotUpdater.checkForUpdate({
     *   updateStrategy: "appVersion",
     *   requestHeaders: {
     *     "x-api-key": "<your-api-key>",
     *   },
     * });
     *
     * if (!updateInfo) {
     *   console.log("App is up to date");
     *   return;
     * }
     *
     * await updateInfo.updateBundle();
     * if (updateInfo.shouldForceUpdate) {
     *   await hotUpdater.reload();
     * }
     * ```
     */
    checkForUpdate: (options: CheckForUpdateOptions) => Promise<import("./checkForUpdate").CheckForUpdateResult | null>;
    /**
     * Updates the bundle of the app.
     *
     * @param {UpdateBundleParams} params - Parameters object required for bundle update
     * @param {string} params.bundleId - The bundle ID of the app
     * @returns {Promise<boolean>} Whether the update was successful
     *
     * @example
     * ```ts
     * const updateInfo = await hotUpdater.checkForUpdate({
     *   updateStrategy: "appVersion",
     *   requestHeaders: {
     *     "x-api-key": "<your-api-key>",
     *   },
     * });
     *
     * if (!updateInfo) {
     *   return {
     *     status: "UP_TO_DATE",
     *   };
     * }
     *
     * await updateInfo.updateBundle();
     * if (updateInfo.shouldForceUpdate) {
     *   await hotUpdater.reload();
     * }
     * ```
     */
    updateBundle: (params: UpdateParams) => Promise<boolean>;
    /**
     * Wraps the app's root: when it mounts, it checks for an update with
     * this instance's configuration, downloads one, and reloads for a
     * forced update. A `fallbackComponent` replaces the root until the
     * check and a forced update finish.
     *
     * @example
     * ```tsx
     * export default hotUpdater.wrap({
     *   updateStrategy: "appVersion",
     *   fallbackComponent: ({ progress }) => <Splash progress={progress} />,
     * })(App);
     * ```
     */
    wrap: (options: HotUpdaterWrapOptions) => <P extends object>(WrappedComponent: React.ComponentType<P>) => React.ComponentType<P>;
};
/** The methods of every instance `HotUpdater.init` returns. */
export type HotUpdaterCore = typeof nativeMethods & ReturnType<typeof createConfiguredMethods>;
/**
 * The instance `HotUpdater.init` returns: HotUpdater's methods, and each
 * plugin's API under the plugin's id.
 */
export type HotUpdaterInstance<TPlugins extends readonly HotUpdaterClientPlugin[] = readonly []> = Readonly<HotUpdaterCore> & ClientPluginApis<TPlugins>;
export declare const HotUpdater: {
    /**
     * Creates the app's HotUpdater instance: the update server, its request
     * settings, and the client plugins. Each call returns an independent
     * instance with its own configuration and plugins, so create one, at the
     * top level of a module, and export it.
     *
     * The instance has every HotUpdater method, such as `wrap`,
     * `checkForUpdate`, and `reload`, and each plugin's API under the
     * plugin's id, such as `hotUpdater.remoteConfig` for `remoteConfig()`.
     *
     * @example
     * ```tsx
     * export const hotUpdater = HotUpdater.init({
     *   baseURL: "<your-update-server-url>",
     *   plugins: [remoteConfig({ defaults: { welcome_message: "Hi" } })],
     * });
     *
     * hotUpdater.remoteConfig.getString("welcome_message");
     * ```
     */
    init: <const TPlugins extends readonly HotUpdaterClientPlugin[] = readonly []>(options: HotUpdaterInitOptions<TPlugins>) => HotUpdaterInstance<TPlugins>;
};
//# sourceMappingURL=index.d.ts.map