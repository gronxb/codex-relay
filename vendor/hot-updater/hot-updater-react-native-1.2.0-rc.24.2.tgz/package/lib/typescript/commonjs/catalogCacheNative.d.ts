export declare const readNativeReleaseCatalogCache: (partition: string) => Promise<string | null>;
export declare const writeNativeReleaseCatalogCache: (partition: string, payload: string) => Promise<boolean>;
export declare const removeNativeReleaseCatalogCache: (partition: string) => Promise<void>;
//# sourceMappingURL=catalogCacheNative.d.ts.map