import { type LaunchReporter } from "./appReady";
import type { ReleaseTransitionKind, UpdateErrorResource, UpdateErrorStage } from "./clientPlugin";
import type { HotUpdaterHttpClient } from "./httpClient";
export type { ReleaseTransitionKind };
export interface CheckForUpdateOptions {
    /**
     * Update strategy
     * - "fingerprint": Use fingerprint hash to check for updates
     * - "appVersion": Use app version to check for updates
     */
    updateStrategy: "appVersion" | "fingerprint";
    /**
     * Override the current channel when checking for updates.
     * The channel switch is only persisted after the returned update is applied.
     */
    channel?: string;
    requestHeaders?: Record<string, string>;
    onError?: (error: Error) => void;
    /**
     * The timeout duration for the request.
     * @default 5000
     */
    requestTimeout?: number;
}
export type CheckForUpdateResult = {
    readonly id: string;
    readonly message: string | null;
    readonly rolloutCohortCount: number;
    readonly shouldForceUpdate: boolean;
    readonly status: "ROLLBACK" | "UPDATE";
    readonly targetCohorts: string[];
    readonly releaseId?: string | null;
    readonly transitionKind?: ReleaseTransitionKind;
    /**
     * Updates the bundle.
     * This method is equivalent to `hotUpdater.updateBundle()` but with all required arguments pre-filled.
     */
    updateBundle: () => Promise<boolean>;
};
export interface InternalCheckForUpdateOptions extends CheckForUpdateOptions {
    client: HotUpdaterHttpClient;
    /** Calls the checking instance's plugin hooks. */
    emit: LaunchReporter["emit"];
}
/** The running bundle, the channel checked, and the update's target. */
type UpdateErrorScope = {
    readonly channel: string;
    readonly bundleId: string;
    readonly updateStrategy: "fingerprint" | "appVersion";
    readonly targetBundleId?: string;
    readonly targetReleaseId?: string | null;
};
/**
 * Tells plugins why an update failed, when it failed as an update. An error
 * the SDK's JavaScript raised happened in `stage`, fetching `resource`.
 */
export declare const reportUpdateError: (emit: LaunchReporter["emit"], error: unknown, stage: UpdateErrorStage, resource: UpdateErrorResource | undefined, scope: UpdateErrorScope) => void;
export declare function checkForUpdate(options: InternalCheckForUpdateOptions): Promise<CheckForUpdateResult | null>;
//# sourceMappingURL=checkForUpdate.d.ts.map