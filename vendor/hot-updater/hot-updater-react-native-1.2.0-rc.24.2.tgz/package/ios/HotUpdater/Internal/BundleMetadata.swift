import Foundation

// MARK: - BundleMetadata

/// Strategy used to derive update identities for OTA updates.
public enum UpdateStrategy: String, Codable {
    case appVersion
    case fingerprint
}

public struct PendingBundleTransition: Codable {
    let fromBundleId: String
    let toBundleId: String
    let updateStrategy: UpdateStrategy

    init(fromBundleId: String, toBundleId: String, updateStrategy: UpdateStrategy) {
        self.fromBundleId = fromBundleId
        self.toBundleId = toBundleId
        self.updateStrategy = updateStrategy
    }
}

public struct CatalogHighWater: Codable, Equatable {
    let generation: Int64
    let catalogHash: String
}

public struct PersistedSelection: Codable {
    let kind: String
    let releaseId: String?
    let bundleId: String
    let catalogId: String?
    let scopeKey: String?
    let generation: Int64?
    let catalogHash: String?
    let channel: String
    let selectionContextHash: String?

    /// A selection that names only a Bundle, with no Release Catalog receipt,
    /// such as the built-in bundle.
    static func bareBundle(_ bundleId: String) -> PersistedSelection {
        PersistedSelection(
            kind: "BUNDLE",
            releaseId: nil,
            bundleId: bundleId,
            catalogId: nil,
            scopeKey: nil,
            generation: nil,
            catalogHash: nil,
            channel: "",
            selectionContextHash: nil
        )
    }

    var dictionary: [String: Any] {
        [
            "kind": kind,
            "releaseId": releaseId ?? NSNull(),
            "bundleId": bundleId,
            "catalogId": catalogId ?? NSNull(),
            "scopeKey": scopeKey ?? NSNull(),
            "generation": generation.map(NSNumber.init(value:)) ?? NSNull(),
            "catalogHash": catalogHash ?? NSNull(),
            "channel": channel,
            "selectionContextHash": selectionContextHash ?? NSNull()
        ]
    }
}

public struct PendingSelectionTransition: Codable {
    let fromReleaseId: String?
    let fromBundleId: String
    let toReleaseId: String?
    let toBundleId: String
}

/// Bundle metadata for managing stable/staging bundles and verification state
public struct BundleMetadata: Codable {
    static let schemaVersion = "metadata-v2"
    static let metadataFilename = "metadata.json"

    let schema: String
    var isolationKey: String?
    var stableBundleId: String?
    var stagingBundleId: String?
    var stableSelection: PersistedSelection?
    var stagingSelection: PersistedSelection?
    var verificationPending: Bool
    var launchInProgress: Bool
    var pendingTransition: PendingBundleTransition?
    var pendingSelectionTransition: PendingSelectionTransition?
    var highestSeenCatalogs: [String: CatalogHighWater]
    var currentSelectionContexts: [String: String]
    var updatedAt: Double

    enum CodingKeys: String, CodingKey {
        case schema
        case isolationKey = "isolation_key"
        case stableBundleId = "stable_bundle_id"
        case stagingBundleId = "staging_bundle_id"
        case stableSelection = "stable_selection"
        case stagingSelection = "staging_selection"
        case verificationPending = "verification_pending"
        case launchInProgress = "launch_in_progress"
        case pendingTransition = "pending_transition"
        case pendingSelectionTransition = "pending_selection_transition"
        case highestSeenCatalogs = "highest_seen_catalogs"
        case currentSelectionContexts = "current_selection_contexts"
        case updatedAt = "updated_at"
    }

    init(
        schema: String = BundleMetadata.schemaVersion,
        isolationKey: String? = nil,
        stableBundleId: String? = nil,
        stagingBundleId: String? = nil,
        stableSelection: PersistedSelection? = nil,
        stagingSelection: PersistedSelection? = nil,
        verificationPending: Bool = false,
        launchInProgress: Bool = false,
        pendingTransition: PendingBundleTransition? = nil,
        pendingSelectionTransition: PendingSelectionTransition? = nil,
        highestSeenCatalogs: [String: CatalogHighWater] = [:],
        currentSelectionContexts: [String: String] = [:],
        updatedAt: Double = Date().timeIntervalSince1970 * 1000
    ) {
        self.schema = schema
        self.isolationKey = isolationKey
        self.stableBundleId = stableBundleId
        self.stagingBundleId = stagingBundleId
        self.stableSelection = stableSelection
        self.stagingSelection = stagingSelection
        self.verificationPending = verificationPending
        self.launchInProgress = launchInProgress
        self.pendingTransition = pendingTransition
        self.pendingSelectionTransition = pendingSelectionTransition
        self.highestSeenCatalogs = highestSeenCatalogs
        self.currentSelectionContexts = currentSelectionContexts
        self.updatedAt = updatedAt
    }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        schema = try values.decodeIfPresent(String.self, forKey: .schema) ?? ""
        isolationKey = try values.decodeIfPresent(String.self, forKey: .isolationKey)
        stableBundleId = try values.decodeIfPresent(String.self, forKey: .stableBundleId)
        stagingBundleId = try values.decodeIfPresent(String.self, forKey: .stagingBundleId)
        stableSelection = try values.decodeIfPresent(PersistedSelection.self, forKey: .stableSelection)
            ?? stableBundleId.map(PersistedSelection.bareBundle)
        stagingSelection = try values.decodeIfPresent(PersistedSelection.self, forKey: .stagingSelection)
            ?? stagingBundleId.map(PersistedSelection.bareBundle)
        verificationPending = try values.decodeIfPresent(Bool.self, forKey: .verificationPending) ?? false
        launchInProgress = try values.decodeIfPresent(Bool.self, forKey: .launchInProgress) ?? false
        pendingTransition = try values.decodeIfPresent(PendingBundleTransition.self, forKey: .pendingTransition)
        pendingSelectionTransition = try values.decodeIfPresent(PendingSelectionTransition.self, forKey: .pendingSelectionTransition)
        highestSeenCatalogs = try values.decodeIfPresent([String: CatalogHighWater].self, forKey: .highestSeenCatalogs) ?? [:]
        currentSelectionContexts = try values.decodeIfPresent([String: String].self, forKey: .currentSelectionContexts) ?? [:]
        updatedAt = try values.decodeIfPresent(Double.self, forKey: .updatedAt) ?? Date().timeIntervalSince1970 * 1000
    }

    static func load(from file: URL, expectedIsolationKey: String) -> BundleMetadata? {
        guard FileManager.default.fileExists(atPath: file.path) else {
            print("[BundleMetadata] Metadata file does not exist: \(file.path)")
            return nil
        }

        do {
            let data = try Data(contentsOf: file)
            let decoder = JSONDecoder()
            let metadata = try decoder.decode(BundleMetadata.self, from: data)

            // Read only metadata written in this schema.
            guard metadata.schema == BundleMetadata.schemaVersion else {
                print("[BundleMetadata] Unsupported schema \(metadata.schema), treating as invalid")
                return nil
            }

            // Validate isolation key
            if let metadataKey = metadata.isolationKey {
                if metadataKey != expectedIsolationKey {
                    print("[BundleMetadata] Isolation key mismatch: expected=\(expectedIsolationKey), got=\(metadataKey)")
                    return nil
                }
            } else {
                print("[BundleMetadata] Missing isolation key in metadata, treating as invalid")
                return nil
            }

            return metadata
        } catch {
            print("[BundleMetadata] Failed to load metadata from file: \(error)")
            return nil
        }
    }

    func save(to file: URL) -> Bool {
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let data = try encoder.encode(self)

            // Create directory if needed
            let directory = file.deletingLastPathComponent()
            if !FileManager.default.fileExists(atPath: directory.path) {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            }

            try data.write(to: file, options: .atomic)
            print("[BundleMetadata] Saved metadata to file: \(file.path)")
            return true
        } catch {
            print("[BundleMetadata] Failed to save metadata to file: \(error)")
            return false
        }
    }
}

// MARK: - CrashedBundleEntry

/// Entry for a crashed bundle in history
public struct CrashedBundleEntry: Codable {
    let bundleId: String
    var crashedAt: Double
    var crashCount: Int

    init(bundleId: String, crashedAt: Double = Date().timeIntervalSince1970 * 1000, crashCount: Int = 1) {
        self.bundleId = bundleId
        self.crashedAt = crashedAt
        self.crashCount = crashCount
    }
}

// MARK: - InterruptedLaunch

/// A bundle whose launch ended before first content without a crash, waiting
/// for its one retry. Such a launch cannot tell a hang from a user leaving
/// early, so the bundle is offered again instead of entering crash history.
/// A second unfinished launch of it adds it there.
///
/// `retryReady` turns true once a later launch shows content. The retry starts
/// with the next process, so the session that recovered never reloads into the
/// same bundle.
public struct InterruptedLaunch: Codable {
    let bundleId: String
    var retryReady: Bool

    enum CodingKeys: String, CodingKey {
        case bundleId
        case retryReady
    }

    init(bundleId: String, retryReady: Bool = false) {
        self.bundleId = bundleId
        self.retryReady = retryReady
    }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        bundleId = try values.decode(String.self, forKey: .bundleId)
        retryReady = try values.decodeIfPresent(Bool.self, forKey: .retryReady) ?? false
    }
}

// MARK: - CrashedHistory

/// History of crashed bundles
public struct CrashedHistory: Codable {
    static let defaultMaxHistorySize = 10
    static let crashedHistoryFilename = "crashed-history.json"

    var bundles: [CrashedBundleEntry]
    var maxHistorySize: Int
    var interruptedLaunch: InterruptedLaunch?

    enum CodingKeys: String, CodingKey {
        case bundles
        case maxHistorySize
        case interruptedLaunch
    }

    init(
        bundles: [CrashedBundleEntry] = [],
        maxHistorySize: Int = CrashedHistory.defaultMaxHistorySize,
        interruptedLaunch: InterruptedLaunch? = nil
    ) {
        self.bundles = bundles
        self.maxHistorySize = maxHistorySize
        self.interruptedLaunch = interruptedLaunch
    }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        bundles = try values.decode([CrashedBundleEntry].self, forKey: .bundles)
        maxHistorySize = try values.decode(Int.self, forKey: .maxHistorySize)
        // A malformed retry record must not drop the crash history.
        interruptedLaunch = try? values.decodeIfPresent(InterruptedLaunch.self, forKey: .interruptedLaunch)
    }

    static func load(from file: URL) -> CrashedHistory {
        guard FileManager.default.fileExists(atPath: file.path) else {
            print("[CrashedHistory] Crashed history file does not exist, returning empty history")
            return CrashedHistory()
        }

        do {
            let data = try Data(contentsOf: file)
            let decoder = JSONDecoder()
            let history = try decoder.decode(CrashedHistory.self, from: data)
            return history
        } catch {
            print("[CrashedHistory] Failed to load crashed history from file: \(error)")
            return CrashedHistory()
        }
    }

    func save(to file: URL) -> Bool {
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let data = try encoder.encode(self)

            // Create directory if needed
            let directory = file.deletingLastPathComponent()
            if !FileManager.default.fileExists(atPath: directory.path) {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            }

            try data.write(to: file)
            print("[CrashedHistory] Saved crashed history to file: \(file.path)")
            return true
        } catch {
            print("[CrashedHistory] Failed to save crashed history to file: \(error)")
            return false
        }
    }

    func contains(_ bundleId: String) -> Bool {
        return bundles.contains { $0.bundleId == bundleId }
    }

    mutating func addEntry(_ bundleId: String) {
        if let index = bundles.firstIndex(where: { $0.bundleId == bundleId }) {
            // Update existing entry
            bundles[index].crashedAt = Date().timeIntervalSince1970 * 1000
            bundles[index].crashCount += 1
        } else {
            // Add new entry
            bundles.append(CrashedBundleEntry(bundleId: bundleId))
        }

        // Trim to max size (keep most recent)
        if bundles.count > maxHistorySize {
            bundles.sort { $0.crashedAt < $1.crashedAt }
            bundles = Array(bundles.suffix(maxHistorySize))
        }
    }

    mutating func clear() {
        bundles.removeAll()
        interruptedLaunch = nil
    }
}

public struct PendingCrashRecovery {
    let launchedBundleId: String?
    let shouldRollback: Bool

    static func from(json: [String: Any]) -> PendingCrashRecovery {
        PendingCrashRecovery(
            launchedBundleId: (json["bundleId"] as? String).flatMap { $0.isEmpty ? nil : $0 },
            shouldRollback: json["shouldRollback"] as? Bool ?? false
        )
    }
}

public struct LaunchSelection {
    let bundleURL: URL?
    let launchedBundleId: String?
    let shouldRollbackOnCrash: Bool
}

public enum LaunchReportStatus: String, Codable {
    case unchanged = "UNCHANGED"
    case updateApplied = "UPDATE_APPLIED"
    case recovered = "RECOVERED"
}

public struct LaunchReport: Codable {
    static let launchReportFilename = "launch-report.json"

    let status: LaunchReportStatus
    let fromReleaseId: String?
    let fromBundleId: String?
    let toReleaseId: String?
    let toBundleId: String?
    let updateStrategy: UpdateStrategy?

    init(
        status: LaunchReportStatus = .unchanged,
        fromReleaseId: String? = nil,
        fromBundleId: String? = nil,
        toReleaseId: String? = nil,
        toBundleId: String? = nil,
        updateStrategy: UpdateStrategy? = nil
    ) {
        self.status = status
        self.fromReleaseId = fromReleaseId
        self.fromBundleId = fromBundleId
        self.toReleaseId = toReleaseId
        self.toBundleId = toBundleId
        self.updateStrategy = updateStrategy
    }

    static func load(from file: URL) -> LaunchReport? {
        guard FileManager.default.fileExists(atPath: file.path) else {
            return nil
        }

        do {
            let data = try Data(contentsOf: file)
            return try JSONDecoder().decode(LaunchReport.self, from: data)
        } catch {
            print("[LaunchReport] Failed to load launch report: \(error)")
            return nil
        }
    }

    func save(to file: URL) -> Bool {
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let data = try encoder.encode(self)
            let directory = file.deletingLastPathComponent()
            if !FileManager.default.fileExists(atPath: directory.path) {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            }
            try data.write(to: file)
            return true
        } catch {
            print("[LaunchReport] Failed to save launch report: \(error)")
            return false
        }
    }
}

/// The random id created once per app installation. It lives in
/// `NoBackupStorage`, so a device backup never carries it to another device.
public struct InstallIdentity: Codable {
    static let installIdentityFilename = "install-identity.json"

    let installId: String

    init(installId: String = UUID().uuidString) {
        self.installId = installId
    }

    static func load(from file: URL) -> InstallIdentity? {
        guard FileManager.default.fileExists(atPath: file.path) else {
            return nil
        }

        do {
            let data = try Data(contentsOf: file)
            let identity = try JSONDecoder().decode(InstallIdentity.self, from: data)
            return identity.installId.isEmpty ? nil : identity
        } catch {
            print("[InstallIdentity] Failed to load install identity: \(error)")
            return nil
        }
    }

    func save(to file: URL) -> Bool {
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let data = try encoder.encode(self)
            try NoBackupStorage.write(data, to: file)
            return true
        } catch {
            print("[InstallIdentity] Failed to save install identity: \(error)")
            return false
        }
    }
}
