import Foundation
import OSLog

private let bundleStorageLog = OSLog(
    subsystem: "com.hotupdater",
    category: "BundleStorage"
)

@_silgen_name("HotUpdaterApplyBsdiffPatch")
private func hotUpdaterApplyBsdiffPatchSymbol(
    _ patchPath: NSString,
    _ basePath: NSString,
    _ outputPath: NSString
) -> ObjCBool

private func hotUpdaterApplyBsdiffPatch(
    patchPath: String,
    basePath: String,
    outputPath: String
) -> Bool {
    return hotUpdaterApplyBsdiffPatchSymbol(
        patchPath as NSString,
        basePath as NSString,
        outputPath as NSString
    ).boolValue
}

public typealias ManifestAssets = [String: Any]

public struct ChangedAssetDescriptor {
    public let fileUrl: URL?
    public let fileHash: String
    public let fileCompression: String?
    public let patch: BsdiffPatchDescriptor?

    public init(
        fileUrl: URL?,
        fileHash: String,
        fileCompression: String? = nil,
        patch: BsdiffPatchDescriptor? = nil
    ) {
        self.fileUrl = fileUrl
        self.fileHash = fileHash
        self.fileCompression = fileCompression
        self.patch = patch
    }
}

public struct BsdiffPatchDescriptor {
    public let algorithm: String
    public let baseBundleId: String
    public let baseFileHash: String
    public let patchFileHash: String
    public let patchUrl: URL
    public let byteSize: Int64?

    public init(
        algorithm: String,
        baseBundleId: String,
        baseFileHash: String,
        patchFileHash: String,
        patchUrl: URL,
        byteSize: Int64? = nil
    ) {
        self.algorithm = algorithm
        self.baseBundleId = baseBundleId
        self.baseFileHash = baseFileHash
        self.patchFileHash = patchFileHash
        self.patchUrl = patchUrl
        self.byteSize = byteSize
    }
}

public struct UpdateProgressPayload {
    public let progress: Double
    public let artifactType: String
    public let details: DiffProgressDetails?

    public struct DiffProgressFileSnapshot {
        public let path: String
        public let downloadPath: String
        public let status: String
        public let progress: Double
        public let order: Int
        public let downloadedBytes: Int64?
        public let totalBytes: Int64?

        public init(
            path: String,
            downloadPath: String? = nil,
            status: String,
            progress: Double,
            order: Int,
            downloadedBytes: Int64? = nil,
            totalBytes: Int64? = nil
        ) {
            self.path = path
            self.downloadPath = downloadPath ?? path
            self.status = status
            self.progress = progress
            self.order = order
            self.downloadedBytes = downloadedBytes
            self.totalBytes = totalBytes
        }

        public var userInfo: [String: Any] {
            var info: [String: Any] = [
                "path": path,
                "downloadPath": downloadPath,
                "status": status,
                "progress": progress,
                "order": order
            ]
            if let downloadedBytes {
                info["downloadedBytes"] = downloadedBytes
            }
            if let totalBytes {
                info["totalBytes"] = totalBytes
            }
            return info
        }
    }

    public struct DiffProgressDetails {
        public let totalFilesCount: Int
        public let completedFilesCount: Int
        public let files: [DiffProgressFileSnapshot]

        public init(
            totalFilesCount: Int,
            completedFilesCount: Int,
            files: [DiffProgressFileSnapshot] = []
        ) {
            self.totalFilesCount = totalFilesCount
            self.completedFilesCount = completedFilesCount
            self.files = files
        }

        public var userInfo: [String: Any] {
            return [
                "totalFilesCount": totalFilesCount,
                "completedFilesCount": completedFilesCount,
                "files": files.map(\.userInfo)
            ]
        }
    }

    public init(
        progress: Double,
        artifactType: String,
        details: DiffProgressDetails? = nil
    ) {
        self.progress = progress
        self.artifactType = artifactType
        self.details = details
    }

    public var userInfo: [String: Any] {
        [
            "artifactType": artifactType,
            "progress": progress,
            "details": details?.userInfo ?? NSNull()
        ]
    }
}

/// How a staged bundle arrived. `updateBundle` resolves with `dictionary`.
public struct UpdateDelivery: Equatable {
    public enum Method: String {
        /// A bsdiff patch produced at least one file.
        case patch
        /// Only changed files were downloaded, possibly none.
        case manifest
        /// The full tar.br archive was downloaded.
        case archive
    }

    public let method: Method
    /// A file's patch was tried, but the full file was downloaded instead.
    public let patchFallback: Bool

    public init(method: Method, patchFallback: Bool) {
        self.method = method
        self.patchFallback = patchFallback
    }

    public var dictionary: [String: Any] {
        [
            "delivery": method.rawValue,
            "patchFallback": patchFallback,
        ]
    }
}

public enum BundleStorageError: Error, CustomNSError {
    case directoryCreationFailed
    case downloadFailed(Error)
    case incompleteDownload(expected: Int64, actual: Int64)
    case invalidBundle
    case signatureVerificationFailed(SignatureVerificationError)
    case moveOperationFailed(Error)
    case bundleInCrashedHistory(String)
    case unknown(Error?)

    // CustomNSError protocol implementation
    public static var errorDomain: String {
        return "HotUpdater"
    }

    public var errorCode: Int {
        return 0
    }

    public var errorCodeString: String {
        switch self {
        case .directoryCreationFailed: return "DIRECTORY_CREATION_FAILED"
        case .downloadFailed: return "DOWNLOAD_FAILED"
        case .incompleteDownload: return "INCOMPLETE_DOWNLOAD"
        case .invalidBundle: return "INVALID_BUNDLE"
        case .signatureVerificationFailed: return "SIGNATURE_VERIFICATION_FAILED"
        case .moveOperationFailed: return "MOVE_OPERATION_FAILED"
        case .bundleInCrashedHistory: return "BUNDLE_IN_CRASHED_HISTORY"
        case .unknown: return "UNKNOWN_ERROR"
        }
    }

    public var errorUserInfo: [String: Any] {
        var userInfo: [String: Any] = [:]

        switch self {
        case .directoryCreationFailed:
            userInfo[NSLocalizedDescriptionKey] = "Failed to create required directory for bundle storage"
            userInfo[NSLocalizedRecoverySuggestionErrorKey] = "Check app permissions and available disk space"

        case .downloadFailed(let underlyingError):
            userInfo[NSLocalizedDescriptionKey] = "Failed to download bundle from server"
            userInfo[NSUnderlyingErrorKey] = underlyingError
            userInfo[NSLocalizedRecoverySuggestionErrorKey] = "Check network connection and try again"

        case .incompleteDownload(let expected, let actual):
            userInfo[NSLocalizedDescriptionKey] = "Download incomplete: received \(actual) bytes, expected \(expected) bytes"
            userInfo[NSLocalizedRecoverySuggestionErrorKey] = "The download was interrupted. Check network connection and try again"

        case .invalidBundle:
            userInfo[NSLocalizedDescriptionKey] = "Bundle missing required platform files (index.ios.bundle or main.jsbundle)"
            userInfo[NSLocalizedRecoverySuggestionErrorKey] = "Verify the bundle was built correctly with metro bundler"

        case .signatureVerificationFailed(let underlyingError):
            userInfo[NSLocalizedDescriptionKey] = "Bundle signature verification failed"
            userInfo[NSUnderlyingErrorKey] = underlyingError
            userInfo[NSLocalizedRecoverySuggestionErrorKey] = "The bundle signature is invalid. Update rejected for security"

        case .moveOperationFailed(let underlyingError):
            userInfo[NSLocalizedDescriptionKey] = "Failed to move bundle to final location"
            userInfo[NSUnderlyingErrorKey] = underlyingError
            userInfo[NSLocalizedRecoverySuggestionErrorKey] = "Check file system permissions"

        case .bundleInCrashedHistory(let bundleId):
            userInfo[NSLocalizedDescriptionKey] = "Bundle '\(bundleId)' is in crashed history and cannot be applied"
            userInfo[NSLocalizedRecoverySuggestionErrorKey] = "This bundle previously caused a crash and was blocked for safety"

        case .unknown(let underlyingError):
            userInfo[NSLocalizedDescriptionKey] = "An unknown error occurred during bundle update"
            if let error = underlyingError {
                userInfo[NSUnderlyingErrorKey] = error
            }
            userInfo[NSLocalizedRecoverySuggestionErrorKey] = "Please try again or contact support with error details"
        }

        return userInfo
    }
}

/**
 * Protocol for interacting with bundle storage system.
 * `updateBundle` operates asynchronously using a completion handler.
 * Other operations are synchronous.
 */
public protocol BundleStorageService {

    // Bundle URL operations
    func setBundleURL(localPath: String?) -> Result<Void, Error>
    func getCachedBundleURL() -> URL?
    func getFallbackBundleURL(bundle: Bundle) -> URL? // Synchronous as it's lightweight
    func prepareLaunch(bundle: Bundle, pendingRecovery: PendingCrashRecovery?) -> LaunchSelection
    /// Settles what the previous process left once per process, before the
    /// first read of the selection: a crash rollback and a launch that never
    /// finished. `prepareLaunch` runs it first; a native update check that runs
    /// before React Native starts runs it earlier. `pendingRecovery` is called
    /// only when this run settles.
    func settlePreviousLaunch(pendingRecovery: () -> PendingCrashRecovery?)
    /// The bundle the next `prepareLaunch` would run, read without preparing
    /// the launch. Nil is the built-in bundle. Call `settlePreviousLaunch`
    /// first, or a bundle the next launch rolls back is returned.
    func peekLaunchBundleId() -> String?

    // Bundle update
    /// Stages a bundle. `selection` is the Release selection the staging
    /// commits; it travels with this staging, and the staging fails as stale
    /// when it is no longer current.
    func updateBundle(bundleId: String, manifestUrl: URL, manifestFileHash: String, archiveUrl: URL?, assets: [String: ChangedAssetDescriptor], fileResolver: ArtifactFileResolver?, selection: PersistedSelection?, progressHandler: @escaping (UpdateProgressPayload) -> Void, completion: @escaping (Result<UpdateDelivery, Error>) -> Void)
    /// Whether a staging of `selection` would still commit.
    func isSelectionCurrent(_ selection: PersistedSelection) -> Bool
    func acceptReleaseCatalog(catalogId: String, scopeKey: String, generation: Int64, catalogHash: String, channel: String, selectionContextHash: String) -> Bool
    func getActiveUpdateState() -> [String: Any]
    func isReleaseSelectionCurrent(catalogId: String, scopeKey: String, generation: Int64, catalogHash: String, channel: String, selectionContextHash: String) -> Bool
    func commitReleaseSelection(_ selection: PersistedSelection) -> Bool

    // Rollback support
    func markLaunchStarted(bundleId: String?)
    /// Forgets that the launch of `bundleId` started, leaving it pending: the
    /// next start launches it again instead of counting an unfinished launch.
    /// For a launch whose process another instance's crash takes down.
    /// Returns whether the launch had started.
    @discardableResult
    func clearLaunchStarted(bundleId: String?) -> Bool
    func markLaunchCompleted(bundleId: String?)
    func notifyAppReady() -> [String: Any]
    func getCrashHistory() -> CrashedHistory
    func clearCrashHistory() -> Bool
    func getInstallId() -> String

    /**
     * Gets the base URL for the current active bundle directory
     * @return Base URL string (e.g., "file:///data/.../bundle-store/abc123") or empty string
     */
    func getBaseURL() -> String
    func getBaseURL(forBundleId bundleId: String?) -> String

    /**
     * Gets the current active bundle ID from bundle storage.
     * Reads the required OTA manifest.json.
     */
    func getBundleId() -> String?

    /**
     * Gets the current manifest from bundle storage.
     * Returns an empty object when manifest.json is missing or invalid.
     */
    func getManifest() -> ManifestAssets
    func getManifest(forBundleId bundleId: String?) -> ManifestAssets

    /**
     * Restores the original bundle and clears downloaded bundle state.
     */
    func resetChannel() -> Result<Bool, Error>

    /**
     * Resets the channel only while the named Release selection is current,
     * checked and reset in one critical section with the catalog checks, so
     * a newer catalog accepted meanwhile keeps the channel. Success is false
     * for a stale selection.
     */
    func resetChannelIfSelectionCurrent(catalogId: String, scopeKey: String, generation: Int64, catalogHash: String, channel: String, selectionContextHash: String) -> Result<Bool, Error>
}

public extension BundleStorageService {
    func settlePreviousLaunch(pendingRecovery _: () -> PendingCrashRecovery?) {}
    @discardableResult
    func clearLaunchStarted(bundleId _: String?) -> Bool { false }
    func peekLaunchBundleId() -> String? { nil }
    func isSelectionCurrent(_: PersistedSelection) -> Bool { false }
    func acceptReleaseCatalog(catalogId _: String, scopeKey _: String, generation _: Int64, catalogHash _: String, channel _: String, selectionContextHash _: String) -> Bool { false }
    func getActiveUpdateState() -> [String: Any] { [:] }
    func isReleaseSelectionCurrent(catalogId _: String, scopeKey _: String, generation _: Int64, catalogHash _: String, channel _: String, selectionContextHash _: String) -> Bool { false }
    func commitReleaseSelection(_: PersistedSelection) -> Bool { false }
    func resetChannelIfSelectionCurrent(catalogId _: String, scopeKey _: String, generation _: Int64, catalogHash _: String, channel _: String, selectionContextHash _: String) -> Result<Bool, Error> { .success(false) }
}

class BundleFileStorageService: BundleStorageService {
    private static let maximumSafeByteSize: Int64 = 9_007_199_254_740_991
    private static let nilUUID = "00000000-0000-0000-0000-000000000000"
    /// Files downloaded at once when the archive is not used.
    static let parallelFileDownloads = 16
    /// What one request costs beyond the first `parallelFileDownloads`, in
    /// bytes: each waits a round trip for a free slot, about 100 ms, which at
    /// 5 MB/s over 16 slots is the time of 32 KiB.
    private static let requestOverheadByteSize: Int64 = 32 * 1024

    private struct ActiveBundleMetadataSnapshot {
        let activeBundleId: String
        let bundleId: String?
        let manifest: ManifestAssets
    }

    private struct ParsedBundleManifest {
        let bundleId: String
        let assets: [String: ParsedManifestAsset]
        let archive: ParsedArchive?
    }

    private struct ParsedManifestAsset {
        let fileHash: String
        let signature: String?
        let byteSize: Int64?
        let downloadByteSize: Int64?
    }

    private struct ParsedArchive {
        let downloadFileHash: String
        let downloadByteSize: Int64
        let tarByteSize: Int64
    }

    private let fileSystem: FileSystemService
    private let downloadService: DownloadService
    /// The wait before a download's second attempt; it doubles for each later one.
    private let downloadRetryDelay: TimeInterval
    private let preferences: PreferencesService
    private let isolationKey: String
    /// Whose store this is: main's `Documents/bundle-store`, or a named
    /// instance's own, with its public key and update strategy.
    private let instance: HotUpdaterInstanceEnvironment

    // Queue for potentially long-running sequences within updateBundle or for explicit background tasks.
    private let fileOperationQueue: DispatchQueue

    private var hasPreparedLaunch = false
    private let settleLock = NSLock()
    private var hasSettledPreviousLaunch = false
    private var currentLaunchReport: LaunchReport?
    // The staged bundle this process launched before its first content. Only that
    // launch is pending; a bundle staged later waits for the next launch.
    private var pendingLaunchBundleId: String?
    // Crash history is written at first content on the main thread while JavaScript can read it.
    private let crashedHistoryLock = NSLock()
    // A bundle waiting for its retry that this process keeps refusing, see InterruptedLaunch.
    private var retryHeldBundleId: String?
    private let activeBundleMetadataLock = NSLock()
    private var activeBundleMetadataSnapshot: ActiveBundleMetadataSnapshot?
    private let builtInBundleIdProvider: () -> String
    private let builtInAssetResolver: BuiltInAssetResolver
    private let updateStrategyProvider: () -> UpdateStrategy
    private let metadataWriter: (BundleMetadata, URL) -> Bool
    private let releaseStateLock = NSRecursiveLock()

    /// App-wide: every instance's storage reads the same install identity
    /// file, so one lock and cache per file keep two instances that start at
    /// once from creating different ids.
    private static let installIdentityLock = NSLock()
    private static var installIdentities: [String: InstallIdentity] = [:]

    private let protectedBundleStoreEntries: Set<String> = [
        BundleMetadata.metadataFilename,
        CrashedHistory.crashedHistoryFilename,
        LaunchReport.launchReportFilename,
        "builtin-index-v1.json",
        // Written when a launch crashes, read at the next start.
        HotUpdaterCrashMarker.filename,
    ]

    private func createDiffProgressFiles(
        changedAssets: [String: ChangedAssetDescriptor]
    ) -> [UpdateProgressPayload.DiffProgressFileSnapshot] {
        return changedAssets.keys.sorted().enumerated().map { index, path in
            UpdateProgressPayload.DiffProgressFileSnapshot(
                path: path,
                downloadPath: path,
                status: "pending",
                progress: 0,
                order: index
            )
        }
    }

    private func updateDiffProgressFile(
        files: inout [UpdateProgressPayload.DiffProgressFileSnapshot],
        assetPath: String,
        status: String,
        progress: Double,
        downloadPath: String? = nil,
        downloadedBytes: Int64? = nil,
        totalBytes: Int64? = nil
    ) {
        guard let fileIndex = files.firstIndex(where: { $0.path == assetPath }) else {
            return
        }

        files[fileIndex] = UpdateProgressPayload.DiffProgressFileSnapshot(
            path: files[fileIndex].path,
            downloadPath: downloadPath ?? files[fileIndex].downloadPath,
            status: status,
            progress: max(0, min(progress, 1)),
            order: files[fileIndex].order,
            downloadedBytes: downloadedBytes ?? files[fileIndex].downloadedBytes,
            totalBytes: totalBytes ?? files[fileIndex].totalBytes
        )
    }

    private func calculateDiffOverallProgress(
        phase: String,
        files: [UpdateProgressPayload.DiffProgressFileSnapshot],
        manifestProgress: Double = 0
    ) -> Double {
        let normalizedManifestProgress = max(0, min(manifestProgress, 1))
        switch phase {
        case "manifest":
            return normalizedManifestProgress * 0.15
        case "downloading":
            guard !files.isEmpty else {
                return 0.92
            }

            let completedFilesCount = files.filter { $0.status == "downloaded" }.count
            let activeProgressUnits = files
                .filter { $0.status == "downloading" }
                .reduce(0.0) { partialResult, file in
                    partialResult + max(0, min(file.progress, 1))
                }
            let normalizedProgress =
                (Double(completedFilesCount) + activeProgressUnits) / Double(files.count)
            return max(0.2, min(0.2 + normalizedProgress * 0.72, 0.92))
        case "finalizing":
            return 0.97
        case "completed":
            return 1.0
        default:
            return 0
        }
    }

    private func emitDiffProgress(
        progressHandler: @escaping (UpdateProgressPayload) -> Void,
        phase: String,
        files: [UpdateProgressPayload.DiffProgressFileSnapshot],
        manifestProgress: Double = 0
    ) {
        let completedFilesCount = files.filter { $0.status == "downloaded" }.count
        progressHandler(
            UpdateProgressPayload(
                progress: calculateDiffOverallProgress(
                    phase: phase,
                    files: files,
                    manifestProgress: manifestProgress
                ),
                artifactType: "diff",
                details: UpdateProgressPayload.DiffProgressDetails(
                    totalFilesCount: files.count,
                    completedFilesCount: completedFilesCount,
                    files: files
                )
            )
        )
    }

    private func resetDiffProgressFile(
        files: inout [UpdateProgressPayload.DiffProgressFileSnapshot],
        assetPath: String,
        progressHandler: @escaping (UpdateProgressPayload) -> Void
    ) {
        updateDiffProgressFile(
            files: &files,
            assetPath: assetPath,
            status: "pending",
            progress: 0,
            downloadPath: assetPath
        )
        emitDiffProgress(
            progressHandler: progressHandler,
            phase: "downloading",
            files: files
        )
    }

    private func patchTempPath(
        tempDirectory: String,
        assetPath: String
    ) -> String {
        let safeName = assetPath
            .replacingOccurrences(of: "/", with: "__")
            .replacingOccurrences(of: "\\", with: "__")
        let patchDirectory = (tempDirectory as NSString).appendingPathComponent("patches")
        _ = fileSystem.createDirectory(atPath: patchDirectory)
        return (patchDirectory as NSString).appendingPathComponent("\(safeName).bsdiff")
    }

    /// Copies, with no OTA bundle installed, the packaged file each built-in
    /// patch was made from, when its bytes are the patch's base: store
    /// processing may have changed them. Only these patches are priced and
    /// applied; the others fall back to their files.
    private func prepareBuiltInPatchBases(
        downloads: [String: ChangedAssetDescriptor],
        currentBundleId: String?,
        tempDirectory: String
    ) -> [String: String] {
        guard currentBundleId == nil else { return [:] }
        var bases: [String: String] = [:]
        for (assetPath, descriptor) in downloads {
            guard let patch = descriptor.patch,
                  isPatchForRunningBundle(patch, currentBundleId: nil) else {
                continue
            }
            let basePath = patchBaseTempPath(
                tempDirectory: tempDirectory,
                assetPath: assetPath
            )
            if builtInAssetResolver.copyIfMatches(
                assetPath: assetPath,
                expectedHash: patch.baseFileHash,
                destination: basePath
            ) {
                bases[assetPath] = basePath
            } else {
                try? fileSystem.removeItem(atPath: basePath)
            }
        }
        return bases
    }

    /// Where the built-in bundle's file is copied to serve as a patch's base.
    private func patchBaseTempPath(
        tempDirectory: String,
        assetPath: String
    ) -> String {
        let safeName = assetPath
            .replacingOccurrences(of: "/", with: "__")
            .replacingOccurrences(of: "\\", with: "__")
        let patchDirectory = (tempDirectory as NSString).appendingPathComponent("patches")
        _ = fileSystem.createDirectory(atPath: patchDirectory)
        return (patchDirectory as NSString).appendingPathComponent("\(safeName).base")
    }

    private func patchDownloadPath(assetPath: String) -> String {
        return "\(assetPath).bsdiff"
    }

    /// Whether `patch` was made against the running bundle: the OTA bundle
    /// `currentBundleId`, or with none, the built-in bundle, whose ID is
    /// MIN_BUNDLE_ID once its native build is registered.
    private func isPatchForRunningBundle(
        _ patch: BsdiffPatchDescriptor,
        currentBundleId: String?
    ) -> Bool {
        guard patch.algorithm == "bsdiff" else { return false }
        if let currentBundleId {
            return currentBundleId == patch.baseBundleId
        }
        // A Debug build reports the nil UUID, and has no built-in bundle.
        guard let builtInBundleId = resolveBuiltInBundleId(),
              builtInBundleId != Self.nilUUID else {
            return false
        }
        return builtInBundleId == patch.baseBundleId
    }

    private func downloadPath(
        assetPath: String,
        changedAsset: ChangedAssetDescriptor
    ) -> String {
        if changedAsset.fileCompression == "br" {
            return "\(assetPath).br"
        }
        return assetPath
    }

    private func compressedTempPath(
        tempDirectory: String,
        assetPath: String,
        compression: String
    ) -> String {
        let safeName = assetPath
            .replacingOccurrences(of: "/", with: "__")
            .replacingOccurrences(of: "\\", with: "__")
        let compressedDirectory = (tempDirectory as NSString).appendingPathComponent("compressed")
        _ = fileSystem.createDirectory(atPath: compressedDirectory)
        return (compressedDirectory as NSString).appendingPathComponent("\(safeName).\(compression)")
    }

    private func materializeDownloadedAsset(
        downloadedPath: String,
        destinationPath: String,
        changedAsset: ChangedAssetDescriptor
    ) throws {
        guard changedAsset.fileCompression == "br" else {
            return
        }

        try BrotliFileDecompressor.decompress(from: downloadedPath, to: destinationPath)
        try? fileSystem.removeItem(atPath: downloadedPath)
    }

    private func applyPatchAssetIfPossible(
        assetPath: String,
        changedAsset: ChangedAssetDescriptor,
        currentBundleId: String?,
        currentBundleDir: String?,
        builtInBasePath: String?,
        destinationPath: String,
        expectedHash: String,
        tempDirectory: String,
        files: inout [UpdateProgressPayload.DiffProgressFileSnapshot],
        progressHandler: @escaping (UpdateProgressPayload) -> Void
    ) -> Bool {
        guard let patch = changedAsset.patch,
              isPatchForRunningBundle(patch, currentBundleId: currentBundleId)
        else {
            return false
        }

        let sourcePath: String
        if currentBundleId == nil {
            // Copied and checked before the plan priced the patch.
            guard let builtInBasePath else { return false }
            sourcePath = builtInBasePath
        } else {
            guard let currentBundleDir else { return false }
            do {
                sourcePath = try FileUtilities.fileURL(
                    for: assetPath,
                    destinationRoot: currentBundleDir
                ).path
            } catch {
                return false
            }
            guard self.fileSystem.fileExists(atPath: sourcePath),
                  HashUtils.verifyHash(
                    fileURL: URL(fileURLWithPath: sourcePath),
                    expectedHash: patch.baseFileHash
                  )
            else {
                return false
            }
        }

        let patchPath = patchTempPath(
            tempDirectory: tempDirectory,
            assetPath: assetPath
        )

        defer {
            try? self.fileSystem.removeItem(atPath: patchPath)
            if currentBundleId == nil {
                try? self.fileSystem.removeItem(atPath: sourcePath)
            }
            if self.fileSystem.fileExists(atPath: destinationPath),
               !HashUtils.verifyHash(
                fileURL: URL(fileURLWithPath: destinationPath),
                expectedHash: expectedHash
               ) {
                try? self.fileSystem.removeItem(atPath: destinationPath)
            }
        }

        var updatedFiles = files
        defer {
            files = updatedFiles
        }

        switch self.downloadFileSynchronously(
            from: patch.patchUrl,
            to: patchPath,
            progressHandler: { progress in
                self.updateDiffProgressFile(
                    files: &updatedFiles,
                    assetPath: assetPath,
                    status: "downloading",
                    progress: progress.progress,
                    downloadPath: self.patchDownloadPath(assetPath: assetPath),
                    downloadedBytes: progress.downloadedBytes,
                    totalBytes: progress.totalBytes
                )
                self.emitDiffProgress(
                    progressHandler: progressHandler,
                    phase: "downloading",
                    files: updatedFiles
                )
            }
        ) {
        case .success(let patchFileURL):
            guard HashUtils.verifyHash(
                fileURL: patchFileURL,
                expectedHash: patch.patchFileHash
            ) else {
                resetDiffProgressFile(
                    files: &updatedFiles,
                    assetPath: assetPath,
                    progressHandler: progressHandler
                )
                return false
            }

            let applied = hotUpdaterApplyBsdiffPatch(
                patchPath: patchPath,
                basePath: sourcePath,
                outputPath: destinationPath
            )
            guard applied else {
                resetDiffProgressFile(
                    files: &updatedFiles,
                    assetPath: assetPath,
                    progressHandler: progressHandler
                )
                return false
            }

            guard HashUtils.verifyHash(
                fileURL: URL(fileURLWithPath: destinationPath),
                expectedHash: expectedHash
            ) else {
                resetDiffProgressFile(
                    files: &updatedFiles,
                    assetPath: assetPath,
                    progressHandler: progressHandler
                )
                return false
            }

            os_log(
                "HotUpdaterBsdiffPatchApplied asset=%{public}@ baseBundleId=%{public}@",
                log: bundleStorageLog,
                type: .default,
                assetPath,
                patch.baseBundleId
            )
            return true
        case .failure:
            resetDiffProgressFile(
                files: &updatedFiles,
                assetPath: assetPath,
                progressHandler: progressHandler
            )
            return false
        }
    }

    private func verifyManifestAssetFile(
        atPath path: String,
        asset: ParsedManifestAsset
    ) throws {
        if let expectedByteSize = asset.byteSize {
            let attributes = try fileSystem.attributesOfItem(atPath: path)
            guard let size = attributes[.size] as? NSNumber,
                  size.int64Value == expectedByteSize else {
                throw BundleStorageError.signatureVerificationFailed(.fileHashMismatch)
            }
        }

        guard let actualHash = HashUtils.calculateSHA256(fileURL: URL(fileURLWithPath: path)) else {
            throw BundleStorageError.signatureVerificationFailed(.fileReadFailed)
        }

        guard actualHash.caseInsensitiveCompare(asset.fileHash) == .orderedSame else {
            throw BundleStorageError.signatureVerificationFailed(.fileHashMismatch)
        }

        let publicKey = instance.publicKey()
        guard SignatureVerifier.isSigningEnabled(publicKey: publicKey) else {
            return
        }

        guard let signature = asset.signature, !signature.isEmpty else {
            throw BundleStorageError.signatureVerificationFailed(.invalidSignatureFormat)
        }

        switch SignatureVerifier.verifyHashSignature(
            fileHash: asset.fileHash,
            signatureBase64: signature,
            publicKey: publicKey
        ) {
        case .success:
            return
        case .failure(let error):
            throw BundleStorageError.signatureVerificationFailed(error)
        }
    }

    public init(fileSystem: FileSystemService,
                downloadService: DownloadService,
                preferences: PreferencesService,
                isolationKey: String,
                instance: HotUpdaterInstanceEnvironment = .main,
                builtInBundleIdProvider: @escaping () -> String = { "" },
                builtInAssetResolver: BuiltInAssetResolver? = nil,
                updateStrategyProvider: (() -> UpdateStrategy)? = nil,
                downloadRetryDelay: TimeInterval = 1,
                metadataWriter: @escaping (BundleMetadata, URL) -> Bool = { metadata, file in
                    metadata.save(to: file)
                }) {

        self.fileSystem = fileSystem
        self.downloadRetryDelay = downloadRetryDelay
        self.downloadService = downloadService
        self.preferences = preferences
        self.isolationKey = isolationKey
        self.instance = instance
        self.builtInBundleIdProvider = builtInBundleIdProvider
        self.builtInAssetResolver = builtInAssetResolver ?? IOSBuiltInAssetResolver(
            cacheURL: URL(fileURLWithPath: instance.bundleStorePath(documentsPath: fileSystem.documentsPath()), isDirectory: true)
                .appendingPathComponent("builtin-index-v1.json"),
            defaultBundle: { instance.bundle }
        )
        self.updateStrategyProvider = updateStrategyProvider ?? { instance.updateStrategy() }
        self.metadataWriter = metadataWriter

        // Create queue for file operations
        self.fileOperationQueue = DispatchQueue(label: "com.hotupdater.fileoperations",
                                               qos: .userInitiated,
                                               attributes: .concurrent)

        // Ensure bundle store directory exists
        _ = bundleStoreDir()

        // Clean up old bundles if isolationKey format changed
        checkAndCleanupIfIsolationKeyChanged()
        recoverInterruptedPromotions()
    }

    // MARK: - Metadata File Paths

    private func metadataFileURL() -> URL? {
        guard case .success(let storeDir) = bundleStoreDir() else {
            return nil
        }
        return URL(fileURLWithPath: storeDir).appendingPathComponent(BundleMetadata.metadataFilename)
    }

    private func crashedHistoryFileURL() -> URL? {
        guard case .success(let storeDir) = bundleStoreDir() else {
            return nil
        }
        return URL(fileURLWithPath: storeDir).appendingPathComponent(CrashedHistory.crashedHistoryFilename)
    }

    private func launchReportFileURL() -> URL? {
        guard case .success(let storeDir) = bundleStoreDir() else {
            return nil
        }
        return URL(fileURLWithPath: storeDir).appendingPathComponent(LaunchReport.launchReportFilename)
    }

    private func installIdentityFileURL() -> URL {
        NoBackupStorage.directory(in: fileSystem)
            .appendingPathComponent(InstallIdentity.installIdentityFilename)
    }

    // MARK: - Metadata Operations

    private func loadMetadataOrNull() -> BundleMetadata? {
        guard let file = metadataFileURL() else {
            return nil
        }
        return BundleMetadata.load(from: file, expectedIsolationKey: isolationKey)
    }

    private func saveMetadata(_ metadata: BundleMetadata) -> Bool {
        guard let file = metadataFileURL() else {
            return false
        }
        var updatedMetadata = metadata
        updatedMetadata.isolationKey = isolationKey
        return metadataWriter(updatedMetadata, file)
    }

    private func loadLaunchReport() -> LaunchReport? {
        if let currentLaunchReport {
            return currentLaunchReport
        }
        guard let file = launchReportFileURL(),
              let report = LaunchReport.load(from: file) else {
            return nil
        }
        currentLaunchReport = report
        return report
    }

    private func saveLaunchReport(_ report: LaunchReport?) {
        currentLaunchReport = report
        guard let file = launchReportFileURL() else {
            return
        }

        guard let report else {
            if FileManager.default.fileExists(atPath: file.path) {
                try? FileManager.default.removeItem(at: file)
            }
            return
        }

        _ = report.save(to: file)
    }

    /// Loads the install identity, creating it once when its file is missing.
    @discardableResult
    private func loadOrCreateInstallIdentity() -> InstallIdentity {
        Self.installIdentityLock.lock()
        defer { Self.installIdentityLock.unlock() }

        let file = installIdentityFileURL()
        if let identity = Self.installIdentities[file.path] {
            return identity
        }
        if let identity = InstallIdentity.load(from: file) {
            Self.installIdentities[file.path] = identity
            return identity
        }

        let identity = InstallIdentity()
        // Keep the new id for this process even when it cannot be saved.
        Self.installIdentities[file.path] = identity
        _ = identity.save(to: file)
        return identity
    }

    private func resolveBuiltInBundleId() -> String? {
        let bundleId = builtInBundleIdProvider().trimmingCharacters(in: .whitespacesAndNewlines)
        return bundleId.isEmpty ? nil : bundleId
    }

    private func createPendingTransition(
        fromBundleId: String,
        toBundleId: String
    ) -> PendingBundleTransition {
        PendingBundleTransition(
            fromBundleId: fromBundleId,
            toBundleId: toBundleId,
            updateStrategy: updateStrategyProvider()
        )
    }

    private func launchReport(for status: LaunchReportStatus, transition: PendingBundleTransition?) -> LaunchReport {
        LaunchReport(
            status: status,
            fromBundleId: transition?.fromBundleId,
            toBundleId: transition?.toBundleId,
            updateStrategy: transition?.updateStrategy
        )
    }

    private func createInitialMetadata() -> BundleMetadata {
        return BundleMetadata(
            isolationKey: isolationKey,
            stableBundleId: nil,
            stagingBundleId: nil,
            verificationPending: false,
            pendingTransition: nil
        )
    }

    private func getCurrentVerifiedBundleId(_ metadata: BundleMetadata) -> String? {
        if let stagingBundleId = metadata.stagingBundleId, !metadata.verificationPending {
            return stagingBundleId
        }
        return metadata.stableBundleId ?? resolveBuiltInBundleId()
    }

    private func getActiveBundleId() -> String? {
        guard let metadata = loadMetadataOrNull() else { return nil }
        if let cachedBundleId = getCachedBundleId(),
           cachedBundleId == metadata.stagingBundleId || cachedBundleId == metadata.stableBundleId {
            return cachedBundleId
        }

        if let stagingBundleId = metadata.stagingBundleId,
           metadata.verificationPending == false {
            return stagingBundleId
        }

        if let stableBundleId = metadata.stableBundleId {
            return stableBundleId
        }

        return nil
    }

    private func withActiveBundleMetadataLock<T>(_ body: () -> T) -> T {
        activeBundleMetadataLock.lock()
        defer { activeBundleMetadataLock.unlock() }
        return body()
    }

    private func clearActiveBundleMetadataSnapshot() {
        withActiveBundleMetadataLock {
            activeBundleMetadataSnapshot = nil
        }
    }

    private func getActiveBundleMetadataSnapshot() -> ActiveBundleMetadataSnapshot? {
        guard let activeBundleId = getActiveBundleId(),
              case .success(let storeDir) = bundleStoreDir() else {
            clearActiveBundleMetadataSnapshot()
            return nil
        }

        if let snapshot = withActiveBundleMetadataLock({
            activeBundleMetadataSnapshot?.activeBundleId == activeBundleId
                ? activeBundleMetadataSnapshot
                : nil
        }) {
            return snapshot
        }

        let bundleDir = (storeDir as NSString).appendingPathComponent(activeBundleId)
        guard fileSystem.fileExists(atPath: bundleDir) else {
            clearActiveBundleMetadataSnapshot()
            return nil
        }

        let snapshot = resolveActiveBundleMetadataSnapshot(
            activeBundleId: activeBundleId,
            bundleDirectory: bundleDir
        )
        return withActiveBundleMetadataLock {
            activeBundleMetadataSnapshot = snapshot
            return snapshot
        }
    }

    private func resolveActiveBundleMetadataSnapshot(
        activeBundleId: String,
        bundleDirectory: String
    ) -> ActiveBundleMetadataSnapshot {
        let manifest = readManifest(in: bundleDirectory) ?? [:]
        let manifestBundleId =
            (manifest["bundleId"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let resolvedBundleId = manifestBundleId?.isEmpty == false ? manifestBundleId : nil

        return ActiveBundleMetadataSnapshot(
            activeBundleId: activeBundleId,
            bundleId: resolvedBundleId,
            manifest: manifest
        )
    }

    private func getBundleMetadataSnapshot(bundleId: String?) -> ActiveBundleMetadataSnapshot? {
        guard let activeBundleId = bundleId?.trimmingCharacters(in: .whitespacesAndNewlines),
              !activeBundleId.isEmpty,
              case .success(let storeDir) = bundleStoreDir() else {
            return nil
        }

        let bundleDir = (storeDir as NSString).appendingPathComponent(activeBundleId)
        guard fileSystem.fileExists(atPath: bundleDir) else {
            return nil
        }

        return resolveActiveBundleMetadataSnapshot(
            activeBundleId: activeBundleId,
            bundleDirectory: bundleDir
        )
    }

    private func readManifest(in bundleDirectory: String) -> [String: Any]? {
        let manifestPath = (bundleDirectory as NSString).appendingPathComponent("manifest.json")
        guard fileSystem.fileExists(atPath: manifestPath) else {
            return nil
        }

        do {
            let manifestData = try Data(contentsOf: URL(fileURLWithPath: manifestPath))
            return try JSONSerialization.jsonObject(with: manifestData) as? [String: Any]
        } catch {
            NSLog("[BundleStorage] Failed to read manifest at \(manifestPath): \(error.localizedDescription)")
            return nil
        }
    }

    private func parseBundleManifest(from manifest: [String: Any]) -> ParsedBundleManifest? {
        guard let manifestBundleId = (manifest["bundleId"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines),
            !manifestBundleId.isEmpty,
            let rawAssets = manifest["assets"] as? [String: Any]
        else {
            return nil
        }

        var assets: [String: ParsedManifestAsset] = [:]
        for (assetPath, assetValue) in rawAssets {
            guard FileUtilities.normalizedRelativePath(from: assetPath) == assetPath else {
                return nil
            }
            guard let asset = assetValue as? [String: Any],
                  let fileHash = asset["fileHash"] as? String,
                  !fileHash.isEmpty
            else {
                return nil
            }
            let signature = (asset["signature"] as? String)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            assets[assetPath] = ParsedManifestAsset(
                fileHash: fileHash,
                signature: signature?.isEmpty == false ? signature : nil,
                byteSize: Self.parseSafeByteSize(asset["byteSize"]),
                downloadByteSize: Self.parseSafeByteSize(asset["downloadByteSize"])
            )
        }

        let archive: ParsedArchive?
        if let payload = manifest["archive"] as? [String: Any],
           let downloadFileHash = payload["downloadFileHash"] as? String,
           Self.isPlainSHA256(downloadFileHash),
           let downloadByteSize = Self.parseSafeByteSize(payload["downloadByteSize"]),
           downloadByteSize > 0,
           let tarByteSize = Self.parseSafeByteSize(payload["tarByteSize"]),
           tarByteSize >= 1024 {
            archive = ParsedArchive(
                downloadFileHash: downloadFileHash,
                downloadByteSize: downloadByteSize,
                tarByteSize: tarByteSize
            )
        } else {
            archive = nil
        }

        return ParsedBundleManifest(
            bundleId: manifestBundleId,
            assets: assets,
            archive: archive
        )
    }

    private static func parseSafeByteSize(_ value: Any?) -> Int64? {
        guard let number = value as? NSNumber,
              String(cString: number.objCType) != "c" else {
            return nil
        }
        let doubleValue = number.doubleValue
        guard doubleValue.isFinite,
              doubleValue >= 0,
              doubleValue <= Double(maximumSafeByteSize),
              doubleValue.rounded(.towardZero) == doubleValue else {
            return nil
        }
        return Int64(doubleValue)
    }

    private static func isPlainSHA256(_ value: String) -> Bool {
        value.count == 64 && value.allSatisfy {
            ("0"..."9").contains($0) || ("a"..."f").contains($0)
        }
    }

    private func copyVerifiedManifest(from source: String, to destination: String) throws {
        let manifestDirectory = (destination as NSString).deletingLastPathComponent
        guard fileSystem.createDirectory(atPath: manifestDirectory) else {
            throw BundleStorageError.directoryCreationFailed
        }
        if fileSystem.fileExists(atPath: destination) {
            try fileSystem.removeItem(atPath: destination)
        }
        do {
            try fileSystem.copyItem(atPath: source, toPath: destination)
        } catch {
            throw BundleStorageError.moveOperationFailed(error)
        }
    }

    private func shouldUseArchive(
        archive: ParsedArchive?,
        archiveUrl: URL?,
        downloads: [String: ChangedAssetDescriptor],
        assets: [String: ParsedManifestAsset],
        currentBundleId: String?,
        builtInPatchBases: [String: String]
    ) -> Bool {
        guard downloads.count >= 2,
              archive != nil,
              archiveUrl != nil,
              assets.values.allSatisfy({ $0.byteSize != nil }) else {
            return false
        }

        var individualLowerBound: Int64 = 0
        var hasOfferedPatch = false
        for (path, descriptor) in downloads {
            guard let originalByteSize = assets[path]?.downloadByteSize else {
                return false
            }
            let plannedByteSize: Int64
            // Only a patch this device applies saves bytes.
            if let patch = descriptor.patch,
               currentBundleId == nil
                ? builtInPatchBases[path] != nil
                : isPatchForRunningBundle(patch, currentBundleId: currentBundleId) {
                hasOfferedPatch = true
                guard let patchByteSize = patch.byteSize,
                      patchByteSize >= 0,
                      patchByteSize <= Self.maximumSafeByteSize else {
                    return false
                }
                plannedByteSize = min(originalByteSize, patchByteSize)
            } else {
                plannedByteSize = originalByteSize
            }
            let (sum, overflowed) = individualLowerBound.addingReportingOverflow(plannedByteSize)
            guard !overflowed,
                  sum <= Self.maximumSafeByteSize else { return false }
            individualLowerBound = sum
        }

        guard let archive else { return false }
        var logicalByteSize: Int64 = 0
        for asset in assets.values {
            guard let byteSize = asset.byteSize else { return false }
            let (sum, overflowed) = logicalByteSize.addingReportingOverflow(byteSize)
            guard !overflowed,
                  sum <= Self.maximumSafeByteSize else { return false }
            logicalByteSize = sum
        }
        let (tarOverhead, overheadUnderflowed) = archive.tarByteSize
            .subtractingReportingOverflow(logicalByteSize)
        guard !overheadUnderflowed,
              tarOverhead >= 0 else { return false }

        // Many small files cost more in requests than in bytes.
        let requestOverhead = Int64(max(0, downloads.count - Self.parallelFileDownloads))
            * Self.requestOverheadByteSize
        let (individualCost, costOverflowed) = individualLowerBound
            .addingReportingOverflow(requestOverhead)
        guard !costOverflowed,
              individualCost <= Self.maximumSafeByteSize else { return false }

        if archive.downloadByteSize <= individualCost {
            return true
        }

        guard downloads.count == assets.count,
              !hasOfferedPatch else {
            return false
        }
        let (archiveBound, boundOverflowed) = individualCost
            .addingReportingOverflow(tarOverhead)
        guard !boundOverflowed,
              archiveBound <= Self.maximumSafeByteSize else { return false }
        return archive.downloadByteSize <= archiveBound
    }

    /**
     * Checks if isolationKey has changed and cleans up old bundles if needed.
     * This handles migration when isolationKey format changes.
     */
    private func checkAndCleanupIfIsolationKeyChanged() {
        guard let metadataURL = metadataFileURL() else {
            return
        }

        let metadataPath = metadataURL.path

        guard fileSystem.fileExists(atPath: metadataPath) else {
            // First launch - no cleanup needed
            return
        }

        do {
            let jsonString = try String(contentsOf: metadataURL, encoding: .utf8)
            if let jsonData = jsonString.data(using: .utf8),
               let json = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any],
               let storedKey = json[BundleMetadata.CodingKeys.isolationKey.rawValue] as? String {

                if storedKey != isolationKey {
                    NSLog("[BundleStorage] isolationKey changed: \(storedKey) -> \(isolationKey)")
                    NSLog("[BundleStorage] Cleaning up old bundles for migration")
                    cleanupAllBundlesForMigration()
                }
            }
        } catch {
            NSLog("[BundleStorage] Error checking isolationKey: \(error.localizedDescription)")
        }
    }

    /**
     * Removes all bundle directories during migration, and the metadata naming them.
     * Called when isolationKey changes, such as when another build is installed.
     */
    private func cleanupAllBundlesForMigration() {
        guard case .success(let storeDir) = bundleStoreDir() else {
            return
        }

        // Replaced atomically before anything is deleted: a crash after this write
        // leaves only files nothing names, and a failed write changes nothing, so
        // the next start repeats this. Left in place, the old metadata comes back
        // to life when its build is installed again.
        guard saveMetadata(createInitialMetadata()) else {
            NSLog("[BundleStorage] Failed to clear metadata; keeping bundles until the next start")
            return
        }

        do {
            let contents = try fileSystem.contentsOfDirectory(atPath: storeDir)
            var cleanedCount = 0

            for item in contents {
                let fullPath = (storeDir as NSString).appendingPathComponent(item)

                if protectedBundleStoreEntries.contains(item) {
                    continue
                }

                if fileSystem.fileExists(atPath: fullPath) {
                    try fileSystem.removeItem(atPath: fullPath)
                    cleanedCount += 1
                    NSLog("[BundleStorage] Migration: removed old bundle \(item)")
                }
            }

            NSLog("[BundleStorage] Migration cleanup complete: removed \(cleanedCount) bundles")
        } catch {
            NSLog("[BundleStorage] Error during migration cleanup: \(error.localizedDescription)")
        }
    }

    // MARK: - Crashed History Operations

    private func loadCrashedHistory() -> CrashedHistory {
        guard let file = crashedHistoryFileURL() else {
            return CrashedHistory()
        }
        return CrashedHistory.load(from: file)
    }

    private func saveCrashedHistory(_ history: CrashedHistory) -> Bool {
        guard let file = crashedHistoryFileURL() else {
            return false
        }
        return history.save(to: file)
    }

    // MARK: - State Machine Methods

    private func isVerificationPending(_ metadata: BundleMetadata) -> Bool {
        return metadata.verificationPending && metadata.stagingBundleId != nil
    }

    private func prepareMetadataForNewStagingBundle(
        _ metadata: BundleMetadata,
        bundleId: String,
        incomingSelection: PersistedSelection?
    ) -> BundleMetadata? {
        let currentVerifiedBundleId = getCurrentVerifiedBundleId(metadata).flatMap { $0 == bundleId ? nil : $0 }
        if let incomingSelection, !isSelectionCurrent(incomingSelection) {
            return nil
        }
        let currentVerifiedSelection: PersistedSelection? = {
            if metadata.stagingBundleId != nil, !metadata.verificationPending {
                return metadata.stagingSelection
            }
            return metadata.stableSelection
        }()?.bundleId == bundleId ? nil : ({
            if metadata.stagingBundleId != nil, !metadata.verificationPending {
                return metadata.stagingSelection
            }
            return metadata.stableSelection
        }())
        let stagingSelection = incomingSelection ?? PersistedSelection.bareBundle(bundleId)
        let fromSelection = currentVerifiedSelection
            ?? PersistedSelection.bareBundle(resolveBuiltInBundleId() ?? bundleId)
        let pendingTransition = currentVerifiedBundleId.map {
            createPendingTransition(fromBundleId: $0, toBundleId: bundleId)
        }
        return BundleMetadata(
            isolationKey: isolationKey,
            stableBundleId: currentVerifiedBundleId,
            stagingBundleId: bundleId,
            stableSelection: currentVerifiedSelection,
            stagingSelection: stagingSelection,
            verificationPending: true,
            pendingTransition: pendingTransition,
            pendingSelectionTransition: PendingSelectionTransition(
                fromReleaseId: fromSelection.releaseId,
                fromBundleId: fromSelection.bundleId,
                toReleaseId: stagingSelection.releaseId,
                toBundleId: stagingSelection.bundleId
            ),
            highestSeenCatalogs: metadata.highestSeenCatalogs,
            currentSelectionContexts: contextsAfterCommitting(metadata.currentSelectionContexts, incomingSelection),
            updatedAt: Date().timeIntervalSince1970 * 1000
        )
    }

    /// Rolls back the pending staging bundle. `unfinishedLaunch` means its launch
    /// ended before first content without a crash marker.
    @discardableResult
    private func rollbackPendingBundle(_ stagingId: String, unfinishedLaunch: Bool = false) -> Bool {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard var metadata = loadMetadataOrNull(), metadata.stagingBundleId == stagingId else {
            return false
        }

        let pendingTransition = metadata.pendingTransition
        let pendingSelectionTransition = metadata.pendingSelectionTransition
        let stableSelection = metadata.stableSelection

        recordFailedLaunch(stagingId, unfinishedLaunch: unfinishedLaunch)

        let fallbackBundleId = metadata.stableBundleId.flatMap { candidate in
            if case .success(let storeDir) = bundleStoreDir() {
                let stableBundleDir = (storeDir as NSString).appendingPathComponent(candidate)
                if case .success(let bundlePath) = findBundleFile(
                    in: stableBundleDir,
                    expectedBundleId: candidate
                ), bundlePath != nil {
                    return candidate
                }
            }
            return nil
        }

        metadata = BundleMetadata(
            isolationKey: isolationKey,
            stableBundleId: nil,
            stagingBundleId: fallbackBundleId,
            stableSelection: nil,
            stagingSelection: stableSelection,
            verificationPending: false,
            pendingTransition: nil,
            pendingSelectionTransition: nil,
            highestSeenCatalogs: metadata.highestSeenCatalogs,
            currentSelectionContexts: metadata.currentSelectionContexts,
            updatedAt: Date().timeIntervalSince1970 * 1000
        )

        guard saveMetadata(metadata) else {
            return false
        }

        if let fallbackBundleId,
           case .success(let storeDir) = bundleStoreDir() {
            let fallbackBundleDir = (storeDir as NSString).appendingPathComponent(fallbackBundleId)
            if case .success(let bundlePath) = findBundleFile(
                in: fallbackBundleDir,
                expectedBundleId: fallbackBundleId
            ), let bundlePath {
                let _ = setBundleURL(localPath: bundlePath)
            }
        } else {
            let _ = setBundleURL(localPath: nil)
        }

        if case .success(let storeDir) = bundleStoreDir() {
            let stagingDir = (storeDir as NSString).appendingPathComponent(stagingId)
            try? fileSystem.removeItem(atPath: stagingDir)
        }

        saveLaunchReport(
            LaunchReport(
                status: .recovered,
                fromReleaseId: pendingSelectionTransition?.toReleaseId,
                fromBundleId: stagingId,
                toReleaseId: stableSelection?.releaseId,
                toBundleId: fallbackBundleId
                    ?? pendingTransition?.fromBundleId
                    ?? resolveBuiltInBundleId(),
                updateStrategy: pendingTransition?.updateStrategy ?? updateStrategyProvider()
            )
        )
        return true
    }

    private func applyPendingRecoveryIfNeeded(_ pendingRecovery: PendingCrashRecovery?) {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard let metadata = loadMetadataOrNull(),
              let stagingBundleId = metadata.stagingBundleId,
              pendingRecovery?.shouldRollback == true,
              pendingRecovery?.launchedBundleId == stagingBundleId,
              isVerificationPending(metadata) else {
            return
        }

        _ = rollbackPendingBundle(stagingBundleId)
    }

    private func releaseScopeStateKey(catalogId: String, scopeKey: String) -> String {
        "\(catalogId)|\(scopeKey)"
    }

    /// The selection contexts that stay current once `selection` commits: only
    /// its own scope's, or none for a staging without a Release selection. A
    /// check made before this commit, of another scope such as another channel,
    /// no longer stages over it.
    private func contextsAfterCommitting(
        _ contexts: [String: String],
        _ selection: PersistedSelection?
    ) -> [String: String] {
        guard let catalogId = selection?.catalogId, let scopeKey = selection?.scopeKey else {
            return [:]
        }
        let stateKey = releaseScopeStateKey(catalogId: catalogId, scopeKey: scopeKey)
        return contexts.filter { $0.key == stateKey }
    }

    private func selectionContextValue(channel: String, selectionContextHash: String) -> String {
        "\(channel)\n\(selectionContextHash)"
    }

    func acceptReleaseCatalog(
        catalogId: String,
        scopeKey: String,
        generation: Int64,
        catalogHash: String,
        channel: String,
        selectionContextHash: String
    ) -> Bool {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        var metadata = loadMetadataOrNull() ?? createInitialMetadata()
        let stateKey = releaseScopeStateKey(catalogId: catalogId, scopeKey: scopeKey)
        if let highestSeen = metadata.highestSeenCatalogs[stateKey] {
            if generation < highestSeen.generation { return false }
            if generation == highestSeen.generation, catalogHash != highestSeen.catalogHash {
                return false
            }
        }
        metadata.highestSeenCatalogs[stateKey] = CatalogHighWater(
            generation: generation,
            catalogHash: catalogHash
        )
        metadata.currentSelectionContexts[stateKey] = selectionContextValue(
            channel: channel,
            selectionContextHash: selectionContextHash
        )
        metadata.updatedAt = Date().timeIntervalSince1970 * 1000
        return saveMetadata(metadata)
    }

    private func activeSelection(_ metadata: BundleMetadata) -> PersistedSelection? {
        metadata.stagingSelection
            ?? metadata.stagingBundleId.map(PersistedSelection.bareBundle)
            ?? metadata.stableSelection
            ?? metadata.stableBundleId.map(PersistedSelection.bareBundle)
    }

    func getActiveUpdateState() -> [String: Any] {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard let metadata = loadMetadataOrNull() else {
            return [
                "activeSelection": NSNull(),
                "stableSelection": NSNull(),
                "verificationPending": false,
                "highestSeenCatalogs": [:]
            ]
        }
        let highWaters = metadata.highestSeenCatalogs.mapValues { highWater in
            [
                "generation": NSNumber(value: highWater.generation),
                "catalogHash": highWater.catalogHash
            ] as [String: Any]
        }
        return [
            "activeSelection": activeSelection(metadata)?.dictionary ?? NSNull(),
            "stableSelection": metadata.stableSelection?.dictionary ?? NSNull(),
            "verificationPending": metadata.verificationPending,
            "highestSeenCatalogs": highWaters
        ]
    }

    func isReleaseSelectionCurrent(
        catalogId: String,
        scopeKey: String,
        generation: Int64,
        catalogHash: String,
        channel: String,
        selectionContextHash: String
    ) -> Bool {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard let metadata = loadMetadataOrNull() else { return false }
        let stateKey = releaseScopeStateKey(catalogId: catalogId, scopeKey: scopeKey)
        return metadata.highestSeenCatalogs[stateKey] == CatalogHighWater(
            generation: generation,
            catalogHash: catalogHash
        ) && metadata.currentSelectionContexts[stateKey] == selectionContextValue(
            channel: channel,
            selectionContextHash: selectionContextHash
        )
    }

    func isSelectionCurrent(_ selection: PersistedSelection) -> Bool {
        guard let catalogId = selection.catalogId,
              let scopeKey = selection.scopeKey,
              let generation = selection.generation,
              let catalogHash = selection.catalogHash,
              let selectionContextHash = selection.selectionContextHash else {
            return false
        }
        return isReleaseSelectionCurrent(
            catalogId: catalogId,
            scopeKey: scopeKey,
            generation: generation,
            catalogHash: catalogHash,
            channel: selection.channel,
            selectionContextHash: selectionContextHash
        )
    }


    func commitReleaseSelection(_ selection: PersistedSelection) -> Bool {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard isSelectionCurrent(selection) else { return false }
        var metadata = loadMetadataOrNull() ?? createInitialMetadata()
        if selection.kind == "BUNDLE" {
            if metadata.stagingSelection?.bundleId == selection.bundleId
                || metadata.stagingBundleId == selection.bundleId {
                metadata.stagingBundleId = selection.bundleId
                metadata.stagingSelection = selection
                // The launch of the staged bundle reports this Release as applied.
                if let transition = metadata.pendingSelectionTransition, transition.toBundleId == selection.bundleId {
                    metadata.pendingSelectionTransition = PendingSelectionTransition(
                        fromReleaseId: transition.fromReleaseId,
                        fromBundleId: transition.fromBundleId,
                        toReleaseId: selection.releaseId,
                        toBundleId: transition.toBundleId
                    )
                }
            } else if metadata.stableSelection?.bundleId == selection.bundleId
                || metadata.stableBundleId == selection.bundleId {
                metadata.stableBundleId = selection.bundleId
                metadata.stableSelection = selection
            } else {
                return false
            }
        } else {
            guard case .success = setBundleURL(localPath: nil) else { return false }
            metadata.stableBundleId = nil
            metadata.stableSelection = nil
            metadata.stagingBundleId = nil
            metadata.stagingSelection = selection
            metadata.verificationPending = false
            metadata.launchInProgress = false
            metadata.pendingTransition = nil
            metadata.pendingSelectionTransition = nil
        }
        metadata.updatedAt = Date().timeIntervalSince1970 * 1000
        metadata.currentSelectionContexts = contextsAfterCommitting(metadata.currentSelectionContexts, selection)
        guard saveMetadata(metadata) else { return false }
        do {
            try preferences.setItem(
                selection.channel,
                forKey: "HotUpdaterChannel"
            )
        } catch {
            return false
        }
        if selection.kind != "BUNDLE", case .success(let storeDir) = bundleStoreDir() {
            for item in (try? fileSystem.contentsOfDirectory(atPath: storeDir)) ?? [] {
                guard !protectedBundleStoreEntries.contains(item) else { continue }
                let path = (storeDir as NSString).appendingPathComponent(item)
                try? fileSystem.removeItem(atPath: path)
            }
        }
        return true
    }
    
    // MARK: - Directory Management
    
    /**
     * Ensures a directory exists at the specified path. Creates it if necessary.
     * Executes synchronously on the calling thread.
     * @param path The path where directory should exist
     * @return Result with the path or an error
     */
    private func ensureDirectoryExists(path: String) -> Result<String, Error> {
        if !self.fileSystem.fileExists(atPath: path) {
            if !self.fileSystem.createDirectory(atPath: path) {
                return .failure(BundleStorageError.directoryCreationFailed)
            }
        }
        return .success(path)
    }
    
    /**
     * Gets the path to the bundle store directory.
     * Executes synchronously on the calling thread.
     * @return Result with the directory path or error
     */
    func bundleStoreDir() -> Result<String, Error> {
        let path = instance.bundleStorePath(documentsPath: fileSystem.documentsPath())
        return ensureDirectoryExists(path: path)
    }
    
    /**
     * Gets the path to the temporary directory.
     * Executes synchronously on the calling thread.
     * @return Result with the directory path or error
     */
    func tempDir() -> Result<String, Error> {
        let path = instance.tempPath(documentsPath: fileSystem.documentsPath())
        return ensureDirectoryExists(path: path)
    }
    
    /**
     * Cleans up temporary files safely. Executes synchronously on the calling thread.
     * @param paths Array of file/directory paths to clean up
     */
    private func cleanupTemporaryFiles(_ paths: [String]) {
        let workItem = DispatchWorkItem {
            for path in paths {
                do {
                    if self.fileSystem.fileExists(atPath: path) {
                        try self.fileSystem.removeItem(atPath: path)
                        NSLog("[BundleStorage] Cleaned up temporary file: \(path)")
                    }
                } catch {
                    NSLog("[BundleStorage] Failed to clean up temporary file \(path): \(error.localizedDescription)")
                }
            }
        }
        DispatchQueue.global(qos: .background).async(execute: workItem)
    }

    /**
     * Downloads `url`, trying again after a retryable failure (see
     * `DownloadError.isRetryable`) up to `DownloadError.maximumAttempts`
     * attempts in all, 1 and then 2 seconds apart, unless `retrying` is
     * false. The last attempt's result is returned, so a failure keeps what
     * classifies it. Blocks the calling thread.
     */
    private func downloadFileSynchronously(
        from url: URL,
        to destination: String,
        retrying: Bool = true,
        progressHandler: @escaping (DownloadProgress) -> Void
    ) -> Result<URL, Error> {
        var attempt = 1
        while true {
            let result = downloadFileOnce(
                from: url,
                to: destination,
                progressHandler: progressHandler
            )
            guard case .failure(let error) = result,
                  retrying,
                  attempt < DownloadError.maximumAttempts,
                  DownloadError.isRetryable(error) else {
                return result
            }
            let delay = downloadRetryDelay * pow(2, Double(attempt - 1))
            NSLog("[BundleStorage] Download failed (attempt \(attempt)/\(DownloadError.maximumAttempts)): \(error.localizedDescription). Retrying in \(delay)s")
            if delay > 0 {
                Thread.sleep(forTimeInterval: delay)
            }
            attempt += 1
        }
    }

    private func downloadFileOnce(
        from url: URL,
        to destination: String,
        progressHandler: @escaping (DownloadProgress) -> Void
    ) -> Result<URL, Error> {
        let semaphore = DispatchSemaphore(value: 0)
        var finalResult: Result<URL, Error> = .failure(BundleStorageError.unknown(nil))

        _ = downloadService.downloadFile(
            from: url,
            to: destination,
            fileSizeHandler: nil,
            progressHandler: progressHandler
        ) { result in
            finalResult = result
            semaphore.signal()
        }

        semaphore.wait()
        return finalResult
    }
    
    // MARK: - Bundle File Operations
    
    /**
     * Finds the bundle file within a directory by checking direct paths.
     * Executes synchronously on the calling thread.
     * @param directoryPath Directory to search in
     * @return Result with path to bundle file or error
     */
    func findBundleFile(
        in directoryPath: String,
        expectedBundleId: String? = nil
    ) -> Result<String?, Error> {
        NSLog("[BundleStorage] Searching for bundle file in directory: \(directoryPath)")

        let manifestPath = (directoryPath as NSString).appendingPathComponent("manifest.json")
        if fileSystem.fileExists(atPath: manifestPath) {
            guard let manifest = readManifest(in: directoryPath),
                  let parsedManifest = parseBundleManifest(from: manifest),
                  expectedBundleId == nil || parsedManifest.bundleId == expectedBundleId else {
                return .success(nil)
            }

            do {
                var bundlePaths: [String] = []
                for assetPath in parsedManifest.assets.keys {
                    let assetURL = try FileUtilities.fileURL(
                        for: assetPath,
                        destinationRoot: directoryPath
                    )
                    guard fileSystem.fileExists(atPath: assetURL.path),
                          let attributes = try? fileSystem.attributesOfItem(atPath: assetURL.path),
                          attributes[.type] as? FileAttributeType == .typeRegular else {
                        return .success(nil)
                    }

                    let fileName = assetURL.lastPathComponent
                    if fileName.hasSuffix(".bundle") || fileName == "main.jsbundle" {
                        bundlePaths.append(assetURL.path)
                    }
                }

                return .success(bundlePaths.count == 1 ? bundlePaths[0] : nil)
            } catch {
                return .failure(error)
            }
        }

        return .success(nil)
    }
        
    /**
    * Cleans up old bundles, keeping only the requested bundle IDs.
    * Executes synchronously on the calling thread.
    * @param currentBundleId ID of the current active bundle (optional)
    * @param bundleId ID of the new bundle to keep (optional)
    * @return Result of operation
    */
    func cleanupOldBundles(currentBundleId: String?, bundleId: String?) -> Result<Void, Error> {
        cleanupOldBundles(bundleIdsToKeep: [currentBundleId, bundleId].compactMap { $0 })
    }

    private func cleanupOldBundles(bundleIdsToKeep: [String]) -> Result<Void, Error> {
        let storeDirResult = bundleStoreDir()

        guard case .success(let storeDir) = storeDirResult else {
            return .failure(storeDirResult.failureError ?? BundleStorageError.unknown(nil))
        }

        // List only directories that are not .tmp
        let contents: [String]
        do {
            contents = try self.fileSystem.contentsOfDirectory(atPath: storeDir)
        } catch let error {
            NSLog("[BundleStorage] Failed to list contents of bundle store directory: \(storeDir)")
            return .failure(BundleStorageError.unknown(error))
        }
        
        let bundles = contents.compactMap { item -> String? in
            let fullPath = (storeDir as NSString).appendingPathComponent(item)

            if protectedBundleStoreEntries.contains(item) || item.hasSuffix(".install-backup") {
                return nil
            }

            return (!item.hasSuffix(".tmp") && self.fileSystem.fileExists(atPath: fullPath)) ? fullPath : nil
        }
        let bundleIdsToKeepSet = Set(bundleIdsToKeep)

        bundles.forEach { bundlePath in
            let bundleName = (bundlePath as NSString).lastPathComponent

            if !bundleIdsToKeepSet.contains(bundleName) {
                do {
                    try self.fileSystem.removeItem(atPath: bundlePath)
                    NSLog("[BundleStorage] Removing old bundle: \(bundleName)")
                } catch {
                    NSLog("[BundleStorage] Failed to remove old bundle at \(bundlePath): \(error)")
                }
            } else {
                NSLog("[BundleStorage] Keeping bundle: \(bundleName)")
            }
        }

        // Remove any leftover .tmp directories
        contents.forEach { item in
            if item.hasSuffix(".tmp") {
                let fullPath = (storeDir as NSString).appendingPathComponent(item)
                do {
                    try self.fileSystem.removeItem(atPath: fullPath)
                    NSLog("[BundleStorage] Removing stale tmp directory: \(item)")
                } catch {
                    NSLog("[BundleStorage] Failed to remove stale tmp directory \(fullPath): \(error)")
                }
            }
        }

        return .success(())
    }

    private func scheduleCleanupOldBundles(bundleIdsToKeep: [String]) {
        let uniqueBundleIdsToKeep = Array(Set(bundleIdsToKeep.filter { !$0.isEmpty }))
        guard !uniqueBundleIdsToKeep.isEmpty else {
            return
        }

        self.fileOperationQueue.async(flags: .barrier) {
            let cleanupResult = self.cleanupOldBundles(bundleIdsToKeep: uniqueBundleIdsToKeep)
            if case .failure(let error) = cleanupResult {
                NSLog("[BundleStorage] Error during deferred cleanup: \(error)")
            }
        }
    }
    
    /**
     * Sets the current bundle URL in preferences.
     * Executes synchronously on the calling thread.
     * @param localPath Path to the bundle file (or nil to reset)
     * @return Result of operation
     */
    func setBundleURL(localPath: String?) -> Result<Void, Error> {
        do {
            NSLog("[BundleStorage] Setting bundle URL to: \(localPath ?? "nil")")
            try self.preferences.setItem(localPath, forKey: "HotUpdaterBundleURL")
            clearActiveBundleMetadataSnapshot()
            return .success(())
        } catch let error {
            return .failure(error)
        }
    }

    private func bundleId(for bundleURL: URL, storeDir: String) -> String? {
        let storeURL = URL(fileURLWithPath: storeDir, isDirectory: true).standardizedFileURL
        let bundleURL = bundleURL.standardizedFileURL
        let storePrefix = storeURL.path + "/"

        guard bundleURL.path.hasPrefix(storePrefix) else {
            return nil
        }

        return bundleURL.path
            .dropFirst(storePrefix.count)
            .split(separator: "/")
            .first
            .map(String.init)
    }

    private func getCachedBundleId() -> String? {
        guard let bundleURL = getCachedBundleURL(),
              case .success(let storeDir) = bundleStoreDir() else {
            return nil
        }

        return bundleId(for: bundleURL, storeDir: storeDir)
    }

    func resolveBundlePathAfterMove(
        _ bundlePath: String,
        from sourceDirectory: String,
        to destinationDirectory: String
    ) throws -> String {
        let sourceURL = URL(
            fileURLWithPath: sourceDirectory,
            isDirectory: true
        ).standardizedFileURL
        let bundleURL = URL(fileURLWithPath: bundlePath).standardizedFileURL
        let sourcePrefix = sourceURL.path + "/"

        guard bundleURL.path.hasPrefix(sourcePrefix) else {
            throw BundleStorageError.invalidBundle
        }

        let relativePath = String(bundleURL.path.dropFirst(sourcePrefix.count))
        guard FileUtilities.normalizedRelativePath(from: relativePath) == relativePath else {
            throw BundleStorageError.invalidBundle
        }

        return try FileUtilities.fileURL(
            for: relativePath,
            destinationRoot: destinationDirectory
        ).path
    }
    
    /**
     * Gets the URL to the cached bundle file if it exists.
     */
    func getCachedBundleURL() -> URL? {
        do {
            guard let savedURLString = try self.preferences.getItem(forKey: "HotUpdaterBundleURL") else {
                return nil
            }

            let savedURL = URL(string: savedURLString)
            let bundleURL = (
                (savedURL?.isFileURL == true ? savedURL : nil)
                    ?? URL(fileURLWithPath: savedURLString)
            ).standardizedFileURL
            guard self.fileSystem.fileExists(atPath: bundleURL.path),
                  case .success(let storeDir) = bundleStoreDir() else {
                return nil
            }

            let storeURL = URL(fileURLWithPath: storeDir, isDirectory: true).standardizedFileURL
            guard let bundleId = bundleId(for: bundleURL, storeDir: storeDir) else {
                return nil
            }

            let bundleDirectory = storeURL.appendingPathComponent(bundleId).path
            guard case .success(let resolvedBundlePath) = findBundleFile(
                in: bundleDirectory,
                expectedBundleId: bundleId
            ), let resolvedBundlePath else {
                return nil
            }
            return URL(fileURLWithPath: resolvedBundlePath)
        } catch {
            NSLog("[BundleStorage] Error getting cached bundle URL: \(error.localizedDescription)")
            return nil
        }
    }
    
    /**
     * Gets the URL to the fallback bundle included in the app.
     * @param bundle instance to lookup the JavaScript bundle resource.
     * @return URL to the fallback bundle or nil if not found
     */
    func getFallbackBundleURL(bundle: Bundle) -> URL? {
        return bundle.url(forResource: "main", withExtension: "jsbundle")
    }

    private func selectLaunch(bundle: Bundle) -> LaunchSelection {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard let metadata = loadMetadataOrNull() else {
            return LaunchSelection(
                bundleURL: getFallbackBundleURL(bundle: bundle),
                launchedBundleId: nil,
                shouldRollbackOnCrash: false
            )
        }

        if let stagingId = metadata.stagingBundleId,
           case .success(let storeDir) = bundleStoreDir() {
            let stagingBundleDir = (storeDir as NSString).appendingPathComponent(stagingId)
            if case .success(let bundlePath) = findBundleFile(
                in: stagingBundleDir,
                expectedBundleId: stagingId
            ), let bundlePath {
                return LaunchSelection(
                    bundleURL: URL(fileURLWithPath: bundlePath),
                    launchedBundleId: stagingId,
                    shouldRollbackOnCrash: metadata.verificationPending
                )
            }

            if metadata.verificationPending, rollbackPendingBundle(stagingId) {
                return selectLaunch(bundle: bundle)
            }
        }

        if let stableId = metadata.stableBundleId,
           case .success(let storeDir) = bundleStoreDir() {
            let stableBundleDir = (storeDir as NSString).appendingPathComponent(stableId)
            if case .success(let bundlePath) = findBundleFile(
                in: stableBundleDir,
                expectedBundleId: stableId
            ), let bundlePath {
                return LaunchSelection(
                    bundleURL: URL(fileURLWithPath: bundlePath),
                    launchedBundleId: stableId,
                    shouldRollbackOnCrash: false
                )
            }
        }

        return LaunchSelection(
            bundleURL: getFallbackBundleURL(bundle: bundle),
            launchedBundleId: nil,
            shouldRollbackOnCrash: false
        )
    }

    func peekLaunchBundleId() -> String? {
        // Reads the store without bundleStoreDir(), which creates it.
        let storeDir = instance.bundleStorePath(documentsPath: fileSystem.documentsPath())
        let metadataFile = URL(fileURLWithPath: storeDir).appendingPathComponent(BundleMetadata.metadataFilename)
        guard let metadata = BundleMetadata.load(from: metadataFile, expectedIsolationKey: isolationKey) else {
            return nil
        }
        func hasBundleFile(_ bundleId: String) -> Bool {
            let directory = (storeDir as NSString).appendingPathComponent(bundleId)
            guard case .success(let bundlePath) = findBundleFile(in: directory, expectedBundleId: bundleId) else {
                return false
            }
            return bundlePath != nil
        }
        if let stagingBundleId = metadata.stagingBundleId, hasBundleFile(stagingBundleId) {
            return stagingBundleId
        }
        if let stableBundleId = metadata.stableBundleId, hasBundleFile(stableBundleId) {
            return stableBundleId
        }
        return nil
    }

    func settlePreviousLaunch(pendingRecovery: () -> PendingCrashRecovery?) {
        settleLock.lock()
        defer { settleLock.unlock() }
        guard !hasSettledPreviousLaunch else { return }
        hasSettledPreviousLaunch = true
        // Cleared before the rollbacks below, so the launch reports their RECOVERED.
        saveLaunchReport(nil)
        applyPendingRecoveryIfNeeded(pendingRecovery())
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        // Only a new storage instance consumes an unfinished launch. Repeated bundle
        // lookups or bridge reloads in this process must not reject its own launch.
        if let metadata = loadMetadataOrNull(),
           metadata.verificationPending,
           metadata.launchInProgress,
           let stagingBundleId = metadata.stagingBundleId {
            rollbackPendingBundle(stagingBundleId, unfinishedLaunch: true)
        }
        // A pending bundle whose file is gone rolls back, as selectLaunch does.
        if let metadata = loadMetadataOrNull(),
           metadata.verificationPending,
           let stagingBundleId = metadata.stagingBundleId,
           !hasBundleFiles(stagingBundleId) {
            rollbackPendingBundle(stagingBundleId)
        }
        forgetVerifiedBundlesWithoutFiles()
    }

    private func hasBundleFiles(_ bundleId: String) -> Bool {
        guard case .success(let storeDir) = bundleStoreDir() else { return false }
        let directory = (storeDir as NSString).appendingPathComponent(bundleId)
        guard case .success(let bundlePath) = findBundleFile(in: directory, expectedBundleId: bundleId) else {
            return false
        }
        return bundlePath != nil
    }

    /// Drops a verified bundle whose files are gone. The launch already skips it,
    /// so the state then says what runs, and a check installs the Release instead
    /// of adopting files that do not exist. It did not fail, so unlike a pending
    /// bundle's rollback this adds nothing to crash history. A released version's
    /// isolation key cleanup left such metadata for a later build of the same key.
    private func forgetVerifiedBundlesWithoutFiles() {
        guard var metadata = loadMetadataOrNull() else { return }
        func isGone(_ bundleId: String?, _ selection: PersistedSelection?) -> Bool {
            // A rollback can leave a selection without its id. A BUILTIN selection
            // and the built-in bundle as the stable one have no files by design.
            let named = bundleId ?? (selection?.kind == "BUNDLE" ? selection?.bundleId : nil)
            guard let named, named != resolveBuiltInBundleId() else { return false }
            return !hasBundleFiles(named)
        }
        let stagingIsGone = !metadata.verificationPending
            && isGone(metadata.stagingBundleId, metadata.stagingSelection)
        let stableIsGone = isGone(metadata.stableBundleId, metadata.stableSelection)
        guard stagingIsGone || stableIsGone else { return }
        if stagingIsGone {
            metadata.stagingBundleId = nil
            metadata.stagingSelection = nil
        }
        if stableIsGone {
            metadata.stableBundleId = nil
            metadata.stableSelection = nil
        }
        metadata.updatedAt = Date().timeIntervalSince1970 * 1000
        _ = saveMetadata(metadata)
    }

    func prepareLaunch(bundle: Bundle, pendingRecovery: PendingCrashRecovery?) -> LaunchSelection {
        builtInAssetResolver.use(bundle: bundle)
        loadOrCreateInstallIdentity()
        if hasPreparedLaunch {
            // A later launch in this process, after a reset or a reload.
            saveLaunchReport(nil)
            applyPendingRecoveryIfNeeded(pendingRecovery)
        } else {
            settlePreviousLaunch { pendingRecovery }
        }
        hasPreparedLaunch = true
        // A launch is recorded only once it can show UI (markLaunchStarted).
        let selection = selectLaunch(bundle: bundle)
        pendingLaunchBundleId = selection.shouldRollbackOnCrash ? selection.launchedBundleId : nil
        return selection
    }
    
    // MARK: - Bundle Update
    
    /**
     * Updates the bundle from the specified URL. This operation is asynchronous.
     * @param bundleId ID of the bundle to update
     * @param manifestUrl URL of the complete target manifest
     * @param manifestFileHash Hash or signature of the target manifest
     * @param progressHandler Callback for download and extraction progress (0.0 to 1.0)
     * @param completion Callback with result of the operation
     */
    func updateBundle(bundleId: String, manifestUrl: URL, manifestFileHash: String, archiveUrl: URL? = nil, assets: [String: ChangedAssetDescriptor], fileResolver: ArtifactFileResolver? = nil, selection: PersistedSelection? = nil, progressHandler: @escaping (UpdateProgressPayload) -> Void, completion: @escaping (Result<UpdateDelivery, Error>) -> Void) {
        // Check if bundle is in crashed history
        if getCrashHistory().contains(bundleId) {
            NSLog("[BundleStorage] Bundle '\(bundleId)' is in crashed history, rejecting update")
            completion(.failure(BundleStorageError.bundleInCrashedHistory(bundleId)))
            return
        }

        fileOperationQueue.async(flags: .barrier) {
            let storeDirResult = self.bundleStoreDir()
            guard case .success(let storeDir) = storeDirResult else {
                completion(.failure(UpdateFailureError.classifying(
                    storeDirResult.failureError ?? BundleStorageError.unknown(nil),
                    during: .storage
                )))
                return
            }
            self.updateBundleFromManifest(
                bundleId: bundleId,
                manifestUrl: manifestUrl,
                manifestFileHash: manifestFileHash,
                archiveUrl: archiveUrl,
                changedAssets: assets,
                fileResolver: fileResolver,
                selection: selection,
                storeDir: storeDir,
                progressHandler: progressHandler,
                completion: completion
            )
        }
    }

    /// Asks `fileResolver` for the URLs of `downloads`, in requests of at
    /// most `artifactFilesRequestLimit` paths.
    private func resolveFileUrls(
        fileResolver: ArtifactFileResolver,
        downloads: inout [String: ChangedAssetDescriptor]
    ) throws {
        let paths = downloads.keys.sorted()
        for start in stride(from: 0, to: paths.count, by: artifactFilesRequestLimit) {
            let chunk = Array(paths[start..<min(start + artifactFilesRequestLimit, paths.count)])
            let files: [String: ResolvedArtifactFile]
            do {
                files = try fileResolver.resolve(paths: chunk)
            } catch {
                throw BundleStorageError.downloadFailed(error)
            }
            for path in chunk {
                guard let file = files[path], let descriptor = downloads[path] else {
                    throw BundleStorageError.invalidBundle
                }
                // A download needs an absolute HTTP(S) URL with a host.
                guard ["http", "https"].contains(file.url.scheme?.lowercased() ?? ""),
                      file.url.host?.isEmpty == false else {
                    throw UpdateFailureError(
                        underlying: NSError(domain: "HotUpdater", code: 0, userInfo: [
                            NSLocalizedDescriptionKey: "Invalid '\(path)' provided: \(file.url.absoluteString)"
                        ]),
                        failure: UpdateFailure.invalidResponse.with(resource: .file)
                    )
                }
                downloads[path] = ChangedAssetDescriptor(
                    fileUrl: file.url,
                    fileHash: descriptor.fileHash,
                    fileCompression: file.compression,
                    patch: descriptor.patch
                )
            }
        }
    }

    /// How the per-file install produced one file.
    private enum AssetInstallOutcome {
        case patched
        /// `patchFallback` is true when a patch for the running bundle was
        /// offered but the original file was downloaded instead.
        case downloaded(patchFallback: Bool)
    }

    private func downloadManifestAsset(
        assetPath: String,
        expectedAsset: ParsedManifestAsset,
        changedAsset: ChangedAssetDescriptor,
        currentBundleId: String?,
        currentBundleDir: String?,
        builtInBasePath: String?,
        destinationPath: String,
        tempDirectory: String,
        progressFile: UpdateProgressPayload.DiffProgressFileSnapshot,
        progressHandler: @escaping (UpdateProgressPayload) -> Void
    ) throws -> AssetInstallOutcome {
        let expectedHash = expectedAsset.fileHash
        var diffFiles = [progressFile]
        let patched = applyPatchAssetIfPossible(
            assetPath: assetPath,
            changedAsset: changedAsset,
            currentBundleId: currentBundleId,
            currentBundleDir: currentBundleDir,
            builtInBasePath: builtInBasePath,
            destinationPath: destinationPath,
            expectedHash: expectedHash,
            tempDirectory: tempDirectory,
            files: &diffFiles,
            progressHandler: progressHandler
        )
        if patched {
            // The patch produced these bytes, so a mismatch is a patch failure.
            try UpdateFailureError.during(.patch, resource: .patch) {
                try verifyManifestAssetFile(atPath: destinationPath, asset: expectedAsset)
            }
            updateDiffProgressFile(
                files: &diffFiles,
                assetPath: assetPath,
                status: "downloaded",
                progress: 1
            )
            self.emitDiffProgress(
                progressHandler: progressHandler,
                phase: diffFiles.allSatisfy { $0.status == "downloaded" }
                    ? "finalizing"
                    : "downloading",
                files: diffFiles
            )
            return .patched
        }

        guard let changedAssetFileUrl = changedAsset.fileUrl else {
            updateDiffProgressFile(
                files: &diffFiles,
                assetPath: assetPath,
                status: "failed",
                progress: 0
            )
            self.emitDiffProgress(
                progressHandler: progressHandler,
                phase: "downloading",
                files: diffFiles
            )
            // With no original file to fall back to, the patch decides the install.
            throw UpdateFailureError(
                underlying: BundleStorageError.downloadFailed(
                    NSError(domain: "HotUpdater", code: 0, userInfo: [
                        NSLocalizedDescriptionKey: "Changed asset fileUrl missing and patch could not be applied: \(assetPath)"
                    ])
                ),
                failure: UpdateFailure.patch.with(resource: .patch)
            )
        }

        let changedAssetDownloadPath = downloadPath(
            assetPath: assetPath,
            changedAsset: changedAsset
        )
        let downloadDestinationPath: String
        if changedAsset.fileCompression == "br" {
            downloadDestinationPath = compressedTempPath(
                tempDirectory: tempDirectory,
                assetPath: assetPath,
                compression: "br"
            )
        } else {
            downloadDestinationPath = destinationPath
        }

        switch self.downloadFileSynchronously(
            from: changedAssetFileUrl,
            to: downloadDestinationPath,
            progressHandler: { progress in
                self.updateDiffProgressFile(
                    files: &diffFiles,
                    assetPath: assetPath,
                    status: "downloading",
                    progress: progress.progress,
                    downloadPath: changedAssetDownloadPath,
                    downloadedBytes: progress.downloadedBytes,
                    totalBytes: progress.totalBytes
                )
                self.emitDiffProgress(
                    progressHandler: progressHandler,
                    phase: "downloading",
                    files: diffFiles
                )
            }
        ) {
        case .success(let downloadedFileURL):
            do {
                try UpdateFailureError.during(.extraction, resource: .file) {
                    try materializeDownloadedAsset(
                        downloadedPath: downloadedFileURL.path,
                        destinationPath: destinationPath,
                        changedAsset: changedAsset
                    )
                }
                // Compressed files are checked after decoding, so their
                // mismatch is an extraction failure.
                let verificationPhase: UpdatePhase =
                    changedAsset.fileCompression == "br" ? .extraction : .verification
                try UpdateFailureError.during(verificationPhase, resource: .file) {
                    try verifyManifestAssetFile(
                        atPath: destinationPath,
                        asset: expectedAsset
                    )
                }
            } catch {
                updateDiffProgressFile(
                    files: &diffFiles,
                    assetPath: assetPath,
                    status: "failed",
                    progress: 1
                )
                self.emitDiffProgress(
                    progressHandler: progressHandler,
                    phase: "downloading",
                    files: diffFiles
                )
                throw error
            }
            updateDiffProgressFile(
                files: &diffFiles,
                assetPath: assetPath,
                status: "downloaded",
                progress: 1
            )
            self.emitDiffProgress(
                progressHandler: progressHandler,
                phase: diffFiles.allSatisfy { $0.status == "downloaded" }
                    ? "finalizing"
                    : "downloading",
                files: diffFiles
            )
            // A patch for the running bundle was offered, but the original
            // file came instead; a patch for another base was never tried.
            let patchWasTried = changedAsset.patch.map {
                isPatchForRunningBundle($0, currentBundleId: currentBundleId)
            } ?? false
            return .downloaded(patchFallback: patchWasTried)
        case .failure(let error):
            let lastKnownProgress = diffFiles.first(where: { $0.path == assetPath })?.progress ?? 0
            updateDiffProgressFile(
                files: &diffFiles,
                assetPath: assetPath,
                status: "failed",
                progress: lastKnownProgress
            )
            self.emitDiffProgress(
                progressHandler: progressHandler,
                phase: "downloading",
                files: diffFiles
            )
            let transferError: Error
            if let downloadError = error as? DownloadError,
               case .incompleteDownload(let expected, let actual) = downloadError {
                transferError = BundleStorageError.incompleteDownload(expected: expected, actual: actual)
            } else {
                transferError = BundleStorageError.downloadFailed(error)
            }
            throw UpdateFailureError.classifying(transferError, during: .transfer, resource: .file)
        }
    }

    // Retain only target files on retry; partial files are rehashed before reuse.
    private func pruneStagingDirectory(_ directory: String, assets: Set<String>, prefix: String = "") throws {
        for name in try fileSystem.contentsOfDirectory(atPath: directory) {
            let relativePath = prefix + name
            let path = (directory as NSString).appendingPathComponent(name)
            let type = try fileSystem.attributesOfItem(atPath: path)[.type] as? FileAttributeType
            if type == .typeDirectory, assets.contains(where: { $0.hasPrefix(relativePath + "/") }) {
                try pruneStagingDirectory(path, assets: assets, prefix: relativePath + "/")
            } else if type != .typeRegular || !assets.contains(relativePath) {
                try fileSystem.removeItem(atPath: path)
            }
        }
    }

    private func installArchive(
        archive: ParsedArchive,
        archiveUrl: URL,
        targetManifest: ParsedBundleManifest,
        preparedDirectory: String,
        tempDirectory: String,
        progressHandler: @escaping (UpdateProgressPayload) -> Void
    ) throws -> [UpdateProgressPayload.DiffProgressFileSnapshot] {
        let archiveScratch = (tempDirectory as NSString).appendingPathComponent("archive")
        try? fileSystem.removeItem(atPath: archiveScratch)
        guard fileSystem.createDirectory(atPath: archiveScratch) else {
            throw BundleStorageError.directoryCreationFailed
        }
        defer { try? fileSystem.removeItem(atPath: archiveScratch) }

        let compressedPath = (archiveScratch as NSString).appendingPathComponent("bundle.tar.br")
        let tarPath = (archiveScratch as NSString).appendingPathComponent("bundle.tar")
        let extractedDirectory = (archiveScratch as NSString).appendingPathComponent("extracted")
        var progressFiles = [UpdateProgressPayload.DiffProgressFileSnapshot(
            path: "bundle.tar.br",
            downloadPath: "bundle.tar.br",
            status: "pending",
            progress: 0,
            order: 0
        )]
        emitDiffProgress(
            progressHandler: progressHandler,
            phase: "downloading",
            files: progressFiles
        )

        // One attempt: a failed archive falls back to per-file downloads, which retry.
        switch downloadFileSynchronously(
            from: archiveUrl,
            to: compressedPath,
            retrying: false,
            progressHandler: { progress in
                self.updateDiffProgressFile(
                    files: &progressFiles,
                    assetPath: "bundle.tar.br",
                    status: "downloading",
                    progress: progress.progress,
                    downloadPath: "bundle.tar.br",
                    downloadedBytes: progress.downloadedBytes,
                    totalBytes: progress.totalBytes
                )
                self.emitDiffProgress(
                    progressHandler: progressHandler,
                    phase: "downloading",
                    files: progressFiles
                )
            }
        ) {
        case .success:
            break
        case .failure(let error):
            throw BundleStorageError.downloadFailed(error)
        }

        let compressedAttributes = try fileSystem.attributesOfItem(atPath: compressedPath)
        guard let compressedSize = compressedAttributes[.size] as? NSNumber,
              compressedSize.int64Value == archive.downloadByteSize,
              HashUtils.verifyHash(
                fileURL: URL(fileURLWithPath: compressedPath),
                expectedHash: archive.downloadFileHash
              ) else {
            throw UpdateFailureError(
                underlying: BundleStorageError.invalidBundle,
                failure: .hashMismatch
            )
        }

        try UpdateFailureError.during(.extraction) {
            try BrotliFileDecompressor.decompress(
                from: compressedPath,
                to: tarPath,
                expectedOutputByteSize: archive.tarByteSize
            )
        }

        let expectedFiles = try targetManifest.assets.reduce(
            into: [String: Int64](),
            { result, entry in
                guard let byteSize = entry.value.byteSize else {
                    throw BundleStorageError.invalidBundle
                }
                result[entry.key] = byteSize
            }
        )
        try UpdateFailureError.during(.extraction) {
            try TarArchiveExtractor.extract(
                from: tarPath,
                to: extractedDirectory,
                expectedFiles: expectedFiles
            )
            for (path, asset) in targetManifest.assets {
                let extractedPath = try FileUtilities.fileURL(
                    for: path,
                    destinationRoot: extractedDirectory
                ).path
                try verifyManifestAssetFile(atPath: extractedPath, asset: asset)
            }
        }

        try promoteVerifiedArchiveDirectory(
            preparedDirectory,
            withArchiveDirectory: extractedDirectory
        )

        updateDiffProgressFile(
            files: &progressFiles,
            assetPath: "bundle.tar.br",
            status: "downloaded",
            progress: 1,
            downloadedBytes: archive.downloadByteSize,
            totalBytes: archive.downloadByteSize
        )
        emitDiffProgress(
            progressHandler: progressHandler,
            phase: "finalizing",
            files: progressFiles
        )
        return progressFiles
    }

    private func promoteVerifiedArchiveDirectory(
        _ preparedDirectory: String,
        withArchiveDirectory archiveDirectory: String
    ) throws {
        let backupDirectory = preparedDirectory + ".archive-backup"
        try? fileSystem.removeItem(atPath: backupDirectory)
        try fileSystem.moveItem(atPath: preparedDirectory, toPath: backupDirectory)

        do {
            try fileSystem.moveItem(
                atPath: archiveDirectory,
                toPath: preparedDirectory
            )
        } catch {
            try? fileSystem.removeItem(atPath: preparedDirectory)
            do {
                try fileSystem.moveItem(atPath: backupDirectory, toPath: preparedDirectory)
            } catch let restoreError {
                throw BundleStorageError.moveOperationFailed(restoreError)
            }
            throw error
        }
        try? fileSystem.removeItem(atPath: backupDirectory)
    }

    private func recoverInterruptedPromotions() {
        guard case .success(let storeDir) = bundleStoreDir(),
              let entries = try? fileSystem.contentsOfDirectory(atPath: storeDir) else { return }
        for entry in entries where entry.hasSuffix(".install-backup") {
            let finalDirectory = (storeDir as NSString).appendingPathComponent(String(entry.dropLast(".install-backup".count)))
            do {
                try recoverInterruptedPromotion(finalDirectory: finalDirectory)
            } catch {
                NSLog("[BundleStorage] Cannot recover interrupted promotion: \(error)")
            }
        }
    }

    private func recoverInterruptedPromotion(finalDirectory: String) throws {
        let backup = finalDirectory + ".install-backup"
        guard fileSystem.fileExists(atPath: backup) else { return }
        if fileSystem.fileExists(atPath: finalDirectory) {
            if isCompleteBundleDirectory(finalDirectory) {
                try fileSystem.removeItem(atPath: backup)
                return
            }
            try fileSystem.removeItem(atPath: finalDirectory)
        }
        try fileSystem.moveItem(atPath: backup, toPath: finalDirectory)
    }

    private func isCompleteBundleDirectory(_ directory: String) -> Bool {
        let bundleId = (directory as NSString).lastPathComponent
        guard let manifest = readManifest(in: directory),
              let parsed = parseBundleManifest(from: manifest),
              parsed.bundleId == bundleId,
              case .success(let bundlePath) = findBundleFile(in: directory, expectedBundleId: bundleId),
              bundlePath != nil else { return false }
        return parsed.assets.allSatisfy { path, asset in
            guard let file = try? FileUtilities.fileURL(for: path, destinationRoot: directory) else { return false }
            return (try? verifyManifestAssetFile(atPath: file.path, asset: asset)) != nil
        }
    }

    private func promoteStagedBundle(
        bundleId: String,
        selection: PersistedSelection?,
        stagingDirectory: String,
        finalDirectory: String,
        bundlePathInStaging: String
    ) throws -> BundleMetadata {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        let currentMetadata = loadMetadataOrNull() ?? createInitialMetadata()
        guard let updatedMetadata = prepareMetadataForNewStagingBundle(
            currentMetadata,
            bundleId: bundleId,
            incomingSelection: selection
        ) else {
            throw BundleStorageError.unknown(StaleReleaseSelectionError())
        }
        let finalBundlePath = try resolveBundlePathAfterMove(
            bundlePathInStaging, from: stagingDirectory, to: finalDirectory
        )
        let previousPreference = try preferences.getItem(forKey: "HotUpdaterBundleURL")
        let backup = finalDirectory + ".install-backup"
        try recoverInterruptedPromotion(finalDirectory: finalDirectory)
        if fileSystem.fileExists(atPath: finalDirectory) {
            try fileSystem.moveItem(atPath: finalDirectory, toPath: backup)
        }
        var promoted = false
        do {
            try fileSystem.moveItem(atPath: stagingDirectory, toPath: finalDirectory)
            promoted = true
            try setBundleURL(localPath: finalBundlePath).get()
            // Metadata is the durable activation point. Launch never uses an
            // untracked preference if this write fails or the process terminates.
            guard saveMetadata(updatedMetadata) else {
                throw UpdateFailureError(
                    underlying: BundleStorageError.unknown(NSError(domain: "HotUpdater", code: 0,
                        userInfo: [NSLocalizedDescriptionKey: "Failed to persist bundle activation metadata"])),
                    failure: .storage
                )
            }
        } catch {
            let installError = error
            let preferenceResult = setBundleURL(localPath: previousPreference)
            if promoted { try fileSystem.removeItem(atPath: finalDirectory) }
            if fileSystem.fileExists(atPath: backup) {
                try fileSystem.moveItem(atPath: backup, toPath: finalDirectory)
            }
            try preferenceResult.get()
            throw installError
        }
        try? fileSystem.removeItem(atPath: backup)
        return updatedMetadata
    }

    private func updateBundleFromManifest(
        bundleId: String,
        manifestUrl: URL,
        manifestFileHash: String,
        archiveUrl: URL?,
        changedAssets: [String: ChangedAssetDescriptor],
        fileResolver: ArtifactFileResolver?,
        selection: PersistedSelection?,
        storeDir: String,
        progressHandler: @escaping (UpdateProgressPayload) -> Void,
        completion: @escaping (Result<UpdateDelivery, Error>) -> Void
    ) {
        let tempDirResult = tempDir()
        guard case .success(let tempDirectory) = tempDirResult else {
            completion(.failure(UpdateFailureError.classifying(
                tempDirResult.failureError ?? BundleStorageError.unknown(nil),
                during: .storage
            )))
            return
        }

        try? self.fileSystem.removeItem(atPath: tempDirectory)
        guard self.fileSystem.createDirectory(atPath: tempDirectory) else {
            completion(.failure(UpdateFailureError.classifying(
                BundleStorageError.directoryCreationFailed,
                during: .storage
            )))
            return
        }

        let currentBundleId = self.getCachedBundleId()
        let currentBundleDir = currentBundleId.map {
            (storeDir as NSString).appendingPathComponent($0)
        }
        let tempManifestPath = (tempDirectory as NSString).appendingPathComponent("manifest.json")
        let tmpDir = (storeDir as NSString).appendingPathComponent("\(bundleId).tmp")
        let realDir = (storeDir as NSString).appendingPathComponent(bundleId)
        var diffFiles: [UpdateProgressPayload.DiffProgressFileSnapshot] = []
        // The running step classifies the errors whose type does not.
        var failurePhase = UpdatePhase.storage
        var failureResource: UpdateFailureResource?

        do {
            try recoverInterruptedPromotion(finalDirectory: realDir)
            failurePhase = .transfer
            failureResource = .manifest
            self.emitDiffProgress(
                progressHandler: progressHandler,
                phase: "manifest",
                files: diffFiles,
                manifestProgress: 0
            )
            switch self.downloadFileSynchronously(
                from: manifestUrl,
                to: tempManifestPath,
                progressHandler: { progress in
                    self.emitDiffProgress(
                        progressHandler: progressHandler,
                        phase: "manifest",
                        files: diffFiles,
                        manifestProgress: progress.progress
                    )
                }
            ) {
            case .success:
                break
            case .failure(let error):
                if let downloadError = error as? DownloadError,
                   case .incompleteDownload(let expected, let actual) = downloadError {
                    throw BundleStorageError.incompleteDownload(expected: expected, actual: actual)
                }
                throw BundleStorageError.downloadFailed(error)
            }

            failurePhase = .verification
            let manifestVerificationResult = SignatureVerifier.verifyBundle(
                fileURL: URL(fileURLWithPath: tempManifestPath),
                fileHash: manifestFileHash,
                publicKey: instance.publicKey()
            )
            guard case .success = manifestVerificationResult else {
                if case .failure(let error) = manifestVerificationResult {
                    throw BundleStorageError.signatureVerificationFailed(error)
                }
                throw BundleStorageError.unknown(nil)
            }

            failurePhase = .manifest
            guard let manifestData = try? Data(contentsOf: URL(fileURLWithPath: tempManifestPath)),
                  let manifestJson = try JSONSerialization.jsonObject(with: manifestData) as? [String: Any],
                  let targetManifest = parseBundleManifest(from: manifestJson),
                  targetManifest.bundleId == bundleId
            else {
                throw BundleStorageError.invalidBundle
            }
            if fileResolver == nil {
                // Legacy: artifact protocol v1, where every file comes with its URL.
                // Validate the entire wire contract even when every byte can be reused.
                guard Set(targetManifest.assets.keys) == Set(changedAssets.keys) else {
                    throw BundleStorageError.invalidBundle
                }
            } else {
                // In v2, `assets` holds only the Hermes patch.
                guard Set(changedAssets.keys).isSubset(of: Set(targetManifest.assets.keys)) else {
                    throw BundleStorageError.invalidBundle
                }
            }
            for (path, asset) in targetManifest.assets {
                guard FileUtilities.normalizedRelativePath(from: path) == path,
                      path != "manifest.json" else {
                    throw BundleStorageError.invalidBundle
                }
                if fileResolver == nil {
                    guard let descriptor = changedAssets[path],
                          descriptor.fileUrl != nil,
                          descriptor.fileHash.caseInsensitiveCompare(asset.fileHash) == .orderedSame else {
                        throw BundleStorageError.invalidBundle
                    }
                }
                _ = try FileUtilities.fileURL(for: path, destinationRoot: tmpDir)
            }
            // In v2, the manifest names every file; URLs come once the install
            // knows which files it downloads.
            let plannedAssets: [String: ChangedAssetDescriptor] = fileResolver == nil
                ? changedAssets
                : targetManifest.assets.reduce(into: [:]) { planned, entry in
                    planned[entry.key] = ChangedAssetDescriptor(
                        fileUrl: nil,
                        fileHash: entry.value.fileHash,
                        patch: changedAssets[entry.key]?.patch
                    )
                }

            // Downloads, patches, and extraction below classify their own errors.
            failurePhase = .storage
            failureResource = nil
            guard self.fileSystem.createDirectory(atPath: tmpDir) else {
                throw BundleStorageError.directoryCreationFailed
            }
            try pruneStagingDirectory(tmpDir, assets: Set(targetManifest.assets.keys))
            let sortedAssets = targetManifest.assets.sorted { $0.key < $1.key }
            let localDirectories = [currentBundleDir, realDir].compactMap { $0 }.filter { fileSystem.fileExists(atPath: $0) }
            var downloads: [String: ChangedAssetDescriptor] = [:]
            for (index, asset) in sortedAssets.enumerated() {
                // Local preparation has its own progress interval, with no download files.
                progressHandler(UpdateProgressPayload(
                    progress: 0.15 + 0.05 * Double(index) / Double(max(1, sortedAssets.count)),
                    artifactType: "diff",
                    details: .init(totalFilesCount: 0, completedFilesCount: 0)
                ))
                let assetPath = asset.key
                let expectedAsset = asset.value
                let destinationPath = try FileUtilities.fileURL(for: assetPath, destinationRoot: tmpDir).path
                guard self.fileSystem.createDirectory(atPath: (destinationPath as NSString).deletingLastPathComponent) else {
                    throw BundleStorageError.directoryCreationFailed
                }
                if (try? fileSystem.attributesOfItem(atPath: destinationPath)[.type] as? FileAttributeType) == .typeRegular,
                   (try? verifyManifestAssetFile(atPath: destinationPath, asset: expectedAsset)) != nil {
                    continue
                }
                if fileSystem.fileExists(atPath: destinationPath) { try self.fileSystem.removeItem(atPath: destinationPath) }

                var reused = false
                // The cached target is only a candidate, just like the active OTA.
                for directory in localDirectories {
                    guard let sourcePath = try? FileUtilities.fileURL(for: assetPath, destinationRoot: directory).path,
                          (try? fileSystem.attributesOfItem(atPath: sourcePath)[.type] as? FileAttributeType) == .typeRegular,
                          (try? verifyManifestAssetFile(atPath: sourcePath, asset: expectedAsset)) != nil else { continue }
                    do {
                        try self.fileSystem.copyItem(atPath: sourcePath, toPath: destinationPath)
                        try verifyManifestAssetFile(atPath: destinationPath, asset: expectedAsset)
                        reused = true
                        break
                    } catch {
                        try? self.fileSystem.removeItem(atPath: destinationPath)
                    }
                }
                if reused { continue }
                if builtInAssetResolver.copyIfMatches(assetPath: assetPath, expectedHash: expectedAsset.fileHash, destination: destinationPath) {
                    try UpdateFailureError.during(.verification, resource: .file) {
                        try verifyManifestAssetFile(atPath: destinationPath, asset: expectedAsset)
                    }
                    continue
                }
                downloads[assetPath] = plannedAssets[assetPath]
            }

            var archiveInstalled = false
            var patchedFiles = false
            // The archive is chosen before any patch is tried, so only the
            // per-file install can fall back from a patch.
            var patchFallbacks = false
            let builtInPatchBases = prepareBuiltInPatchBases(
                downloads: downloads,
                currentBundleId: currentBundleId,
                tempDirectory: tempDirectory
            )
            if shouldUseArchive(
                archive: targetManifest.archive,
                archiveUrl: archiveUrl,
                downloads: downloads,
                assets: targetManifest.assets,
                currentBundleId: currentBundleId,
                builtInPatchBases: builtInPatchBases
            ), let archive = targetManifest.archive, let archiveUrl {
                do {
                    diffFiles = try UpdateFailureError.during(.storage, resource: .archive) {
                        try installArchive(
                            archive: archive,
                            archiveUrl: archiveUrl,
                            targetManifest: targetManifest,
                            preparedDirectory: tmpDir,
                            tempDirectory: tempDirectory,
                            progressHandler: progressHandler
                        )
                    }
                    archiveInstalled = true
                } catch {
                    NSLog("[BundleStorage] tar.br optimization failed; falling back to individual files: \(error.localizedDescription)")
                    guard fileSystem.fileExists(atPath: tmpDir) else {
                        throw error
                    }
                }
            }

            if !archiveInstalled {
                if let fileResolver {
                    failurePhase = .transfer
                    failureResource = .file
                    try resolveFileUrls(fileResolver: fileResolver, downloads: &downloads)
                    failurePhase = .storage
                    failureResource = nil
                }
                diffFiles = createDiffProgressFiles(changedAssets: downloads)
                emitDiffProgress(progressHandler: progressHandler, phase: "downloading", files: diffFiles)
                let progressLock = NSLock()
                let workers = OperationQueue()
                workers.maxConcurrentOperationCount = Self.parallelFileDownloads
                var installError: Error?
                var installOutcomes: [AssetInstallOutcome] = []
                for progressFile in diffFiles {
                    let assetPath = progressFile.path
                    let expectedAsset = targetManifest.assets[assetPath]!
                    let descriptor = downloads[assetPath]!
                    let destinationPath = try FileUtilities.fileURL(for: assetPath, destinationRoot: tmpDir).path
                    // Separate temp namespaces also avoid collisions between flattened asset paths.
                    let workerTemp = (tempDirectory as NSString).appendingPathComponent(String(progressFile.order))
                    workers.addOperation {
                        progressLock.lock()
                        let shouldSkip = installError != nil
                        progressLock.unlock()
                        if shouldSkip { return }
                        do {
                            guard self.fileSystem.createDirectory(atPath: workerTemp) else { throw BundleStorageError.directoryCreationFailed }
                            let outcome = try self.downloadManifestAsset(
                                assetPath: assetPath, expectedAsset: expectedAsset, changedAsset: descriptor,
                                currentBundleId: currentBundleId, currentBundleDir: currentBundleDir,
                                builtInBasePath: builtInPatchBases[assetPath],
                                destinationPath: destinationPath, tempDirectory: workerTemp, progressFile: progressFile,
                                progressHandler: { payload in
                                    progressLock.lock()
                                    defer { progressLock.unlock() }
                                    if let snapshot = payload.details?.files.first,
                                       let index = diffFiles.firstIndex(where: { $0.path == assetPath }) {
                                        diffFiles[index] = snapshot
                                    }
                                    self.emitDiffProgress(progressHandler: progressHandler, phase: "downloading", files: diffFiles)
                                }
                            )
                            progressLock.lock()
                            installOutcomes.append(outcome)
                            progressLock.unlock()
                        } catch {
                            progressLock.lock()
                            if installError == nil { installError = error }
                            progressLock.unlock()
                        }
                    }
                }
                // Join all workers before cleaning scratch files, even after a failure.
                workers.waitUntilAllOperationsAreFinished()
                if let installError { throw installError }
                for outcome in installOutcomes {
                    switch outcome {
                    case .patched:
                        patchedFiles = true
                    case .downloaded(let patchFallback):
                        patchFallbacks = patchFallbacks || patchFallback
                    }
                }
            }

            self.emitDiffProgress(
                progressHandler: progressHandler,
                phase: "finalizing",
                files: diffFiles
            )

            let manifestDestination = (tmpDir as NSString).appendingPathComponent("manifest.json")
            try copyVerifiedManifest(from: tempManifestPath, to: manifestDestination)

            switch self.findBundleFile(in: tmpDir, expectedBundleId: bundleId) {
            case .success(let maybeBundlePath):
                guard let bundlePathInTmp = maybeBundlePath else {
                    // The manifest does not name exactly one platform bundle file.
                    throw UpdateFailureError(
                        underlying: BundleStorageError.invalidBundle,
                        failure: UpdateFailure.invalidResponse.with(resource: .manifest)
                    )
                }

                let updatedMetadata = try promoteStagedBundle(
                    bundleId: bundleId,
                    selection: selection,
                    stagingDirectory: tmpDir,
                    finalDirectory: realDir,
                    bundlePathInStaging: bundlePathInTmp
                )
                self.cleanupTemporaryFiles([tempDirectory])
                self.scheduleCleanupOldBundles(
                    bundleIdsToKeep: [currentBundleId, updatedMetadata.stableBundleId, bundleId].compactMap { $0 }
                )
                progressHandler(UpdateProgressPayload(
                    progress: 1.0,
                    artifactType: "diff",
                    details: .init(
                        totalFilesCount: diffFiles.count,
                        completedFilesCount: diffFiles.filter { $0.status == "downloaded" }.count,
                        files: diffFiles
                    )
                ))
                let delivery: UpdateDelivery.Method =
                    archiveInstalled ? .archive : (patchedFiles ? .patch : .manifest)
                completion(.success(UpdateDelivery(method: delivery, patchFallback: patchFallbacks)))
            case .failure(let error):
                throw error
            }
        } catch {
            NSLog("[BundleStorage] Manifest-driven install failed: \(error.localizedDescription).")
            // Preserve staging for a hash-checked retry. Never trust its presence alone.
            self.cleanupTemporaryFiles([tempDirectory])
            completion(.failure(UpdateFailureError.classifying(
                error,
                during: failurePhase,
                resource: failureResource
            )))
        }
    }

    func markLaunchStarted(bundleId: String?) {
        // Unlike prepareLaunch, this can run while JavaScript stages a newer bundle.
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard let bundleId,
              var metadata = loadMetadataOrNull(),
              metadata.verificationPending,
              !metadata.launchInProgress,
              metadata.stagingBundleId == bundleId else {
            return
        }
        metadata.launchInProgress = true
        _ = saveMetadata(metadata)
    }

    @discardableResult
    func clearLaunchStarted(bundleId: String?) -> Bool {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard let bundleId,
              var metadata = loadMetadataOrNull(),
              metadata.verificationPending,
              metadata.launchInProgress,
              metadata.stagingBundleId == bundleId else {
            return false
        }
        metadata.launchInProgress = false
        return saveMetadata(metadata)
    }

    func markLaunchCompleted(bundleId: String?) {
        // Before the guard: content from the built-in bundle (nil) also counts.
        readyInterruptedLaunchRetry(bundleId)
        // A Release selection can commit at the same time, from a native update
        // check or JavaScript; neither may save over the other's read.
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard let bundleId,
              var metadata = loadMetadataOrNull(),
              metadata.verificationPending,
              metadata.stagingBundleId == bundleId else {
            return
        }

        let pendingTransition = metadata.pendingTransition
        let pendingSelectionTransition = metadata.pendingSelectionTransition
        metadata.stableBundleId = nil
        metadata.stableSelection = nil
        metadata.verificationPending = false
        metadata.launchInProgress = false
        metadata.pendingTransition = nil
        metadata.pendingSelectionTransition = nil
        metadata.updatedAt = Date().timeIntervalSince1970 * 1000
        let _ = saveMetadata(metadata)
        saveLaunchReport(
            LaunchReport(
                status: .updateApplied,
                fromReleaseId: pendingSelectionTransition?.fromReleaseId,
                fromBundleId: pendingSelectionTransition?.fromBundleId ?? pendingTransition?.fromBundleId,
                toReleaseId: pendingSelectionTransition?.toReleaseId,
                toBundleId: pendingSelectionTransition?.toBundleId ?? pendingTransition?.toBundleId,
                updateStrategy: pendingTransition?.updateStrategy
            )
        )
    }

    func notifyAppReady() -> [String: Any] {
        guard let report = loadLaunchReport() else {
            if let launchedBundleId = pendingLaunchBundleId,
               let metadata = loadMetadataOrNull(),
               metadata.verificationPending,
               metadata.stagingBundleId == launchedBundleId {
                return ["status": "PENDING"]
            }
            return ["status": LaunchReportStatus.unchanged.rawValue]
        }

        var result: [String: Any] = ["status": report.status.rawValue]
        if let fromReleaseId = report.fromReleaseId {
            result["fromReleaseId"] = fromReleaseId
        }
        if let fromBundleId = report.fromBundleId {
            result["fromBundleId"] = fromBundleId
        }
        if let toBundleId = report.toBundleId {
            result["toBundleId"] = toBundleId
        }
        if let toReleaseId = report.toReleaseId {
            result["toReleaseId"] = toReleaseId
        }
        if let updateStrategy = report.updateStrategy {
            result["updateStrategy"] = updateStrategy.rawValue
        }
        return result
    }

    /**
     * Returns the bundles this device refuses to install: crash history, plus a
     * bundle waiting for its retry until a process that may retry it.
     * @return The crashed history object
     */
    func getCrashHistory() -> CrashedHistory {
        crashedHistoryLock.lock()
        defer { crashedHistoryLock.unlock() }
        var history = loadCrashedHistory()
        if let interrupted = history.interruptedLaunch,
           !interrupted.retryReady || interrupted.bundleId == retryHeldBundleId,
           !history.contains(interrupted.bundleId) {
            history.bundles.append(CrashedBundleEntry(bundleId: interrupted.bundleId))
        }
        return history
    }

    /**
     * Clears the crashed bundle history.
     * @return true if clearing was successful
     */
    func clearCrashHistory() -> Bool {
        crashedHistoryLock.lock()
        defer { crashedHistoryLock.unlock() }
        var history = loadCrashedHistory()
        history.clear()
        retryHeldBundleId = nil
        return saveCrashedHistory(history)
    }

    /// A crash, or a second unfinished launch of the same bundle, adds the bundle
    /// to crash history. A first unfinished launch cannot tell a hang from a user
    /// leaving early, so it leaves the bundle one retry instead.
    private func recordFailedLaunch(_ bundleId: String, unfinishedLaunch: Bool) {
        crashedHistoryLock.lock()
        defer { crashedHistoryLock.unlock() }
        var history = loadCrashedHistory()
        let interrupted = history.interruptedLaunch
        if unfinishedLaunch, interrupted?.bundleId != bundleId {
            NSLog("[BundleStorage] Launch of \(bundleId) ended before first content; it gets one retry")
            history.interruptedLaunch = InterruptedLaunch(bundleId: bundleId)
            retryHeldBundleId = bundleId
        } else {
            history.addEntry(bundleId)
            if interrupted?.bundleId == bundleId {
                history.interruptedLaunch = nil
            }
        }
        _ = saveCrashedHistory(history)
    }

    /// First content appeared, so the app works again. A bundle waiting for its
    /// retry may be installed from the next process on. This process keeps
    /// refusing it, so the session that recovered never reloads into it. Content
    /// from that bundle verifies it.
    private func readyInterruptedLaunchRetry(_ currentBundleId: String?) {
        crashedHistoryLock.lock()
        defer { crashedHistoryLock.unlock() }
        var history = loadCrashedHistory()
        guard let interrupted = history.interruptedLaunch else {
            return
        }
        if interrupted.bundleId == currentBundleId {
            history.interruptedLaunch = nil
        } else if interrupted.retryReady {
            return
        } else {
            history.interruptedLaunch?.retryReady = true
            retryHeldBundleId = interrupted.bundleId
        }
        _ = saveCrashedHistory(history)
    }

    func getInstallId() -> String {
        loadOrCreateInstallIdentity().installId
    }

    /**
     * Gets the base URL for the current active bundle directory
     * Returns the file:// URL to the bundle directory without trailing slash
     */
    func getBaseURL() -> String {
        if let bundleId = getActiveBundleId() {
            if case .success(let storeDir) = bundleStoreDir() {
                let bundleDir = (storeDir as NSString).appendingPathComponent(bundleId)
                if fileSystem.fileExists(atPath: bundleDir) {
                    return "file://\(bundleDir)"
                }
            }
        }

        return ""
    }

    func getBaseURL(forBundleId bundleId: String?) -> String {
        guard let bundleId = bundleId?.trimmingCharacters(in: .whitespacesAndNewlines),
              !bundleId.isEmpty,
              case .success(let storeDir) = bundleStoreDir() else {
            return ""
        }

        let bundleDir = (storeDir as NSString).appendingPathComponent(bundleId)
        guard fileSystem.fileExists(atPath: bundleDir) else {
            return ""
        }

        return "file://\(bundleDir)"
    }

    func getBundleId() -> String? {
        return getActiveBundleMetadataSnapshot()?.bundleId
    }

    func getManifest() -> ManifestAssets {
        return getActiveBundleMetadataSnapshot()?.manifest ?? [:]
    }

    func getManifest(forBundleId bundleId: String?) -> ManifestAssets {
        return getBundleMetadataSnapshot(bundleId: bundleId)?.manifest ?? [:]
    }

    func resetChannelIfSelectionCurrent(
        catalogId: String,
        scopeKey: String,
        generation: Int64,
        catalogHash: String,
        channel: String,
        selectionContextHash: String
    ) -> Result<Bool, Error> {
        // The catalog checks take the same recursive lock, so none accepts a
        // newer catalog between this check and the reset.
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard isReleaseSelectionCurrent(
            catalogId: catalogId,
            scopeKey: scopeKey,
            generation: generation,
            catalogHash: catalogHash,
            channel: channel,
            selectionContextHash: selectionContextHash
        ) else {
            return .success(false)
        }
        return resetChannel()
    }

    func resetChannel() -> Result<Bool, Error> {
        releaseStateLock.lock()
        defer { releaseStateLock.unlock() }
        guard case .success = setBundleURL(localPath: nil) else {
            return .failure(BundleStorageError.unknown(nil))
        }

        var clearedMetadata = loadMetadataOrNull() ?? BundleMetadata(isolationKey: isolationKey)
        clearedMetadata.stableBundleId = nil
        clearedMetadata.stagingBundleId = nil
        clearedMetadata.stableSelection = nil
        clearedMetadata.stagingSelection = nil
        clearedMetadata.verificationPending = false
        clearedMetadata.pendingTransition = nil
        clearedMetadata.pendingSelectionTransition = nil
        // Selections made before the reset no longer stage; the high-water
        // marks stay, so an older catalog is still refused.
        clearedMetadata.currentSelectionContexts = [:]
        clearedMetadata.updatedAt = Date().timeIntervalSince1970 * 1000

        guard saveMetadata(clearedMetadata) else {
            return .failure(BundleStorageError.unknown(nil))
        }

        saveLaunchReport(nil)

        guard case .success(let storeDir) = bundleStoreDir() else {
            return .failure(BundleStorageError.unknown(nil))
        }

        do {
            for item in try fileSystem.contentsOfDirectory(atPath: storeDir) {
                if protectedBundleStoreEntries.contains(item) {
                    continue
                }

                let bundlePath = (storeDir as NSString).appendingPathComponent(item)
                if fileSystem.fileExists(atPath: bundlePath) {
                    try fileSystem.removeItem(atPath: bundlePath)
                }
            }
            return .success(true)
        } catch {
            return .failure(BundleStorageError.moveOperationFailed(error))
        }
    }
}

// Helper to get the associated error from a Result, if it's a failure
extension Result {
    var failureError: Failure? {
        guard case .failure(let error) = self else { return nil }
        return error
    }
}
