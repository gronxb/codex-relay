import useSyncExternalStoreExports from "use-sync-external-store/shim/with-selector";

import type {
  HotUpdaterDiffFileSnapshot,
  HotUpdaterDiffProgressDetails,
  HotUpdaterProgressEvent,
} from "./native";
import { addListener } from "./native";

export type HotUpdaterState = {
  progress: number;
  isUpdateDownloaded: boolean;
  artifactType: "diff" | null;
  details: HotUpdaterDiffProgressDetails | null;
};

const { useSyncExternalStoreWithSelector } = useSyncExternalStoreExports;

const areDiffDetailsEqual = (
  left: HotUpdaterDiffProgressDetails | null,
  right: HotUpdaterDiffProgressDetails | null,
) => {
  if (left === right) {
    return true;
  }

  if (left === null || right === null) {
    return false;
  }

  if (
    left.totalFilesCount !== right.totalFilesCount ||
    left.completedFilesCount !== right.completedFilesCount ||
    left.files.length !== right.files.length
  ) {
    return false;
  }

  return left.files.every((leftFile, index) => {
    const rightFile = right.files[index];
    return (
      rightFile !== undefined &&
      leftFile.order === rightFile.order &&
      leftFile.path === rightFile.path &&
      leftFile.downloadPath === rightFile.downloadPath &&
      leftFile.downloadedBytes === rightFile.downloadedBytes &&
      leftFile.progress === rightFile.progress &&
      leftFile.status === rightFile.status &&
      leftFile.totalBytes === rightFile.totalBytes
    );
  });
};

const areStatesEqual = (left: HotUpdaterState, right: HotUpdaterState) => {
  return (
    left.progress === right.progress &&
    left.isUpdateDownloaded === right.isUpdateDownloaded &&
    left.artifactType === right.artifactType &&
    areDiffDetailsEqual(left.details, right.details)
  );
};

const normalizeByteCount = (value: number | undefined) => {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
    return undefined;
  }
  return Math.round(value);
};

const normalizeDownloadPath = (value: string | undefined) => {
  return typeof value === "string" && value.length > 0 ? value : undefined;
};

const createHotUpdaterStore = () => {
  let state: HotUpdaterState = {
    progress: 0,
    isUpdateDownloaded: false,
    artifactType: null,
    details: null,
  };

  const getSnapshot = () => {
    return state;
  };

  const listeners = new Set<() => void>();
  let isEmitScheduled = false;

  const emitChange = () => {
    if (isEmitScheduled) {
      return;
    }

    isEmitScheduled = true;
    const scheduleFrame =
      typeof requestAnimationFrame === "function"
        ? requestAnimationFrame
        : (callback: (timestamp: number) => void) => callback(0);
    scheduleFrame(() => {
      isEmitScheduled = false;
      for (const listener of listeners) {
        listener();
      }
    });
  };

  const normalizeDiffDetails = (
    details: HotUpdaterDiffProgressDetails,
  ): HotUpdaterDiffProgressDetails => {
    const totalFilesCount = Math.max(0, details.totalFilesCount);
    const normalizedFiles: HotUpdaterDiffFileSnapshot[] = details.files
      .map((file) => {
        const downloadPath =
          normalizeDownloadPath(file.downloadPath) ?? file.path;

        return {
          downloadPath,
          downloadedBytes: normalizeByteCount(file.downloadedBytes),
          order: Math.max(0, file.order),
          path: file.path,
          progress: Math.max(0, Math.min(file.progress, 1)),
          status: file.status,
          totalBytes: normalizeByteCount(file.totalBytes),
        };
      })
      .sort((left, right) => left.order - right.order);

    return {
      completedFilesCount: Math.max(
        0,
        Math.min(details.completedFilesCount, totalFilesCount),
      ),
      files: normalizedFiles,
      totalFilesCount,
    };
  };

  const setState = (newState: Partial<HotUpdaterState>) => {
    // Merge first, then normalize derived fields.
    const nextState: HotUpdaterState = {
      ...state,
      ...newState,
    };

    // Derive `isUpdateDownloaded` from `progress` if provided.
    // If `progress` is not provided but `isUpdateDownloaded` is,
    // honor the explicit value.
    if ("progress" in newState && typeof newState.progress === "number") {
      nextState.progress = Math.max(0, Math.min(newState.progress, 1));
      nextState.isUpdateDownloaded = nextState.progress >= 1;
    } else if (
      "isUpdateDownloaded" in newState &&
      typeof newState.isUpdateDownloaded === "boolean"
    ) {
      nextState.isUpdateDownloaded = newState.isUpdateDownloaded;
    }

    if (newState.details === undefined) {
      nextState.details = state.details;
    }

    if (areStatesEqual(state, nextState)) {
      return;
    }

    state = nextState;
    emitChange();
  };

  const applyProgressEvent = (event: HotUpdaterProgressEvent) => {
    setState({
      artifactType: event.artifactType,
      details: normalizeDiffDetails(event.details),
      progress: event.progress,
    });
  };

  const subscribe = (listener: () => void) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };

  // Subscribe to native onProgress events
  // This listener is registered once when the store is created
  addListener("onProgress", applyProgressEvent);

  return { getSnapshot, setState, subscribe };
};

export const hotUpdaterStore = createHotUpdaterStore();

export const useHotUpdaterStore = <T = HotUpdaterState>(
  selector: (snapshot: HotUpdaterState) => T = (snapshot) => snapshot as T,
) => {
  return useSyncExternalStoreWithSelector(
    hotUpdaterStore.subscribe,
    hotUpdaterStore.getSnapshot,
    hotUpdaterStore.getSnapshot,
    selector,
  );
};
