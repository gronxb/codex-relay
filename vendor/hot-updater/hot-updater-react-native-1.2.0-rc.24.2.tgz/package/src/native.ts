import {
  type ArtifactAsset,
  type CatalogHighWater,
  type ChangedAssetPatch,
  INVALID_COHORT_ERROR_MESSAGE,
  isValidCohort,
  normalizeCohortValue,
  type UpdateStatus,
  type PersistedSelectionReceipt,
} from "@hot-updater/protocol";
import { NativeEventEmitter, Platform } from "react-native";

import { HotUpdaterErrorCode, isHotUpdaterError } from "./error";
import HotUpdaterNative, {
  type InstallArtifactParams,
  type UpdateBundleParams,
} from "./specs/NativeHotUpdater";

export { HotUpdaterErrorCode, isHotUpdaterError };

const NIL_UUID = "00000000-0000-0000-0000-000000000000";
type PersistedUpdateStrategy = "fingerprint" | "appVersion";

const normalizeAndValidateCohort = (cohort: string): string => {
  const normalized = normalizeCohortValue(cohort);
  if (!isValidCohort(normalized)) {
    throw new Error(INVALID_COHORT_ERROR_MESSAGE);
  }
  return normalized;
};

export interface ManifestAsset {
  fileHash: string;
  signature?: string;
}

export interface Manifest {
  bundleId: string;
  assets: Record<string, ManifestAsset>;
}

type ActiveBundleSnapshotCacheValues = {
  bundleId?: string;
  manifest?: Manifest;
  baseURL?: string | null;
};

type ActiveBundleSnapshotCacheKey = keyof ActiveBundleSnapshotCacheValues;

class HotUpdaterSessionState {
  private readonly defaultChannel: string;
  private currentChannel: string;
  private cachedCohort: string | undefined;
  private readonly inflightUpdates = new Map<
    string,
    Promise<BundleDelivery | null>
  >();
  private lastInstalledBundleId: string | null = null;
  private readonly activeBundleSnapshotCache = new Map<
    ActiveBundleSnapshotCacheKey,
    ActiveBundleSnapshotCacheValues[ActiveBundleSnapshotCacheKey]
  >();

  constructor() {
    const constants = HotUpdaterNative.getConstants();
    this.defaultChannel = constants.DEFAULT_CHANNEL ?? constants.CHANNEL;
    this.currentChannel = constants.CHANNEL;
  }

  getChannel(): string {
    return this.currentChannel;
  }

  getDefaultChannel(): string {
    return this.defaultChannel;
  }

  isChannelSwitched(): boolean {
    return this.currentChannel !== this.defaultChannel;
  }

  hasInstalledBundle(bundleId: string): boolean {
    return this.lastInstalledBundleId === bundleId;
  }

  getInflightUpdate(
    bundleId: string,
  ): Promise<BundleDelivery | null> | undefined {
    return this.inflightUpdates.get(bundleId);
  }

  trackInflightUpdate(
    bundleId: string,
    promise: Promise<BundleDelivery | null>,
  ) {
    this.inflightUpdates.set(bundleId, promise);
  }

  clearInflightUpdate(bundleId: string) {
    this.inflightUpdates.delete(bundleId);
  }

  markBundleInstalled(bundleId: string, channel?: string) {
    this.lastInstalledBundleId = bundleId;
    if (channel) {
      this.currentChannel = channel;
    }
    this.clearActiveBundleSnapshotCache();
  }

  resetChannelState() {
    this.currentChannel = this.defaultChannel;
    this.lastInstalledBundleId = null;
    this.inflightUpdates.clear();
    this.clearActiveBundleSnapshotCache();
  }

  getCachedBundleId(): string | undefined {
    return this.getActiveBundleSnapshotValue("bundleId");
  }

  cacheBundleId(bundleId: string) {
    this.setActiveBundleSnapshotValue("bundleId", bundleId);
  }

  getCachedManifest(): Manifest | undefined {
    const manifest = this.getActiveBundleSnapshotValue("manifest");
    return manifest ? cloneManifest(manifest) : undefined;
  }

  cacheManifest(manifest: Manifest) {
    this.setActiveBundleSnapshotValue("manifest", cloneManifest(manifest));
  }

  getCachedBaseURL(): string | null | undefined {
    return this.getActiveBundleSnapshotValue("baseURL");
  }

  cacheBaseURL(baseURL: string | null) {
    this.setActiveBundleSnapshotValue("baseURL", baseURL);
  }

  getCachedCohort(): string | undefined {
    return this.cachedCohort;
  }

  cacheCohort(cohort: string) {
    this.cachedCohort = cohort;
  }

  private clearActiveBundleSnapshotCache() {
    this.activeBundleSnapshotCache.clear();
  }

  private getActiveBundleSnapshotValue<K extends ActiveBundleSnapshotCacheKey>(
    key: K,
  ): ActiveBundleSnapshotCacheValues[K] | undefined {
    return this.activeBundleSnapshotCache.get(key) as
      | ActiveBundleSnapshotCacheValues[K]
      | undefined;
  }

  private setActiveBundleSnapshotValue<K extends ActiveBundleSnapshotCacheKey>(
    key: K,
    value: ActiveBundleSnapshotCacheValues[K],
  ) {
    this.activeBundleSnapshotCache.set(key, value);
  }
}

const sessionState = new HotUpdaterSessionState();

const cloneManifest = (manifest: Manifest): Manifest => ({
  bundleId: manifest.bundleId,
  assets: Object.fromEntries(
    Object.entries(manifest.assets).map(([key, asset]) => [
      key,
      {
        fileHash: asset.fileHash,
        ...(asset.signature ? { signature: asset.signature } : {}),
      },
    ]),
  ),
});

const resolveBundleId = (bundleId: string | null): string => {
  return !bundleId || bundleId === NIL_UUID ? getMinBundleId() : bundleId;
};

const getFreshBundleId = (): string => {
  const resolvedBundleId = resolveBundleId(HotUpdaterNative.getBundleId());
  sessionState.cacheBundleId(resolvedBundleId);
  return resolvedBundleId;
};

export type HotUpdaterProgressArtifactType = "diff";

export type HotUpdaterDiffFileStatus =
  | "pending"
  | "downloading"
  | "downloaded"
  | "failed";

export interface HotUpdaterDiffFileSnapshot {
  /**
   * Manifest asset path for this progress entry.
   *
   * This is the stable identity of the asset in the installed bundle. Use this
   * when matching progress back to the manifest or to the final file location.
   */
  path: string;
  /**
   * Artifact path currently being transferred for this progress entry.
   *
   * Usually this is the same as `path`. It can differ when the updater
   * downloads an intermediate artifact that will be applied to produce the
   * final asset.
   */
  downloadPath: string;
  /**
   * Current download state for this asset within the manifest diff update.
   */
  status: HotUpdaterDiffFileStatus;
  /**
   * Download progress for this file, normalized from 0 to 1.
   */
  progress: number;
  /**
   * Stable display order among diff files.
   */
  order: number;
  /**
   * Bytes downloaded for `downloadPath`, when the native downloader reports it.
   */
  downloadedBytes?: number;
  /**
   * Total expected bytes for `downloadPath`, when known.
   */
  totalBytes?: number;
}

export interface HotUpdaterDiffProgressDetails {
  totalFilesCount: number;
  completedFilesCount: number;
  files: HotUpdaterDiffFileSnapshot[];
}

export type HotUpdaterProgressEvent = {
  progress: number;
  artifactType: "diff";
  details: HotUpdaterDiffProgressDetails;
};

export type HotUpdaterEvent = {
  onProgress: HotUpdaterProgressEvent;
};

const eventEmitter = new NativeEventEmitter(HotUpdaterNative);

export const addListener = <T extends keyof HotUpdaterEvent>(
  eventName: T,
  listener: (event: HotUpdaterEvent[T]) => void,
) => {
  const subscription = eventEmitter.addListener(eventName, listener);

  return () => {
    subscription.remove();
  };
};

export type UpdateParams = UpdateBundleParams & {
  status: UpdateStatus;
  shouldSkipCurrentBundleIdCheck?: boolean;
};

/** How the update check stages a Bundle over artifact protocol v2. */
export type InstallArtifactUpdateParams = Omit<
  InstallArtifactParams,
  "patch"
> & {
  patch?: (ChangedAssetPatch & { assetPath: string }) | null;
  status: UpdateStatus;
  shouldSkipCurrentBundleIdCheck?: boolean;
};

/**
 * Whether native installs artifact protocol v2. Native built from an SDK
 * older than protocol v2 has no `installArtifact`, and an OTA can bring this
 * JavaScript to such native code, so the update check then asks for v1.
 */
export const supportsArtifactFiles = (): boolean =>
  typeof (HotUpdaterNative as { installArtifact?: unknown }).installArtifact ===
  "function";

export interface ActiveUpdateState {
  readonly activeSelection: ActiveUpdateSelection | null;
  readonly stableSelection: ActiveUpdateSelection | null;
  readonly verificationPending: boolean;
}

type ActiveUpdateSelection = Pick<
  PersistedSelectionReceipt,
  "kind" | "releaseId" | "bundleId" | "channel"
>;

export interface InternalActiveUpdateState {
  readonly activeSelection: PersistedSelectionReceipt | null;
  readonly stableSelection: PersistedSelectionReceipt | null;
  readonly verificationPending: boolean;
  readonly highestSeenCatalogs: Readonly<Record<string, CatalogHighWater>>;
}

export interface ReleaseSelectionGuard {
  readonly catalogId: string;
  readonly scopeKey: string;
  readonly generation: number;
  readonly catalogHash: string;
  readonly selectionContextHash: string;
  readonly channel: string;
}

export const acceptReleaseCatalog = (input: {
  readonly catalogId: string;
  readonly scopeKey: string;
  readonly generation: number;
  readonly catalogHash: string;
  readonly channel: string;
  readonly selectionContextHash: string;
}): boolean => HotUpdaterNative.acceptReleaseCatalog(input);

export const getActiveUpdateState = (): InternalActiveUpdateState => {
  const value: unknown = HotUpdaterNative.getActiveUpdateState();
  if (typeof value === "string") {
    return JSON.parse(value) as InternalActiveUpdateState;
  }
  return value as InternalActiveUpdateState;
};

export const getPublicActiveUpdateState = (): ActiveUpdateState => {
  const state = getActiveUpdateState();
  const selection = (
    receipt: PersistedSelectionReceipt | null,
  ): ActiveUpdateSelection | null =>
    receipt === null
      ? null
      : {
          kind: receipt.kind,
          releaseId: receipt.releaseId,
          bundleId: receipt.bundleId,
          channel: receipt.channel,
        };
  return {
    activeSelection: selection(state.activeSelection),
    stableSelection: selection(state.stableSelection),
    verificationPending: state.verificationPending,
  };
};

export const isReleaseSelectionCurrent = (
  input: ReleaseSelectionGuard,
): boolean => HotUpdaterNative.isReleaseSelectionCurrent(input);

export const commitReleaseSelection = async (input: {
  readonly selection: PersistedSelectionReceipt;
  readonly guard: ReleaseSelectionGuard;
}): Promise<boolean> => {
  const ok = await HotUpdaterNative.commitReleaseSelection(input);
  if (ok)
    sessionState.markBundleInstalled(
      input.selection.bundleId,
      input.selection.channel,
    );
  return ok;
};

/** How native delivered a staged bundle. */
export type BundleDelivery = {
  /**
   * "patch" when a bsdiff patch produced a file, "manifest" when only the
   * changed files were downloaded, "archive" for the full archive.
   */
  readonly delivery: "patch" | "manifest" | "archive";
  /** A patch was tried, but the file or the archive was downloaded instead. */
  readonly patchFallback: boolean;
};

const readBundleDelivery = (value: unknown): BundleDelivery | null => {
  if (typeof value !== "object" || value === null) return null;
  const { delivery, patchFallback } = value as Record<string, unknown>;
  if (
    delivery !== "patch" &&
    delivery !== "manifest" &&
    delivery !== "archive"
  ) {
    return null;
  }
  return { delivery, patchFallback: patchFallback === true };
};

/**
 * Stages a bundle for the next launch. Resolves with how native delivered
 * it, or with null when this runtime had already staged it and nothing was
 * downloaded; rejects when the download or install fails.
 *
 * @throws {Error} Rejects with error.code from HotUpdaterErrorCode enum and error.message
 */
export async function stageBundle(
  params: UpdateParams | InstallArtifactUpdateParams,
): Promise<BundleDelivery | null> {
  const updateBundleId = params.bundleId;
  const status = params.status;
  const currentBundleId = status === "UPDATE" ? getFreshBundleId() : undefined;

  // If native is still on the same bundle we installed in this session,
  // skip re-download. Native state can move back to the built-in bundle after
  // rollback/reset, so check a fresh native bundle id before using this guard.
  if (
    status === "UPDATE" &&
    sessionState.hasInstalledBundle(updateBundleId) &&
    currentBundleId === updateBundleId
  ) {
    return null;
  }

  const shouldSkipCurrentBundleIdCheck =
    params.shouldSkipCurrentBundleIdCheck === true;

  if (
    !shouldSkipCurrentBundleIdCheck &&
    status === "UPDATE" &&
    currentBundleId !== undefined &&
    updateBundleId.localeCompare(currentBundleId) <= 0
  ) {
    throw new Error(
      "Update bundle id is not newer than the current bundle id. Preventing infinite update loop.",
    );
  }

  // In-flight guard: return the same promise if the same bundle is already updating.
  const existing = sessionState.getInflightUpdate(updateBundleId);
  if (existing) return existing;

  const targetChannel = params.channel;

  const promise = (async () => {
    try {
      const selection = params.selection;
      const common = {
        bundleId: updateBundleId,
        channel: targetChannel,
        manifestFileHash: params.manifestFileHash,
        manifestUrl: params.manifestUrl,
        ...(params.archiveUrl ? { archiveUrl: params.archiveUrl } : {}),
        ...(selection === undefined ? {} : { selection }),
      };
      const staged =
        "assets" in params
          ? // Legacy: artifact protocol v1, where every file comes with its
            // URL, and the `filesUrl` form earlier releases documented, which
            // native `updateBundle` keeps accepting.
            await HotUpdaterNative.updateBundle({
              ...common,
              assets: params.assets as Record<string, ArtifactAsset>,
              ...(params.filesUrl ? { filesUrl: params.filesUrl } : {}),
              ...(params.filesUrl && params.requestHeaders
                ? { requestHeaders: params.requestHeaders }
                : {}),
              ...(params.filesUrl && params.requestTimeout
                ? { requestTimeout: params.requestTimeout }
                : {}),
            })
          : await HotUpdaterNative.installArtifact({
              ...common,
              filesUrl: params.filesUrl,
              ...(params.patch ? { patch: params.patch } : {}),
              ...(params.requestHeaders
                ? { requestHeaders: params.requestHeaders }
                : {}),
              ...(params.requestTimeout
                ? { requestTimeout: params.requestTimeout }
                : {}),
            });
      sessionState.markBundleInstalled(updateBundleId, targetChannel);
      return readBundleDelivery(staged);
    } finally {
      sessionState.clearInflightUpdate(updateBundleId);
    }
  })();

  sessionState.trackInflightUpdate(updateBundleId, promise);
  return promise;
}

/**
 * Downloads files and applies them to the app.
 *
 * @param {UpdateParams} params - Parameters object required for bundle update
 * @returns {Promise<boolean>} Resolves with true if download was successful
 * @throws {Error} Rejects with error.code from HotUpdaterErrorCode enum and error.message
 */
export async function updateBundle(params: UpdateParams): Promise<boolean> {
  await stageBundle(params);
  return true;
}

/**
 * Fetches the current app version.
 */
export const getAppVersion = (): string | null => {
  const constants = HotUpdaterNative.getConstants();
  return constants?.APP_VERSION ?? null;
};

/**
 * Restarts the app so it loads the current bundle.
 *
 * Android restarts the app process cold, so no native module can reach the
 * JavaScript runtime while it is replaced. iOS reloads React Native in place.
 */
export const reload = async () => {
  if (Platform.OS === "android") {
    // An older native build's reload() reloads in place on Android.
    await HotUpdaterNative.reloadProcess();
    return;
  }

  await HotUpdaterNative.reload();
};

/**
 * Fetches the minimum bundle id created from the native app build time.
 *
 * Release Catalog selection uses this value as its minimum Release id.
 *
 * @returns {string} The minimum bundle id.
 */
export const getMinBundleId = (): string => {
  const constants = HotUpdaterNative.getConstants();
  return constants.MIN_BUNDLE_ID;
};

/** Returns the selected update ID shown in the console, including staged updates. */
export const getUpdateId = (): string =>
  getActiveUpdateState().activeSelection?.releaseId ?? getBundleId();

/**
 * Fetches the current bundle version id.
 *
 * JS falls back to MIN_BUNDLE_ID only after native confirms there is no active
 * downloaded bundle. When the native module does not expose `getBundleId()`,
 * treat it as a JS/native SDK mismatch instead of silently reporting the
 * built-in bundle.
 *
 * @returns {string} Resolves with the current version id.
 */
export const getBundleId = (): string => {
  const cachedBundleId = sessionState.getCachedBundleId();
  if (cachedBundleId !== undefined) {
    return cachedBundleId;
  }

  return getFreshBundleId();
};

/**
 * Fetches the current manifest for the active bundle.
 *
 * Returns a normalized manifest with empty assets when manifest.json is missing
 * or invalid.
 */
export const getManifest = (): Manifest => {
  const cachedManifest = sessionState.getCachedManifest();
  if (cachedManifest !== undefined) {
    return cachedManifest;
  }

  // Android's old-architecture module returns the manifest as a JSON string.
  const manifest = HotUpdaterNative.getManifest() as
    | Record<string, unknown>
    | string
    | null;

  let normalizedManifest: Manifest;

  if (!manifest) {
    normalizedManifest = createEmptyManifest();
  } else if (typeof manifest === "string") {
    try {
      normalizedManifest = normalizeManifest(JSON.parse(manifest));
    } catch {
      normalizedManifest = createEmptyManifest();
    }
  } else {
    normalizedManifest = normalizeManifest(manifest);
  }

  sessionState.cacheBundleId(normalizedManifest.bundleId);
  sessionState.cacheManifest(normalizedManifest);
  return cloneManifest(normalizedManifest);
};

/**
 * Fetches the channel for the app.
 *
 * @returns {string} Resolves with the channel or null if not available.
 */
export const getChannel = (): string => {
  return sessionState.getChannel();
};

/**
 * Fetches the build-time default channel for the app.
 */
export const getDefaultChannel = (): string => {
  return sessionState.getDefaultChannel();
};

/**
 * Returns whether the app is currently using a runtime channel override.
 */
export const isChannelSwitched = (): boolean => {
  return sessionState.isChannelSwitched();
};

/**
 * Fetches the fingerprint for the app.
 *
 * @returns {string | null} Resolves with the fingerprint hash
 */
export const getFingerprintHash = (): string | null => {
  const constants = HotUpdaterNative.getConstants();
  return constants.FINGERPRINT_HASH ?? null;
};

export const getInstallId = (): string => HotUpdaterNative.getInstallId();

/** Reads a value from the SDK's native key-value store. */
export const getStorageItem = (key: string): string | null => {
  const value: unknown = HotUpdaterNative.getStorageItem(key);
  return typeof value === "string" ? value : null;
};

/** Writes a value to the SDK's native key-value store; null removes it. */
export const setStorageItem = (key: string, value: string | null): void => {
  HotUpdaterNative.setStorageItem(key, value);
};

/**
 * Takes and clears the events of the native update checks, as JSON. Native
 * built from an earlier SDK has no `takeNativeUpdateEvents`, and an OTA can
 * bring this JavaScript to such native code, which has no events to replay.
 */
export const takeNativeUpdateEvents = (): string | null => {
  const native = HotUpdaterNative as { takeNativeUpdateEvents?: unknown };
  if (typeof native.takeNativeUpdateEvents !== "function") {
    return null;
  }
  const value: unknown = HotUpdaterNative.takeNativeUpdateEvents();
  return typeof value === "string" ? value : null;
};

/**
 * Result returned by notifyAppReady()
 */
export type NotifyAppReadyResult =
  | { status: "UNCHANGED" }
  | {
      status: "UPDATE_APPLIED";
      fromBundleId: string;
      toBundleId: string;
      fromReleaseId?: string;
      toReleaseId?: string;
    }
  | {
      status: "RECOVERED";
      fromBundleId: string;
      toBundleId: string;
      fromReleaseId?: string;
      toReleaseId?: string;
    };

/** An update applied or recovered at this launch, as native persisted it. */
export type LaunchTransition = {
  type: "UPDATE_APPLIED" | "RECOVERED";
  fromBundleId: string;
  toBundleId: string;
  fromReleaseId: string | null;
  toReleaseId: string | null;
  updateStrategy: PersistedUpdateStrategy;
};

type RawNotifyAppReadyResult = {
  status?: string;
  fromReleaseId?: string;
  fromBundleId?: string;
  toReleaseId?: string;
  toBundleId?: string;
  updateStrategy?: PersistedUpdateStrategy;
};

const isPersistedUpdateStrategy = (
  value: unknown,
): value is PersistedUpdateStrategy => {
  return value === "appVersion" || value === "fingerprint";
};

const readRawNotifyAppReadyResult = (): RawNotifyAppReadyResult => {
  const result = HotUpdaterNative.notifyAppReady();

  if (typeof result === "string") {
    try {
      const parsed = JSON.parse(result) as unknown;
      if (
        typeof parsed !== "object" ||
        parsed === null ||
        Array.isArray(parsed)
      ) {
        return {};
      }
      return parsed as RawNotifyAppReadyResult;
    } catch {
      return {};
    }
  }

  if (typeof result !== "object" || result === null || Array.isArray(result)) {
    return {};
  }

  return result as RawNotifyAppReadyResult;
};

const readDirectionalBundleId = (bundleId: unknown): string | null => {
  if (typeof bundleId !== "string") {
    return null;
  }
  const normalizedBundleId = bundleId.trim();
  if (normalizedBundleId.length === 0) {
    return null;
  }
  return resolveBundleId(normalizedBundleId);
};

const readDirectionalReleaseId = (releaseId: unknown): string | null => {
  if (typeof releaseId !== "string") return null;
  const normalizedReleaseId = releaseId.trim();
  return normalizedReleaseId.length === 0 ? null : normalizedReleaseId;
};

const getNotifyAppReadyTransition = (
  result: RawNotifyAppReadyResult,
): {
  status: "UPDATE_APPLIED" | "RECOVERED";
  fromBundleId: string;
  toBundleId: string;
  fromReleaseId: string | null;
  toReleaseId: string | null;
} | null => {
  if (result.status === "UPDATE_APPLIED") {
    const fromBundleId = readDirectionalBundleId(result.fromBundleId);
    const toBundleId = readDirectionalBundleId(result.toBundleId);
    if (fromBundleId && toBundleId) {
      return {
        status: "UPDATE_APPLIED",
        fromBundleId,
        toBundleId,
        fromReleaseId: readDirectionalReleaseId(result.fromReleaseId),
        toReleaseId: readDirectionalReleaseId(result.toReleaseId),
      };
    }
  }

  if (result.status === "RECOVERED") {
    const fromBundleId = readDirectionalBundleId(result.fromBundleId);
    const toBundleId = readDirectionalBundleId(result.toBundleId);
    if (fromBundleId && toBundleId) {
      return {
        status: "RECOVERED",
        fromBundleId,
        toBundleId,
        fromReleaseId: readDirectionalReleaseId(result.fromReleaseId),
        toReleaseId: readDirectionalReleaseId(result.toReleaseId),
      };
    }
  }

  return null;
};

const getLaunchTransition = (
  result: RawNotifyAppReadyResult,
): LaunchTransition | null => {
  const transition = getNotifyAppReadyTransition(result);

  if (!transition || !isPersistedUpdateStrategy(result.updateStrategy)) {
    return null;
  }

  return {
    type: transition.status,
    fromBundleId: transition.fromBundleId,
    toBundleId: transition.toBundleId,
    fromReleaseId: transition.fromReleaseId,
    toReleaseId: transition.toReleaseId,
    updateStrategy: result.updateStrategy,
  };
};

const normalizeNotifyAppReadyResult = (
  result: RawNotifyAppReadyResult,
): NotifyAppReadyResult => {
  const transition = getNotifyAppReadyTransition(result);

  if (transition) {
    return {
      status: transition.status,
      fromBundleId: transition.fromBundleId,
      toBundleId: transition.toBundleId,
      ...(transition.fromReleaseId === null
        ? {}
        : { fromReleaseId: transition.fromReleaseId }),
      ...(transition.toReleaseId === null
        ? {}
        : { toReleaseId: transition.toReleaseId }),
    };
  }

  return { status: "UNCHANGED" };
};

export const readNotifyAppReady = (): {
  result: NotifyAppReadyResult;
  transition: LaunchTransition | null;
  pending: boolean;
} => {
  const rawResult = readRawNotifyAppReadyResult();

  return {
    result: normalizeNotifyAppReadyResult(rawResult),
    transition: getLaunchTransition(rawResult),
    pending: rawResult.status === "PENDING",
  };
};

/**
 * Reads the native launch report for the current process.
 *
 * This function is called automatically after the app has rendered.
 *
 * @returns {NotifyAppReadyResult} Bundle state information
 * - `status: "UNCHANGED"` - No qualifying OTA transition to report
 * - `status: "UPDATE_APPLIED"` - A pending update became active
 * - `status: "RECOVERED"` - Crash recovery rolled back to another bundle
 *
 * @example
 * ```ts
 * const result = hotUpdater.notifyAppReady();
 *
 * if (result.status === "RECOVERED") {
 *   console.log(result.fromBundleId, result.toBundleId);
 * }
 * ```
 */
export const notifyAppReady = (): NotifyAppReadyResult => {
  return readNotifyAppReady().result;
};

const createEmptyManifest = (): Manifest => ({
  bundleId: getBundleId(),
  assets: {},
});

const normalizeManifest = (value: unknown): Manifest => {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return createEmptyManifest();
  }

  const bundleIdValue = (value as { bundleId?: unknown }).bundleId;
  const bundleId =
    typeof bundleIdValue === "string" && bundleIdValue.trim()
      ? bundleIdValue.trim()
      : getBundleId();

  return {
    bundleId,
    assets: normalizeManifestAssets((value as { assets?: unknown }).assets),
  };
};

const normalizeManifestAssets = (value: unknown): Manifest["assets"] => {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {};
  }

  return Object.fromEntries(
    Object.entries(value).flatMap(([key, entry]) => {
      const trimmedKey = key.trim();

      if (!trimmedKey) {
        return [];
      }

      if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
        return [];
      }

      const { fileHash, signature } = entry as {
        fileHash?: unknown;
        signature?: unknown;
      };
      if (typeof fileHash !== "string" || !fileHash.trim()) {
        return [];
      }

      return [
        [
          trimmedKey,
          {
            fileHash: fileHash.trim(),
            ...(typeof signature === "string" && signature.trim()
              ? { signature: signature.trim() }
              : {}),
          },
        ] as const,
      ];
    }),
  );
};

/**
 * Gets the list of bundle IDs that have been marked as crashed.
 * These bundles will be rejected if attempted to install again.
 *
 * @returns {string[]} Array of crashed bundle IDs
 */
export const getCrashHistory = (): string[] => {
  const result = HotUpdaterNative.getCrashHistory();
  // Android's old-architecture module returns the history as a JSON string.
  if (typeof result === "string") {
    try {
      return JSON.parse(result);
    } catch {
      return [];
    }
  }
  return result;
};

/**
 * Clears the crashed bundle history, allowing previously crashed bundles
 * to be installed again.
 *
 * @returns {boolean} true if clearing was successful
 */
export const clearCrashHistory = (): boolean => {
  return HotUpdaterNative.clearCrashHistory();
};

/**
 * Gets the base URL for the current active bundle directory.
 * Returns the file:// URL to the bundle directory without trailing slash.
 * This is used for Expo DOM components to construct full asset paths.
 *
 * @returns {string | null} Base URL string (e.g., "file:///data/.../bundle-store/abc123") or null if not available
 */
export const getBaseURL = (): string | null => {
  const cachedBaseURL = sessionState.getCachedBaseURL();
  if (cachedBaseURL !== undefined) {
    return cachedBaseURL;
  }

  const result = HotUpdaterNative.getBaseURL();
  const baseURL = typeof result === "string" && result !== "" ? result : null;
  sessionState.cacheBaseURL(baseURL);
  return baseURL;
};

/**
 * Clears the runtime channel override and restores the original bundle.
 */
export const resetChannel = async (): Promise<boolean> => {
  const ok = await HotUpdaterNative.resetChannel();
  if (ok) {
    sessionState.resetChannelState();
  }
  return ok;
};

/**
 * Clears the runtime channel only while the Release selection `guard` names
 * is current. Native that checks and resets in one step does so; native from
 * an earlier SDK is checked first, then reset. Returns false for a stale
 * selection.
 */
export const resetChannelIfSelectionCurrent = async (
  guard: ReleaseSelectionGuard,
): Promise<boolean> => {
  const native = HotUpdaterNative as Partial<typeof HotUpdaterNative>;
  if (typeof native.resetChannelIfSelectionCurrent !== "function") {
    // Earlier native: the check and the reset are two steps.
    return isReleaseSelectionCurrent(guard) && (await resetChannel());
  }
  const ok = await native.resetChannelIfSelectionCurrent(guard);
  if (ok) {
    sessionState.resetChannelState();
  }
  return ok;
};

/**
 * Sets the persisted cohort used for update checks.
 *
 * HotUpdater only derives a device-based cohort when nothing has been stored
 * yet. If you need to restore that initial value later, read it with
 * `getCohort()` before calling `setCohort()`, then store it yourself.
 */
export const setCohort = (cohort: string): void => {
  const normalized = normalizeAndValidateCohort(cohort);
  HotUpdaterNative.setCohort(normalized);
  sessionState.cacheCohort(normalized);
};

/**
 * Gets the persisted cohort used for rollout calculations.
 * If none has been stored yet, native derives the initial value once and
 * persists it before returning.
 */
export const getCohort = (): string => {
  const cachedCohort = sessionState.getCachedCohort();
  if (cachedCohort !== undefined) {
    return cachedCohort;
  }

  const cohort = normalizeAndValidateCohort(HotUpdaterNative.getCohort());
  sessionState.cacheCohort(cohort);
  return cohort;
};
