package com.hotupdater

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

/**
 * An I/O failure writing to local storage, as opposed to a failure reading or
 * decoding the data being written.
 */
class LocalStorageException(
    cause: IOException,
) : IOException(cause.message, cause)

/**
 * An output stream to a local file whose I/O failures, including opening the
 * file, surface as [LocalStorageException].
 */
internal class LocalStorageOutputStream private constructor(
    private val output: OutputStream,
) : OutputStream() {
    companion object {
        fun open(file: File): LocalStorageOutputStream = LocalStorageOutputStream(storageOperation { FileOutputStream(file) })
    }

    override fun write(byte: Int) = storageOperation { output.write(byte) }

    override fun write(
        buffer: ByteArray,
        offset: Int,
        length: Int,
    ) = storageOperation { output.write(buffer, offset, length) }

    override fun flush() = storageOperation { output.flush() }

    override fun close() = storageOperation { output.close() }
}

/** Runs a local file operation, reporting its I/O failure as [LocalStorageException]. */
internal inline fun <T> storageOperation(block: () -> T): T =
    try {
        block()
    } catch (error: LocalStorageException) {
        throw error
    } catch (error: IOException) {
        throw LocalStorageException(error)
    }

/**
 * Interface for file system operations
 */
interface FileSystemService {
    /**
     * Checks if a file exists at the given path
     */
    fun fileExists(path: String): Boolean

    /**
     * Creates directory at the given path, including any necessary parent directories
     */
    fun createDirectory(path: String): Boolean

    /**
     * Removes a file or directory at the given path
     */
    fun removeItem(path: String): Boolean

    /**
     * Moves a file or directory from source path to destination path
     */
    fun moveItem(
        sourcePath: String,
        destinationPath: String,
    ): Boolean

    /**
     * Copies a file or directory from source path to destination path
     */
    fun copyItem(
        sourcePath: String,
        destinationPath: String,
    ): Boolean

    /**
     * Lists the contents of a directory
     */
    fun contentsOfDirectory(path: String): List<String>

    /**
     * Gets the internal files directory for the application
     */
    fun getInternalFilesDir(): File?
}

/**
 * Implementation of FileSystemService using standard File API
 */
class FileManagerService(
    private val context: Context,
    // A named instance's root beside the app's files; null is the app's files directory.
    private val internalFilesDir: File? = null,
) : FileSystemService {
    override fun fileExists(path: String): Boolean = File(path).exists()

    override fun createDirectory(path: String): Boolean = File(path).mkdirs()

    override fun removeItem(path: String): Boolean = File(path).deleteRecursively()

    override fun moveItem(
        sourcePath: String,
        destinationPath: String,
    ): Boolean {
        val source = File(sourcePath)
        val destination = File(destinationPath)

        return try {
            if (destination.exists()) {
                destination.deleteRecursively()
            }
            source.renameTo(destination)
        } catch (e: Exception) {
            false
        }
    }

    override fun copyItem(
        sourcePath: String,
        destinationPath: String,
    ): Boolean {
        val source = File(sourcePath)
        val destination = File(destinationPath)

        return try {
            if (destination.exists()) {
                destination.deleteRecursively()
            }
            source.copyRecursively(target = destination, overwrite = true)
        } catch (e: Exception) {
            false
        }
    }

    override fun contentsOfDirectory(path: String): List<String> {
        val directory = File(path)
        return directory.listFiles()?.map { it.name } ?: listOf()
    }

    override fun getInternalFilesDir(): File? = internalFilesDir ?: context.filesDir
}
