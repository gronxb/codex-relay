#if HOT_UPDATER_SANDBOX_LAYER
import UIKit

/// What this process runs while a session lasts, a dev server's JavaScript or a
/// stored bundle, read by `HotUpdaterSandboxDevOverride.m`. It lives and dies
/// with the process: nothing can arm a later launch, and a crash re-arms nothing.
@objc(HotUpdaterSandboxDevState)
public final class HotUpdaterSandboxDevState: NSObject {
    private static let lock = NSLock()
    private static var bundleURL: URL?
    private static var stored: HotUpdaterSandboxStoredBundle?
    private static var storage: [String: String] = [:]
    private static var isInstalled = false

    @objc public static func overrideInstalled() {
        lock.lock()
        isInstalled = true
        lock.unlock()
    }

    @objc(bundleURLForImpl:)
    public static func bundleURL(forImpl impl: AnyObject) -> URL? {
        lock.lock()
        let url = bundleURL
        lock.unlock()
        // Named instances keep their own bundle and their own launch.
        return url != nil && impl === HotUpdaterNativeUpdateBridge.sharedImpl ? url : nil
    }

    /// A stored session's bundle, nil for a dev session.
    @objc public static var storedBundleId: String? {
        lock.lock()
        defer { lock.unlock() }
        return stored?.bundleId
    }

    @objc public static var storedBaseURL: String? {
        lock.lock()
        defer { lock.unlock() }
        return stored?.baseURL
    }

    @objc public static var storedManifest: NSDictionary? {
        lock.lock()
        defer { lock.unlock() }
        return stored?.manifest
    }

    /// A stored session's active state, which names its release; nil otherwise,
    /// and for a row that never knew it.
    @objc(storedActiveStateWithChannel:)
    public static func storedActiveState(channel: String) -> NSDictionary? {
        lock.lock()
        defer { lock.unlock() }
        guard let stored, let releaseId = stored.releaseId else { return nil }
        return hotUpdaterSandboxStoredActiveState(releaseId: releaseId, bundleId: stored.bundleId, channel: channel) as NSDictionary
    }

    @objc public static func storageItem(_ key: String) -> String? {
        lock.lock()
        defer { lock.unlock() }
        return storage[key]
    }

    @objc public static func setStorageItem(_ key: String, value: String?) {
        lock.lock()
        storage[key] = value
        lock.unlock()
    }

    static var canRun: Bool {
        lock.lock()
        defer { lock.unlock() }
        return isInstalled
    }

    static var running: URL? {
        lock.lock()
        defer { lock.unlock() }
        return bundleURL
    }

    static func set(_ url: URL?, stored bundle: HotUpdaterSandboxStoredBundle? = nil) {
        lock.lock()
        bundleURL = url
        stored = bundle
        if url == nil { storage = [:] }
        lock.unlock()
    }
}

/// A process that ran a session and died leaves this behind, and any crash marker
/// it wrote is the session's, never the selected bundle's: the next process drops
/// it before anything settles it.
enum HotUpdaterSandboxDevLeftover {
    private static var note: URL? {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first?
            .appendingPathComponent("HotUpdater", isDirectory: true)
            .appendingPathComponent("sandbox-dev-running")
    }

    static func mark() {
        guard let note else { return }
        try? FileManager.default.createDirectory(at: note.deletingLastPathComponent(), withIntermediateDirectories: true)
        FileManager.default.createFile(atPath: note.path, contents: Data())
    }

    static func clear() {
        guard let note else { return }
        try? FileManager.default.removeItem(at: note)
    }

    static func dropCrashOfLastProcess() {
        guard let note, FileManager.default.fileExists(atPath: note.path) else { return }
        let marker = HotUpdaterCrashMarker.url(for: .main, documentsPath: FileManagerService().documentsPath())
        if (try? FileManager.default.removeItem(at: marker)) != nil {
            NSLog("[HotUpdaterSandbox] dropped a crash marker of the last dev process")
        }
        clear()
    }
}

/// What a person reads when a dev server can't run.
private struct DevServerFailure: Error {
    let message: String
}

/// The one owner of connecting and reloading on iOS, where a reload is in place:
/// connections run one at a time, and a launch of the normal selection that was
/// already prepared stops being watched, so the dev JavaScript's first content
/// can't verify it and its crash can't charge it.
@MainActor
final class HotUpdaterSandboxLiveDevServer: HotUpdaterSandboxDevServer {
    private static let recentHostsKey = "devServerRecentHosts"
    private static let maxRecentHosts = 5
    private static let probeSeconds: TimeInterval = 1
    private static let fetchSeconds: TimeInterval = 120

    private let start: (_ launchWasPrepared: Bool) -> Void
    private let reload: () -> Void
    private let defaults = UserDefaults(suiteName: "hot-updater-sandbox") ?? .standard
    private var answered: [String: Bool] = [:]
    private lazy var connector = HotUpdaterSandboxDevConnector(
        resolve: { host in
            switch await Self.resolveBundle(host: host) {
            case .success(let bundle): return .bundle(bundle)
            case .failure(let failure): return .failure(failure.message)
            }
        },
        commit: { [weak self] host, bundle in self?.startSession(host: host, bundle: bundle) }
    )

    /// What the last reload couldn't do. A failed connect says so to its completion.
    var lastDevServerError: String? { connector.lastError }

    var onDevServerChange: (() -> Void)? {
        didSet {
            connector.onChange = onDevServerChange
            if onDevServerChange != nil { probe() }
        }
    }

    /// `start` runs the session's JavaScript, `reload` restarts React Native in place.
    init(start: @escaping (_ launchWasPrepared: Bool) -> Void, reload: @escaping () -> Void) {
        self.start = start
        self.reload = reload
    }

    var isRunningDevServer: Bool { HotUpdaterSandboxDevState.running != nil && HotUpdaterSandboxDevState.storedBundleId == nil }

    private var runningHostURL: String? {
        guard isRunningDevServer else { return nil }
        return HotUpdaterSandboxDevState.running.flatMap { url in
            url.scheme.flatMap { scheme in url.host.map { "\(scheme)://\($0):\(url.port ?? 8081)" } }
        }
    }

    var runningDevServerHost: String? { runningHostURL.map(HotUpdaterSandboxDevHost.display) }

    private var hostURLs: [String] {
        #if targetEnvironment(simulator)
        let isSimulator = true
        #else
        let isSimulator = false
        #endif
        return HotUpdaterSandboxDevHost.listed(
            isSimulator: isSimulator,
            recent: defaults.stringArray(forKey: Self.recentHostsKey) ?? []
        )
    }

    var devServerHosts: [HotUpdaterSandboxDevServerHost] {
        hostURLs.map { HotUpdaterSandboxDevServerHost(address: HotUpdaterSandboxDevHost.display($0), isRunning: answered[$0]) }
    }

    private func remember(_ host: String) {
        let recent = [host] + (defaults.stringArray(forKey: Self.recentHostsKey) ?? []).filter { $0 != host }
        defaults.set(Array(recent.prefix(Self.maxRecentHosts)), forKey: Self.recentHostsKey)
    }

    /// One `GET /status` per listed host, with a second to answer.
    private func probe() {
        let urls = hostURLs
        Task { @MainActor in
            await withTaskGroup(of: (String, Bool).self) { group in
                for url in urls {
                    group.addTask { (url, await Self.answers(url)) }
                }
                for await (url, isRunning) in group {
                    answered[url] = isRunning
                }
            }
            onDevServerChange?()
        }
    }

    private nonisolated static func answers(_ host: String) async -> Bool {
        guard let url = URL(string: "\(host)/status") else { return false }
        var request = URLRequest(url: url)
        request.timeoutInterval = probeSeconds
        return await withCheckedContinuation { continuation in
            URLSession.shared.dataTask(with: request) { data, response, _ in
                let body = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                let ok = (response as? HTTPURLResponse)?.statusCode == 200 && body.contains("packager-status:running")
                continuation.resume(returning: ok)
            }.resume()
        }
    }

    /// What a fetch of the JavaScript came to.
    private enum Fetched {
        case found
        case notFound
        case failed(String)
    }

    /// Whether the JavaScript can be read: a release build dies if React Native can't load it.
    private nonisolated static func fetch(_ bundle: URL, host: String) async -> Fetched {
        var request = URLRequest(url: bundle)
        request.timeoutInterval = fetchSeconds
        return await withCheckedContinuation { continuation in
            URLSession.shared.downloadTask(with: request) { file, response, error in
                if let file { try? FileManager.default.removeItem(at: file) }
                let name = HotUpdaterSandboxDevHost.display(host)
                if let error = error as? URLError, error.code == .appTransportSecurityRequiresSecureConnection {
                    continuation.resume(returning: .failed("App Transport Security blocks http to \(name). Use a local address, or serve the dev server over https."))
                } else if let error {
                    continuation.resume(returning: .failed("Couldn't load JavaScript from \(name). \(error.localizedDescription) Check that the dev server runs and this device can reach it."))
                } else if let status = (response as? HTTPURLResponse)?.statusCode, status == 404 {
                    continuation.resume(returning: .notFound)
                } else if let status = (response as? HTTPURLResponse)?.statusCode, status != 200 {
                    continuation.resume(returning: .failed("\(name) answered \(status) for its JavaScript. Check the dev server's output."))
                } else {
                    continuation.resume(returning: .found)
                }
            }.resume()
        }
    }

    /// What an Expo server's manifest names; any other server answers with no manifest.
    private nonisolated static func manifestEntry(host: String) async -> HotUpdaterSandboxDevEntry? {
        guard let url = URL(string: host) else { return nil }
        var request = URLRequest(url: url)
        request.timeoutInterval = fetchSeconds
        request.setValue("ios", forHTTPHeaderField: "expo-platform")
        request.setValue("application/expo+json,application/json", forHTTPHeaderField: "accept")
        return await withCheckedContinuation { continuation in
            URLSession.shared.dataTask(with: request) { data, _, _ in
                continuation.resume(returning: data.flatMap(HotUpdaterSandboxDevHost.entry(ofManifest:)))
            }.resume()
        }
    }

    /// The JavaScript's URL at this host, or what's wrong.
    private nonisolated static func resolveBundle(host: String) async -> Result<URL, DevServerFailure> {
        let name = HotUpdaterSandboxDevHost.display(host)
        let entry = await manifestEntry(host: host) ?? HotUpdaterSandboxDevEntry()
        guard let bundle = HotUpdaterSandboxDevHost.bundleURL(host: host, entry: entry) else {
            return .failure(DevServerFailure(message: "\(name) has no JavaScript to load. Check the dev server's output."))
        }
        switch await fetch(bundle, host: host) {
        case .found:
            return .success(bundle)
        case .failed(let message):
            return .failure(DevServerFailure(message: message))
        case .notFound:
            return .failure(DevServerFailure(message: "\(name) has no /\(entry.path).bundle. Check the dev server's output."))
        }
    }

    func connect(host: String, completion: @escaping (String?) -> Void) {
        guard HotUpdaterSandboxDevState.canRun else {
            completion("This build of the SDK can't run a dev server. Rebuild the sandbox with this CLI's version of @hot-updater/react-native.")
            return
        }
        guard let url = HotUpdaterSandboxDevHost.normalize(host) else {
            completion("\"\(host)\" isn't a dev server address. Enter one like 192.168.0.2:8081.")
            return
        }
        connector.connect(url, completion: completion)
    }

    private func startSession(host: String, bundle: URL) {
        remember(host)
        begin(bundle, stored: nil)
        NSLog("[HotUpdaterSandbox] dev session on %@", host)
        onDevServerChange?()
    }

    /// A stored bundle runs as a dev server's JavaScript does: for this process,
    /// and its crash is the session's. Another row swaps it in place.
    func startStored(_ bundle: HotUpdaterSandboxStoredBundle) {
        connector.ended()
        begin(bundle.bundleURL, stored: bundle)
        NSLog("[HotUpdaterSandbox] stored session of %@", bundle.bundleId)
        onDevServerChange?()
    }

    private func begin(_ url: URL, stored: HotUpdaterSandboxStoredBundle?) {
        let wasPrepared = retireNormalLaunch()
        HotUpdaterSandboxDevLeftover.mark()
        HotUpdaterSandboxDevState.set(url, stored: stored)
        start(wasPrepared)
    }

    /// The launch of the normal selection stops being watched and counted as
    /// started. Returns whether one was prepared, so its URL may be held already.
    private func retireNormalLaunch() -> Bool {
        let coordinator = HotUpdaterRecoveryHub.shared.coordinator
        let main = HotUpdaterInstanceEnvironment.mainName
        guard let launch = coordinator.launch(named: main), launch.generation > 0 else { return false }
        _ = launch.storage.clearLaunchStarted(bundleId: launch.bundleId)
        coordinator.finishMonitoring(name: main, generation: launch.generation)
        HotUpdaterNativeUpdateBridge.sharedImpl.resetLaunchPreparation()
        return true
    }

    /// Fetches the running host's JavaScript again. The session goes on if it can't.
    func reloadDevServer() {
        guard let host = runningHostURL else { return }
        connector.reload(host)
    }

    /// Only here does a session end, other than with its process.
    func exitDevServer() {
        guard HotUpdaterSandboxDevState.running != nil else { return }
        connector.ended()
        HotUpdaterSandboxDevState.set(nil)
        HotUpdaterSandboxDevLeftover.clear()
        NSLog("[HotUpdaterSandbox] dev session ended")
        reload()
        onDevServerChange?()
    }
}
#endif
